

#ifndef ResourceRecordTest_h
#define ResourceRecordTest_h

#include "unittest.h"

int ResourceRecordTest(void);

#endif /* ResourceRecordTest_h */
