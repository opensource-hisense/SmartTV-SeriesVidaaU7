# DNSSD command-line tool

The DNSSD command line tool (dns-sd) can be used to explore the local DNS-SD environment. Information on how to use the command can be obtained by typing "dns-sd -h" for a brief list of common options, or "dns-sd -H" for a full set of options.
