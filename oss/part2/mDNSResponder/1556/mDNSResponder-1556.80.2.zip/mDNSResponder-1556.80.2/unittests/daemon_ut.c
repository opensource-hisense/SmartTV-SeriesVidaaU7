#include "DNSCommon.h"
#include "unittest_common.h"

mDNSexport void init_logging_ut(void)
{
}
