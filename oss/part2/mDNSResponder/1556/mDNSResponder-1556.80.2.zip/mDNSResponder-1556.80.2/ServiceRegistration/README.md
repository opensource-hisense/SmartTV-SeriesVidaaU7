# DNSSD Extensions for Service Registration, Advertising Proxy, Discovery Proxy and Discovery Relay

This subdirectory includes the implementations for various DNSSD extensions. These share a common code base that is largely separate from mDNSResponder.

[Coding conventions used in this subdirectory](../Documents/ServiceRegistrationConventions.md)
