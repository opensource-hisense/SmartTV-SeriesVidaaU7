/*------------------------------------------------------------------------------
 * MediaTek Inc. (C) 2018. All rights reserved.
 *
 * Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 *----------------------------------------------------------------------------*/

#ifndef _MI_DRM_H_
#define _MI_DRM_H_

#ifdef __cplusplus
extern "C" {
#endif

//-------------------------------------------------------------------------------------------------
//  Defines - Constant
//-------------------------------------------------------------------------------------------------
#define MI_DRM_PLAYREADY_LICENSE_STATE_DATA_NUM_COUNTS_MAX (4)
#define MI_DRM_PLAYREADY_LICENSE_STATE_DATA_NUM_DATES_MAX  (4)


//-------------------------------------------------------------------------------------------------
//  Types - Enums
//-------------------------------------------------------------------------------------------------
typedef enum
{
    E_MI_DRM_TYPE_PLAYREADY = 0,
    E_MI_DRM_TYPE_WIDEVINE_CENC,
    E_MI_DRM_TYPE_MAX,
} MI_DRM_Type_e;

typedef enum
{
    E_MI_DRM_ATTR_TYPE_DRM_MIN = 0x000,
    E_MI_DRM_ATTR_TYPE_DRM_INFO = E_MI_DRM_ATTR_TYPE_DRM_MIN,
    // < [get] Get DRM info.
    // < [in] None.
    // < [out] Parameter type is a pointer to MI_DRM_Type_e.
    E_MI_DRM_ATTR_TYPE_DRM_MAX,
    E_MI_DRM_ATTR_TYPE_PLAYREADY_MIN = 0x100,
    E_MI_DRM_ATTR_TYPE_PLAYREADY_ERROR_CODE = E_MI_DRM_ATTR_TYPE_PLAYREADY_MIN,
    // < [get] Get Error code returned by PlayReady API.
    // < [in] None.
    // < [out] Parameter type is a pointer to MI_U32.
    E_MI_DRM_ATTR_TYPE_PLAYREADY_OUTPUT_PROTECT_LEVELS,
    // < [get] Get output protect levels.
    // < [in] Parameter type is pointer to MI_U32.
    // < [out] Parameter type is a pointer to MI_DRM_PlayReadyOutputProtectLevels_t.
    E_MI_DRM_ATTR_TYPE_PLAYREADY_ADDITIONAL_RESPONSE_DATA,
    // < [get] Get a piece of data string from server response.
    // < [in] Parameter type is a pointer to MI_DRM_PlayReadyAdditionalResponseDataType_t.
    // < [out] Parameter type is a pointer to MI_DRM_PlayReadyAdditionalResponseData_t.
    E_MI_DRM_ATTR_TYPE_PLAYREADY_IS_KEY_ACQUIRED,
    // < [get] Get content key status.
    // < [in] Parameter type is pointer to MI_U32.
    // < [out] Parameter type is a pointer to MI_DRM_PlayReadyLicenseState_e.
    E_MI_DRM_ATTR_TYPE_PLAYREADY_CSP_CUSTOM_DATA,
    // < [set] Set CSP custom data.
    // < Parameter type is a pointer to MI_DRM_PlayReadyCspCustomData_t.
    E_MI_DRM_ATTR_TYPE_PLAYREADY_QUERY_LICENSE,
    // < [get] Get license rights information.
    // < [in] Parameter type is a pointer to MI_DRM_PlayReadyQueryLicense_t.
    // < [out] Parameter type is an array of MI_DRM_PlayReadyLicenseStateData_t.
    E_MI_DRM_ATTR_TYPE_PLAYREADY_MAX,
} MI_DRM_AttrType_e;

typedef enum
{
    E_MI_DRM_PLAYREADY_GARD_DATA_TYPE_CUSTOM_DATA  = 1, /// < Custom data.
    E_MI_DRM_PLAYREADY_GARD_DATA_TYPE_REDIRECT_URL,     /// < Redirect URL.
    E_MI_DRM_PLAYREADY_GARD_DATA_TYPE_SERVICE_ID,       /// < Service identifier.
    E_MI_DRM_PLAYREADY_GARD_DATA_TYPE_ACCOUNT_ID,       /// < Account identifier.
    E_MI_DRM_PLAYREADY_GARD_DATA_TYPE_MAX,
} MI_DRM_PlayReadyGardDataType_e;

typedef enum
{
    E_MI_DRM_PLAYREADY_LICENSE_STATE_NOT_FOUND = 0, /// < License not found.
    E_MI_DRM_PLAYREADY_LICENSE_STATE_FOUND,         /// < License found.
    E_MI_DRM_PLAYREADY_LICENSE_STATE_EXPIRED,       /// < License expired.
    E_MI_DRM_PLAYREADY_LICENSE_STATE_INVALID,       /// < License invalid.
    E_MI_DRM_PLAYREADY_LICENSE_STATE_MAX,
} MI_DRM_PlayReadyLicenseState_e;

typedef enum
{
    E_MI_DRM_CRYPTO_SCHEME_CLEAR = 0,
    E_MI_DRM_CRYPTO_SCHEME_AES_CTR,
    E_MI_DRM_CRYPTO_SCHEME_AES_CBC,
    E_MI_DRM_CRYPTO_SCHEME_MAX,
} MI_DRM_CryptoScheme_e;

typedef enum
{
    E_MI_DRM_PLAYREADY_LICENSE_STATE_CATEGORY_NORIGHT = 0,               /// < Indicates the string will take the form "Playback not permitted."
    E_MI_DRM_PLAYREADY_LICENSE_STATE_CATEGORY_UNLIM,                     /// < Indicates the string will take the form "Playback unlimited."
    E_MI_DRM_PLAYREADY_LICENSE_STATE_CATEGORY_COUNT,                     /// < Indicates the string will take the form "Playback valid 5 times."
    E_MI_DRM_PLAYREADY_LICENSE_STATE_CATEGORY_FROM,                      /// < Indicates the string will take the form "Playback valid from 5/12/2004"
    E_MI_DRM_PLAYREADY_LICENSE_STATE_CATEGORY_UNTIL,                     /// < Indicates the string will take the form "Playback valid until 7/12/2008"
    E_MI_DRM_PLAYREADY_LICENSE_STATE_CATEGORY_FROM_UNTIL,                /// < Indicates the string will take the form "Playback valid from 5/12/2004 to 9/12/2008."
    E_MI_DRM_PLAYREADY_LICENSE_STATE_CATEGORY_COUNT_FROM,                /// < Indicates the string will take the form "Playback valid 5 times from 5/12/2004."
    E_MI_DRM_PLAYREADY_LICENSE_STATE_CATEGORY_COUNT_UNTIL,               /// < Indicates the string will take the form "Playback valid 5 times until 7/12/2008."
    E_MI_DRM_PLAYREADY_LICENSE_STATE_CATEGORY_COUNT_FROM_UNTIL,          /// < Indicates the string will take the form "Playback valid 5 times from 5/12/2004 to 9/12/2008."
    E_MI_DRM_PLAYREADY_LICENSE_STATE_CATEGORY_EXPIRATION_AFTER_FIRSTUSE, /// < Indicates the string will take the form "Playback valid for 24 hours from first use."
    E_MI_DRM_PLAYREADY_LICENSE_STATE_CATEGORY_FORCE_SYNC,                /// < No string. For license sync functionality.
    E_MI_DRM_PLAYREADY_LICENSE_STATE_CATEGORY_NOT_FOUND,                 /// < No string. For license sync functionality.
    E_MI_DRM_PLAYREADY_LICENSE_STATE_CATEGORY_ENTRY_MARKED_FOR_DELETION, /// < No string. For license sync functionality.
    E_MI_DRM_PLAYREADY_LICENSE_STATE_CATEGORY_MAX,
} MI_DRM_PlayReadyLicenseStateCategory_e;

//-------------------------------------------------------------------------------------------------
//  Types - Structures
//-------------------------------------------------------------------------------------------------
typedef struct MI_DRM_InitParams_s
{
    MI_U8 u8Reserved;    /// < Reserve for the future.
} MI_DRM_InitParams_t;

typedef struct MI_DRM_OpenParams_s
{
    MI_DRM_Type_e eDrmType; /// < DRM type.
} MI_DRM_OpenParams_t;

typedef struct MI_DRM_StartParams_s
{
    MI_U8 u8Reserved;    /// < Reserve for the future.
} MI_DRM_StartParams_t;

typedef struct MI_DRM_PlayReadyCspCustomData_s
{
    MI_U8 *pu8CustomData;    /// < [in] String of PlayReady custom data to be sent to the server.
    MI_U32 u32CustomDataLen; /// < [in] Length of custom data, including the terminating null character.
} MI_DRM_PlayReadyCspCustomData_t;

typedef struct MI_DRM_PlayReadyOutputProtectLevels_s
{
    MI_S32 s32CompressedDigitalVideo;   /// < [out] Output protect level for compressed digital video.
    MI_S32 s32UncompressedDigitalVideo; /// < [out] Output protect level for uncompressed digital video.
    MI_S32 s32AnalogVideo;              /// < [out] Output protect level for analog video.
    MI_S32 s32CompressedDigitalAudio;   /// < [out] Output protect level for compressed digital audio.
    MI_S32 s32UncompressedDigitalAudio; /// < [out] Output protect level for uncompressed digital audio.
} MI_DRM_PlayReadyOutputProtectLevels_t;

typedef struct MI_DRM_PlayReadyAdditionalResponseDataType_s
{
    MI_U32 u32HandleIndex;                    /// < [in] Index of PlayReady handle.
    MI_DRM_PlayReadyGardDataType_e eDataType; /// < [in] Data type of pu8DataString.
    MI_U32 u32DataStringLen;                  /// < [in] Length of data or buffer.
} MI_DRM_PlayReadyAdditionalResponseDataType_t;

typedef struct MI_DRM_PlayReadyAdditionalResponseData_s
{
    MI_U8 *pu8DataString;                     /// < [out] Pointer to a buffer for received data.
    MI_U32 u32DataStringLen;                  /// < [out] Length of data or buffer.
} MI_DRM_PlayReadyAdditionalResponseData_t;

typedef struct MI_DRM_WidevineCencClientInfo_s
{
    MI_U8 *pszProductName;     /// < [in] The name of the product or application, e.g. "YouTube"
    MI_U8 *pszCompanyName;     /// < [in] The name of the company who makes the device. Make sure the pszCompanyName is the same with "Company Name" in wv_keyboxrequest form.
    MI_U8 *pszDeviceName;      /// < [in] The name of the device.
    MI_U8 *pszModelName;       /// < [in] The device model name. Make sure the pszModelName is the same with "Device Model Number" in wv_keyboxrequest form.
    MI_U8 *pszArchName;        /// < [in] The architecture of the device, e.g. "arm-32"
    MI_U8 *pszBuildInfo;       /// < [in] The name of information about the build of the browser, application, or platform.
} MI_DRM_WidevineCencClientInfo_t;

typedef struct MI_DRM_WidevineCencLicenseMetadata_s
{
    MI_DRM_WidevineCencClientInfo_t stClientInfo;
    MI_U8 *pszServiceCertificate;
} MI_DRM_WidevineCencLicenseMetadata_t;

typedef struct MI_DRM_PlayReadyLicenseMetadata_s
{
    MI_U32 u32HandleIndex; /// < [in] Index of PlayReady handle.
} MI_DRM_PlayReadyLicenseMetadata_t;

typedef struct MI_DRM_LicenseMetadata_s
{
    union
    {
        MI_DRM_WidevineCencLicenseMetadata_t stWvCenc;
        MI_DRM_PlayReadyLicenseMetadata_t stPlayReady;
    };
} MI_DRM_LicenseMetadata_t;

typedef struct MI_DRM_RequestLicenseParams_s
{
    MI_U8 *pu8DrmData;                          /// < [in] Pointer to buffer of DRM header.
    MI_U32 u32DrmDataSize;                      /// < [in] Size of DRM header.
    MI_DRM_LicenseMetadata_t stLicenseMetadata; /// < [in] License metadata.
    MI_BOOL bSecurePath;                        /// < [in] Enable secure path.
    const MI_U8 *pszLicenseServerUrl;           /// < [in] Specify license server url.
} MI_DRM_RequestLicenseParams_t;

typedef struct MI_DRM_SubsampleEntry_s
{
    MI_U32 u32ClearBytes;   /// < Number of clear bytes.
    MI_U32 u32CipherBytes;  /// < Number of cipher bytes.
} MI_DRM_SubsampleEntry_t;

typedef struct MI_DRM_WidevineCencDecryptMetadata_s
{
    MI_U8 *pu8KeyId;
    MI_U32 u32KeyIdSize;
} MI_DRM_WidevineCencDecryptMetadata_t;

typedef struct MI_DRM_PlayReadyDecryptMetadata_s
{
    MI_U32 u32HandleIndex;      /// < [in] Index of PlayReady handle.
    MI_U64 u64BlockOffset;      /// < [in] Block offset.
    MI_U8 u8ByteOffset;         /// < [in] Byte offset.
} MI_DRM_PlayReadyDecryptMetadata_t;

typedef struct MI_DRM_DecryptMetadata_s
{
    union
    {
        MI_DRM_WidevineCencDecryptMetadata_t stWvCenc;
        MI_DRM_PlayReadyDecryptMetadata_t stPlayReady;
    };
} MI_DRM_DecryptMetadata_t;

typedef struct MI_DRM_DecryptParams_s
{
    const MI_U8 *pu8EncryptedData;              /// < [in] Buffer of encrypted data.
    MI_U8 *pu8DecryptedData;                    /// < [in] Buffer of decrypted data.
    MI_U32 u32DataSize;                         /// < [in] Data size.
    MI_U8 *pu8Iv;                               /// < [in] IV.
    MI_U32 u32IvLen;                            /// < [in] IV length.
    MI_DRM_SubsampleEntry_t *pstSubsamples;     /// < [in] Subsamples.
    MI_U32 u32SubsamplesNum;                    /// < [in] Number of subsamples.
    MI_DRM_CryptoScheme_e eCryptoSchemeType;    /// < [in] Crypto scheme type.
    MI_BOOL bIsVideo;                           /// < [in] Determine whether it is video or not.
    void *pSecureHandle;                        /// < [in] Opaque pointer for SVP secure handle.
    MI_U32 u32SecureHandleLength;               /// < [in] Secure handle length.
    MI_DRM_DecryptMetadata_t stDecryptMetadata; /// < [in] Decrypt metadata.
} MI_DRM_DecryptParams_t;

typedef struct MI_DRM_PlayReadyLicenseFileTime_s
{
    MI_U32 u32LowDateTime;   /// < Low 32 bits of the file time.
    MI_U32 u32HighDateTime;  /// < High 32 bits of the file time.
} MI_DRM_PlayReadyLicenseFileTime_t;

typedef struct MI_DRM_PlayReadyLicenseStateData_s
{
    MI_U32 u32StreamId;                                                                               /// < Stream number to which the license applies.
    MI_DRM_PlayReadyLicenseStateCategory_e eCategory;                                                 /// < Category of string to be displayed.
    MI_U32 u32NumCounts;                                                                              /// < Number of items in au32Count.
    MI_U32 au32Count[MI_DRM_PLAYREADY_LICENSE_STATE_DATA_NUM_COUNTS_MAX];                             /// < Number of times the action specified in eCategory can be performed.
    MI_U32 u32NumDates;                                                                               /// < Number of items in astDateTime.
    MI_DRM_PlayReadyLicenseFileTime_t astDateTime[MI_DRM_PLAYREADY_LICENSE_STATE_DATA_NUM_DATES_MAX]; /// < Array of MI_DRM_PlayReadyLicenseFileTime_t. Represent dates in the license.
    MI_U32 u32Vague;                                                                                  /// < Certainty of the information.
} MI_DRM_PlayReadyLicenseStateData_t;

typedef struct MI_DRM_PlayReadyQueryLicense_s
{
    MI_U32 u32HandleIndex;              /// < [in] Index of PlayReady handle.
    const MI_U8 * const *ppszRights;    /// < [in] Array of string. Array of actions for which license data to be queried.
    MI_U32 u32RightsQueried;            /// < [in] Size of ppszRights and MI_DRM_PlayReadyLicenseStateData_t array.
} MI_DRM_PlayReadyQueryLicense_t;

//-------------------------------------------------------------------------------------------------
//  Functions
//-------------------------------------------------------------------------------------------------

//------------------------------------------------------------------------------
/// @brief Init DRM module.
/// @param[in] pstInitParams: A pointer to structure MI_DRM_InitParams_t for initialization.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_DRM_Init(const MI_DRM_InitParams_t *pstInitParams);

//------------------------------------------------------------------------------
/// @brief Finalize DRM module.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_DRM_DeInit(void);

//------------------------------------------------------------------------------
/// @brief Open a DRM handle.
/// @param[in] pstOpenParams: A pointer to structure MI_DRM_OpenParams_t for opening DRM module.
/// @param[out] phDrm: A handle pointer to retrieve an instance of a created DRM module.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_PARAMETER: Parameters are invalid.
/// @return MI_ERR_RESOURCES: No available resource.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_DRM_Open(const MI_DRM_OpenParams_t *pstOpenParams, MI_HANDLE *phDrm);

//--------------------------------------------------- ---------------------------
/// @brief Close a DRM handle.
/// @param[in] hDrm: An instance of a created DRM module.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_DRM_Close(MI_HANDLE hDrm);

//------------------------------------------------------------------------------
/// @brief Start a DRM service.
/// @param[in] hDrm: An instance of a created DRM module.
/// @param[in] pstStartParams: A pointer to structure MI_DRM_StartParams_t for start DRM service.
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_DRM_Start(MI_HANDLE hDrm, const MI_DRM_StartParams_t *pstStartParams);

//------------------------------------------------------------------------------
/// @brief Stop a DRM service.
/// @param[in] hDrm: An instance of a created DRM module.
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_DRM_Stop(MI_HANDLE hDrm);

//------------------------------------------------------------------------------
/// @brief Set the attribute/information of a created DRM instance.
/// @param[in] hDrm: An instance of a created DRM module.
/// @param[in] eAttrType: The parameter type for setting attribute.
/// @param[in] pAttrParams: pointer to set attribute corresponding to the eAttrType. The prototype of pAttrParams please see the description of enum MI_DRM_AttrType_e.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_SUPPORT: eAttrType is not supported.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: parameters is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_DRM_SetAttr(MI_HANDLE hDrm, MI_DRM_AttrType_e eAttrType, const void *pAttrParams);

//------------------------------------------------------------------------------
/// @brief Get the attribute/ information of a created DRM instance.
/// @param[in] hDrm: An instance of a created DRM module.
/// @param[in] eAttrType: The parameter type for getting attribute.
/// @param[in] pInputParams: pointer to retrieve the attribute corresponding to the eAttrType. The prototype of pParam please see the description of enum MI_DRM_AttrType_e.
/// @param[out] pOutputParams: pointer to retrieve the attribute corresponding to the eAttrType. The prototype of pParam please see the description of enum MI_DRM_AttrType_e.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters are invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_DRM_GetAttr(MI_HANDLE hDrm, MI_DRM_AttrType_e eAttrType, const void *pInputParams, void *pOutputParams);

//------------------------------------------------------------------------------
/// @brief Set DRM debug level.
/// @param[in] u32DebugLevel: Debug level defined in enum type MI_DBG_LEVEL.
/// @return MI_OK: Set debug level success.
//------------------------------------------------------------------------------
MI_RESULT MI_DRM_SetDebugLevel(MI_DBG_LEVEL u32DebugLevel);

/// @brief DRM function for requesting license.
/// @param[in] hDrm: A handle of a created DRM instance.
/// @param[in] pstRequestLicenseParams: Parameters for requesting license.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_SUPPORT: DRM instance is invalid.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters are invalid.
/// @return MI_ERR_RESOURCES: No available resource.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_DRM_RequestLicense(MI_HANDLE hDrm, MI_DRM_RequestLicenseParams_t *pstRequestLicenseParams);

//------------------------------------------------------------------------------
/// @brief DRM function for decrypting content.
/// @param[in] hDrm: A Handle of a created DRM instance.
/// @param[in] pstDecryptParams: Parameters for decrypting content.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_NOT_SUPPORT: DRM instance is invalid.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters are invalid.
/// @return MI_ERR_MEMORY_ALLOCATE: Fail to allocate memory.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_DRM_Decrypt(MI_HANDLE hDrm, MI_DRM_DecryptParams_t *pstDecryptParams);

#ifdef __cplusplus
}
#endif

#endif///_MI_DRM_H_
