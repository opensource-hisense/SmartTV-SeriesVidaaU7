/*------------------------------------------------------------------------------
 * MediaTek Inc. (C) 2018. All rights reserved.
 *
 * Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 *----------------------------------------------------------------------------*/
//------------------------------------------------------------------------------
// Use GetAttr/SetAttr only
//------------------------------------------------------------------------------

#ifndef _MI_TSR_H_
#define _MI_TSR_H_

#ifdef __cplusplus
extern "C" {
#endif

#include "mi_dmx.h"

//-------------------------------------------------------------------------------------------------
//  Defines - Constant
//-------------------------------------------------------------------------------------------------
#define MI_TSR_PID_NULL                                    (0x1FFF)

//-------------------------------------------------------------------------------------------------
//  Defines - Macros
//-------------------------------------------------------------------------------------------------

//-------------------------------------------------------------------------------------------------
//  Types - Enums
//-------------------------------------------------------------------------------------------------
typedef enum
{
    E_MI_TSR_RUNNING_STATUS_STOP = 0,                                   ///< Recorder's status: stop
    E_MI_TSR_RUNNING_STATUS_RECORDING,                                  ///< Recorder's status: recording
    E_MI_TSR_RUNNING_STATUS_PAUSE,                                      ///< Recorder's status: pause
} MI_TSR_RunningStatus_e;

typedef enum
{
    E_MI_TSR_PACKET_MODE_188 = 188,                                     ///< Recorded packet is 188 bytes
    E_MI_TSR_PACKET_MODE_192 = 192,                                     ///< Recorded packet is 192 bytes including 4 bytes timestamp
    E_MI_TSR_PACKET_MODE_MAX,
} MI_TSR_PacketMode_e;

typedef enum
{
    // Get
    E_MI_TSR_ATTR_TYPE_GET_MIN = 0x0,
    E_MI_TSR_ATTR_TYPE_GET_BUF_INFO = E_MI_TSR_ATTR_TYPE_GET_MIN,       ///< [Get]: Get record buffer information: pointer to MI_TSR_BufInfo_t
    E_MI_TSR_ATTR_TYPE_GET_RUNNING_STATUS,                              ///< [Get]: Get record status: pointer to MI_TSR_RunningStatus_e
    E_MI_TSR_ATTR_TYPE_GET_WRITE_POINTER,                               ///< [Get]: Get record buffer write pointer: pointer to MI_PHY
    E_MI_TSR_ATTR_TYPE_GET_TIMESTAMP,                                   ///< [Get]: Get record timestamp: pointer to MI_U32
    E_MI_TSR_ATTR_TYPE_GET_FREE_PID_FILTER_NUMBER,                      ///< [Get]: Get record remain PID filter number: pointer to MI_U32
    E_MI_TSR_ATTR_TYPE_GET_SOURCE_TYPE,                                 ///< [Get]: Get record source type: pointer to MI_TSR_SrcType_e
    E_MI_TSR_ATTR_TYPE_GET_DMX_ID,                                      ///< [Get]: Get record driver dmx id: pInputParams is pointer to MI_U16(PID), pOutputParams is pointer to MI_U32(DMX ID)
    E_MI_TSR_ATTR_TYPE_GET_DMX_HANDLER,
    E_MI_TSR_ATTR_TYPE_GET_MAX,

    // Set
    E_MI_TSR_ATTR_TYPE_SET_MIN = 0x100,
    E_MI_TSR_ATTR_TYPE_SET_READ_POINTER = E_MI_TSR_ATTR_TYPE_SET_MIN,   ///< [Set]: Set record buffer read pointer: pointer to MI_PHY
    E_MI_TSR_ATTR_TYPE_SET_TIMESTAMP,                                   ///< [Set]: Set record timestamp: pointer to MI_U32
    E_MI_TSR_ATTR_TYPE_SET_MAX,

} MI_TSR_AttrType_e;

typedef enum
{
    E_MI_TSR_EVENT_DATA_READY = MI_BIT(0),                              ///< Info how many record data in buffer: parameter type is a pointer to MI_U32
    E_MI_TSR_EVENT_BUFFER_OVERFLOW = MI_BIT(1),                         ///< Buffer overflow notification: no parameter
    E_MI_TSR_EVENT_MAX,
} MI_TSR_CallbackEvent_e;

typedef enum
{
    E_MI_TSR_SRC_TYPE_TSIF_LIVE_MIN = 0,
    E_MI_TSR_SRC_TYPE_TSIF_LIVE0 = E_MI_TSR_SRC_TYPE_TSIF_LIVE_MIN,     ///< Record source is from TS interface of live streams number 0
    E_MI_TSR_SRC_TYPE_TSIF_LIVE1,                                       ///< Record source is from TS interface of live streams number 1
    E_MI_TSR_SRC_TYPE_TSIF_LIVE2,                                       ///< Record source is from TS interface of live streams number 2
    E_MI_TSR_SRC_TYPE_TSIF_LIVE3,                                       ///< Record source is from TS interface of live streams number 3
    E_MI_TSR_SRC_TYPE_TSIF_LIVE4,                                       ///< Record source is from TS interface of live streams number 4
    E_MI_TSR_SRC_TYPE_TSIF_LIVE5,                                       ///< Record source is from TS interface of live streams number 5
    E_MI_TSR_SRC_TYPE_TSIF_LIVE6,                                       ///< Record source is from TS interface of live streams number 6
    E_MI_TSR_SRC_TYPE_TSIF_LIVE_MAX,

    E_MI_TSR_SRC_TYPE_TSIF_FILE_MIN = 0x100,
    E_MI_TSR_SRC_TYPE_TSIF_FILE0 = E_MI_TSR_SRC_TYPE_TSIF_FILE_MIN,     ///< Record source is from TS interface of file input number 0
    E_MI_TSR_SRC_TYPE_TSIF_FILE1,                                       ///< Record source is from TS interface of file input number 1
    E_MI_TSR_SRC_TYPE_TSIF_FILE2,                                       ///< Record source is from TS interface of file input number 2
    E_MI_TSR_SRC_TYPE_TSIF_FILE3,                                       ///< Record source is from TS interface of file input number 3
    E_MI_TSR_SRC_TYPE_TSIF_FILE4,                                       ///< Record source is from TS interface of file input number 4
    E_MI_TSR_SRC_TYPE_TSIF_FILE5,                                       ///< Record source is from TS interface of file input number 5
    E_MI_TSR_SRC_TYPE_TSIF_FILE6,                                       ///< Record source is from TS interface of file input number 6
    E_MI_TSR_SRC_TYPE_TSIF_FILE_MAX,
} MI_TSR_SrcType_e;

//-------------------------------------------------------------------------------------------------
//  Types - Structures
//-------------------------------------------------------------------------------------------------
typedef struct MI_TSR_Caps_s
{
    MI_U32 u32MaxEngineNum;                             ///[OUT]: Max support recorders simultaneously
    MI_U32 u32MaxPidFiltNum;                            ///[OUT]: Max supported record PID filters
} MI_TSR_Caps_t;

typedef struct MI_TSR_InitParams_s
{
    MI_U8 u8Reserved;                                   ///[IN]:  Reserved
} MI_TSR_InitParams_t;

typedef MI_RESULT (* MI_TSR_EventCallback)(MI_HANDLE hTsr, MI_TSR_CallbackEvent_e eEvent, void *pEventParams, void *pUserParams);
typedef struct MI_TSR_CallbackParams_s
{
    MI_TSR_EventCallback pfEventCallback;               ///[IN]:  Callback function pointer to notify applicaiton event
    MI_U32 u32EventFlag;                                ///[IN]:  Event flags defined by MI_TSR_CallbackEvent_e
    MI_U32 u32ThresholdSize;                            ///[IN]:  Data ready notification threshold: by size, e.g. 0x40000 (byte)
    MI_U32 u32ThresholdPeriod;                          ///[IN]:  Data ready notification threshold: by time period, e.g. 50 (ms)
    void *pUserParams;                                  ///[IN]:  User parameter
} MI_TSR_CallbackParams_t;

typedef struct MI_TSR_OpenParams_s
{
    MI_U8 *pszName;                                     ///[IN]:  Custom defined module instance name which is a string with zero terminated.
    MI_DMX_PathParams_t stPathParams;                   ///[IN]:  Demux path for record
    MI_PHY phyRecBufAddr;                               ///[IN]:  Transport Stream Recorder buffer, should be physical address
    MI_U32 u32RecBufSize;                               ///[IN]:  Transport Stream Recorder buffer size
    MI_TSR_PacketMode_e ePacketMode;                    ///[IN]:  Transport Stream Recorder packet mode
    MI_TSR_CallbackParams_t stCallbackParams;           ///[IN]:  For callback mode, application should do polling data if pfEventCallback is NULL
    MI_BOOL bSecureMode;                                ///[IN]:  Enable secure control mode if TRUE
} MI_TSR_OpenParams_t;

typedef struct MI_TSR_StartParams_s
{
    MI_BOOL bRecordAll;                                 ///[IN]:  Record all
} MI_TSR_StartParams_t;

typedef struct MI_TSR_BufInfo_s
{
    MI_PHY phyStartAddr;                                ///[OUT]: Record buffer physical start address
    MI_U32 u32Size;                                     ///[OUT]: Record buffer size
} MI_TSR_BufInfo_t;

typedef struct MI_TSR_ReadParams_s
{
    MI_U8 *pu8ReadBuf;                                  ///[IN]:  Buffer allocated by applicaiton, should be virtual address
    MI_U32 u32BufSize;                                  ///[IN]:  Record buffer size
} MI_TSR_ReadParams_t;

typedef struct MI_TSR_ReadOutputParams_s
{
    MI_U32 u32ActualReadLength;                         ///[OUT]: Actual read data length
} MI_TSR_ReadOutputParams_t;

typedef struct MI_TSR_DumpInfoParams_s
{
    MI_BOOL bAll;                                       ///[IN]:  Dump all
} MI_TSR_DumpInfoParams_t;

typedef struct MI_TSR_QueryHandleParams_s
{
    MI_U8 *pszName;                                     ///[IN]:  tsr handle with string name.
}MI_TSR_QueryHandleParams_t;

//-------------------------------------------------------------------------------------------------
//  Functions
//-------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------
/// @brief Get TSR(Transport Stream Recorder) module capibilities.
/// @param[out] pstTsrCaps: A pointer to structure MI_TSR_Caps_t to retrieve the information of TSR capabilities
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_TSR_GetCaps(MI_TSR_Caps_t *pstCaps);

//------------------------------------------------------------------------------
/// @brief Init TSR module.
/// @param[in] pstInitParams: A pointer to structure MI_TSR_InitParams_t for initialization.
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_TSR_Init(const MI_TSR_InitParams_t *pstInitParams);

//------------------------------------------------------------------------------
/// @brief Finalize TSR module.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_TSR_DeInit(void);

//------------------------------------------------------------------------------
/// @brief Create a TSR handle.
/// @param[in] pstOpenParams: Pointer to MI_TSR_OpenParams_t for creating a TSR engine.
/// @param[out] phTsr: A handle pointer to retrieve an instance of a created TSR engine.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_RESOURCES: No available resource.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_TSR_Open(const MI_TSR_OpenParams_t *pstOpenParams, MI_HANDLE *phTsr);

//------------------------------------------------------------------------------
/// @brief Destroy a TSR handle.
/// @param[in] hTsr: An instance of a created TSR engine.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_TSR_Close(MI_HANDLE hTsr);

//------------------------------------------------------------------------------
/// @brief Add record PID for a TSR handle.
/// @param[in] hTsr: An instance of a created TSR engine.
/// @param[in] u16Pid: PID value to be added
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_TSR_AddPid(MI_HANDLE hTsr, MI_U16 u16Pid);

//------------------------------------------------------------------------------
/// @brief Remove record PID for a TSR handle.
/// @param[in] hTsr: An instance of a created TSR engine.
/// @param[out] pu16Pid: PID value to be removed
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_TSR_RemovePid(MI_HANDLE hTsr, MI_U16 u16Pid);

//------------------------------------------------------------------------------
/// @brief Pause record PID for a TSR handle.
/// @param[in] hTsr: An instance of a created TSR engine.
/// @param[in] pu16Pid: PID value to be paused
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_TSR_PausePid(MI_HANDLE hTsr, MI_U16 u16Pid);

//------------------------------------------------------------------------------
/// @brief Resume record PID for a TSR handle.
/// @param[in] hTsr: An instance of a created TSR engine.
/// @param[in] pu16Pid: PID value to be resume
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_TSR_ResumePid(MI_HANDLE hTsr, MI_U16 u16Pid);

//------------------------------------------------------------------------------
/// @brief Start record engine for a TSR handle.
/// @param[in] hTsr: An instance of a created TSR engine.
/// @param[in] pstStartParams: Pointer to struct MI_TSR_StartParams_t.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_TSR_Start(MI_HANDLE hTsr, const MI_TSR_StartParams_t *pstStartParams);

//------------------------------------------------------------------------------
/// @brief Stop record engine for a TSR handle.
/// @param[in] hTsr: An instance of a created TSR engine.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_TSR_Stop(MI_HANDLE hTsr);

//------------------------------------------------------------------------------
/// @brief Pause record engine for a TSR handle.
/// @param[in] hTsr: An instance of a created TSR engine.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_TSR_Pause(MI_HANDLE hTsr);

//------------------------------------------------------------------------------
/// @brief Resume record engine for a TSR handle.
/// @param[in] hTsr: An instance of a created TSR engine.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_TSR_Resume(MI_HANDLE hTsr);

//------------------------------------------------------------------------------
/// @brief Set TSR information of the specified attribute.
/// @param[in] hTsr: An instance of a created TSR engine.
/// @param[in] eAttrType: the attribute described in enum type MI_TSR_AttrType_e.
/// @param[in] pAttrParams: A pointer to to set attribute corresponding to the eAttrType. The prototype of pInputParams plz see the description of enum MI_TSR_AttrType_e
/// @return MI_OK: Set debug level success.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_TSR_SetAttr(MI_HANDLE hTsr, MI_TSR_AttrType_e eAttrType, const void *pAttrParams);

//------------------------------------------------------------------------------
/// @brief Get TSR information of the specified attribute.
/// @param[in] hTsr: An instance of a created TSR engine.
/// @param[in] eAttrType: the attribute described in enum type MI_TSR_AttrType_e.
/// @param[in] pInputParams: A pointer to to pass input parameters corresponding to the eAttrType. The prototype of pInputParams plz see the description of enum MI_TSR_AttrType_e
/// @param[out] pOutputParams: A pointer to to get attribute corresponding to the eAttrType. The prototype of pInputParams plz see the description of enum MI_TSR_AttrType_e
/// @return MI_OK: Set debug level success.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_TSR_GetAttr(MI_HANDLE hTsr, MI_TSR_AttrType_e eAttrType, const void * pInputParams, void * pOutputParams);

//------------------------------------------------------------------------------
/// @brief read data to buffer allocated by application.
/// @param[in] hTsr: An instance of a created TSR engine.
/// @param[in] pstReadParams: Pointer to struct MI_TSR_ReadParams_t.
/// @param[out] pstOutputParams: Pointer to struct MI_TSR_ReadOutputParams_t
/// @return MI_OK: Set debug level success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_TSR_Read(MI_HANDLE hTsr, const MI_TSR_ReadParams_t *pstReadParams, MI_TSR_ReadOutputParams_t *pstOutputParams);

//------------------------------------------------------------------------------
/// @brief Flush record buffer of a TSR handle.
/// @param[in] hTsr: An instance of a created TSR engine.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_TSR_FlushBuffer(MI_HANDLE hTsr);

//------------------------------------------------------------------------------
/// @brief Dump TSR Info.
/// @param[in] bAll: TRUE for print all resources, FALSE for print opned resources only.
/// @return MI_OK: Dump information success.
//------------------------------------------------------------------------------
MI_RESULT MI_TSR_DumpInfo(const MI_TSR_DumpInfoParams_t *pstDumpInfoParams);

//------------------------------------------------------------------------------
/// @brief Set TSR debug level.
/// @param[in] u32DebugLevel: Debug level defined in enum type MI_DBG_LEVEL
/// @return MI_OK: Set debug level success.
//------------------------------------------------------------------------------
MI_RESULT MI_TSR_SetDebugLevel(MI_DBG_LEVEL u32DebugLevel);

//------------------------------------------------------------------------------
/// @brief get TSR handle.
/// @param[in]  pstQueryParams: Query parameters
/// @param[out] *phTsr: An instance of a created TSR engine.
/// @return MI_OK: Get TSR handle success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_INVALID_PARAMETER: parameter null
//------------------------------------------------------------------------------
MI_RESULT MI_TSR_GetHandle(const MI_TSR_QueryHandleParams_t *pstQueryParams, MI_HANDLE *phTsr);


#ifdef __cplusplus
}
#endif

#endif///_MI_TSR_H_


