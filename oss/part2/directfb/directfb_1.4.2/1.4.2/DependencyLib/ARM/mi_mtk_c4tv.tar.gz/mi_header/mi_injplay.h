/*------------------------------------------------------------------------------
 * MediaTek Inc. (C) 2018. All rights reserved.
 *
 * Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 *----------------------------------------------------------------------------*/
//------------------------------------------------------------------------------
// Use GetXxx/SetXxx and GetAttr/SetAttr coexist
//------------------------------------------------------------------------------

#ifndef _MI_INJPLAY_H_
#define _MI_INJPLAY_H_

#ifdef __cplusplus
extern "C" {
#endif

#include "mi_inject.h"
#include "mi_video.h"
#include "mi_audio.h"
#include "mi_sync.h"
#include "mi_svp.h"

//-------------------------------------------------------------------------------------------------
//  Defines
//-------------------------------------------------------------------------------------------------

//-------------------------------------------------------------------------------------------------
//  Structures
//-------------------------------------------------------------------------------------------------
typedef enum
{
    E_MI_INJPLAY_SPEED_DISP_1X = 0,              ///< Speed 1X
    E_MI_INJPLAY_SPEED_DISP_2X,                  ///< Speed 2X
    E_MI_INJPLAY_SPEED_DISP_4X,                  ///< Speed 4X
    E_MI_INJPLAY_SPEED_DISP_8X,                  ///< Speed 8X
    E_MI_INJPLAY_SPEED_DISP_16X,                 ///< Speed 16X
    E_MI_INJPLAY_SPEED_DISP_32X,                 ///< Speed 32X
    E_MI_INJPLAY_SPEED_DISP_STEP = 0x4000,       ///< Display one frame

    E_MI_INJPLAY_SPEED_DISP_MAX,                 ///< Enum value of max supported speed control
} MI_INJPLAY_SpeedCtrl_e;

typedef enum
{
    E_MI_INJPLAY_CLEAR_BLANK = 0,                ///< Clear all the buffered stream of video/audio, and clear the current display frame as blank
    E_MI_INJPLAY_CLEAR_KEEP_SCREEN,              ///< Clear all the buffered stream of video/audio, and keep the last display frame on screen.

    E_MI_INJPLAY_CLEAR_MAX,                      ///< Enum value of max supported clear mode
} MI_INJPLAY_ClearMode_e;

typedef enum
{
    E_MI_INJPLAY_EVENT_VIDEO_START_DONE = MI_BIT(0),                ///< Video start done event
    E_MI_INJPLAY_EVENT_VIDEO_DECODE_ERROR = MI_BIT(1),              ///< Video decode error event
    E_MI_INJPLAY_EVENT_VIDEO_FIRST_FRAME = MI_BIT(2),               ///< Video first frame decoded event
    E_MI_INJPLAY_EVENT_VIDEO_PLAYBACK_DONE = MI_BIT(3),             ///< Video end of playback
    E_MI_INJPLAY_EVENT_VIDEO_NOT_ENOUGH_FRAME_BUFFER = MI_BIT(4),   ///< Video frame buffer size is not enough for the defined profile/level of the received stream.
    E_MI_INJPLAY_EVENT_VIDEO_STEP_DISPLAY_DONE = MI_BIT(5),         ///< Video display one frame done event
    E_MI_INJPLAY_EVENT_VIDEO_ALL = 0x000000FF,                      ///< Enum value of all video events

    E_MI_INJPLAY_EVENT_AUDIO_PLAYBACK_DONE = MI_BIT(8),             ///< Audio end of playback
    E_MI_INJPLAY_EVENT_AUDIO_DECODE_OK = MI_BIT(9),                 ///< Audio decoder is decoding normally
    E_MI_INJPLAY_EVENT_AUDIO_ALL = 0x0000FF00,                      ///< Enum value of all audio events

    E_MI_INJPLAY_EVENT_SECURE_INFO_READY = MI_BIT(16),              ///< Secure info is ready, user can call MI_INJPLAY_GetSecureInfo to get secure info
    E_MI_INJPLAY_EVENT_SECURE_ALL = 0x00FF0000,

    E_MI_INJPLAY_EVENT_ALL = 0xFFFFFFFF,                            ///< Enum value of all events
} MI_INJPLAY_Event_e;

typedef enum
{
    E_MI_INJPLAY_PLAYBACK_STOP = 0,              ///< Stop state
    E_MI_INJPLAY_PLAYBACK_PLAY,                  ///< Playing state
    E_MI_INJPLAY_PLAYBACK_PAUSE,                 ///< Pause state
    E_MI_INJPLAY_PLAYBACK_FF,                    ///< Fastfoward
    E_MI_INJPLAY_PLAYBACK_FB,                    ///< Fastbackward
    E_MI_INJPLAY_PLAYBACK_STEP,                  ///< frame by frame display

    E_MI_INJPLAY_PLAYBACK_MAX,                   ///< Enum value of max supported playback state
} MI_INJPLAY_PlaybackState_e;

typedef enum
{
    E_MI_INJPLAY_PLAY_MODE_NORAML = 0,           ///< Ts inject play mode. a/v is playing.
    E_MI_INJPLAY_PLAY_MODE_VIDEO_ONLY,           ///< Ts inject play mode. Video is playing only.
    E_MI_INJPLAY_PLAY_MODE_AUDIO_ONLY,           ///< Ts inject play mode. Audio is playing only.

    E_MI_INJPLAY_PLAY_MODE_MAX,                  ///< Enum value of max supported play mode.
}MI_INJPLAY_PlayMode_e;

typedef enum
{
    E_MI_INJPLAY_TIMESTAMP_NONE = 0,             ///< without timestamp information
    E_MI_INJPLAY_TIMESTAMP_PTS,                  ///< PTS (Presentation Time Stamp)
    E_MI_INJPLAY_TIMESTAMP_DTS,                  ///< DTS (Decode Time Stamp)
    E_MI_INJPLAY_TIMESTAMP_STS,                  ///< STS (Sorted Time Stamp)
    E_MI_INJPLAY_TIMESTAMP_PTS_MPEG_DIRECTV_SD,  ///< PTS_RVU (Presentation Time Stamp)
    E_MI_INJPLAY_TIMESTAMP_DTS_MPEG_DIRECTV_SD,  ///< DTS_RVU (Decode Time Stamp)
} MI_INJPLAY_TimestampType_e;

typedef enum
{
    E_MI_INJPLAY_ATTR_TYPE_PRE_BUFFER_CTRL,         ///< [Set/Get] prebuffer control before starting playack, parameter type is a pointer to MI_INJECT_PreBufferCtrl_t. Set NULL param for disable.
    E_MI_INJPLAY_ATTR_TYPE_STOP_CLEAR_MODE,         ///< [Set/Get] the clear mode when MI_INJPLAY_Stop is called, parameter type is a pointer to MI_INJPLAY_ClearMode_e.
    E_MI_INJPLAY_ATTR_TYPE_VDEC_LATENCY_CTRL,       ///< [Set/Get] configure the video decode latency control, parameter type is a pointer to MI_VIDEO_LatencyCtrl_t. Set NULL param for using default setting.
    E_MI_INJPLAY_ATTR_TYPE_SYNC_MODE,               ///< [Set/Get] sync mode, parameter type is a pointer to struct MI_INJPLAY_SyncMode_t. Set NULL param for using defalut setting.
    E_MI_INJPLAY_ATTR_TYPE_GET_AVDEC_BUFFER_INFO,   ///< [Get] the buffer info corresponding to the the stream type of inject player, parameter type is a pointer to struct MI_INJPLAY_AvDecBufferInfo_t
    E_MI_INJPLAY_ATTR_TYPE_SET_DROP_ERROR_FRAME,    ///< [Set] drop the error frame while playback, parameter is a pointer to MI_BOOL to enable or disable.
    E_MI_INJPLAY_ATTR_TYPE_SET_DISPLAY_WINDOW,      ///< [Set] video display window position, parameter is a pointer to MI_INJPLAY_DispWin_t
    E_MI_INJPLAY_ATTR_TYPE_TS_INJECT_PLAY_MODE,     ///< [Set] Ts inject play mode. Support video only, normal mode. parameter is a pointer to MI_INJPLAY_PlayMode_e
    E_MI_INJPLAY_ATTR_TYPE_ES_BUFFER_LEVEL_CTRL,    ///< [Set] the es buffer level control paras of a speicifed injection stream type, parameter is a pointer to MI_INJECT_ESBufLevCtrl_t.
    E_MI_INJPLAY_ATTR_TYPE_TIMESTAMP_TYPE,          ///< [Set] set timestamp type for vdec, parameter is a pointer to MI_INJPLAY_TimestampType_e.
    E_MI_INJPLAY_ATTR_TYPE_GET_PLAYBACK_INFO,       ///< [Get] the playback info corresponding to the the stream type of inject player, parameter type is a pointer to struct MI_INJPLAY_PlaybackInfo_t
    E_MI_INJPLAY_ATTR_TYPE_TS_BYPASS_TIMESTAMP,     ///< [Set/Get] tsio bypass file-in timestamp enable/disable, parameter is a pointer to MI_BOOL
    E_MI_INJPLAY_ATTR_TYPE_GET_TS_FILEIN_TIMESTAMP, ///< [Get] file-in timestamp, 192 bytes per packet's timestamp from previous 4 bytes, parameter type is a pointer to MI_U32
    E_MI_INJPLAY_ATTR_TYPE_TS_PLAYBACK_TIMESTAMP,   ///< [Set/Get] playback timestamp, parameter type is a pointer to MI_U32
    E_MI_INJPLAY_ATTR_TYPE_SECURE_MODE,             ///< [Set/Get] set or get secure mode to injplay, parameter type is a pointer to MI_U32
    E_MI_INJPLAY_ATTR_TYPE_MAX,                     ///< Enum value of max attr type
} MI_INJPLAY_AttrType_e;

typedef enum
{
    E_MI_INJPLAY_SECURE_MODE_NONE = 0,              ///< Secure mode is disable

    E_MI_INJPLAY_SECURE_MODE_TS_PAYLOAD,            ///< Secure mode is TS file in with payload encryption
    E_MI_INJPLAY_SECURE_MODE_TS_BLOCK,              ///< Secure mode is TS file in with block encryption
    E_MI_INJPLAY_SECURE_MODE_ES,                    ///< Secure mode is ES file in with block encryption

    E_MI_INJPLAY_SECURE_MODE_MAX,                    ///< Enum value of max supported secure mode.
}MI_INJPLAY_SecureMode_e;

typedef struct MI_INJPLAY_Caps_s
{
    MI_U32 u32MaxSupportVidDecNum;                  /// [OUT]: < Number of max supported video decoder
    MI_U32 u32SupportVidCodecs;                     /// [OUT]: < Bit-wise supported video codecs defined by MI_VIDEO_CodecType_e
    MI_U32 u32MaxSupportAudDecNum;                  /// [OUT]: < Number of max supported audio decoder
    MI_U32 u32SupportAudCodecs;                     /// [OUT]: < Bit-wise supported audio codecs define by MI_AUDIO_CodecType_e
    MI_U32 u32MaxTsBufSize;                         /// [OUT]: < Max internal buffer size of TS injection
    MI_U32 u32MaxVpesBufSize;                       /// [OUT]: < Max internal buffer size of VPES injection
    MI_U32 u32MaxApesBufSize;                       /// [OUT]: < Max internal buffer size of APES injection
    MI_U32 u32MaxVesBufSize;                        /// [OUT]: < Max internal buffer size of VES injection
    MI_U32 u32MaxAesBufSize;                        /// [OUT]: < Max internal buffer size of AES injection

} MI_INJPLAY_Caps_t;

typedef struct MI_INJPLAY_InitParams_s
{
    MI_U8 u8Reserved;                           ///< Reserved for future
} MI_INJPLAY_InitParams_t;

typedef struct MI_INJPLAY_OpenParams_s
{
    MI_U8 *pszName;                             /// [IN]: < Custom defined injplay name which is a string
    MI_INJECT_StreamType_e eStreamType;         /// [IN]: < The stream type of content
} MI_INJPLAY_OpenParams_t;

typedef struct MI_INJPLAY_StartParams_s
{
    MI_HANDLE hDisp;                            /// [IN]: < The handle of Display
    MI_HANDLE hAout;                            /// [IN]: < The hanlde of Aout
} MI_INJPLAY_StartParams_t;

typedef struct MI_INJPLAY_Wmv3CodecData_s
{
    MI_U16 u16Width;                            /// [IN]: < Width of video frame
    MI_U16 u16Height;                           /// [IN]: < Height of video frame
    MI_U32 u32FrameRate;                        /// [IN]: < Numerator of frame rate
    MI_U32 u32FrameRateBase;                    /// [IN]: < Denominator of frame rate. i.e. 29.97 = 30000/1001, numerator = 30000, denominator = 1001.
    MI_U8 au8SeqHdrData[4];                     /// [IN]: < E_MI_VIDEO_CODEC_TYPE_VC1_MAIN, 4bytes Table 263: Sequence Header Data Structure STRUCT_C for Simple and Main Profiles
} MI_INJPLAY_Wmv3CodecData_t;

typedef struct MI_INJPLAY_Divx311CodecData_s
{
    MI_U16 u16Width;                            /// [IN]: < Width of video frame
    MI_U16 u16Height;                           /// [IN]: < Height of video frame
    MI_U32 u32FrameRate;                        /// [IN]: < Numerator of frame rate
    MI_U32 u32FrameRateBase;                    /// [IN]: < Denominator of frame rate. i.e. 29.97 = 30000/1001, numerator = 30000, denominator = 1001.
} MI_INJPLAY_Divx311CodecData_t;

typedef struct MI_INJPLAY_PrivateVideoCodecData_s
{
    MI_U16 u16Width;                            /// [IN]: < Width of video frame
    MI_U16 u16Height;                           /// [IN]: < Height of video frame
    MI_U32 u32FrameRate;                        /// [IN]: < Numerator of frame rate
    MI_U32 u32FrameRateBase;                    /// [IN]: < Denominator of frame rate. i.e. 29.97 = 30000/1001, numerator = 30000, denominator = 1001.
    MI_U8 *pu8MetaData;                         /// [IN]: < Meta data corresponding to the video codec
    MI_U32 u32MetaDataSize;                     /// [IN]: < Size of meta data
} MI_INJPLAY_PrivateVideoCodecData_t;

typedef struct MI_INJPLAY_TsData_s
{
    MI_U16 u16Pid;                              /// [IN]: < PID of TS stream
    MI_U8 u8PacketSize;                         /// [IN]: < Packet size of TS stream, 188, 192 or 204
} MI_INJPLAY_TsData_t;

typedef struct MI_INJPLAY_VideoCodecData_s
{
    MI_VIDEO_CodecType_e eCodecType;                    /// [IN]: < Video codec type
    union
    {
        MI_INJPLAY_TsData_t stTs;                       /// [IN]: < Transport Stream codec data
        MI_INJPLAY_Wmv3CodecData_t stWmv3;              /// [IN]: < WMV3 codec data
        MI_INJPLAY_Divx311CodecData_t stDivx311;        /// [IN]: < DIVX311 codec data
        MI_INJPLAY_PrivateVideoCodecData_t stPrivate;   /// [IN]: < private/others codec data
    } attr;

} MI_INJPLAY_VideoCodecData_t;

typedef struct MI_INJPLAY_AudioExtraData_s
{
    // WAVEFORMATEX
    MI_U16 u16FormatTag;        /// [IN]: < Format tag for WMA 0x161, 0x162,...
    MI_U8 u8Channels;           /// [IN]: < Channels, 1(mono), 2(stereo),...
    MI_U32 u32SampleRate;       /// [IN]: < Sampling rate, 48000(48KHz), 44100(44.1KHz), 32000(32KHz),....
    MI_U32 u32AvgBytesPerSec;   /// [IN]: < Average byte per second
    MI_U16 u16BlockSize;        /// [IN]: < Size of block align defined in WMA header
    MI_U8 u8BitsPerSample;      /// [IN]: < Bits per sample, 8(bits), 16(bits), 24(bits),...
    MI_U8 u8BigEndian;          /// [IN]: < For LPCM, 0x0: little endian, 0xFF: big endian
    // specific data
    MI_U16 u16ExtDataSize;      /// [IN]: < The count in bytes of the size of extension data
    MI_U8 au8ExtData[32];       /// [IN]: < Extension data
    ///< WMAV1: need  4 Bytes extra information at least
    ///< WMAV2: need 10 Bytes extra information at least
    ///< WMAV3: need 18 Bytes extra information at least
    ///< AAC: au8ExtData[0] for profile, 0: AAC_MAIN, 1: AAC_LC, 2: AAC_SSR, 3: AAC_LTP,...
} MI_INJPLAY_AudioExtraData_t;

typedef struct MI_INJPLAY_AudioCodecData_s
{
    MI_AUDIO_CodecType_e eCodecType;                    /// [IN]: < Audio codec type
    union
    {
        MI_INJPLAY_TsData_t stTs;                       /// [IN]: < Audio Ts data
        MI_INJPLAY_AudioExtraData_t stExtraCodecData;   /// [IN]: < Audio codec extra data
    } attr;

} MI_INJPLAY_AudioCodecData_t;

typedef struct MI_INJPLAY_PlaybackInfo_s
{
    MI_INJECT_StreamType_e eStreamType;         /// [OUT]: < The stream type of injection
    MI_VIDEO_CodecType_e eVidCodecType;         /// [OUT]: < The video codec data
    MI_U16 u16VidWidth;                         /// [OUT]: < Width of video frame
    MI_U16 u16VidHeight;                        /// [OUT]: < Height of video frame
    MI_U32 u32VidFrameRate;                     /// [OUT]: < Numerator of frame rate
    MI_U32 u32VidFrameRateBase;                 /// [OUT]: < Denominator of frame rate. i.e. 29.97 = 30000/1001, numerator = 30000, denominator = 1001.
    MI_AUDIO_CodecType_e eAudCodecType;         /// [OUT]: < The audio codec data
    MI_U32 u32AudSampleRate;                    /// [OUT]: < Sampling rate, 48000(48KHz), 44100(44.1KHz), 32000(32KHz),....
    MI_U8 u8AudChannels;                        /// [OUT]: < Channels, 1(mono), 2(stereo),...
    MI_U8 u8AudBitsPerSample;                   /// [OUT]: < Bits per sample, 8(bits), 16(bits), 24(bits),...
} MI_INJPLAY_PlaybackInfo_t;

typedef MI_RESULT (*MI_INJPLAY_EventCallback)(MI_HANDLE hInjPlay, MI_U32 u32Event, void * pEventParams, void *pUserParams);   ///< The prototype of event callback function
typedef struct MI_INJPLAY_CallbackInputParams_s
{
    MI_U64 u64CallbackId;                       /// [IN]: < for multi-callback, use 0 for first register or single callback.
    MI_INJPLAY_EventCallback pfEventCallback;   /// [IN]: < Event callback function
    MI_U32 u32EventFlags;                       /// [IN]: < Bit-wise events defined by MI_INJPLAY_Event_e
    void *pUserParams;                          /// [IN]: < User parameter for the event callback function
} MI_INJPLAY_CallbackInputParams_t;

typedef struct MI_INJPLAY_CallbackOutputParams_s
{
    MI_U64 u64CallbackId;                   ///[OUT]: The returned ID for update or unregister callback.
} MI_INJPLAY_CallbackOutputParams_t;

typedef struct MI_INJPLAY_SyncMode_s
{
    MI_SYNC_SyncMode_e eSyncMode;           ///< Sync mode
                                            /// [IN]: for MI_INJPLAY_SetAttr
                                            /// [OUT]: for MI_INJPLAY_GetAttr
    MI_U16 u16PcrPid;                       ///< Sync parameter for E_MI_SYNC_MODE_PCR_MASTER, E_MI_SYNC_MODE_PCR_AUDIO_AUTO
                                            /// [IN]: for MI_INJPLAY_SetAttr
                                            /// [OUT]: for MI_INJPLAY_GetAttr
} MI_INJPLAY_SyncMode_t;

typedef struct MI_INJPLAY_AvDecBufferInfo_s
{
    MI_U32 u32VdecEsBufTotalSize;           /// [OUT]: < Total size of vdec es buffer
    MI_U32 u32VdecEsBufSize;                /// [OUT]: < Size of valid video es buffer
    MI_U32 u32VdecDecFrameCnt;              /// [OUT]: < Vdec deocded frame count
    MI_U32 u32AdecEsBufTotalSize;           /// [OUT]: < Total size of adec es buffer
    MI_U32 u32AdecEsBufSize;                /// [OUT]: < Size of valid adec es buffer
    MI_U32 u32AdecPcmBufSize;               /// [OUT]: < Size of valid PCM buffer
    MI_U32 u32AdecDecFrameCnt;              /// [OUT]: < Adec decoded frame count
} MI_INJPLAY_AvDecBufferInfo_t;

typedef struct MI_INJPLAY_DispWin_s
{
    MI_U32 u32X;               /// [IN]: < Horizontal start position of display window
    MI_U32 u32Y;               /// [IN]: < Vertical start position of display window
    MI_U32 u32Width;           /// [IN]: < Width of display window
    MI_U32 u32Height;          /// [IN]: < Height of display window
}MI_INJPLAY_DispWin_t;

typedef struct MI_INJPLAY_SecureInfo_s
{
    MI_SVP_PlayerType_e ePlayerType;        /// [IN] Svp player type
    void *pSecureHandle;                    /// [IN] Secure handle
    MI_U32 u32SecureHandleLength;           /// [IN] Secure handle length
    MI_U64 u64TspVidFilterId;               /// [IN] Tsp video filter id
    MI_U64 u64TspAudFilterId;               /// [IN] Tsp audio filter id
} MI_INJPLAY_SecureInfo_t;

//-------------------------------------------------------------------------------------------------
//  Global Functions
//-------------------------------------------------------------------------------------------------

//------------------------------------------------------------------------------
/// @brief Get INJECT module capabilities.
/// @param[out] pstInjPlayCaps: A pointer to structure MI_INJPLAY_Caps_t to retrieve the information of INJECT related capabilities
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_INJPLAY_GetCaps(MI_INJPLAY_Caps_t *pstCaps);

//------------------------------------------------------------------------------
/// @brief Init INJECT module.
/// @param[in] pstInitParams: A pointer to structure MI_INJPLAY_InitParams_t for initialization.
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_RESOURCES: No available resource.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_INJPLAY_Init(const MI_INJPLAY_InitParams_t *pstInitParams);

//------------------------------------------------------------------------------
/// @brief Finalize INJECT module.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_INJPLAY_DeInit(void);

//------------------------------------------------------------------------------
/// @brief Open a injection port for feeding stream to decoder.
/// @param[in] pstOpenParams: A pointer to structure MI_INJPLAY_OpenParams_t to determine the stream configuration of injection .
/// @param[out] phInjPlay: Pointer to MI_HANDLE to retrieve an instance of injection corresponding to the stream config pstOpenParams.
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_RESOURCES: No available resource.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_INJPLAY_Open(const MI_INJPLAY_OpenParams_t *pstOpenParams, MI_HANDLE *phInjplay);

//------------------------------------------------------------------------------
/// @brief Close a created injection port.
/// @param[in] hInjPlay: A handle of a created injection instance.
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE: Hanlde is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_INJPLAY_Close(MI_HANDLE hInjplay);

//------------------------------------------------------------------------------
/// @brief Set video codec data for the specified codec.
/// @param[in] hInjPlay: A handle of a created injection instance.
/// @param[in] pstVidCodecData: A pointer to structure MI_INJPLAY_VideoCodecData_t contains the video codec and the essential parameters of the video stream.
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE: Hanlde is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_RESOURCES: No available resource.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_INJPLAY_SetVideoCodecData(MI_HANDLE hInjPlay, MI_INJPLAY_VideoCodecData_t *pstVidCodecData);

//------------------------------------------------------------------------------
/// @brief Set audio codec data for the specified codec.
/// @param[in] hInjPlay: A handle of a created injection instance.
/// @param[in] pstAudCodecData: A pointer to structure MI_INJPLAY_AudioCodecData_t contains the audio codec and the essential parameters of the audio stream.
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE: Hanlde is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_RESOURCES: No available resource.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_INJPLAY_SetAudioCodecData(MI_HANDLE hInjPlay, MI_INJPLAY_AudioCodecData_t *pstAudCodecData);

//------------------------------------------------------------------------------
/// @brief Start playback for a created injection port.
/// @param[in] hInjPlay: A handle of a created injection instance.
/// @param[in] pstStartParams: Reserve parameter.
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE: Hanlde is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_INJPLAY_Start(MI_HANDLE hInjplay, const MI_INJPLAY_StartParams_t * pstStartParams);

//------------------------------------------------------------------------------
/// @brief Stop playback for a created injection port.
/// @param[in] hInjPlay: A handle of a created injection instance.
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE: Hanlde is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_INJPLAY_Stop(MI_HANDLE hInjplay);

//------------------------------------------------------------------------------
/// @brief Query the free buffer for injection from a created injection port.
/// @param[in] hInjPlay: A handle of a created injection instance.
/// @param[in] pstQueryBufParams: A pointer to structure MI_INJECT_QueryBufferParams_t to query free buffer
/// @param[out] pstBufParams: A pointer to structure MI_INJECT_BufferParams_t to retrieve the free buffer information.
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE: Hanlde is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_CHAOS: The injection hasn't started playback yet.
//------------------------------------------------------------------------------
MI_RESULT MI_INJPLAY_QueryFreeBuffer(MI_HANDLE hInjplay, MI_INJECT_QueryBufferParams_t *pstQueryBufParams, MI_INJECT_BufferParams_t *pstBufParams);

//------------------------------------------------------------------------------
/// @brief Info the stream writen into buffer is complete and ready for injecting into a created injection port.
/// @param[in] hInjPlay: A handle of a created injection instance.
/// @param[in] pstBufParams: A pointer to structure MI_INJECT_BufferParams_t describes the stream for injection.
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE: Hanlde is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_CHAOS: The injection hasn't started playback yet.
//------------------------------------------------------------------------------
MI_RESULT MI_INJPLAY_WriteBufferComplete(MI_HANDLE hInjplay, MI_INJECT_BufferParams_t *pstBufParams);

//------------------------------------------------------------------------------
/// @brief Pause playback for a created injection port. Call MI_INJPLAY_Resume() for back to the normal playback.
/// @param[in] hInjPlay: A handle of a created injection instance.
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE: Hanlde is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_INJPLAY_Pause(MI_HANDLE hInjplay);

//------------------------------------------------------------------------------
/// @brief Resume playback for a created injection port.
/// @param[in] hInjPlay: A handle of a created injection instance.
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE: Hanlde is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_INJPLAY_Resume(MI_HANDLE hInjplay);

//------------------------------------------------------------------------------
/// @brief Set the speed of fastfoward for a created injection port. Call MI_INJPLAY_Resume() for back to the normal playback.
/// @param[in] hInjPlay: A handle of a created injection instance.
/// @param[in] eSpeedCtrl: Enum type of MI_INJPLAY_SpeedCtrl_e to determine the display mode corresponding to the speed.
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE: Hanlde is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_INJPLAY_FastForward(MI_HANDLE hInjplay, MI_INJPLAY_SpeedCtrl_e eSpeedCtrl);

//------------------------------------------------------------------------------
/// @brief Set the speed of fastbackward for a created injection port. Call MI_INJPLAY_Resume() for back to the normal playback.
/// @param[in] hInjPlay: A handle of a created injection instance.
/// @param[in] eSpeedCtrl: Enum type of MI_INJPLAY_SpeedCtrl_e to determine the display mode corresponding to the speed.
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE: Hanlde is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_INJPLAY_FastBackward(MI_HANDLE hInjplay, MI_INJPLAY_SpeedCtrl_e eSpeedCtrl);

//------------------------------------------------------------------------------
/// @brief Get current playback state.
/// @param[in] hInjPlay: A handle of a created injection instance.
/// @param[out] pePlaybkState: A pointer to enum type MI_INJPLAY_PlaybackState_e to retrieve the current playback state.
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE: Hanlde is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_INJPLAY_GetPlaybackState(MI_HANDLE hInjplay, MI_INJPLAY_PlaybackState_e *pePlaybkState);

//------------------------------------------------------------------------------
/// @brief Clear all the buffered stream of video/audio
/// @param[in] hInjPlay: A handle of a created injection instance.
/// @param[in] eClearMode: A enum value to detemine the video screen display after cleared.
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE: Hanlde is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_CHAOS: The injection hasn't started playback yet.
//------------------------------------------------------------------------------
MI_RESULT MI_INJPLAY_Clear(MI_HANDLE hInjplay, MI_INJPLAY_ClearMode_e eClearMode);

//------------------------------------------------------------------------------
/// @brief Get the attribute/information of a created injection instance.
/// @param[in] hInjPlay: A handle of a created injection instance.
/// @param[in] eAttrType: The parameter type for getting attribute.
/// @param[in] pInputParams: A pointer to to get attribute corresponding to the eAttrType. The prototype of pParam plz see the description of enum MI_INJPLAY_AttrType_e
/// @param[out] pOutputParams: A pointer to to get attribute corresponding to the eAttrType. The prototype of pParam plz see the description of enum MI_INJPLAY_AttrType_e
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_SUPPORT: eAttrType is not supported.
/// @return MI_ERR_INVALID_HANDLE: Hanlde is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_INJPLAY_GetAttr(MI_HANDLE hInjplay, MI_INJPLAY_AttrType_e eAttrType, const void *pInputParams, void *pOutputParams);

//------------------------------------------------------------------------------
/// @brief Set the attribute/information of a created injection instance.
/// @param[in] hInjPlay: A handle of a created injection instance.
/// @param[in] eAttrType: The parameter type for setting attribute.
/// @param[in] pAttrParams: A pointer to to set attribute corresponding to the eAttrType. The prototype of pParam plz see the description of enum MI_INJPLAY_AttrType_e
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_SUPPORT: eAttrType is not supported.
/// @return MI_ERR_INVALID_HANDLE: Hanlde is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_INJPLAY_SetAttr(MI_HANDLE hInjplay, MI_INJPLAY_AttrType_e eAttrType, const void *pAttrParams);

//------------------------------------------------------------------------------
/// @brief Register the callback function for receiving the events of injection related.
/// @param[in] hInjPlay: A handle of a created injection instance.
/// @param[in] pstInputParams: A pointer to structure MI_INJPLAY_CallbackInputParams_t for events registered.
/// @param[out] pstOutputParams: A pointer to structure MI_INJPLAY_CallbackOutputParams_t for events registered.
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE: Hanlde is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_INJPLAY_RegisterCallback(MI_HANDLE hInjplay, const MI_INJPLAY_CallbackInputParams_t * pstInputParams, MI_INJPLAY_CallbackOutputParams_t *pstOutputParams);

//------------------------------------------------------------------------------
/// @brief UnRegister the callback function for receiving the events of injection related.
/// @param[in] hInjPlay: A handle of a created injection instance.
/// @param[in] u32EventFlags: Bit-wise events defined by MI_INJPLAY_Event_e.
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE: Hanlde is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_INJPLAY_UnRegisterCallback(MI_HANDLE hInjplay, const MI_INJPLAY_CallbackInputParams_t * pstInputParams);

//------------------------------------------------------------------------------
/// @brief Get Secure Info
/// @param[in] hInjPlay: A handle of a created injection instance.
/// @param[in] ePlayerType: Player type of SVP.
/// @param [out] pstSecureInfo: Secure info parameters.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_INVALID_PARAMETER: Parameter is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_INJPLAY_GetSecureInfo(MI_HANDLE hInjplay, MI_SVP_PlayerType_e ePlayerType, MI_INJPLAY_SecureInfo_t *pstSecureInfo);

//------------------------------------------------------------------------------
/// @brief Release Secure Info
/// @param[in] hInjPlay: A handle of a created injection instance.
/// @param [in] pstSecureInfo: Secure info parameters.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_INVALID_PARAMETER: Parameter is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_INJPLAY_ReleaseSecureInfo(MI_HANDLE hInjplay, MI_INJPLAY_SecureInfo_t *pstSecureInfo);

//------------------------------------------------------------------------------
/// @brief Set INJECT debug level.
/// @param[in] u32DbgLevel: Debug level defined in enum type MI_DBG_LEVEL
/// @return MI_OK: Set debug level success.
//------------------------------------------------------------------------------
MI_RESULT MI_INJPLAY_SetDebugLevel(MI_DBG_LEVEL u32DebugLevel);
#ifdef __cplusplus
}
#endif

#endif///_MI_INJPLAY_H_

