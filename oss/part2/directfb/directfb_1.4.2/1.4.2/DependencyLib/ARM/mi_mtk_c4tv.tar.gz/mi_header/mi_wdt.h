/*------------------------------------------------------------------------------
 * MediaTek Inc. (C) 2018. All rights reserved.
 *
 * Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 *----------------------------------------------------------------------------*/
#ifndef _MI_WDT_H_
#define _MI_WDT_H_

#ifdef __cplusplus
extern "C" {
#endif

//-------------------------------------------------------------------------------------------------
//  Defines
//-------------------------------------------------------------------------------------------------
/// Max charactor number of Thread name
#define MI_WDT_MAX_NAME_LENGTH             (64)

//-------------------------------------------------------------------------------------------------
//  Structures
//-------------------------------------------------------------------------------------------------
typedef enum
{
    E_MI_WDT_SET_TIMER_SEC,         /* timer second */
    E_MI_WDT_SET_TIMER_MS_SEC,      /* timer millisecond */
    E_MI_WDT_SET_TIMER_US_SEC       /* timer microsecond */
} MI_WDT_SetTimer_e;

typedef enum
{
    E_MI_WDT_ATTR_TYPE_INVALID = -1,      ///< Invalid Attribute of MY SYS.
    E_MI_WDT_ATTR_TYPE_MIN = 0,        ///< Min Attribute of MY SYS.
    E_MI_WDT_ATTR_TYPE_SET_TIMER_SEC = E_MI_WDT_ATTR_TYPE_MIN,   ///< set timer second.
    E_MI_WDT_ATTR_TYPE_SET_TIMER_MS,  ///< set timer millisecond.
    E_MI_WDT_ATTR_TYPE_SET_TIMER_US,  ///< set timer microsecond.
    E_MI_WDT_ATTR_TYPE_SET_INT_TIMER,       ///< Set INT Timer.
    E_MI_WDT_ATTR_TYPE_CLEAR_TIMER,        ///< clear WDT timer and get result.
    E_MI_WDT_ATTR_TYPE_IS_ENABLE,          ///< get info to check if WDT is Enable, TRUE: Initial FALSE: Not initial.
    E_MI_WDT_ATTR_TYPE_IS_RESET,            ///< get info to check if WDT is reset, TRUE: Reseted FALSE: Not Reset.
    E_MI_WDT_ATTR_TYPE_CLEAR_RESET_FLAG,      ///< get clear WDT reset flag.
    E_MI_WDT_ATTR_TYPE_MAX,               ///< Max Attribute of MY SYS.
} MI_WDT_AttrType_e;
typedef enum
{
    E_MI_WDT_EVENT_ID_NONE = 0,
    E_MI_WDT_EVENT_ID_GET_INTERRUPT = MI_BIT(0),
    E_MI_WDT_EVENT_ID_GET_TASKDEAD = MI_BIT(1),

    E_MI_WDT_EVENT_ID_ALL = -1,
} MI_WDT_EventId_e;

//parameter structure to initialize the wdt
typedef struct MI_WDT_InitParams_s
{
    MI_U8 u8Reserved;
} MI_WDT_InitParams_t;

typedef struct MI_WDT_OpenParams_s
{
    MI_U8 u8Reserved;
} MI_WDT_OpenParams_t;
typedef MI_WDT_OpenParams_t MI_WDT_QueryHandleParams_t;

typedef MI_RESULT (*MI_WDT_EventCallback)(MI_HANDLE hWdt, MI_U32 u32Event, void *pEventParams, void *pUserParams);

typedef struct MI_WDT_CallbackInputParams_s
{
    MI_U64 u64CallbackId;                           ///[IN]: Use 0 for first register, other valid value(returned by MI_WDT_CallbackOutputParams_t) for update callback event.
    MI_WDT_EventCallback pfEventCallback;          ///[IN]: Event callback function pointer.
    MI_U32 u32EventFlags;                           ///[IN]: Registered events which are bitwise OR operation.
    void *pUserParams;                              ///[IN]: For passing user-defined parameters.
} MI_WDT_CallbackInputParams_t;

typedef struct MI_WDT_CallbackOutputParams_s
{
    MI_U64 u64CallbackId;                           ///[OUT]: the returned ID for update or unregister callback.
} MI_WDT_CallbackOutputParams_t;

typedef struct MI_WDT_MonitorThreadInfo_s
{
    MI_U32 u32ProcessId;                           /// Process ID of monitor thread
    MI_U32 u32ThreadId;                            /// Thread ID of monitor thread
    MI_U8  szThreadName[MI_WDT_MAX_NAME_LENGTH];       /// Thread name of monitor thread
} MI_WDT_MonitorThreadInfo_t;


//-------------------------------------------------------------------------------------------------
//  Global Functions
//-------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------
/// @brief \b Function  \b Name: MI_WDT_Init
/// @brief \b Function  \b Description: Init and Start WDT
/// @param <OUT>        \b None:
/// @param <RET>        \b TRUE: Initial FALSE: Not initial
/// @param <GLOBAL>     \b None :
//------------------------------------------------------------------------------
MI_RESULT MI_WDT_Init(const MI_WDT_InitParams_t *pstInitParams);


//------------------------------------------------------------------------------
/// @brief \b Function  \b Name: MI_WDT_DeInit
/// @brief \b Function  \b Description: Init WDT Stop
/// @param <OUT>        \b None :
/// @param <RET>        \b MI_RESULT
/// @param <GLOBAL>     \b None :
//------------------------------------------------------------------------------
MI_RESULT MI_WDT_DeInit(void);

//------------------------------------------------------------------------------
/// @brief open WDT handle
/// @param[in] pstOpenParams.
/// @param[out] phWdt.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_WDT_Open(const MI_WDT_OpenParams_t *pstOpenParams, MI_HANDLE *phWdt);

//------------------------------------------------------------------------------
/// @brief close WDT handle
/// @param[in] hPm: wdt handle
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_WDT_Close(MI_HANDLE hWdt);

//------------------------------------------------------------------------------
/// @brief \b Function  \b Name: MI_WDT_SetAttr
/// @brief \b Function  \b Description: Set attribute from wdt
/// @param <IN>         \b hWdt: wdt handle to process
/// @param <IN>         \b eAttrType: Parameter type
/// @param <IN>         \b pParam : for user to set
/// @param <RET>        \b MI_OK: Process success ,MI_ERR_FAILED: Process failure
/// @param <GLOBAL>     \b None :
//------------------------------------------------------------------------------
MI_RESULT MI_WDT_SetAttr(MI_HANDLE hWdt, MI_WDT_AttrType_e eAttrType, const void *pAttrParams);


//------------------------------------------------------------------------------
/// @brief \b Function  \b Name: MI_WDT_GetAttr
/// @brief \b Function  \b Description: Get attribute from wdt
/// @param <IN>         \b hWdt: wdt handle to process
/// @param <IN>         \b eAttrType: Parameter type
/// @param <IN>         \b pInputParams: the pointer to parameters of eAttrType
/// @param <OUT>        \b pOutputParams : result for user to get
/// @param <RET>        \b MI_OK: Process success ,MI_ERR_FAILED: Process failure
/// @param <GLOBAL>     \b None :
//------------------------------------------------------------------------------
MI_RESULT MI_WDT_GetAttr(MI_HANDLE hWdt, MI_WDT_AttrType_e eAttrType, const void * pInputParams, void * pOutputParams);

//------------------------------------------------------------------------------
/// @brief Get WDT handle
/// @param[in] MI_WDT_QueryHandleParams_t: GetHandle Params
/// @param[out] phWdt: get WDT handle
/// @return MI_OK: Get WDT handle success.
/// @return MI_ERR_FAILED: Get WDT handle fail.
//------------------------------------------------------------------------------
MI_RESULT MI_WDT_GetHandle(const MI_WDT_QueryHandleParams_t *pstQueryParams, MI_HANDLE *phWdt);

//------------------------------------------------------------------------------
/// @brief Register the callback function for receiving the events of WDT related.
/// @param[in] hWdt: A Handle of a created WDT instance.
/// @param[in] pstInputParams: A pointer to structure MI_WDT_CallbackInputParams_t for events registered.
/// @param[out] pstOutputParams: A pointer to structure MI_WDT_CallbackOutputParams_t.
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE: hanlde is invalid.
/// @return MI_ERR_INVALID_PARAMETER: parameters is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_WDT_RegisterCallback(MI_HANDLE hWdt, const MI_WDT_CallbackInputParams_t *pstInputParams, MI_WDT_CallbackOutputParams_t *pstOutputParams);

//------------------------------------------------------------------------------
/// @brief UnRegister the callback function for receiving the events of WDT related.
/// @param[in] hWdt: A Handle of a created WDT instance.
/// @param[in] pstInputParams: A pointer to structure MI_WDT_CallbackInputParams_t for events registered.
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE: hanlde is invalid.
/// @return MI_ERR_INVALID_PARAMETER: parameters is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_WDT_UnRegisterCallback(MI_HANDLE hWdt, const MI_WDT_CallbackInputParams_t *pstInputParams);

//------------------------------------------------------------------------------
/// @brief Add a thread to wdt thread monitor.
/// @param[in] hWdt: A Handle of a created WDT instance.
/// @param[in] pstThreadInfo: A pointer to structure MI_WDT_MonitorThreadInfo_t for thread to monitor.
/// @param[in] u16Interval: Maxium time for wdt thread monitor wait for this thread.
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE: hanlde is invalid.
/// @return MI_ERR_INVALID_PARAMETER: parameters is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_WDT_AddMonitor(MI_HANDLE hWdt, MI_WDT_MonitorThreadInfo_t *pstThreadInfo, MI_U16 u16Interval);

//------------------------------------------------------------------------------
/// @brief Remove a thread from wdt thread monitor.
/// @param[in] hWdt: A Handle of a created WDT instance.
/// @param[in] pstThreadInfo: A pointer to structure MI_WDT_MonitorThreadInfo_t for thread to monitor.
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE: hanlde is invalid.
/// @return MI_ERR_INVALID_PARAMETER: parameters is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_WDT_RemoveMonitor(MI_HANDLE hWdt, MI_WDT_MonitorThreadInfo_t *pstThreadInfo);

//------------------------------------------------------------------------------
/// @brief Send Heart Beat to wdt thread monitor.
/// @param[in] hWdt: A Handle of a created WDT instance.
/// @param[in] pstThreadInfo: A pointer to structure MI_WDT_MonitorThreadInfo_t for thread to monitor.
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE: hanlde is invalid.
/// @return MI_ERR_INVALID_PARAMETER: parameters is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_WDT_SendHeartBeat(MI_HANDLE hWdt, MI_WDT_MonitorThreadInfo_t *pstThreadInfo);

//------------------------------------------------------------------------------
/// @brief \b Function  \b Name: MI_WDT_SetDebugLevel
/// @brief \b Function  \b Description: Set MI Debug Level
/// @param <IN>         \b MI_DBG_LEVEL: eDbgLevel
/// @param <OUT>        \b None :
/// @param <RET>        \b MI_RESULT
/// @param <GLOBAL>     \b None :
//------------------------------------------------------------------------------
MI_RESULT MI_WDT_SetDebugLevel(MI_DBG_LEVEL u32DebugLevel);

#ifdef __cplusplus
}
#endif

#endif///_MI_WDT_H_

