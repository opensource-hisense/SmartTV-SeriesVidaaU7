/*------------------------------------------------------------------------------
 * MediaTek Inc. (C) 2018. All rights reserved.
 *
 * Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 *----------------------------------------------------------------------------*/

#ifndef _MI_APM_H_
#define _MI_APM_H_

#ifdef __cplusplus
extern "C" {
#endif

//-------------------------------------------------------------------------------------------------
//  Defines - Constant
//-------------------------------------------------------------------------------------------------

#define MI_APM_EVENT_SIZE  (256-sizeof(MI_U32))

//-------------------------------------------------------------------------------------------------
//  Types - Enums
//-------------------------------------------------------------------------------------------------

typedef enum
{
    E_MI_APM_AUDIO_OUT_DIGITAL_MODE_NONE = 0xff,
    E_MI_APM_AUDIO_OUT_DIGITAL_MODE_PCM  = 0x0,           //PCM
    E_MI_APM_AUDIO_OUT_DIGITAL_MODE_AUTO,                 //Auto
    E_MI_APM_AUDIO_OUT_DIGITAL_MODE_TRANSCODE,            //Transcode
    E_MI_APM_AUDIO_OUT_DIGITAL_MODE_BYPASS,               //Bypass
    E_MI_APM_AUDIO_OUT_DIGITAL_MODE_MAX,
} MI_APM_AudioOutDigitalMode_e;

typedef enum
{
    E_MI_APM_CEC_AUDIO_CODEC_TYPE_RESERVED  = 0x00,
    E_MI_APM_CEC_AUDIO_CODEC_TYPE_LPCM      = 0x01,
    E_MI_APM_CEC_AUDIO_CODEC_TYPE_AC3       = 0x02,
    E_MI_APM_CEC_AUDIO_CODEC_TYPE_MPEG1     = 0x03,
    E_MI_APM_CEC_AUDIO_CODEC_TYPE_MP3       = 0x04,
    E_MI_APM_CEC_AUDIO_CODEC_TYPE_MPEG2     = 0x05,
    E_MI_APM_CEC_AUDIO_CODEC_TYPE_AAC       = 0x06,
    E_MI_APM_CEC_AUDIO_CODEC_TYPE_DTS       = 0x07,
    E_MI_APM_CEC_AUDIO_CODEC_TYPE_ATRAC     = 0x08,
    E_MI_APM_CEC_AUDIO_CODEC_TYPE_DSD       = 0x09,
    E_MI_APM_CEC_AUDIO_CODEC_TYPE_EAC3      = 0x0A,
    E_MI_APM_CEC_AUDIO_CODEC_TYPE_DTSHD     = 0X0B,
    E_MI_APM_CEC_AUDIO_CODEC_TYPE_MAT       = 0x0C,
    E_MI_APM_CEC_AUDIO_CODEC_TYPE_DST       = 0x0D,
    E_MI_APM_CEC_AUDIO_CODEC_TYPE_WMA       = 0x0E,
    E_MI_APM_CEC_AUDIO_CODEC_TYPE_EXTENSION = 0x0F,
    E_MI_APM_CEC_AUDIO_CODEC_TYPE_MAX,
} MI_APM_CecAudioCodecType_e;              /// Define the enum for CEC short audio descriptor codec

typedef enum
{
    // GMT
    E_MI_APM_TIME_ZONE_GMT_0_MIN,
    E_MI_APM_TIME_ZONE_CANARY = E_MI_APM_TIME_ZONE_GMT_0_MIN,
    E_MI_APM_TIME_ZONE_MONTEVIDEO,
    E_MI_APM_TIME_ZONE_LIMA,
    E_MI_APM_TIME_ZONE_SANTIAGO,
    E_MI_APM_TIME_ZONE_CARACAS,
    E_MI_APM_TIME_ZONE_QUITO,
    E_MI_APM_TIME_ZONE_SAN_JOSE,
    E_MI_APM_TIME_ZONE_ASUNCION,
    E_MI_APM_TIME_ZONE_LA_PAZ,
    E_MI_APM_TIME_ZONE_BELMOPAN,
    E_MI_APM_TIME_ZONE_MANAGUA,
    E_MI_APM_TIME_ZONE_GUATEMALA,
    E_MI_APM_TIME_ZONE_LISBON,
    E_MI_APM_TIME_ZONE_DUBLIN,
    E_MI_APM_TIME_ZONE_LONDON,
    E_MI_APM_TIME_ZONE_GMT_0_MAX = E_MI_APM_TIME_ZONE_LONDON,

    // GMT + 0.5
    E_MI_APM_TIME_ZONE_GMT_0_POINT_5_MIN,
    E_MI_APM_TIME_ZONE_GMT_0_POINT_5_MAX = E_MI_APM_TIME_ZONE_GMT_0_POINT_5_MIN,

    // GMT + 1
    E_MI_APM_TIME_ZONE_GMT_1_MIN,
    E_MI_APM_TIME_ZONE_AMSTERDAM = E_MI_APM_TIME_ZONE_GMT_1_MIN,
    E_MI_APM_TIME_ZONE_BEOGRAD,
    E_MI_APM_TIME_ZONE_BERLIN,
    E_MI_APM_TIME_ZONE_BERN,
    E_MI_APM_TIME_ZONE_BRATISLAVA,
    E_MI_APM_TIME_ZONE_BRUSSELS,
    E_MI_APM_TIME_ZONE_BUDAPEST,
    E_MI_APM_TIME_ZONE_COPENHAGEN,
    E_MI_APM_TIME_ZONE_GENEVA,
    E_MI_APM_TIME_ZONE_LIUBLJANA,
    E_MI_APM_TIME_ZONE_LUXEMBOURG,
    E_MI_APM_TIME_ZONE_MADRID,
    E_MI_APM_TIME_ZONE_OSLO,
    E_MI_APM_TIME_ZONE_PARIS,
    E_MI_APM_TIME_ZONE_PRAGUE,
    E_MI_APM_TIME_ZONE_ROME,
    E_MI_APM_TIME_ZONE_STOCKHOLM,
    E_MI_APM_TIME_ZONE_WARSAW,
    E_MI_APM_TIME_ZONE_VIENNA,
    E_MI_APM_TIME_ZONE_SKOPJE,
    E_MI_APM_TIME_ZONE_ZAGREB,
    E_MI_APM_TIME_ZONE_GMT_1_MAX = E_MI_APM_TIME_ZONE_ZAGREB,

    // GMT + 1.5
    E_MI_APM_TIME_ZONE_GMT_1_POINT_5_MIN,
    E_MI_APM_TIME_ZONE_GMT_1_POINT_5_MAX = E_MI_APM_TIME_ZONE_GMT_1_POINT_5_MIN,

    // GMT + 2
    E_MI_APM_TIME_ZONE_GMT_2_MIN,
    E_MI_APM_TIME_ZONE_ATHENS = E_MI_APM_TIME_ZONE_GMT_2_MIN,
    E_MI_APM_TIME_ZONE_BUCURESTI,
    E_MI_APM_TIME_ZONE_HELSINKI,
    E_MI_APM_TIME_ZONE_ISTANBUL,
    E_MI_APM_TIME_ZONE_SOFIA,
    E_MI_APM_TIME_ZONE_TALLINN,
    E_MI_APM_TIME_ZONE_KYIV,
    E_MI_APM_TIME_ZONE_VILNIUS,
    E_MI_APM_TIME_ZONE_GMT_2_MAX = E_MI_APM_TIME_ZONE_VILNIUS,

    // GMT + 2.5
    E_MI_APM_TIME_ZONE_GMT_2_POINT_5_MIN,
    E_MI_APM_TIME_ZONE_GMT_2_POINT_5_MAX = E_MI_APM_TIME_ZONE_GMT_2_POINT_5_MIN,

    // GMT + 3
    E_MI_APM_TIME_ZONE_GMT_3_MIN,
    E_MI_APM_TIME_ZONE_MOSCOW = E_MI_APM_TIME_ZONE_GMT_3_MIN,
    E_MI_APM_TIME_ZONE_GMT_3_MAX = E_MI_APM_TIME_ZONE_MOSCOW,

    // GMT + 3.5
    E_MI_APM_TIME_ZONE_GMT_3_POINT_5_MIN,
    E_MI_APM_TIME_ZONE_TEHERAN = E_MI_APM_TIME_ZONE_GMT_3_POINT_5_MIN,
    E_MI_APM_TIME_ZONE_GMT_3_POINT_5_MAX = E_MI_APM_TIME_ZONE_TEHERAN,

    //GMT + 4
    E_MI_APM_TIME_ZONE_GMT_4_MIN,
    E_MI_APM_TIME_ZONE_DUBAI = E_MI_APM_TIME_ZONE_GMT_4_MIN,
    E_MI_APM_TIME_ZONE_GMT_4_MAX = E_MI_APM_TIME_ZONE_DUBAI,

    //GMT + 4.5
    E_MI_APM_TIME_ZONE_GMT_4_POINT_5_MIN,
    E_MI_APM_TIME_ZONE_KABUL = E_MI_APM_TIME_ZONE_GMT_4_POINT_5_MIN,
    E_MI_APM_TIME_ZONE_GMT_4_POINT_5_MAX = E_MI_APM_TIME_ZONE_KABUL,

    //GMT + 5
    E_MI_APM_TIME_ZONE_GMT_5_MIN,
    E_MI_APM_TIME_ZONE_URAL = E_MI_APM_TIME_ZONE_GMT_5_MIN,
    E_MI_APM_TIME_ZONE_ISLAMABAD,
    E_MI_APM_TIME_ZONE_GMT_5_MAX = E_MI_APM_TIME_ZONE_ISLAMABAD,

    //GMT + 5.5
    E_MI_APM_TIME_ZONE_GMT_5_POINT_5_MIN,
    E_MI_APM_TIME_ZONE_CALCUTTA = E_MI_APM_TIME_ZONE_GMT_5_POINT_5_MIN,
    E_MI_APM_TIME_ZONE_NEWDELHI,
    E_MI_APM_TIME_ZONE_GMT_5_POINT_5_MAX = E_MI_APM_TIME_ZONE_NEWDELHI,

    //GMT + 5.45
    E_MI_APM_TIME_ZONE_GMT_5_POINT_45_MIN,
    E_MI_APM_TIME_ZONE_KATHMANDU = E_MI_APM_TIME_ZONE_GMT_5_POINT_45_MIN,
    E_MI_APM_TIME_ZONE_GMT_5_POINT_45_MAX = E_MI_APM_TIME_ZONE_KATHMANDU,

    //GMT + 6
    E_MI_APM_TIME_ZONE_GMT_6_MIN,
    E_MI_APM_TIME_ZONE_ALMAATA = E_MI_APM_TIME_ZONE_GMT_6_MIN,
    E_MI_APM_TIME_ZONE_GMT_6_MAX = E_MI_APM_TIME_ZONE_ALMAATA,

    //GMT + 6.5
    E_MI_APM_TIME_ZONE_GMT_6_POINT_5_MIN,
    E_MI_APM_TIME_ZONE_YANGON = E_MI_APM_TIME_ZONE_GMT_6_POINT_5_MIN,
    E_MI_APM_TIME_ZONE_GMT_6_POINT_5_MAX = E_MI_APM_TIME_ZONE_YANGON,

    //GMT + 7
    E_MI_APM_TIME_ZONE_GMT_7_MIN,
    E_MI_APM_TIME_ZONE_BANGKOK = E_MI_APM_TIME_ZONE_GMT_7_MIN,
    E_MI_APM_TIME_ZONE_HANOI,
    E_MI_APM_TIME_ZONE_JAKARTA,
    E_MI_APM_TIME_ZONE_GMT_7_MAX = E_MI_APM_TIME_ZONE_JAKARTA,

    // GMT + 7.5
    E_MI_APM_TIME_ZONE_GMT_7_POINT_5_MIN,
    E_MI_APM_TIME_ZONE_GMT_7_POINT_5_MAX = E_MI_APM_TIME_ZONE_GMT_7_POINT_5_MIN,

    //GMT + 8
    E_MI_APM_TIME_ZONE_GMT_8_MIN,
    E_MI_APM_TIME_ZONE_WA = E_MI_APM_TIME_ZONE_GMT_8_MIN,
    E_MI_APM_TIME_ZONE_BEIJING,
    E_MI_APM_TIME_ZONE_HONGKONG,
    E_MI_APM_TIME_ZONE_TAIPEI,
    E_MI_APM_TIME_ZONE_KUALALUMPUR,
    E_MI_APM_TIME_ZONE_SINGAPORE,
    E_MI_APM_TIME_ZONE_GMT_8_MAX = E_MI_APM_TIME_ZONE_SINGAPORE,

    // GMT + 8.5
    E_MI_APM_TIME_ZONE_GMT_8_POINT_5_MIN,
    E_MI_APM_TIME_ZONE_GMT_8_POINT_5_MAX = E_MI_APM_TIME_ZONE_GMT_8_POINT_5_MIN,

    //GMT + 9
    E_MI_APM_TIME_ZONE_GMT_9_MIN,
    E_MI_APM_TIME_ZONE_TOKYO = E_MI_APM_TIME_ZONE_GMT_9_MIN,
    E_MI_APM_TIME_ZONE_SEOUL,
    E_MI_APM_TIME_ZONE_GMT_9_MAX = E_MI_APM_TIME_ZONE_SEOUL,

    //GMT + 9.5
    E_MI_APM_TIME_ZONE_GMT_9_POINT_5_MIN,
    E_MI_APM_TIME_ZONE_SA = E_MI_APM_TIME_ZONE_GMT_9_POINT_5_MIN,
    E_MI_APM_TIME_ZONE_NT,
    E_MI_APM_TIME_ZONE_GMT_9_POINT_5_MAX = E_MI_APM_TIME_ZONE_NT,

    //GMT + 10
    E_MI_APM_TIME_ZONE_GMT_10_MIN,
    E_MI_APM_TIME_ZONE_NSW = E_MI_APM_TIME_ZONE_GMT_10_MIN,
    E_MI_APM_TIME_ZONE_VIC,
    E_MI_APM_TIME_ZONE_QLD,
    E_MI_APM_TIME_ZONE_TAS,
    E_MI_APM_TIME_ZONE_GMT_10_MAX = E_MI_APM_TIME_ZONE_TAS,

    //GMT + 10.5
    E_MI_APM_TIME_ZONE_GMT_10_POINT_5_MIN,
    E_MI_APM_TIME_ZONE_ADLAIDE = E_MI_APM_TIME_ZONE_GMT_10_POINT_5_MIN,
    E_MI_APM_TIME_ZONE_GMT_10_POINT_5_MAX = E_MI_APM_TIME_ZONE_ADLAIDE,

    //GMT + 11
    E_MI_APM_TIME_ZONE_GMT_11_MIN,
    E_MI_APM_TIME_ZONE_SYNDEY = E_MI_APM_TIME_ZONE_GMT_11_MIN,
    E_MI_APM_TIME_ZONE_GMT_11_MAX = E_MI_APM_TIME_ZONE_SYNDEY,

    // GMT + 11.5
    E_MI_APM_TIME_ZONE_GMT_11_POINT_5_MIN,
    E_MI_APM_TIME_ZONE_GMT_11_POINT_5_MAX = E_MI_APM_TIME_ZONE_GMT_11_POINT_5_MIN,

    //GMT +  12
    E_MI_APM_TIME_ZONE_GMT_12_MIN,
    E_MI_APM_TIME_ZONE_NZST = E_MI_APM_TIME_ZONE_GMT_12_MIN,
    E_MI_APM_TIME_ZONE_GMT_12_MAX = E_MI_APM_TIME_ZONE_NZST,

    // GMT + 12.5
    E_MI_APM_TIME_ZONE_GMT_12_POINT_5_MIN,
    E_MI_APM_TIME_ZONE_GMT_12_POINT_5_MAX = E_MI_APM_TIME_ZONE_GMT_12_POINT_5_MIN,

    //GMT +  13
    E_MI_APM_TIME_ZONE_GMT_13_MIN,
    E_MI_APM_TIME_ZONE_TONGATAPU = E_MI_APM_TIME_ZONE_GMT_13_MIN,
    E_MI_APM_TIME_ZONE_GMT_13_MAX = E_MI_APM_TIME_ZONE_TONGATAPU,

    //GMT - 12
    E_MI_APM_TIME_ZONE_GMT_MINUS12_MIN,
    E_MI_APM_TIME_ZONE_GMT_MINUS12_MAX = E_MI_APM_TIME_ZONE_GMT_MINUS12_MIN,

    //GMT - 11.5
    E_MI_APM_TIME_ZONE_GMT_MINUS11_POINT_5_MIN,
    E_MI_APM_TIME_ZONE_GMT_MINUS11_POINT_5_MAX = E_MI_APM_TIME_ZONE_GMT_MINUS11_POINT_5_MIN,

    //GMT - 11
    E_MI_APM_TIME_ZONE_GMT_MINUS11_MIN,
    E_MI_APM_TIME_ZONE_NORTH_AMERICA_MIDWAY = E_MI_APM_TIME_ZONE_GMT_MINUS11_MIN,
    E_MI_APM_TIME_ZONE_GMT_MINUS11_MAX = E_MI_APM_TIME_ZONE_NORTH_AMERICA_MIDWAY,

    //GMT - 10.5
    E_MI_APM_TIME_ZONE_GMT_MINUS10_POINT_5_MIN,
    E_MI_APM_TIME_ZONE_GMT_MINUS10_POINT_5_MAX = E_MI_APM_TIME_ZONE_GMT_MINUS10_POINT_5_MIN,

    //GMT - 10
    E_MI_APM_TIME_ZONE_GMT_MINUS10_MIN,
    E_MI_APM_TIME_ZONE_NORTH_AMERICA_HAWAIIAN = E_MI_APM_TIME_ZONE_GMT_MINUS10_MIN,
    E_MI_APM_TIME_ZONE_GMT_MINUS10_MAX = E_MI_APM_TIME_ZONE_NORTH_AMERICA_HAWAIIAN,

    //GMT - 9.5
    E_MI_APM_TIME_ZONE_GMT_MINUS9_POINT_5_MIN,
    E_MI_APM_TIME_ZONE_GMT_MINUS9_POINT_5_MAX = E_MI_APM_TIME_ZONE_GMT_MINUS9_POINT_5_MIN,

    //GMT - 9
    E_MI_APM_TIME_ZONE_GMT_MINUS9_MIN,
    E_MI_APM_TIME_ZONE_NORTH_AMERICA_ALASKAN = E_MI_APM_TIME_ZONE_GMT_MINUS9_MIN,
    E_MI_APM_TIME_ZONE_GMT_MINUS9_MAX = E_MI_APM_TIME_ZONE_NORTH_AMERICA_ALASKAN,

    //GMT - 8.5
    E_MI_APM_TIME_ZONE_GMT_MINUS8_POINT_5_MIN,
    E_MI_APM_TIME_ZONE_GMT_MINUS8_POINT_5_MAX = E_MI_APM_TIME_ZONE_GMT_MINUS8_POINT_5_MIN,

    //GMT - 8
    E_MI_APM_TIME_ZONE_GMT_MINUS8_MIN,
    E_MI_APM_TIME_ZONE_NORTH_AMERICA_PACIFIC = E_MI_APM_TIME_ZONE_GMT_MINUS8_MIN,
    E_MI_APM_TIME_ZONE_GMT_MINUS8_MAX = E_MI_APM_TIME_ZONE_NORTH_AMERICA_PACIFIC,

    //GMT - 7.5
    E_MI_APM_TIME_ZONE_GMT_MINUS7_POINT_5_MIN,
    E_MI_APM_TIME_ZONE_GMT_MINUS7_POINT_5_MAX = E_MI_APM_TIME_ZONE_GMT_MINUS7_POINT_5_MIN,

    //GMT - 7
    E_MI_APM_TIME_ZONE_GMT_MINUS7_MIN,
    E_MI_APM_TIME_ZONE_NORTH_AMERICA_MOUNTAIN = E_MI_APM_TIME_ZONE_GMT_MINUS7_MIN,
    E_MI_APM_TIME_ZONE_GMT_MINUS7_MAX = E_MI_APM_TIME_ZONE_NORTH_AMERICA_MOUNTAIN,

    //GMT - 6.5
    E_MI_APM_TIME_ZONE_GMT_MINUS6_POINT_5_MIN,
    E_MI_APM_TIME_ZONE_GMT_MINUS6_POINT_5_MAX = E_MI_APM_TIME_ZONE_GMT_MINUS6_POINT_5_MIN,

    //GMT - 6
    E_MI_APM_TIME_ZONE_GMT_MINUS6_MIN,
    E_MI_APM_TIME_ZONE_NORTH_AMERICA_CENTRAL = E_MI_APM_TIME_ZONE_GMT_MINUS6_MIN,
    E_MI_APM_TIME_ZONE_GMT_MINUS6_MAX = E_MI_APM_TIME_ZONE_NORTH_AMERICA_CENTRAL,

    //GMT - 5.5
    E_MI_APM_TIME_ZONE_GMT_MINUS5_POINT_5_MIN,
    E_MI_APM_TIME_ZONE_GMT_MINUS5_POINT_5_MAX = E_MI_APM_TIME_ZONE_GMT_MINUS5_POINT_5_MIN,

    //GMT - 5
    E_MI_APM_TIME_ZONE_GMT_MINUS5_MIN,
    E_MI_APM_TIME_ZONE_NORTH_AMERICA_EASTERN=E_MI_APM_TIME_ZONE_GMT_MINUS5_MIN,
    /* THE UTC OF BRAZIL ISDB-T WILL MINUS 3 HOURS*/
    E_MI_APM_TIME_ZONE_AM_WEST,
    E_MI_APM_TIME_ZONE_ACRE,
    /* THE UTC OF BRAZIL ISDB-T WILL MINUS 3 HOURS*/
    E_MI_APM_TIME_ZONE_BOGOTA,
    E_MI_APM_TIME_ZONE_GMT_MINUS5_MAX = E_MI_APM_TIME_ZONE_BOGOTA,

    //GMT - 4.5
    E_MI_APM_TIME_ZONE_GMT_MINUS4_POINT_5_MIN,
    E_MI_APM_TIME_ZONE_GMT_MINUS4_POINT_5_MAX = E_MI_APM_TIME_ZONE_GMT_MINUS4_POINT_5_MIN,

    //GMT - 4
    E_MI_APM_TIME_ZONE_GMT_MINUS4_MIN,
    E_MI_APM_TIME_ZONE_NORTH_AMERICA_ATLANTIC=E_MI_APM_TIME_ZONE_GMT_MINUS4_MIN,
    /* THE UTC OF BRAZIL ISDB-T WILL MINUS 3 HOURS*/
    E_MI_APM_TIME_ZONE_M_GROSSO,
    E_MI_APM_TIME_ZONE_NORTH,
    /* THE UTC OF BRAZIL ISDB-T WILL MINUS 3 HOURS*/
    E_MI_APM_TIME_ZONE_GMT_MINUS4_MAX = E_MI_APM_TIME_ZONE_NORTH,


    //GMT - 3.5
    E_MI_APM_TIME_ZONE_GMT_MINUS3_POINT_5_MIN,
    E_MI_APM_TIME_ZONE_NORTH_AMERICA_NEWFOUNDLAND=E_MI_APM_TIME_ZONE_GMT_MINUS3_POINT_5_MIN,
    E_MI_APM_TIME_ZONE_GMT_MINUS3_POINT_5_MAX = E_MI_APM_TIME_ZONE_NORTH_AMERICA_NEWFOUNDLAND,

    //GMT - 3 BUENOS AIRES
    E_MI_APM_TIME_ZONE_GMT_MINUS3_MIN,
    E_MI_APM_TIME_ZONE_BUENOS_AIRES=E_MI_APM_TIME_ZONE_GMT_MINUS3_MIN,
    /* THE UTC OF BRAZIL ISDB-T WILL MINUS 3 HOURS*/
    E_MI_APM_TIME_ZONE_BRASILIA,
    E_MI_APM_TIME_ZONE_NORTHEAST,
    /* THE UTC OF BRAZIL ISDB-T WILL MINUS 3 HOURS*/
    E_MI_APM_TIME_ZONE_GMT_MINUS3_MAX = E_MI_APM_TIME_ZONE_NORTHEAST,

    //GMT - 2.5
    E_MI_APM_TIME_ZONE_GMT_MINUS2_POINT_5_MIN,
    E_MI_APM_TIME_ZONE_GMT_MINUS2_POINT_5_MAX = E_MI_APM_TIME_ZONE_GMT_MINUS2_POINT_5_MIN,

    //GMT - 2
    E_MI_APM_TIME_ZONE_GMT_MINUS2_MIN,
    /* THE UTC OF BRAZIL ISDB-T WILL MINUS 3 HOURS*/
    E_MI_APM_TIME_ZONE_F_NORONHA = E_MI_APM_TIME_ZONE_GMT_MINUS2_MIN,
    /* THE UTC OF BRAZIL ISDB-T WILL MINUS 3 HOURS*/
    E_MI_APM_TIME_ZONE_GMT_MINUS2_MAX = E_MI_APM_TIME_ZONE_F_NORONHA,

    //GMT - 1.5
    E_MI_APM_TIME_ZONE_GMT_MINUS1_POINT_5_MIN,
    E_MI_APM_TIME_ZONE_GMT_MINUS1_POINT_5_MAX = E_MI_APM_TIME_ZONE_GMT_MINUS1_POINT_5_MIN,

    //GMT - 1
    E_MI_APM_TIME_ZONE_GMT_MINUS1_MIN,
    E_MI_APM_TIME_ZONE_AZORES = E_MI_APM_TIME_ZONE_GMT_MINUS1_MIN,
    E_MI_APM_TIME_ZONE_GMT_MINUS1_MAX = E_MI_APM_TIME_ZONE_AZORES,

    //GMT - 0.5
    E_MI_APM_TIME_ZONE_GMT_MINUS0_POINT_5_MIN,
    E_MI_APM_TIME_ZONE_GMT_MINUS0_POINT_5_MAX = E_MI_APM_TIME_ZONE_GMT_MINUS0_POINT_5_MIN,

    //GMT + 8.45
    E_MI_APM_TIME_ZONE_GMT_8_POINT_45_MIN,
    E_MI_APM_TIME_ZONE_WA_EUCLA = E_MI_APM_TIME_ZONE_GMT_8_POINT_45_MIN,
    E_MI_APM_TIME_ZONE_WA_CAIGUNA,
    E_MI_APM_TIME_ZONE_WA_MADURA,
    E_MI_APM_TIME_ZONE_GMT_8_POINT_45_MAX = E_MI_APM_TIME_ZONE_WA_MADURA,

    //GMT +  12.45
    E_MI_APM_TIME_ZONE_GMT_12_POINT_45_MIN,
    E_MI_APM_TIME_ZONE_CHATHAM = E_MI_APM_TIME_ZONE_GMT_12_POINT_45_MIN,
    E_MI_APM_TIME_ZONE_GMT_12_POINT_45_MAX = E_MI_APM_TIME_ZONE_CHATHAM,

    E_MI_APM_TIME_ZONE_MAX, //E_MI_APM_TIMEZONE MAX
} MI_APM_TimeZone_e;


typedef enum
{
    E_MI_APM_NOTIFICATION_FORMAT_DOLBYVISION    = 0x0,
    E_MI_APM_NOTIFICATION_FORMAT_DOLBYATMOS,
    E_MI_APM_NOTIFICATION_FORMAT_MAX,
} MI_APM_NotificationFormat_e;

typedef enum
{
    E_MI_APM_NOTIFICATION_TYPE_NONE             = 0x0,
    E_MI_APM_NOTIFICATION_TYPE_SUPPRESSIBLE,
    E_MI_APM_NOTIFICATION_TYPE_NONSUPPRESSIBLE,
    E_MI_APM_NOTIFICATION_TYPE_MAX,
} MI_APM_NotificationType_e;

typedef enum
{
    E_MI_APM_LOW_POWER_STANDBY_MODE_STATUS_SUCCESS      = 0x0,
    E_MI_APM_LOW_POWER_STANDBY_MODE_STATUS_ERROR,
    E_MI_APM_LOW_POWER_STANDBY_MODE_STATUS_FORBIDDEN,
    E_MI_APM_LOW_POWER_STANDBY_MODE_STATUS_NOT_SUPPORT,
} MI_APM_LowPowerStandbyModeStatus_e;

typedef enum
{
    E_MI_APM_EXECUTE_APP_MODE_RUN_TO_FOREGROUND  = 0,        /// < Run application in the foreground.
    E_MI_APM_EXECUTE_APP_MODE_RUN_TO_BACKGROUND,             /// < Run application in the background.
    E_MI_APM_EXECUTE_APP_MODE_MAX,
} MI_APM_ExecuteAppMode_e;

typedef enum
{
    E_MI_APM_RESOURCE_NONE            = 0x00000000,
    E_MI_APM_RESOURCE_OVERALL         = 0x00000001,
    E_MI_APM_RESOURCE_VIDEO           = 0x00000002,
    E_MI_APM_RESOURCE_AUDIO           = 0x00000003,
    E_MI_APM_RESOURCE_MAX,
} MI_APM_Resource_e;

typedef enum
{
    E_MI_APM_EVENT_CALLBACK_TYPE_GET_FOCUS = MI_BIT(0),                                      /* Event params is NULL, this will be called after APP is launched */
    E_MI_APM_EVENT_CALLBACK_TYPE_LOSE_FOCUS = MI_BIT(1),                                     /* Event params is NULL, this will be called before APP is going to be killed */
    E_MI_APM_EVENT_CALLBACK_TYPE_NOTIFY_EVENT = MI_BIT(2),                                   /* Event params is MI_APM_NotifyEvent_t, the parameter will be send to APP after APP is launched */
    E_MI_APM_EVENT_CALLBACK_TYPE_GET_RESOURCE = MI_BIT(3),                                   /* Event params is MI_APM_Resource_e type enum, this will be called after APP is launched */
    E_MI_APM_EVENT_CALLBACK_TYPE_LOSE_RESOURCE = MI_BIT(4),                                  /* Event params is MI_APM_Resource_e type enum, this will be called before APP is going to be killed */
    E_MI_APM_EVENT_CALLBACK_TYPE_DESTORY_APP = MI_BIT(5),                                    /* Event params is NULL, this will be called before APP is going to be killed */

    E_MI_APM_EVENT_CALLBACK_TYPE_SYSTEM_GET_LANGUAGE = MI_BIT(8),                            /* To get system language info, please follow iso639_1, iso639_2T, iso639_2B, iso639_3 format, event params is a pointer to MI_U8 */
    E_MI_APM_EVENT_CALLBACK_TYPE_SYSTEM_GET_COUNTRY = MI_BIT(9),                             /* To get system country info, please follow iso3166_1_ALPHA2 or iso3166_1_ALPHA3 format, event params is a pointer to MI_U8 */
    E_MI_APM_EVENT_CALLBACK_TYPE_SYSTEM_GET_TIMEZONE = MI_BIT(10),                           /* To get system timezone info, event params plz refer to enum MI_APM_TimeZone_e for timezone */
    E_MI_APM_EVENT_CALLBACK_TYPE_SYSTEM_GET_PANEL_WIDTH = MI_BIT(11),                        /* To get system panel width info, the unit is millimeter, event params is MI_S32 */
    E_MI_APM_EVENT_CALLBACK_TYPE_SYSTEM_GET_PANEL_HEIGHT = MI_BIT(12),                       /* To get system panel height info, the unit is millimeter, event params is MI_S32 */
    E_MI_APM_EVENT_CALLBACK_TYPE_SYSTEM_GET_WOW_SETTING = MI_BIT(13),                        /* To get Wake on Wireless LAN setting(enable/disable) from system, event params is MI_BOOL */
    E_MI_APM_EVENT_CALLBACK_TYPE_SYSTEM_GET_WOL_SETTING = MI_BIT(14),                        /* To get Wake on LAN setting(enable/disable) from system, event params is MI_BOOL */
    E_MI_APM_EVENT_CALLBACK_TYPE_SYSTEM_GET_AUDIO_DIGITAL_MODE = MI_BIT(15),                 /* To get system audio digital mode, event params plz refer to enum MI_U32 MI_APM_AudioOutDigitalMode_e */
    E_MI_APM_EVENT_CALLBACK_TYPE_SYSTEM_GET_CEC_SAD_INFO = MI_BIT(16),                       /* To get CEC short audio descriptor information, event params is a pointer to struct MI_APM_CecSadInfo_t */
    E_MI_APM_EVENT_CALLBACK_TYPE_SYSTEM_GET_FORMAT_NOTIFICATION = MI_BIT(17),                /* To get format notification from system, event params is a pointer to struct MI_APM_FormatNotificationInfo_t */
    E_MI_APM_EVENT_CALLBACK_TYPE_SYSTEM_GET_LOW_POWER_STANDBY_MODE_STATUS = MI_BIT(18),      /* To get system low power standby mode status, event params plz refer to enum MI_APM_LowPowerStandbyModeStatus_e */
    E_MI_APM_EVENT_CALLBACK_TYPE_SYSTEM_GET_IS_ALWAYS_FRESH_SUPPORT = MI_BIT(19),            /* To get system support always fresh status, event params is MI_BOOL */

    E_MI_APM_EVENT_CALLBACK_TYPE_SYSTEM_SET_AUDIO_DIGITAL_MODE = MI_BIT(24),                 /* To set system audio digital mode, event params plz refer to enum MI_U32 MI_APM_AudioOutDigitalMode_e */
    E_MI_APM_EVENT_CALLBACK_TYPE_SYSTEM_SET_FORMAT_NOTIFICATION = MI_BIT(25),                /* To set format notification to system, event params is a pointer to struct MI_APM_FormatNotificationInfo_t */
    E_MI_APM_EVENT_CALLBACK_TYPE_SYSTEM_SET_TO_LOW_POWER_STANDBY_MODE = MI_BIT(26),          /* To set system to enter low power standby mode, event params is NULL */
} MI_APM_EventCallbackType_e;

typedef enum
{
    E_MI_APM_EVENT_TYPE_BLOCKING_EVENT = 0,          /// < Blocking event
    E_MI_APM_EVENT_TYPE_NONBLOCKING_EVENT,           /// < Non-Blocking event
    E_MI_APM_EVENT_TYPE_MAX,
} MI_APM_EventType_e;

//-------------------------------------------------------------------------------------------------
//  Types - Structures
//-------------------------------------------------------------------------------------------------

typedef struct MI_APM_CecSadInfo_s
{
    MI_APM_CecAudioCodecType_e eFormat;              /// < [IN]: CEC format
    MI_BOOL bDolbyAtmosSupport;                      /// < [OUT]: Dolby Atmos Support
} MI_APM_CecSadInfo_t;


typedef struct MI_APM_FormatNotificationInfo_s
{
    MI_APM_NotificationFormat_e eNotificationFormat; /// < [IN]: Notification Format
    MI_APM_NotificationType_e eNotificationType;     /// < [OUT]: Notification Type
    MI_BOOL bNotificationFormatEnable;               /// < [IN]: Notification Format Enable
    MI_U8 *pszAppName;                               /// < [IN]: Application name.
} MI_APM_FormatNotificationInfo_t;

typedef struct MI_APM_NotifyEvent_s
{
    MI_APM_EventType_e eEventType;                    /// < [IN]: Event notify type.
    MI_U32 u32Id;                                     /// < [IN]: Event id, defined by each APP.
    MI_U8 u8DataLen;                                  /// < [IN]: Event Data length.
    MI_U8 au8Data[MI_APM_EVENT_SIZE];                 /// < [IN]: Event Data.
    MI_U32 u32PayloadSize;                            /// < [IN]: Size of data payload(maximum size is 1M-8K)
    void *pPayload;                                   /// < [IN]: Data payload.
} MI_APM_NotifyEvent_t;

//------------------------------------------------------------------------------
/// @brief Event callback function for a registered APM instance.
/// @param[in] hApm: An instance of a created APM module.
/// @param[in] u32Event: To identify callback event in MI_APM_EventCallbackType_e.
/// @param[in] pEventParams: Event parameters for callback function. please see the description of enum MI_APM_EventCallbackType_e.
/// @param[in] pUserParams: User defined parameters for callback function. Reserve for the future.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
typedef MI_RESULT (*MI_APM_EventCallback)(MI_HANDLE hApm, MI_U32 u32Event, void *pEventParams, void *pUserParams);

typedef struct MI_APM_CallbackInputParams_s
{
    MI_APM_EventCallback pfEventCallback;                  /// < [IN]: Callback function pointer.
    MI_U32 u32EventFlags;                                  /// < [IN]: Registered events which are bitwise OR operation.
    void *pUserParams;                                     /// < [IN]: For passing user-defined parameters.
} MI_APM_CallbackInputParams_t;

typedef struct MI_APM_InitParams_s
{
    MI_U8 u8Reserved;      /// < Reserve for the future.
} MI_APM_InitParams_t;

typedef struct MI_APM_OpenParams_s
{
    MI_APM_CallbackInputParams_t *pstCallbackInputParams;   /// < [IN]: the callback parameters.
} MI_APM_OpenParams_t;

typedef struct MI_APM_RunAppParams_s
{
    MI_APM_ExecuteAppMode_e eMode;      /// < [IN]: Run application mode.
    MI_U8 u8AppNameLen;                 /// < [IN]: Application name length.
    MI_U8 *pszAppName;                  /// < [IN]: Application name.
    MI_U32 u32ParamsLen;                /// < [IN]: Parameter length.
    MI_U8 *pu8Params;                   /// < [IN]: The parameter will be sent to application by notify event.
} MI_APM_RunAppParams_t;

typedef struct MI_APM_ExitAppParams_s
{
    MI_U8 u8AppNameLen;                 /// < [IN]: Application name length.
    MI_U8 *pszAppName;                  /// < [IN]: Application name.
    MI_U32 u32ExitEventId;              /// < [IN]: Exit event id.
    MI_U8 u8DataLen;                    /// < [IN]: Event data length.
    MI_U8 au8Data[MI_APM_EVENT_SIZE];   /// < [IN]: Event data.
} MI_APM_ExitAppParams_t;

typedef struct MI_APM_SuspendParams_s
{
    MI_U8 u8Reserved;                   /// < Reserve for the future.
} MI_APM_SuspendParams_t;

typedef struct MI_APM_ResumeParams_s
{
    MI_U8 u8Reserved;                   /// < Reserve for the future.
} MI_APM_ResumeParams_t;

//-------------------------------------------------------------------------------------------------
//  Functions
//-------------------------------------------------------------------------------------------------

//------------------------------------------------------------------------------
/// @brief Initialize APM module.
/// @param[in] pstInitParams: A pointer to structure MI_APM_InitParams_t for initialization.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_APM_Init(const MI_APM_InitParams_t *pstInitParams);

//------------------------------------------------------------------------------
/// @brief Finalize APM module.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_APM_DeInit(void);

//------------------------------------------------------------------------------
/// @brief Open a APM handle and join to APM service.
/// @param[in] pstOpenParams: A pointer to structure MI_APM_OpenParams_t for opening APM module.
/// @param[out] phApm: A handle pointer to retrieve an instance of a created APM module.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_PARAMETER: Parameters are invalid.
/// @return MI_ERR_RESOURCES: No available resource.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_APM_Open(const MI_APM_OpenParams_t *pstOpenParams, MI_HANDLE *phApm);

//--------------------------------------------------- ---------------------------
/// @brief Close a APM handle and leave APM service.
/// @param[in] hApm: An instance of a created APM module.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_APM_Close(MI_HANDLE hApm);

//------------------------------------------------------------------------------
/// @brief Request to run the specific application.
/// @param[in] hApm: A Handle of a created APM instance.
/// @param[in] pstAppParams: A pointer to structure MI_APM_RunAppParams_t for running the specific application.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters are invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_APM_RequestToRunApp(MI_HANDLE hApm, MI_APM_RunAppParams_t *pstAppParams);

//------------------------------------------------------------------------------
/// @brief Request to exit the specific application.
/// @param[in] hApm: A Handle of a created APM instance.
/// @param[in] pstAppParams: A pointer to structure MI_APM_ExitAppParams_t for exiting the specific application.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters are invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_APM_RequestToExitApp(MI_HANDLE hApm, MI_APM_ExitAppParams_t *pstAppParams);

//------------------------------------------------------------------------------
/// @brief Send suspend event to all running applications and notify them that system is going to suspend. This API should be used before system suspend.
/// @param[in] hApm: A Handle of a created APM instance.
/// @param[in] pstSuspendParams: A pointer to structure MI_APM_SuspendParams_t for suspending all running applications.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters are invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_APM_RequestToSuspend(MI_HANDLE hApm, MI_APM_SuspendParams_t *pstSuspendParams);

//------------------------------------------------------------------------------
/// @brief Send resume event to all running applications.
/// @param[in] hApm: A Handle of a created APM instance.
/// @param[in] pstResumeParams: A pointer to structure MI_APM_ResumeParams_t for resuming all running applications.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters are invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_APM_RequestToResume(MI_HANDLE hApm, MI_APM_ResumeParams_t *pstResumeParams);

//------------------------------------------------------------------------------
/// @brief Set APM debug level.
/// @param[in] u32DebugLevel: Debug level defined in enum type MI_DBG_LEVEL_e
/// @return MI_OK: Set debug level success.
//------------------------------------------------------------------------------
MI_RESULT MI_APM_SetDebugLevel(MI_DBG_LEVEL u32DebugLevel);

#ifdef __cplusplus
}
#endif

#endif
