/*------------------------------------------------------------------------------
 * MediaTek Inc. (C) 2018. All rights reserved.
 *
 * Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 *----------------------------------------------------------------------------*/
//----------------------------------------------------------------------------------------
//  GetXxx/SetXxx and GetAttr/SetAttr coexit
//----------------------------------------------------------------------------------------

#ifndef _MI_VIDEO_H_
#define _MI_VIDEO_H_

#ifdef __cplusplus
extern "C" {
#endif

/// Define callback function type.
typedef MI_RESULT (* MI_VIDEO_EventCallback)(MI_HANDLE hVidDec, MI_U32 u32Event, void * pEventParams, void * pUserParams);

typedef MI_RESULT (* MI_VIDEO_PushClearPatternCallback)(MI_U8 *pu8Buf, MI_U32 u32BufSize, void *pUserParams);

//CC callback event, MI_VIDEO_CcEventCallbackParams_t::u32EventFlags used.
typedef enum
{
    E_MI_VIDEO_CC_CALLBACK_EVENT_DATA_FOUND_608 = MI_BIT(0), ///< CC 608 data found, parameter type is a pointer to MI_VIDEO_CcDataBuf_t
    E_MI_VIDEO_CC_CALLBACK_EVENT_DATA_FOUND_708 = MI_BIT(1), ///< CC 708 data found, parameter type is a pointer to MI_VIDEO_CcDataBuf_t
    E_MI_VIDEO_CC_CALLBACK_EVENT_DATA_FOUND_RAW_DATA = MI_BIT(2), ///< CC user raw data found, parameter type is a pointer to MI_VIDEO_CcDataBuf_t
} MI_VIDEO_CcCallbackEvent_e;

/// MI codec type enumerator (Copy from apiVDEC_EX.h VDEC_CodecType)
typedef enum
{
    ///Unsupported codec type
    E_MI_VIDEO_CODEC_TYPE_NONE = 0,
    ///MPEG-1 / MPEG-2
    E_MI_VIDEO_CODEC_TYPE_MPEG2,
    ///H263 (short video header)
    E_MI_VIDEO_CODEC_TYPE_H263,
    ///MPEG4 (default)
    E_MI_VIDEO_CODEC_TYPE_MPEG4,
    ///MPEG4 (Divx311)
    E_MI_VIDEO_CODEC_TYPE_DIVX311,
    ///MPEG4 (Divx412)
    E_MI_VIDEO_CODEC_TYPE_DIVX412,
    ///FLV
    E_MI_VIDEO_CODEC_TYPE_FLV,
    ///VC1 advanced profile (VC1)
    E_MI_VIDEO_CODEC_TYPE_VC1_ADV,
    ///VC1 main profile (RCV)
    E_MI_VIDEO_CODEC_TYPE_VC1_MAIN,
    ///Real Video version 8
    E_MI_VIDEO_CODEC_TYPE_RV8,
    ///Real Video version 9 and 10
    E_MI_VIDEO_CODEC_TYPE_RV9,
    ///H264
    E_MI_VIDEO_CODEC_TYPE_H264,
    ///AVS
    E_MI_VIDEO_CODEC_TYPE_AVS,
    ///MJPEG
    E_MI_VIDEO_CODEC_TYPE_MJPEG,
    ///MVC
    E_MI_VIDEO_CODEC_TYPE_MVC,
    ///VP8
    E_MI_VIDEO_CODEC_TYPE_VP8,
    ///HEVC
    E_MI_VIDEO_CODEC_TYPE_HEVC,
    ///VP9
    E_MI_VIDEO_CODEC_TYPE_VP9,
    ///HEVC_DV
    E_MI_VIDEO_CODEC_TYPE_HEVC_DV,
    ///H264_DV
    E_MI_VIDEO_CODEC_TYPE_H264_DV,
    ///AVS2
    E_MI_VIDEO_CODEC_TYPE_AVS2,
    ///DIVX5
    E_MI_VIDEO_CODEC_TYPE_DIVX5,
    ///AV1
    E_MI_VIDEO_CODEC_TYPE_AV1,
    /// DIVX h264
    E_MI_VIDEO_CODEC_TYPE_DIVX_H264,
    /// DIVX HEVC
    E_MI_VIDEO_CODEC_TYPE_DIVX_HEVC,
    ///max
    E_MI_VIDEO_CODEC_TYPE_MAX
} MI_VIDEO_CodecType_e;

/// Stream type
typedef enum
{
    ///Live stream
    E_MI_VIDEO_STREAM_LIVE = 0,
    ///TS file
    E_MI_VIDEO_STREAM_TSFILE,
    ///PES file
    E_MI_VIDEO_STREAM_PES,
    ///ES file
    E_MI_VIDEO_STREAM_ES,
    ///PVR file
    E_MI_VIDEO_STREAM_PVR,
    ///Stream type max
    E_MI_VIDEO_STREAM_MAX
} MI_VIDEO_StreamType_e;

/// timestamp type of command queue
typedef enum
{
    ///without timestamp information
    E_MI_VIDEO_TIME_STAMP_NONE = 0,
    ///PTS (Presentation Time Stamp)
    E_MI_VIDEO_TIME_STAMP_PTS,
    ///DTS (Decode Time Stamp)
    E_MI_VIDEO_TIME_STAMP_DTS,
    ///STS (Sorted Time Stamp)
    E_MI_VIDEO_TIME_STAMP_STS,
    ///PTS_RVU (Presentation Time Stamp)
    E_MI_VIDEO_TIME_STAMP_PTS_MPEG_DIRECTV_SD,
    ///DTS_RVU (Decode Time Stamp)
    E_MI_VIDEO_TIME_STAMP_DTS_MPEG_DIRECTV_SD,
} MI_VIDEO_TimeStampType_e;

typedef enum
{
   /// Get wall clock from system time, unit: ns
    E_MI_VIDEO_WALL_CLOCK_TYPE_SYSTEM_TIME,
} MI_VIDEO_WallClockType_e;

/// Parameter type
typedef enum
{
    ///Attr type get/set min
    E_MI_VIDEO_ATTR_TYPE_MIN = 0,
    ///Set/Get stream type, attribute type is a pointer to MI_VIDEO_StreamType_e
    E_MI_VIDEO_ATTR_TYPE_STREAM_TYPE = E_MI_VIDEO_ATTR_TYPE_MIN,
    ///< Set/Get video code data, attribute type is a pointer to struct MI_VIDEO_CodecParam_t
    E_MI_VIDEO_ATTR_TYPE_CODEC_DATA,
    ///Attr type get/set max
    E_MI_VIDEO_ATTR_TYPE_MAX,

    ///Attr type get min
    E_MI_VIDEO_ATTR_TYPE_GET_MIN = 0x100,
    ///Get stream Id, attribute type is a pointer to MI_VIDEO_StreamId_t
    E_MI_VIDEO_ATTR_TYPE_GET_STREAM_ID = E_MI_VIDEO_ATTR_TYPE_GET_MIN,
    ///Get video decode/error/skip/drop count, attribute type is a pointer to MI_VIDEO_FrameCntInfo_t
    E_MI_VIDEO_ATTR_TYPE_GET_FRAME_COUNT,
    ///Get video 32 bitspts with unit ms, attribute type is a pointer to MI_U32
    E_MI_VIDEO_ATTR_TYPE_GET_PTS,
    ///Get ES buffer info, attribute type is a pointer to MI_VIDEO_BitStrmInfo_t
    E_MI_VIDEO_ATTR_TYPE_GET_ESBUF_INFO,
    ///Get decoder info, attribute type is a pointer to MI_VIDEO_DecInfo_t
    E_MI_VIDEO_ATTR_TYPE_GET_DEC_INFO,
    ///Get video frame ready or not, attribute type is a pointer to MI_BOOL
    E_MI_VIDEO_ATTR_TYPE_GET_FRAME_READY,
    ///Get video reach sync or not, attribute type is a pointer to MI_BOOL
    E_MI_VIDEO_ATTR_TYPE_GET_REACH_SYNC,
    ///Get video decode status, attribute type is a pointer to MI_VIDEO_VdecStatus_t
    E_MI_VIDEO_ATTR_TYPE_GET_DEC_STATUS,
    ///Get video codec type, attribute type is a pointer to MI_VIDEO_CodecType_e
    E_MI_VIDEO_ATTR_TYPE_GET_CODEC_TYPE,
    ///Get video 33bits pts with unit 90KHz, attribute type is a pointer to MI_U64
    E_MI_VIDEO_ATTR_TYPE_GET_PTS64,
    /// Get video latest PTS at parsing time in parser, attribute type is a pointer to MI_U64
    E_MI_VIDEO_ATTR_TYPE_GET_PARSER_PTS64,
    /// Get video current PTS and related wallclock
    /// param[in] pInputParams of the attribute type is a pointer to MI_VIDEO_WallClockType_e
    /// param[out] pOutputParams of the attribute type is a pointer to MI_VIDEO_GetPtsInfo_t
    E_MI_VIDEO_ATTR_TYPE_GET_PTS_INFO,
    ///Attr type get max
    E_MI_VIDEO_ATTR_TYPE_GET_MAX,

    ///Attr type set min
    E_MI_VIDEO_ATTR_TYPE_SET_MIN = 0x200,
    ///Drop error frame, attribute type is a pointer to MI_BOOL
    E_MI_VIDEO_ATTR_TYPE_DROP_ERROR = E_MI_VIDEO_ATTR_TYPE_SET_MIN,
    ///< Set video error tolerance to drop current frame, attribute type is a pointer to struct MI_VIDEO_ErrorTolerance_t
    E_MI_VIDEO_ATTR_TYPE_DROP_ERROR_TOLERANCE,
    ///Set time stamp type, attribute type is a pointer to MI_VIDEO_TimeStampType_e
    E_MI_VIDEO_ATTR_TYPE_TIME_STAMP_TYPE,
    ///< set video FIFO control by MI_VIDEO or porting layer, attribute type is a pointer to MI_VIDEO_FifoCtrl_e
    E_MI_VIDEO_ATTR_TYPE_FIFO_CTRL,
    ///< video latency control, attribute type is a pointer to struct MI_VIDEO_LatencyCtrl_t. Set NULL for clear all the configuration.
    E_MI_VIDEO_ATTR_TYPE_LATENCY_CTRL,
    ///< [Set] Specifies video frame info for caculate decoder loading, attribute type is a pointer to struct MI_VIDEO_DecoderLoadingParams_t.
    ///< [Get] Get decoder loading from VDEC, attribute type is a pointer to struct MI_VIDEO_DecoderLoadingParams_t.
    E_MI_VIDEO_ATTR_TYPE_DECODER_LOADING,

    ///Attr type set max
    E_MI_VIDEO_ATTR_TYPE_SET_MAX,
} MI_VIDEO_AttrType_e;

typedef enum
{
    E_MI_VIDEO_FIFO_CTRL_AUTO_ENABLE = 0,
    E_MI_VIDEO_FIFO_CTRL_MANUAL_ENABLE,
    E_MI_VIDEO_FIFO_CTRL_MANUAL_DISABLE,
} MI_VIDEO_FifoCtrl_e;

/// Define Vidoe related event
typedef enum
{
    ///Decode error
    E_MI_VIDEO_CALLBACK_EVENT_DECODE_ERROR   = MI_BIT(0),
    ///First frame event
    E_MI_VIDEO_CALLBACK_EVENT_FIRST_FRAME    = MI_BIT(1),
    ///One frame decoded event
    E_MI_VIDEO_CALLBACK_EVENT_DECODE_ONE_FRAME = MI_BIT(2),
    ///API MI_VIDEO_Step done event, and the callback event parameter(pEventParams) is a pointer to struct MI_VIDEO_StepParams_t
    E_MI_VIDEO_CALLBACK_EVENT_STEP_DONE = MI_BIT(3),
    ///API MI_VIDEO_SeekToPts done event, and the callback event parameter(pEventParams) is a pointer to struct MI_VIDEO_SeekParams_t
    E_MI_VIDEO_CALLBACK_EVENT_SEEK_DONE = MI_BIT(4),
    ///First frame displayed event
    E_MI_VIDEO_CALLBACK_EVENT_DISPLAY_FIRST_FRAME = MI_BIT(5),
    ///Last frame displayed event, need with clear API.
    E_MI_VIDEO_CALLBACK_EVENT_DISPLAY_LAST_FRAME = MI_BIT(6),
    ///Decoder overloading event, use specified frame info for cacluate decoder loading if E_MI_VIDEO_ATTR_TYPE_DECODER_LOADING is set,
    ///And the callback event parameter(pEventParams) is a pointer to struct MI_VIDEO_DecoderOverloadingList_t
    E_MI_VIDEO_CALLBACK_EVENT_DECODER_OVERLOADING = MI_BIT(7),
    ///Event number
    E_MI_VIDEO_CALLBACK_EVENT_ALL            = 0xFFFFFFFF
} MI_VIDEO_CallbackEvent_e;

/// Vdec stage (Copy from apiVDEC_EX.h VDEC_EX_Stage)
typedef enum
{
    /// Stop
    E_MI_VIDEO_VDEC_STAGE_STOP = 0,
    /// Init
    E_MI_VIDEO_VDEC_STAGE_INIT,
    /// Play
    E_MI_VIDEO_VDEC_STAGE_PLAY,
    /// Pause
    E_MI_VIDEO_VDEC_STAGE_PAUSE,
} MI_VIDEO_VdecStage_e;

/// Video display speed
typedef enum
{
    ///Normal play
    E_MI_VIDEO_NORMAL_SPEED_1X = 0,

    ///Fast Speed min
    E_MI_VIDEO_FAST_SPEED_MIN = 0x100,
    ///Fast speed 2x
    E_MI_VIDEO_FAST_SPEED_2X = E_MI_VIDEO_FAST_SPEED_MIN,
    ///Fast speed 4x
    E_MI_VIDEO_FAST_SPEED_4X,
    ///Fast speed 8x
    E_MI_VIDEO_FAST_SPEED_8X,
    ///Fast speed 16x
    E_MI_VIDEO_FAST_SPEED_16X,
    ///Fast speed 32x
    E_MI_VIDEO_FAST_SPEED_32X,
    ///Fast speed Max
    E_MI_VIDEO_FAST_SPEED_MAX,

    ///Slow speed min
    E_MI_VIDEO_SLOW_SPEED_MIN = 0x200,
    ///Slow speed 2x
    E_MI_VIDEO_SLOW_SPEED_2X = E_MI_VIDEO_SLOW_SPEED_MIN,
    ///Slow speed 4x
    E_MI_VIDEO_SLOW_SPEED_4X,
    ///Slow speed 8x
    E_MI_VIDEO_SLOW_SPEED_8X,
    ///Slow speed 16x
    E_MI_VIDEO_SLOW_SPEED_16X,
    ///Slow speed 32x
    E_MI_VIDEO_SLOW_SPEED_32X,
    ///Slow speed max
    E_MI_VIDEO_SLOW_SPEED_MAX
} MI_VIDEO_Speed_e;

/// Video trick mode    (Copy from apiVDEC_EX.h VDEC_DispInfo)
typedef enum
{
    ///Decode all
    E_MI_VIDEO_TRICK_DEC_ALL = 0,
    ///Decode I/P frame
    E_MI_VIDEO_TRICK_DEC_IP,
    ///Decode I frame
    E_MI_VIDEO_TRICK_DEC_I,
    ///Trick decode Max
    E_MI_VIDEO_TRICK_DEC_MAX
} MI_VIDEO_TrickDec_e;

typedef enum    // For MI_VIDEO_FrameFormat_t
{
    E_MI_VIDEO_FRAME_TYPE_I,   //Indicate this frame type is I.
    E_MI_VIDEO_FRAME_TYPE_P,  //Indicate this frame type is P.
    E_MI_VIDEO_FRAME_TYPE_B,  //Indicate this frame type is B.
    E_MI_VIDEO_FRAME_TYPE_OTHER,  //Not used yet.
    E_MI_VIDEO_FRAME_TYPE_MAX,
}MI_VIDEO_FrameType_e;


typedef enum    // For MI_VIDEO_FrameFormat_t
{
    E_MI_VIDEO_FRAME_FIELD_TYPE_NONE,   //Not used yet.
    E_MI_VIDEO_FRAME_FIELD_TYPE_TOP,   //Indicate this frame field type is top filed.
    E_MI_VIDEO_FRAME_FIELD_TYPE_BOTTOM,   //Indicate this frame field type is bottom field.
    E_MI_VIDEO_FRAME_FIELD_TYPE_BOTH,   //Indicate this frame field type contain both field.
    E_MI_VIDEO_FRAME_FIELD_TYPE_MAX,
}MI_VIDEO_FrameFieldType_e;

typedef enum
{
    E_MI_VIDEO_SCAN_TYPE_PROGRESSIVE = 0,  //Indicate this frame info contain a progressive frame.
    E_MI_VIDEO_SCAN_TYPE_INTERLACE_FRAME, //Indicate this frame info contain a interlace frame
    E_MI_VIDEO_SCAN_TYPE_INTERLACE_FIELD,  //Indicate this frame info contain a interlace field
    E_MI_VIDEO_SCAN_TYPE_MAX,
}MI_VIDEO_ScanType_e;

typedef enum
{
    E_MI_VIDEO_RENDER_MODE_HARDWIRE,     //decoder output data to hw automatically
    E_MI_VIDEO_RENDER_MODE_HANDSHAKE,    //decoder output data to user manually
}MI_VIDEO_RenderMode_e;

typedef enum
{
    E_MI_VIDEO_FRAME_TILE_BLOCK_NONE  = 0x0,
    E_MI_VIDEO_FRAME_TILE_BLOCK_16X16 = 0x1,
    E_MI_VIDEO_FRAME_TILE_BLOCK_16X32 = 0x2,
    E_MI_VIDEO_FRAME_TILE_BLOCK_32X16 = 0x3,
    E_MI_VIDEO_FRAME_TILE_BLOCK_32X32 = 0x4,
    E_MI_VIDEO_FRAME_TILE_BLOCK_4X2_COMPRESSION_MODE = 0x5,
    E_MI_VIDEO_FRAME_TILE_BLOCK_8X1_COMPRESSION_MODE = 0x6,
    E_MI_VIDEO_FRAME_TILE_BLOCK_32X16_82PACK = 0x7,
    E_MI_VIDEO_FRAME_TILE_BLOCK_MAX,
} MI_VIDEO_FrameTileBlock_e;

typedef enum
{
    E_MI_VIDEO_COLOR_FORMAT_YUV420,                 /// YUV420. (NV12)
    E_MI_VIDEO_COLOR_FORMAT_YUV422,                 /// YUV422. (YUYV)
    E_MI_VIDEO_COLOR_FORMAT_RGB565,                 /// RGB565.
    E_MI_VIDEO_COLOR_FORMAT_ARGB8888,               /// ARGB8888.
    E_MI_VIDEO_COLOR_FORMAT_MAX,
} MI_VIDEO_ColorFormat_e;

typedef enum
{
    E_MI_VIDEO_AFD_CODE_NONE = 0x0,         /// No AFD code value
    E_MI_VIDEO_AFD_CODE_16_9_TOP = 0x2,     /// 16:9 image put in top.
    E_MI_VIDEO_AFD_CODE_14_9_TOP = 0x3,     /// 14:9 image put in top.
    E_MI_VIDEO_AFD_CODE_LARGER_16_9_CENTER = 0x4,   /// Box larger than 16:9 image put in center.
    E_MI_VIDEO_AFD_CODE_SAME_AS_PICTURE = 0x8,      /// Full Frame image, same as the frame (4:3 or 16:9).
    E_MI_VIDEO_AFD_CODE_4_3_CENTER = 0x9,           /// 4:3 Image: Full Frame in 4:3 frame, Pillarbox in 16:9 frame.
    E_MI_VIDEO_AFD_CODE_16_9_CENTER = 0xA,          /// 16:9 Image: Letterbox in 4:3 frame, Full Frame in 16:9 frame.
    E_MI_VIDEO_AFD_CODE_14_9_CENTER = 0xB,          /// 14:9 Pillarbox/Letterbox image
    E_MI_VIDEO_AFD_CODE_4_3_WITH_SHOOT_14_9_CENTER = 0xD,   /// 4:3 with shoot and protect 14:9 centre.
    E_MI_VIDEO_AFD_CODE_16_9_WITH_SHOOT_14_9_CENTER = 0xE,  /// 16:9 with shoot and protect 14:9 centre.
    E_MI_VIDEO_AFD_CODE_16_9_WITH_SHOOT_4_3_CENTER = 0xF,   /// 16:9 with shoot and protect 4:3 centre.
} MI_VIDEO_AfdCode_e;

// Seek type
typedef enum
{
   E_MI_VIDEO_SEEK_TYPE_DECODE = 0,   // Decoder will start decode with full speed until target PTS is reached (equal or larger), and display from I/P/B frame after reached.
   E_MI_VIDEO_SEEK_TYPE_SKIP_DECODE,  // Decoder will skip all frames before target PTS is reached  (equal or larger),  and display from I frame after reached.
   E_MI_VIDEO_SEEK_TYPE_MAX,
} MI_VIDEO_SeekType_e;

// Step type
typedef enum
{
   E_MI_VIDEO_STEP_TYPE_DECODE_FRAME = 0, // Step the decode frame
   E_MI_VIDEO_STEP_TYPE_DISP_FRAME,       // Step the display frame
   E_MI_VIDEO_STEP_TYPE_MAX,
} MI_VIDEO_StepType_e;

// Video debug info  type
typedef enum
{
    E_MI_VIDEO_DBG_INFO_NONE = 0,
    E_MI_VIDEO_DBG_INFO_SETUP = MI_BIT(0),
    E_MI_VIDEO_DBG_INFO_AVSYNC = MI_BIT(1),
    E_MI_VIDEO_DBG_INFO_SETTING = MI_BIT(2),
    E_MI_VIDEO_DBG_INFO_EVENT = MI_BIT(3),
    E_MI_VIDEO_DBG_INFO_FLIP = MI_BIT(4),
    E_MI_VIDEO_DBG_INFO_INTERNAL = MI_BIT(30),
    E_MI_VIDEO_DBG_INFO_DUMPSTACK = MI_BIT(31),
} MI_VIDEO_DbgInfoType_e;

/// Video capability
typedef struct MI_VIDEO_Caps_s
{
    ///[OUT]:Number of max supported video decoder
    MI_U32 u32MaxSupportVidDecNum;
    ///[OUT]:Bit-wise supported video codecs defined by MI_VIDEO_CodecType_e
    MI_U32 u32SupportVidCodecs;
} MI_VIDEO_Caps_t;

/// Video init parameter
typedef struct MI_VIDEO_InitParams_s
{
    ///Reserved
    MI_U8 u8Reserved;
} MI_VIDEO_InitParams_t;

/// Video stream Id    (Copy from apiVDEC_EX.h VDEC_StreamId)
typedef struct MI_VIDEO_StreamId_s
{
    MI_U32 u32Version;          ///[OUT]: version
    MI_U32 u32Id;               ///[OUT]: Id
} MI_VIDEO_StreamId_t;

/// Video Open Parameters
typedef struct MI_VIDEO_OpenParams_s
{
    ///[IN]: video handle with string name.
    MI_U8 * pszName;
    ///[IN]: Video stream type
    MI_VIDEO_StreamType_e eVidStreamType;
    ///[IN]: Force interlace
    MI_BOOL bForceInterlace;
    ///[IN]: Render mode
    MI_VIDEO_RenderMode_e eRenderMode;
} MI_VIDEO_OpenParams_t;

/// Video Query Handle Parameters
typedef struct MI_VIDEO_QueryHandleParams_s
{
    MI_U8 * pszName;                           ///[IN]: video handle with string name.
}MI_VIDEO_QueryHandleParams_t;

/// Video Start Parameters
typedef struct MI_VIDEO_StartParams_s
{
    ///[IN]: Codec type
    MI_VIDEO_CodecType_e eCodecType;
}MI_VIDEO_StartParams_t;

/// Clear Params
typedef struct MI_VIDEO_ClearParams_s
{
    ///[IN]:  pid of video ts packet
    MI_U16 u16VideoPid;
    ///[IN]: size of per video ts packet
    MI_U8 u8TsPacketSize;
    ///[IN]: user data for pfPushClearPattern
    void *pUserParams;
    ///[IN]:  function pointer for pushing clear pattern
    MI_VIDEO_PushClearPatternCallback pfPushClearPattern;

    MI_VIDEO_VdecStage_e eLastStage;
} MI_VIDEO_ClearParams_t;

/// Video decoder status    (Copy from apiVDEC_EX.h VDEC_EX_Status)
typedef struct MI_VIDEO_VdecStatus_s
{
    ///[OUT]: Decoder is init or not
    MI_BOOL bInit;
    ///[OUT]: Decoder is idle or not
    MI_BOOL bIdle;
    ///[OUT]: Vdec stage
    MI_VIDEO_VdecStage_e eStage;
} MI_VIDEO_VdecStatus_t;

/// Video information (Copy from apiVDEC_EX.h VDEC_EX_DispInfo)
typedef struct MI_VIDEO_DecInfo_s
{
    ///[OUT]: bitstream horizontal size
    MI_U16 u16HorSize;
    ///[OUT]: bitstream vertical size
    MI_U16 u16VerSize;
    ///[OUT]: frame rate
    MI_U32 u32FrameRate;
    ///[OUT]: interlace flag
    MI_U8 u8Interlace;
    ///[OUT]: right cropping
    MI_U16 u16CropRight;
    ///[OUT]: left cropping
    MI_U16 u16CropLeft;
    ///[OUT]: bottom cropping
    MI_U16 u16CropBottom;
    ///[OUT]: top cropping
    MI_U16 u16CropTop;
    ///Display width. (Display Aspect Ratio(DAR) width).
    MI_U32 u32AspectWidth;
    ///Display height. (Display Aspect Ratio(DAR) height)
    MI_U32 u32AspectHeight;
    ///Sample aspect rate(SAR) width.(i.e Pixel Aspect Ratio(PAR) Width).
    MI_U16 u16SarWidth;
    ///Sample aspect rate(SAR) height. (i.e Pixel Aspect Ratio(PAR) Height).
    MI_U16 u16SarHeight;
    ///Active Format Description(AFD) Code. Accroding to ETSI TS 101 154.
    MI_VIDEO_AfdCode_e eAfdCode;
} MI_VIDEO_DecInfo_t;

/// ES bit-stream information
typedef struct MI_VIDEO_BitStrmInfo_s
{
    ///[OUT]: VDEC bitstream buffer address
    MI_VIRT virtBitstreamBufAddr;
    ///[OUT]: VDEC bitstream buffer size
    MI_U32 u32BitstreamBufSize;
    ///[OUT]: VDEC process buffer size
    MI_U32 u32DrvProcBufSize;
    ///[OUT]: ES buffer read address
    MI_PHY phyReadAddr;
    ///[OUT]: ES buffer write address
    MI_PHY phyWriteAddr;
    ///[OUT]: ES buffer vacancy
    MI_U32 u32Vacancy;
    ///[OUT]: ES bps(Live only)
    MI_U32 u32BitRate;
} MI_VIDEO_BitStrmInfo_t;

/// IFrame data
typedef struct MI_VIDEO_IFrameData_s
{
    ///[IN]: Buffer address
    void *pBuffer;
    ///[IN]: Data size
    MI_U32 u32Size;
    ///[IN]: IFrame codec type
    MI_VIDEO_CodecType_e eCodecType;
} MI_VIDEO_IFrameData_t;

/// Video frame count info
typedef struct MI_VIDEO_FrameCntInfo_s
{
    ///[OUT]: Decode count
    MI_U32 u32DecFrameCnt;
    ///[OUT]: Error count
    MI_U32 u32ErrFrameCnt;
    ///[OUT]: Skip count
    MI_U32 u32SkipFrameCnt;
    ///[OUT]: Drop count
    MI_U32 u32DropFrameCnt;
    ///[OUT]: Disp count
    MI_U32 u32DispFrameCnt;
} MI_VIDEO_FrameCntInfo_t;

/// Callback function parameter struct.
typedef struct MI_VIDEO_CallbackInputParams_s
{
    MI_U64 u64CallbackId;                       ///[IN]: for multi-callback, use 0 for first register or single callback
    MI_VIDEO_EventCallback pfEventCallback;     ///[IN]: callback function pointer.
    MI_U32 u32EventFlags;                       ///[IN]: registered events which are bitwise OR operation.Event flags defined by MI_VIDEO_CallbackEvent_e
    void *pUserParams;                            ///[IN]: for passing user-defined parameters.
} MI_VIDEO_CallbackInputParams_t;

typedef struct MI_VIDEO_CallbackOutputParams_s
{
    MI_U64 u64CallbackId;                       ///[OUT]: the returned ID for update or unregister callback.
}MI_VIDEO_CallbackOutputParams_t;

/// Mmv3 codec data
typedef struct MI_VIDEO_Wmv3CodecData_s
{
    ///[IN]: Video width
    MI_U16 u16Width;
    ///[IN]:Video height
    MI_U16 u16Height;
    ///[IN]:Frame rate
    MI_U32 u32FrameRate;
    ///[IN]:Frame rate base
    MI_U32 u32FrameRateBase;
    ///[IN]:Header data
    MI_U8 au8SeqHdrData[4];    /// VIDEO_DECODER_VC1_MAIN, 4bytes Table 263: Sequence Header Data Structure STRUCT_C for Simple and Main Profiles
    ///[IN]:Data size
    MI_U32 u32DataSize;
} MI_VIDEO_Wmv3CodecData_t;

/// Divx311 codec data
typedef struct MI_VIDEO_Divx311CodecData_s
{
    ///[IN]:Video width
    MI_U16 u16Width;
    ///[IN]:Video height
    MI_U16 u16Height;
    ///[IN]:Frame rate
    MI_U32 u32FrameRate;
    ///[IN]:Frame rate base
    MI_U32 u32FrameRateBase;
} MI_VIDEO_Divx311CodecData_t;

///Private codec data
typedef struct MI_VIDEO_PrivateCodecData_s
{
    ///[IN]:Video width
    MI_U16 u16Width;
    ///[IN]:Video height
    MI_U16 u16Height;
    ///[IN]:Frame rate
    MI_U32 u32FrameRate;
    ///[IN]:Frame rate base
    MI_U32 u32FrameRateBase;
    ///[IN]:Private data
    MI_U8 *pu8PrivateData;
    ///[IN]:Data size
    MI_U32 u32DataSize;
} MI_VIDEO_PrivateCodecData_t;

///RV8 codec data
typedef struct MI_VIDEO_Rv8CodecData_s
{
    ///[IN]:Video width
    MI_U16 au16Width[8];
    ///[IN]:Video height
    MI_U16 au16Height[8];
    ///[IN]:Frame rate
    MI_U32 u32FrameRate;
    ///[IN]:Frame rate base
    MI_U32 u32FrameRateBase;
    ///[IN]:RPR size
    MI_U8 u8RprNumSize;
} MI_VIDEO_Rv8CodecData_t;

/// Video codec parameter
typedef struct MI_VIDEO_CodecParams_s
{
    ///[IN]:Codec type
    MI_VIDEO_CodecType_e eCodecType;
    union
    {
        ///[IN]:Wmv3 codec data
        MI_VIDEO_Wmv3CodecData_t stWmv3CodecData;
        ///[IN]:Divx311 codec data
        MI_VIDEO_Divx311CodecData_t stDivx311CodecData;
        ///[IN]:Privata codec data
        MI_VIDEO_PrivateCodecData_t stPrivateCodecData;
        ///[IN]:RV8 codec data
        MI_VIDEO_Rv8CodecData_t stRv8CodecData;
    } attr;
} MI_VIDEO_CodecParams_t;

/// Video adavance configuration
typedef struct MI_VIDEO_LatencyCtrl_s
{
    MI_BOOL bSetMinFrameGap;            ///< [IN]: TRUE for configuring min frame gap with u32MinFrameGap, FALSE for using default setting..
    MI_BOOL bSetFdMaskDelayCnt;         ///<  [IN]:TRUE for configuring FD mask count by , FALSE for default setting.
    MI_BOOL bSetAutoExhaustEsMode;      ///<  [IN]:TRUE for configuring auto exhaust ES mode with u32AutoExhaustEsMode, FALSE to ignore this setting..
    MI_BOOL bSetAutoDropDispQueue;      ///<  [IN]:TRUE for configuring auto drop display queue with u32AutoDropDispQueue for display the latest frame ASAP, FALSE to ignore this setting.
    MI_BOOL bSetDecOrderDisp;           ///<  [IN]:TRUE for display by decode order, used for stream contains IP frames only, FALSE for using display order.
    MI_BOOL bSetMinDecEsLevel;          ///<  [IN]:TRUE for configuring min ES level with u32MinDecEsLevel to trigger decode, FALSE to ignore this setting.
    MI_BOOL bSetMvdParserFifoThreshold; ///<  [IN]:TRUE for configuring PES parser fifo threshold with u32MvdParserFifoThreshold to request DMA to ES buffer, FALSE to ignore this setting.
    MI_U8 u8Reserved[5];               ///<  [IN]:reserved for furture extended using.

    MI_U32 u32MinFrameGap;              ///<  [IN]:This control will be configured if bSetMinFrameGap is TRUE.
    MI_U32 u32AutoExhaustEsMode;        ///<  [IN]:This control will be configured if bSetAutoExhaustEsMode is TRUE.
    MI_U32 u32MinDecEsLevel;            ///<  [IN]:This control will be configured if bSetMinDecEsLevel is TRUE.
    MI_U32 u32AutoDropDispQueue;        ///<  [IN]:This control will be configured if bSetAutoDropDispQueue is TRUE.
    MI_U32 u32FdMaskDelayCnt;           ///<  [IN]:This control will be configured if bSetFdMaskDelayCnt is TRUE.
    MI_U32 u32MvdParserFifoThreshold;   ///<  [IN]:This control will be configured if bSetMvdParserFifoThreshold is TRUE.
} MI_VIDEO_LatencyCtrl_t;

/// Video drop error frame configuration
typedef struct MI_VIDEO_ErrorTolerance_s
{
    MI_BOOL bEnable;                    ///<  [IN]: switch to enable or disable dropping error frame
    MI_U8 u8Tolerance;                  ///<  [IN]: error tolerance to drop frame, range is 0 to 100, if 0 means dropping all error frame, if 100 means keeping all error frame.
} MI_VIDEO_ErrorTolerance_t;

/// Video connect input HW IP parameters
typedef struct MI_VIDEO_ConnectInputParams_s
{
    MI_HANDLE hVidDmxFilt;      ///< Handle of Video DMX filter opened by MI_DMX_Open()
}MI_VIDEO_ConnectInputParams_t;

/// Using for CC raw data found event, notify user where is data address & size.
typedef struct MI_VIDEO_CcDataBuf_s
{
    MI_U8 *pu8CcData;   ///< [IN]: CC data buffer address.
    MI_U32 u32DataSize; ///< [IN]: CC data size
    MI_U64 u64Pts;      ///<[Out]: Pts of CC data, unit is ms.
    MI_BOOL bOddFieldFirst; ///<[Out]: Is Odd(top) filed first of CC data
}MI_VIDEO_CcDataBuf_t;

/// Define CC callback function type.
typedef MI_RESULT (* MI_VIDEO_CcCallback)(MI_HANDLE hVidDec, MI_VIDEO_CcCallbackEvent_e eEvent, void *pEventParams, void *pUserParams);

// CC Callback event paramters of function pointer MI_VIDEO_CcRawDataCallback used.
typedef struct MI_VIDEO_RegisterCcCallbackInputParams_s
{
    MI_U64 u64CallbackId;                ///< [IN]: for multi-callback, use 0 for first register or single callback
    MI_VIDEO_CcCallback pfCcCallback;    ///< [IN]: Callback of CC
    MI_U32 u32EventFlags;                ///< [IN]: Event flags defined by MI_VIDEO_CcCallbackEvent_e
    void *pUserParams;                     ///< [IN]: User parameter
}MI_VIDEO_RegisterCcCallbackInputParams_t;

typedef struct MI_VIDEO_RegisterCcCallbackOutputParams_s
{
    MI_U64 u64CallbackId;                ///[OUT]: the returned ID for update or unregister callback.
}MI_VIDEO_RegisterCcCallbackOutputParams_t;

typedef struct MI_VIDEO_ConnectedConds_s
{
    MI_BOOL bIsInput;
    MI_U32 u32Module;

    //if need other conditions add here
} MI_VIDEO_ConnectedConds_t;


typedef struct MI_VIDEO_MicroBlockErrInfo_s
{
    MI_U16 u16ErrRate;                     // frame error rate 0%~100 based on micro block
    MI_BOOL bRefFrameErr;                  // Does reference frame have error
    MI_BOOL bPropagateRefErr;              //Does this frame have propagate reference error
}MI_VIDEO_MicroBlockErrInfo_t;

typedef struct MI_VIDEO_FramesFormat_s
{
    MI_PHY phyLumaAddr;                    // Luma Address for YUV color spece.
    MI_PHY phyChromaAddr;                  // Chroma Address for YUV color space.
    MI_VIDEO_FrameType_e eFrameType;       // Indicate frame type. (I/B/P Frame)
    MI_VIDEO_FrameFieldType_e eFieldType;  // Indicate frame filed type. (Bottom/Top/Both)
    MI_U8 u8LumaBitDepth;                  // Luma color bit depth.
    MI_U8 u8ChromaBitDepth;                // Chroma color bit depth.
    MI_U16 u16LumaPitch;                     // Luma Pitch. Unit: Pixel.
    MI_U16 u16ChromaPitch;                   // Chroma Pitch. Unit: Pixel.
}MI_VIDEO_FramesFormat_t;

typedef struct MI_VIDEO_FrameInfo_s
{
    MI_VIRT virtMetadata; // private metadata of frame.

    MI_VIDEO_FramesFormat_t astFramesFormat[2];  // If bBottomFieldFirst = TRUE, bottom(0) top(1). If bBottomFieldFirst = FALSE, bottom(1), top(0).
    MI_U64 u64Pts;                              // unit: microsecond(10^-6), for invalid PTS please assign MI_INVALID_PTS.
    MI_VIDEO_ScanType_e eScanType;             // Indicate this frame is progressive/interlace frame/interlace field.
    MI_U32 u32FrameRate;                        // unit: 1000
    MI_U32 u32AspectWidth;                      // Display width.
    MI_U32 u32AspectHeight;                     // Display height.
    MI_U32 u32Width;                            // original video width.
    MI_U32 u32Height;                           // original video height.
    MI_U32 u32CropLeft;                         // Left cropping.
    MI_U32 u32CropRight;                        // Right cropping.
    MI_U32 u32CropTop;                          // Top cropping.
    MI_U32 u32CropBottom;                       // Bottom cropping.
    MI_BOOL bBottomFieldFirst;                  // Indiacte the bottom/top position for MI_VIDEO_FramesFormat_t.
    MI_U32 u32FrameFieldNum;                    // Frame field num.
    MI_VIDEO_ColorFormat_e eColorFormat;        // Frame Color format.
    MI_VIDEO_FrameTileBlock_e eTileBlock;       // Frame tile block.
    MI_U8 u8ToggleTime;                         // Frame interval toggle time, 1 toggle time means frame 0.5 frame time. Interlace field/frame: 1,  Progressive: 2, 32pulldown mode: 2 or 3.
    MI_VIDEO_MicroBlockErrInfo_t astMicroBlockErrInfo[2];// Frame Error Microblock Information, If bBottomFieldFirst = TRUE, bottom(0) top(1). If bBottomFieldFirst = FALSE, bottom(1), top(0)
} MI_VIDEO_FrameInfo_t;

typedef struct MI_VIDEO_DumpInfoParams_s
{
    MI_U8 u8Reserve;
}MI_VIDEO_DumpInfoParams_t;

// MI_VIDEO_SeekToPts parameter struct.
typedef struct MI_VIDEO_SeekParams_s
{
    MI_VIDEO_SeekType_e eSeekType;  // Seek type
    MI_U64 u64Pts;                  // Target PTS
}MI_VIDEO_SeekParams_t;

// MI_VIDEO_Step parameter struct.
typedef struct MI_VIDEO_StepParams_s
{
    MI_VIDEO_StepType_e eStepType;  // Step type
    MI_BOOL bEnable;                // Step enable
}MI_VIDEO_StepParams_t;

// Decoder loading parameters.
typedef struct MI_VIDEO_DecoderLoadingParams_s
{
    MI_U16 u16Width;         //Width
    MI_U16 u16Height;        // Height
    MI_U32 u32FrameRate;     // Frame rate
    MI_U32 u32FrameRateBase; // Frame rate base
    MI_U32 u32Percentage;    // [Get Only] Decoder loading percentage, unit is %
    void *pUserParams;       // User Parameter for Decoder loading used, binding with MI_VIDEO handle
}MI_VIDEO_DecoderLoadingParams_t;

// Decoder loading List information
typedef struct MI_VIDEO_DecoderOverloadingInfo_s
{
    MI_HANDLE hVideo;                                // MI handle, related with VDEC instance
    MI_VIDEO_DecoderLoadingParams_t stLoadingParams; // Decoder loading
}MI_VIDEO_DecoderOverloadingInfo_t;

// Decoder overloading list, for E_MI_VIDEO_CALLBACK_EVENT_DECODER_OVERLOADING used
typedef struct MI_VIDEO_DecoderOverloadingList_s
{
    MI_U32 u32DecoderNum;                                   // Decoder number in this Overloading list.
    MI_VIDEO_DecoderOverloadingInfo_t *pstOverLoadingInfo;  // Decoder loading information.
}MI_VIDEO_DecoderOverloadingList_t;

/// Wall clock with Video PTS
typedef struct MI_VIDEO_GetPtsInfo_s
{
    MI_U64 u64Pts;         /// Current PTS, unit: 90KHz
    MI_U64 u64WallClock;   /// Related with Video PTS, unit: defined in MI_VIDEO_WallClockType_e
} MI_VIDEO_GetPtsInfo_t;   /// Get PTS and related wall clock


//-------------------------------------------------------------------------------------------------
//  Global Functions
//-------------------------------------------------------------------------------------------------

//------------------------------------------------------------------------------
/// @brief Video get capability
/// @param[out] pstCaps decoder capability
/// @return MI_OK: Process success.
//------------------------------------------------------------------------------
MI_RESULT MI_VIDEO_GetCaps(MI_VIDEO_Caps_t *pstCaps);

//------------------------------------------------------------------------------
/// @brief VIDEO system initial
/// @param[in] pstInitParams video init parameter
/// @return MI_OK: Process success.
/// @return MI_HAS_INITED: Video module is inited
/// @return MI_ERR_FAILED: Process failed
//------------------------------------------------------------------------------
MI_RESULT MI_VIDEO_Init(const MI_VIDEO_InitParams_t *pstInitParams);

//------------------------------------------------------------------------------
/// @brief Video de-init
/// @param[in] None
/// @return MI_OK: Process success.
//------------------------------------------------------------------------------
MI_RESULT MI_VIDEO_DeInit(void);

//------------------------------------------------------------------------------
/// @brief Open Video handler
/// @param[in] pstOpenParams decoder attribute
/// @param[out] *phVideo video path handler
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process failed
/// @return MI_ERR_INVALID_PARAMETER: Null parameter
//------------------------------------------------------------------------------
MI_RESULT MI_VIDEO_Open(const MI_VIDEO_OpenParams_t *pstOpenParams, MI_HANDLE *phVideo);

//------------------------------------------------------------------------------
/// @brief Close Video handler
/// @param[in] hVideo video path handler
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Video module is not inited
/// @return MI_ERR_INVALID_HANDLE: Invalid video handle
//------------------------------------------------------------------------------
MI_RESULT MI_VIDEO_Close(MI_HANDLE hVideo);

//------------------------------------------------------------------------------
/// @brief Get Video handler
/// @param[in] pstQueryParams Query parameters
/// @param[out] *phVideo video path handler
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: vdec control failed
/// @return MI_ERR_INVALID_PARAMETER: parameter null
//------------------------------------------------------------------------------
MI_RESULT MI_VIDEO_GetHandle(const MI_VIDEO_QueryHandleParams_t *pstQueryParams, MI_HANDLE *phVideo);

//------------------------------------------------------------------------------
/// @brief Video start
/// @param[in] hVideo Video handle
/// @param[in] pstStartParams video start parameters
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process failed
//------------------------------------------------------------------------------
MI_RESULT MI_VIDEO_Start(MI_HANDLE hVideo, const MI_VIDEO_StartParams_t *pstStartParams);

//------------------------------------------------------------------------------
/// @brief Video stop
/// @param[in] hVideo Video handle
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Video module is not inited
/// @return MI_ERR_INVALID_HANDLE: Invalid video handle
/// @return MI_ERR_FAILED: Process failed
//------------------------------------------------------------------------------
MI_RESULT MI_VIDEO_Stop(MI_HANDLE hVideo);

//------------------------------------------------------------------------------
/// @brief Video pause
/// @param[in] hVideo Video handle
/// @return MI_OK: vdec control success
/// @return MI_ERR_NOT_INITED: Video module is not inited
/// @return MI_ERR_INVALID_HANDLE: Invalid video handle
/// @return MI_ERR_FAILED: Process failed
//------------------------------------------------------------------------------
MI_RESULT MI_VIDEO_Pause(MI_HANDLE hVideo);

//------------------------------------------------------------------------------
/// @brief Video resume
/// @param[in] hVideo Video handle
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Video module is not inited
/// @return MI_ERR_INVALID_HANDLE: Invalid video handle
/// @return MI_ERR_FAILED: Process failed
//------------------------------------------------------------------------------
MI_RESULT MI_VIDEO_Resume(MI_HANDLE hVideo);

//------------------------------------------------------------------------------
/// @brief Set video freeze display
/// @param[in] hVideo Video handle
/// @param[in] bFreeze Video freeze of not
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Video module is not inited
/// @return MI_ERR_INVALID_HANDLE: Invalid video handle
/// @return MI_ERR_FAILED: Process failed
//------------------------------------------------------------------------------
MI_RESULT MI_VIDEO_FreezeDisp(MI_HANDLE hVideo, MI_BOOL bFreeze);

//------------------------------------------------------------------------------
/// @brief Video decode I frame
/// @param[in] hVideo Video handle
/// @param[in] pstIFrame Iframe data info
/// @return TRUE: Process success.
/// @return MI_ERR_NOT_INITED: Video module is not inited
/// @return MI_ERR_INVALID_HANDLE: Invalid video handle
/// @return FALSE: Process failed.
//------------------------------------------------------------------------------
MI_RESULT MI_VIDEO_PlayIFrame(MI_HANDLE hVideo, MI_VIDEO_IFrameData_t *pstIFrame);

//------------------------------------------------------------------------------
/// @brief Video stop I frame
/// @param[in] hVideo Video handle
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Video module is not inited
/// @return MI_ERR_INVALID_HANDLE: Invalid video handle
/// @return MI_ERR_INVALID_PARAMETER: parameter null
/// @return MI_ERR_FAILED: Process failed
//------------------------------------------------------------------------------
MI_RESULT MI_VIDEO_StopIFrame(MI_HANDLE hVideo);

//------------------------------------------------------------------------------
/// @brief Register Video notify event
/// @param[in] hVideo Video handle
/// @param[in] pstInputParams Input parameters
/// @param[out] pstOutputParams Output parameters
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Video module is not inited
/// @return MI_ERR_INVALID_HANDLE: Invalid video handle
/// @return MI_ERR_INVALID_PARAMETER: parameter null
/// @return MI_ERR_FAILED: Process failed
//------------------------------------------------------------------------------
MI_RESULT MI_VIDEO_RegisterCallback(MI_HANDLE hVideo, const MI_VIDEO_CallbackInputParams_t *pstInputParams, MI_VIDEO_CallbackOutputParams_t *pstOutputParams);

//------------------------------------------------------------------------------
/// @brief Unregister Video notify event
/// @param[in] hVideo Video handle
/// @param[in] pstInputParams Input parameters
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Video module is not inited
/// @return MI_ERR_INVALID_HANDLE: Invalid video handle
/// @return MI_ERR_INVALID_PARAMETER: parameter null
/// @return MI_ERR_FAILED: Process failed
//------------------------------------------------------------------------------
MI_RESULT MI_VIDEO_UnRegisterCallback(MI_HANDLE hVideo, const MI_VIDEO_CallbackInputParams_t *pstInputParams);

//------------------------------------------------------------------------------
/// @brief Register Video CC notify event, only for CC raw data used.
/// @param[in] hVideo Video handle
/// @param[in] pstCallbackInputParams Input Parameters
/// @param[out] pstCallbackOutputParams Output parameters
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Video module is not inited
/// @return MI_ERR_INVALID_HANDLE: Invalid video handle
/// @return MI_ERR_INVALID_PARAMETER: parameter null
/// @return MI_ERR_FAILED: Process failed
//------------------------------------------------------------------------------
MI_RESULT MI_VIDEO_RegisterCcCallback(MI_HANDLE hVideo, const MI_VIDEO_RegisterCcCallbackInputParams_t *pstCallbackInputParams, MI_VIDEO_RegisterCcCallbackOutputParams_t *pstCallbackOutputParams);

//------------------------------------------------------------------------------
/// @brief Unregister Video CC notify event, only for CC raw data used.
/// @param[in] hVideo Video handle
/// @param[in] pstCallbackInputParams Input Parameters
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Video module is not inited
/// @return MI_ERR_INVALID_HANDLE: Invalid video handle
/// @return MI_ERR_INVALID_PARAMETER: parameter null
/// @return MI_ERR_FAILED: Process failed
//------------------------------------------------------------------------------
MI_RESULT MI_VIDEO_UnRegisterCcCallback(MI_HANDLE hVideo, const MI_VIDEO_RegisterCcCallbackInputParams_t *pstCallbackInputParams);

//------------------------------------------------------------------------------
/// @brief set video attribute
/// @param[in] hViddeo Video handle
/// @param[in] eAttrType attributes type
/// @param[in] pAttrParams  A pointer to to set attribute corresponding to the eAttrType. The prototype of pAttrParams plz see the description of enum MI_VIDEO_AttrType_e
/// @return MI_OK: setting success
/// @return MI_ERR_NOT_INITED: Video module is not inited
/// @return MI_ERR_INVALID_HANDLE: Invalid video handle
/// @return MI_ERR_FAILED: Process failed
//------------------------------------------------------------------------------
MI_RESULT MI_VIDEO_SetAttr(MI_HANDLE hVideo, MI_VIDEO_AttrType_e eAttrType, const void *pAttrParams);

//------------------------------------------------------------------------------
/// @brief Get video attribute
/// @param[in] hVideo Video handle
/// @param[in] eAttrType attributes type
/// @param[in] pInputParams input params
/// @param[out] pOutputParams A pointer to to get attribute corresponding to the eAttrType. The prototype of pOutputparams plz see the description of enum MI_VIDEO_AttrType_e
/// @return MI_OK: Get video attribute success
/// @return MI_ERR_NOT_INITED: Video module is not inited
/// @return MI_ERR_INVALID_HANDLE: Invalid video handle
/// @return MI_ERR_FAILED: Process failed
//------------------------------------------------------------------------------
MI_RESULT MI_VIDEO_GetAttr(MI_HANDLE hVideo, MI_VIDEO_AttrType_e eAttrType, const void *pInputParams, void *pOutputParams);

//------------------------------------------------------------------------------
/// @brief Set video trick mode
/// @param[in] hVideo Video handle
/// @param[in] eTrickMode trick mode
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: mutex obtain failed
/// @return MI_ERR_FAILED: vdec control failed
//------------------------------------------------------------------------------
MI_RESULT MI_VIDEO_SetTrickMode(MI_HANDLE hVideo, MI_VIDEO_TrickDec_e eTrickMode);

//------------------------------------------------------------------------------
/// @brief Get video trick mode
/// @param[in] hVideo Video handle
/// @param[out] eTrickMode trick mode
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: mutex obtain failed
/// @return MI_ERR_FAILED: vdec control failed
//------------------------------------------------------------------------------
MI_RESULT MI_VIDEO_GetTrickMode(MI_HANDLE hVideo, MI_VIDEO_TrickDec_e *peTrickMode);

//------------------------------------------------------------------------------
/// @brief Set video video speed
/// @param[in] hVideo Video handle
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: vdec control failed
//------------------------------------------------------------------------------
MI_RESULT MI_VIDEO_SetSpeed(MI_HANDLE hVideo, MI_VIDEO_Speed_e eVidSpeed);

//------------------------------------------------------------------------------
/// @brief Set the video codec parameter
/// @param[in] hVideo Video handle
/// @param[IN] pstCodecParams pointer to struct MI_VIDEO_CodecParams_t for a specified codec
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Video module is not inited
/// @return MI_ERR_INVALID_HANDLE: Invalid video handle
//------------------------------------------------------------------------------
MI_RESULT MI_VIDEO_SetCodecParams(MI_HANDLE hVideo, MI_VIDEO_CodecParams_t *pstCodecParams);

//------------------------------------------------------------------------------
/// @brief Set video debug level.
/// @param[in] u32DebugLevel.
/// @return MI_OK: Set debug level success.
//------------------------------------------------------------------------------
MI_RESULT MI_VIDEO_SetDebugLevel(MI_DBG_LEVEL u32DebugLevel);

//------------------------------------------------------------------------------
/// @brief Set video debug info type.
/// @param[in] eDebugInfo.
/// @return MI_OK: Set debug Info success.
//------------------------------------------------------------------------------
MI_RESULT MI_VIDEO_SetDebugInfo(MI_VIDEO_DbgInfoType_e eDebugInfo);

//------------------------------------------------------------------------------
/// @brief Set video debug info type.
/// @param[in] *peDebugInfo.
/// @return MI_OK: Get setting debug Info success.
//------------------------------------------------------------------------------
MI_RESULT MI_VIDEO_GetDebugInfo(MI_VIDEO_DbgInfoType_e *peDebugInfo);

//------------------------------------------------------------------------------
/// @brief Video clear
/// @param[in] hVideo Video handle
/// @param[in] ClearParams
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process failed
//------------------------------------------------------------------------------
MI_RESULT MI_VIDEO_Clear(MI_HANDLE hVideo, MI_VIDEO_ClearParams_t *pstClearParams);

//------------------------------------------------------------------------------
/// @brief For video is a down stream module. Video connect its input with hInput, i.e. hInput --> hVideo
/// @param[in] hVideo Video handle
/// @param[in] hInput Handle of up stream to connect with video's input
/// @param[in] pstParams Pointer to struct MI_VIDEO_ConnectInputParams_t to speicified the parameters for video connect input with hUpHdl
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE: invalid handle.
/// @return MI_ERR_FAILED: Process failed
//------------------------------------------------------------------------------
MI_RESULT MI_VIDEO_ConnectInput(MI_HANDLE hVideo, MI_HANDLE hInput, const MI_VIDEO_ConnectInputParams_t *pstParams);

//------------------------------------------------------------------------------
/// @brief For video is a down stream module. Video disconnect its input hInput, i.e. hInput -X-> hVideo
/// @param[in] hVideo Video handle
/// @param[in] hInput Handle of up stream to connect with video's input
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE: invalid handle.
/// @return MI_ERR_FAILED: Process failed
//------------------------------------------------------------------------------
MI_RESULT MI_VIDEO_DisconnectInput(MI_HANDLE hVideo, MI_HANDLE hInput);

//------------------------------------------------------------------------------
/// @brief Get the element which is connected to the specified element.
/// @param[in] hVideo Video handle
/// @param[in] bIsinput: The direction for finding the connected module.
/// @param[in] pstVideoConds: bIsinput-The direction for finding the connected module.
///                           u32ModuleType-The module type of connected with VIDEO. it defined in mi_common.h with prefix MI_MODULE_TYPE_XXX.
///                                         If it is MI_MODULE_TYPE_NONE it find all type of connected modules.
///                                         e.g. MI_VIDEO_GetConnectedNum(hVideo, TRUE, MI_MODULE_TYPE_TSIO, pu32ConnectedNum)
/// @param[out] pu32ConnectedNum: The number of connected handle
/// @return MI_OK: Process success.
//------------------------------------------------------------------------------
MI_RESULT MI_VIDEO_GetConnectedNum(const MI_HANDLE hVideo, const MI_VIDEO_ConnectedConds_t *pstVideoConds, MI_U32 *pu32ConnectedNum);

//------------------------------------------------------------------------------
/// @brief Get the element which is connected to the specified element.
/// @param[in] hVideo Video handle
/// @param[in] bIsinput: The direction for finding the connected module.
/// @param[in] pstVideoConds: bIsinput-The direction for finding the connected module.
///                           u32ModuleType-The module type of connected with VIDEO. it defined in mi_common.h with prefix MI_MODULE_TYPE_XXX.
///                                         If it is MI_MODULE_TYPE_NONE it find all type of connected modules.
///                                         e.g. MI_VIDEO_GetConnected(hVideo, TRUE, MI_MODULE_TYPE_TSIO, u32ConnectedNum, phConnectedArray)
/// @param[in] u32ConnectedNum: The number of get handle
/// @param[out] phConnectedArray: Pointer to handle buffer to retrieve the handle of MI module which is connected to the specified element with the specified direction.
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_FAILED: Process fail, no connection is available.
//------------------------------------------------------------------------------
MI_RESULT MI_VIDEO_GetConnected(const MI_HANDLE hVideo, const MI_VIDEO_ConnectedConds_t *pstVideoConds, const MI_U32 u32ConnectedNum, MI_HANDLE *phConnectedArray);

//------------------------------------------------------------------------------
/// @brief Get video next frame info.
/// @param[in] hVideo Video handle
/// @param[out] pstNextFrameInfo: Pointer to get vdec frame info.
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_FAILED: Process fail, no connection is available.
//------------------------------------------------------------------------------
MI_RESULT MI_VIDEO_GetNextFrame(const MI_HANDLE hVideo, MI_VIDEO_FrameInfo_t *pstNextFrameInfo);

//------------------------------------------------------------------------------
/// @brief Release video frame when recevie mi_disp flip done callback.
/// @param[in] hVideo Video handle
/// @param[in] pstReleaseFrameInfo: Pointer to release vdec frame info.
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_FAILED: Process fail, no connection is available.
//------------------------------------------------------------------------------
MI_RESULT MI_VIDEO_ReleaseFrame(const MI_HANDLE hVideo, const MI_VIDEO_FrameInfo_t *pstReleaseFrameInfo);

//------------------------------------------------------------------------------
/// @brief Enable vdec security mode. This API cannot be used while video module is not inited or video is running.
/// @param[in] bEnable: Enable secure mode.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Video module is not inited.
/// @return MI_ERR_BUSY: This API cannot be used while video is running.
//------------------------------------------------------------------------------
MI_RESULT MI_VIDEO_EnableSecurityMode(MI_BOOL bEnable);

//------------------------------------------------------------------------------
/// @brief Dump MI_VIDEO handle instance info.
/// @param[in] pstDumpInfoParams: Dump info param.
/// @return MI_OK: Process success.
//------------------------------------------------------------------------------
MI_RESULT MI_VIDEO_DumpInfo(const MI_VIDEO_DumpInfoParams_t *pstDumpInfoParams);

//------------------------------------------------------------------------------
/// @brief video decoder will seek to target PTS
/// @param[in] hVideo Video handle
/// @param[in] pstSeekParams Pointer to struct MI_VIDEO_SeekParams_t to speicified the parameters for seek type and target PTS.
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE: invalid handle.
/// @return MI_ERR_FAILED: Process failed
//------------------------------------------------------------------------------
MI_RESULT MI_VIDEO_SeekToPts(MI_HANDLE hVideo, const MI_VIDEO_SeekParams_t *pstSeekParams);

//------------------------------------------------------------------------------
/// @brief video decoder will enable(/disable) step mode
/// @param[in] hVideo Video handle
/// @param[in] pstStepParams Pointer to struct MI_VIDEO_StepParams_t to speicified the parameters for steptype and enabble(/disable).
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE: invalid handle.
/// @return MI_ERR_FAILED: Process failed
//------------------------------------------------------------------------------
MI_RESULT MI_VIDEO_Step(MI_HANDLE hVideo, const MI_VIDEO_StepParams_t *pstStepParams);

//------------------------------------------------------------------------------
/// @brief video enable/disable security mode by handle
/// @param[in] hVideo Video handle
/// @param[in] enable/disable
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE: invalid handle.
/// @return MI_ERR_FAILED: Process failed
//------------------------------------------------------------------------------
MI_RESULT MI_VIDEO_EnableSecurityModeByHandle(MI_HANDLE hVideo, MI_BOOL bEnable);

#ifdef __cplusplus
}
#endif

#endif///_MI_VIDEO_H_
