/*------------------------------------------------------------------------------
 * MediaTek Inc. (C) 2018. All rights reserved.
 *
 * Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 *----------------------------------------------------------------------------*/
//-------------------------------------------------------------------------------------------------
//  GetXxx and SetAttr coexist
//-------------------------------------------------------------------------------------------------



#ifndef _MI_PCMCIA_H_
#define _MI_PCMCIA_H_

#ifdef __cplusplus
extern "C" {
#endif

//-------------------------------------------------------------------------------------------------
//  Defines
//-------------------------------------------------------------------------------------------------
#define MI_PCMCIA_STRLEN_MAX (64)
#define MI_PCMCIA_CONFIG_MAX (6)

//-------------------------------------------------------------------------------------------------
//  Structures
//-------------------------------------------------------------------------------------------------

typedef enum
{
    E_MI_PCMCIA_EVENT_DATA = 0,                               /// < Callback event: data valid
    E_MI_PCMCIA_EVENT_IN,                                     /// < Callback event: Card in
    E_MI_PCMCIA_EVENT_OUT,                                    /// < Callback event: Card out

    E_MI_PCMCIA_EVENT_MAX
} MI_PCMCIA_Event_e;

typedef enum
{
    E_MI_PCMCIA_ATTR_TYPE_DETECTION_ENABLE,                   /// < //Set detect enable bit,parameter type is a pointer to MI_BOOL
    E_MI_PCMCIA_ATTR_TYPE_CI_TEST_MODE,                     /// < //Set CI Test MODE, Change PAD ,parameter type is a pointer to MI_BOOL

    E_MI_PCMCIA_ATTR_TYPE_MAX,
} MI_PCMCIA_AttrType_e;

typedef enum
{
    E_MI_PCMCIA_RAW_CONTROL_COMMAND_READ_ATTR_MEM = 0,        /// < pAttrParams is a pointer to MI_PCMCIA_RawCtrlMemParams_t
    E_MI_PCMCIA_RAW_CONTROL_COMMAND_WRITE_ATTR_MEM,           /// < pAttrParams is a pointer to MI_PCMCIA_RawCtrlMemParams_t
    E_MI_PCMCIA_RAW_CONTROL_COMMAND_PARSE_ATTR_MEM,           /// < pAttrParams is a pointer to MI_PCMCIA_RawCtrlParseAttrMemParams_t
    E_MI_PCMCIA_RAW_CONTROL_COMMAND_READ_IO_MEM,              /// < pAttrParams is a pointer to MI_PCMCIA_RawCtrlMemParams_t
    E_MI_PCMCIA_RAW_CONTROL_COMMAND_WRITE_IO_MEM,             /// < pAttrParams is a pointer to MI_PCMCIA_RawCtrlMemParams_t
    E_MI_PCMCIA_RAW_CONTROL_COMMAND_SWITCH_IO_MODE,           /// < pAttrParams is a pointer to MI_PCMCIA_Info_t
    E_MI_PCMCIA_RAW_CONTROL_COMMAND_RESET_INTERFACE,          /// < pAttrParams is a pointer to NULL
    E_MI_PCMCIA_RAW_CONTROL_COMMAND_NEGOTIATE_BUFFER_SIZE,    /// < pAttrParams is a pointer to MI_PCMCIA_RawCtrlNegoBufSizeParams_t
    E_MI_PCMCIA_RAW_CONTROL_COMMAND_SET_BUFFER_SIZE,          /// < pAttrParams is a pointer to MI_U16
    E_MI_PCMCIA_RAW_CONTROL_COMMAND_READY_STATUS,             /// < pAttrParams is a pointer to MI_BOOL
    E_MI_PCMCIA_RAW_CONTROL_COMMAND_WRITE_IO_DATA,            /// < pAttrParams is a pointer to MI_PCMCIA_RawCtrlWriteParams_t
    E_MI_PCMCIA_RAW_CONTROL_COMMAND_READ_IO_DATA,             /// < pAttrParams is a pointer to MI_PCMCIA_RawCtrlReadParams_t

    E_MI_PCMCIA_RAW_CONTROL_COMMAND_MAX
} MI_PCMCIA_RawCtrlCmd_e;

typedef enum
{
    E_MI_PCMCIA_OPEN_MODE_INTEGRATED = 0,
    E_MI_PCMCIA_OPEN_MODE_RAW,

    E_MI_PCMCIA_OPEN_MODE_MAX
}MI_PCMCIA_OpenMode_e;


typedef MI_RESULT (*MI_PCMCIA_EventCallback)(MI_HANDLE hPcmcia, MI_U32 u32Event ,void * pEventParams, void * pUserParams);

typedef struct MI_PCMCIA_CallbackParams_s
{
    MI_PCMCIA_EventCallback pfEventCallback;                  /// <[IN]: A function pointer for event notification
    void *pUserParams;                                         /// <[IN]: A pointer to user private data
} MI_PCMCIA_CallbackParams_t;

typedef struct MI_PCMCIA_InitParams_s
{
    MI_U8 u8Reserved;                                      /// <[IN]: reserved for future
} MI_PCMCIA_InitParams_t;

typedef struct MI_PCMCIA_OpenParams_s
{
    MI_U32 u32PcmciaId;                                     /// <[IN]: Pcmcia interface ID
    MI_PCMCIA_CallbackParams_t stCallbackParams;            /// <[IN]: A function pointer for event notification
    MI_PCMCIA_OpenMode_e eOpenMode;
} MI_PCMCIA_OpenParams_t;

typedef struct MI_PCMCIA_Config_s
{
    MI_VIRT virtEaAddr;                                      /// <[OUT]:
    MI_U32 u32EaLen;                                         /// <[OUT]:
    MI_U16 u16IrqData;                                       /// <[OUT]:
    MI_U8 u8ConfigIndex;                                     /// <[OUT]:
    MI_U8 u8IrqDesc1;                                        /// <[OUT]:
    MI_U8 u8CiTagPresent;                                    /// <[OUT]:
} MI_PCMCIA_Config_t;

typedef struct MI_PCMCIA_Info_s
{
    MI_U32 u32ConfigOffset;                                  /// <[OUT]: Offset of the Configuration byte in the Attribute Memory
    MI_U32 u32ValidFlags;                                    /// <[OUT]: Bitmask that defines which of the other fields are valid
    MI_U16 u16ManufactureId;                                 /// <[OUT]: 16Bit Manufacturer ID (PCMCIAINFO_MANID_VALID)
    MI_U16 u16CardId;                                        /// <[OUT]: 16Bit Card ID (PCMCIAINFO_MANID_VALID)
    MI_U16 u16PcmciaStdRev;                                  /// <[OUT]: PCMCIA Standard version supported by the card (PCMCIAINFO_VERS1_VALID)
    MI_U8 szManufactureName[MI_PCMCIA_STRLEN_MAX];           /// <[OUT]: Name of the card manufacturer (PCMCIAINFO_VERS1_VALID)
    MI_U8 szProductName[MI_PCMCIA_STRLEN_MAX];               /// <[OUT]: Product name (PCMCIAINFO_VERS1_VALID)
    MI_U8 szProductInfo1[MI_PCMCIA_STRLEN_MAX];              /// <[OUT]: (PCMCIAINFO_VERS1_VALID)
    MI_U8 szProductInfo2[MI_PCMCIA_STRLEN_MAX];              /// <[OUT]: (PCMCIAINFO_VERS1_VALID)
    MI_BOOL bCiPlus;                                         /// <[OUT]: PCMCIA card CI Plus Compatibility Identification
    MI_U8 u8FuncIdSysInfo;                                   /// <[OUT]: SysInitByte from the FuncID block (PCMCIAINFO_FUNCID_VALID)
    MI_BOOL bSupportInterrupt;                               /// <[OUT]: PCMCIA card Support interrupt or not
    MI_U8 u8NumConfigs;                                      /// <[OUT]: The number of configurations supported by the card. Exactly bNumConfigs entries are valid in the Config array
    MI_PCMCIA_Config_t astConfig[MI_PCMCIA_CONFIG_MAX];      /// <[OUT]: The array of possible card configurations
} MI_PCMCIA_Info_t;

typedef struct MI_PCMCIA_ReadParams_s
{
    MI_U8* pu8ReadBuffer;                                    /// <[OUT]: The Read data Buffer
    MI_U16 u16BufferLen;                                     /// <[IN]:    The buffer size
}MI_PCMCIA_ReadParams_t;

typedef struct MI_PCMCIA_ReadOutputParams_s
{
    MI_U16 u16ActualReadLen;                                 /// <[OUT]: The read data len
}MI_PCMCIA_ReadOutputParams_t;

typedef struct MI_PCMCIA_WriteParams_s
{
    MI_U8* pu8WriteBuffer;                                   /// <[IN]: The Write data Buffer
    MI_U16 u16WriteLen;                                      /// <[IN]: The write data len
}MI_PCMCIA_WriteParams_t;

typedef struct MI_PCMCIA_RawCtrlMemParams_s
{
    MI_U16 u16Addr;
    MI_U8 u8Value;
}MI_PCMCIA_RawCtrlMemParams_t;

typedef struct MI_PCMCIA_RawCtrlNegoBufSizeParams_s
{
    MI_PCMCIA_Info_t stInfo;
    MI_U16 u16Len;
}MI_PCMCIA_RawCtrlNegoBufSizeParams_t;

typedef struct MI_PCMCIA_RawCtrlParseAttrMemParams_s
{
    const MI_U8* pu8AttrMem;
    MI_U16 u16Len;
    MI_PCMCIA_Info_t stInfo;
}MI_PCMCIA_RawCtrlParseAttrMemParams_t;

typedef struct MI_PCMCIA_RawCtrlWriteParams_s
{
    MI_U16 u16Addr;                                          /// <[IN]: The Write address
    MI_U8* pu8WriteBuffer;                                   /// <[IN]: The Write data Buffer
    MI_U16 u16WriteLen;                                      /// <[IN]: The write data len
}MI_PCMCIA_RawCtrlWriteParams_t;

typedef struct MI_PCMCIA_RawCtrlReadParams_s
{
    MI_U16 u16Addr;                                          /// <[IN]:    The Read address
    MI_U16 u16BufferLen;                                     /// <[IN]:    The buffer size
    MI_U8* pu8ReadBuffer;                                    /// <[OUT]: The Read data Buffer
    MI_U16 u16ActualReadLen;                                 /// <[OUT]: The Read data len
}MI_PCMCIA_RawCtrlReadParams_t;

typedef struct MI_PCMCIA_ConnectInputParams_s
{
    MI_U8 u8Reserved;               ///< [IN]: reserved for future
} MI_PCMCIA_ConnectInputParams_t;

typedef struct MI_PCMCIA_ConnectedConds_s
{
    MI_BOOL bIsInput;
    MI_U32 u32Module;
    //if need other conditions add here
} MI_PCMCIA_ConnectedConds_t;

//-------------------------------------------------------------------------------------------------
//  Global Functions
//-------------------------------------------------------------------------------------------------

//------------------------------------------------------------------------------
/// @brief Init PCMCIA module.
/// @param[in] pstInitParams: A pointer to structure MI_PCMCIA_InitParams_t for initialization.
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_RESOURCES: No available resource.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_PCMCIA_Init(const MI_PCMCIA_InitParams_t *pstInitParams);

//------------------------------------------------------------------------------
/// @brief DeInit MI_PCMCIA MODULE
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE : Error handler
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_PCMCIA_DeInit(void);

//------------------------------------------------------------------------------
/// @brief Open a PCMCIA handle.
/// @param[in] pstOpenParams: A pointer to structure MI_PCMCIA_OpenParams_t for open pcmcia interface.
/// @param[out] phPcmcia: A handle pointer to retrieve an instance of a created pcmcia interface.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_RESOURCES: No available resource.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_PCMCIA_Open(const MI_PCMCIA_OpenParams_t *pstOpenParams, MI_HANDLE *phPcmcia);

//------------------------------------------------------------------------------
/// @brief Open Pcmcia Device
/// @param[in] MI_HANDLE : Handle of MI PCMCIA module
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE : Error handler
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_PCMCIA_Close(MI_HANDLE hPcmcia);

//------------------------------------------------------------------------------
/// @brief Set The Power State
/// @param[in] MI_HANDLE : Handle of MI PCMCIA module
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE : Error handler
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_PCMCIA_PowerOn(MI_HANDLE hPcmcia);


//------------------------------------------------------------------------------
/// @brief Set The Power State
/// @param[in] MI_HANDLE : Handle of MI PCMCIA module
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE : Error handler
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_PCMCIA_PowerOff(MI_HANDLE hPcmcia);


//------------------------------------------------------------------------------
/// @brief Get The Card Plug State
/// @param[in] MI_HANDLE : Handle of MI PCMCIA module
/// @param[out] pbDetect: A pointer to boolean value of detected result.
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE : Error handler
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_PCMCIA_Detect(MI_HANDLE hPcmcia, MI_BOOL *pbDetect);

//------------------------------------------------------------------------------
/// @brief Get The device information
/// @param[in] MI_HANDLE : Handle of MI PCMCIA module
/// @param[out] pstInfo: A pointer to struct of device information.
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE : Error handler
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_PCMCIA_GetInfo(MI_HANDLE hPcmcia, MI_PCMCIA_Info_t *pstInfo);

//------------------------------------------------------------------------------
/// @brief Get The device read/write buffer size
/// @param[in] MI_HANDLE : Handle of MI PCMCIA module
/// @param[out] pu16Size: A pointer to the value of device buffer size.
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE : Error handler
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_PCMCIA_GetDeviceBufferSize(MI_HANDLE hPcmcia, MI_U16 *pu16Size);

//------------------------------------------------------------------------------
/// @brief Reads the address is 0 IO memory data
/// @param[in] MI_HANDLE : Handle of MI PCMCIA module
/// @param[in] MI_U8*: Buffer address
/// @param[in] MI_U16: Buffer length
/// @param[out] MI_U16: read length
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE : Error handler
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_PCMCIA_ReadData(MI_HANDLE hPcmcia, MI_PCMCIA_ReadParams_t * pstReadParams , MI_PCMCIA_ReadOutputParams_t *pstOutputParams);

//------------------------------------------------------------------------------
/// @brief Write the address to 0 IO memory data
/// @param[in] MI_HANDLE : Handle of MI PCMCIA module
/// @param[in] MI_U8* : write buffer addr
/// @param[in] MI_U16 : write buffer length
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE : Error handler
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_PCMCIA_WriteData(MI_HANDLE hPcmcia, const MI_PCMCIA_WriteParams_t * pstWriteParams);


//------------------------------------------------------------------------------
/// @brief Toggle PCMCIA reset pin
/// @param[in] MI_HANDLE : Handle of MI PCMCIA module
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE : Error handler
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_PCMCIA_ResetHw(MI_HANDLE hPcmcia);

//------------------------------------------------------------------------------
/// @brief check is there any data ready to send from PCMCIA device.
/// @param[in] MI_HANDLE : Handle of MI PCMCIA module
/// @param[out] MI_BOOL*: check result
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE : Error handler
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_PCMCIA_CheckDataAvailable(MI_HANDLE hPcmcia, MI_BOOL* pbDataAvailable);

//------------------------------------------------------------------------------
/// @brief Set PCMCIA module attributes
/// @param[in] MI_HANDLE : Handle of MI PCMCIA module
/// @param[in] MI_PCMCIA_AttrType_e : the attribute type.
/// @param[in] void *: the pointer to value/values that will be set in MI_PCMCIA_Attribute_t's member.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_NOT_SUPPORT: The function is not supported.
//------------------------------------------------------------------------------
MI_RESULT MI_PCMCIA_SetAttr(MI_HANDLE hPcmcia, MI_PCMCIA_AttrType_e eAttrType, const void * pAttrParams);

//------------------------------------------------------------------------------
/// @brief For Pcmcia is a down stream module. Pcmcia connect its input with hInput, i.e. hInput --> hPcmcia
/// @param[in] hPcmcia: Handle of MI PCMCIA module
/// @param[in] hInput: Handle of up stream to connect with Pcmia's input
/// @param[in] pstParams: Pointer to struct MI_PCMCIA_ConnectInputParams_t to speicified the parameters for pcmcia connect input with hUpHdl
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE: invalid handle.
/// @return MI_ERR_FAILED: Process failed
//------------------------------------------------------------------------------
MI_RESULT MI_PCMCIA_ConnectInput(MI_HANDLE hPcmcia, MI_HANDLE hInput, const MI_PCMCIA_ConnectInputParams_t *pstParams);

//------------------------------------------------------------------------------
/// @brief For PCMCIA is a down stream module. PCMCIA disconnect its input with hInput, i.e. hInput -X-> hPcmcia
/// @param[in] hPcmcia: An instance of a Pcmcia resource.
/// @param[in] hInput: Handle of up stream to connect with Pcmcia's input
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE: invalid handle.
/// @return MI_ERR_FAILED: Process failed
//------------------------------------------------------------------------------
MI_RESULT MI_PCMCIA_DisconnectInput(MI_HANDLE hPcmcia, MI_HANDLE hInput);

//------------------------------------------------------------------------------
/// @brief Get the element which is connected to the specified element.
/// @param[in] hPcmcia: An instance of a Pcmcia resource.
/// @param[in] pstPcmciaConds: bIsinput-The direction for finding the connected module.
///                          u32ModuleType-The module type of connected with PCMCIA. it defined in mi_common.h with prefix MI_MODULE_TYPE_XXX.
///                                        If it is MI_MODULE_TYPE_NONE it find all type of connected modules.
///                                        e.g. MI_PCMCIA_GetConnectedNum(hPcmcia, TRUE, MI_MODULE_TYPE_TUNER, pu32ConnectedNum)
/// @param[out] pu32ConnectedNum: The number of connected handle
/// @return MI_OK: Process success.
//------------------------------------------------------------------------------
MI_RESULT MI_PCMCIA_GetConnectedNum(const MI_HANDLE hPcmcia, const MI_PCMCIA_ConnectedConds_t *pstPcmciaConds, MI_U32 *pu32ConnectedNum);

//------------------------------------------------------------------------------
/// @brief Get the element which is connected to the specified element.
/// @param[in] hPcmcia: An instance of a Pcmcia resource.
/// @param[in] pstTsioConds: bIsinput-The direction for finding the connected module.
///                          u32ModuleType-The module type of connected with PCMCIA. it defined in mi_common.h with prefix MI_MODULE_TYPE_XXX.
///                                        If it is MI_MODULE_TYPE_NONE it find all type of connected modules.
///                                        e.g. MI_PCMCIA_GetConnected(hPcmcia, TRUE, MI_MODULE_TYPE_TUNER, u32ConnectedNum, phConnectedArray)
/// @param[in] u32ConnectedNum: The number of get handle
/// @param[out] phConnectedArray: Pointer to handle buffer to retrieve the handle of MI module which is connected to the specified element with the specified direction.
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_FAILED: Process fail, no connection is available.
//------------------------------------------------------------------------------
MI_RESULT MI_PCMCIA_GetConnected(const MI_HANDLE hPcmcia, const MI_PCMCIA_ConnectedConds_t *pstPcmciaConds, const MI_U32 u32ConnectedNum, MI_HANDLE *phConnectedArray);

//------------------------------------------------------------------------------
/// @brief Set OS debug level.
/// @param[in] eDbgLevel.
/// @return MI_OK: Set debug level success.
//------------------------------------------------------------------------------
MI_RESULT MI_PCMCIA_SetDebugLevel(MI_DBG_LEVEL u32DebugLevel);

//------------------------------------------------------------------------------
/// @brief 
/// @param[in] MI_HANDLE : Handle of MI PCMCIA module
/// @param[in] MI_PCMCIA_RawCtrlCmd_e : the Raw Ctrl Cmd type.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_NOT_SUPPORT: The function is not supported.
//------------------------------------------------------------------------------
MI_RESULT MI_PCMCIA_RawControl(MI_HANDLE hPcmcia, MI_PCMCIA_RawCtrlCmd_e eCmd, void *pAttrParams);


#ifdef __cplusplus
}
#endif

#endif///_MI_PCMCIA_H_


