/*------------------------------------------------------------------------------
 * MediaTek Inc. (C) 2018. All rights reserved.
 *
 * Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 *----------------------------------------------------------------------------*/

#ifndef _MI_SAR_H_
#define _MI_SAR_H_

#ifdef __cplusplus
extern "C" {
#endif

//------------------------------------------------------------------------------
//  Defines
//------------------------------------------------------------------------------
#define SAR_PLATFORM_VOLPIN_MAX_NUM 24

typedef enum
{
    E_MI_SAR_KEYPAD_STATE_PRESS = 0,
    E_MI_SAR_KEYPAD_STATE_REPEAT,
    E_MI_SAR_KEYPAD_STATE_RELEASE,
    E_MI_SAR_KEYPAD_STATE_MAX,
} MI_SAR_KeypadState_e;

typedef enum
{
    E_MI_SAR_CHANNEL_0 = 0,
    E_MI_SAR_CHANNEL_1,
    E_MI_SAR_CHANNEL_2,
    E_MI_SAR_CHANNEL_3,
    E_MI_SAR_CHANNEL_4,
    E_MI_SAR_CHANNEL_5,
    E_MI_SAR_CHANNEL_6,
    E_MI_SAR_CHANNEL_7,
    E_MI_SAR_CHANNEL_MAX,
    E_MI_SAR_ADC_HSYNC_CHANNEL_0 = 0x100,
    E_MI_SAR_ADC_HSYNC_CHANNEL_1,
    E_MI_SAR_ADC_HSYNC_CHANNEL_2,
    E_MI_SAR_ADC_HSYNC_CHANNEL_3,
    E_MI_SAR_ADC_HSYNC_CHANNEL_MAX,
} MI_SAR_Channel_e;

typedef enum
{
    E_MI_SAR_USAGE_TYPE_KEYPAD = 0,
    E_MI_SAR_USAGE_TYPE_ADC,
    E_MI_SAR_USAGE_TYPE_GPIO,
    E_MI_SAR_USAGE_TYPE_HSYNC,
    E_MI_SAR_USAGE_TYPE_VOLTAGE,
    E_MI_SAR_USAGE_TYPE_MAX,
} MI_SAR_UsageType_e;

typedef enum
{
    E_MI_SAR_KEYPAD_STATUS_INVALID=0,
    E_MI_SAR_KEYPAD_STATUS_INIT_OK = MI_BIT(0),
    E_MI_SAR_KEYPAD_STATUS_NOT_SUPPORT = MI_BIT(1),
    E_MI_SAR_KEYPAD_STATUS_MAX = 0xFF
} MI_SAR_KeypadStatus_e;

typedef enum
{
    E_MI_SAR_VOLTAGE_LEVEL_20V =0,
    E_MI_SAR_VOLTAGE_LEVEL_33V = 1,
} MI_SAR_VoltageLevel_e;

typedef enum
{
    E_MI_SAR_CONFIG_MODE_GPIO =0, //0: configured as GPIO input
    E_MI_SAR_CONFIG_MODE_ADC =1,  //1: configured as ADC
}MI_SAR_ConfigMode_e;

typedef enum
{
    E_MI_SAR_EVENT_KEYPAD_PRESS = MI_BIT(0),   ///< notify keypad press event, pEventParam is MI_U8*
    E_MI_SAR_EVENT_KEYPAD_REPEAT = MI_BIT(1),  ///< notify keypad repeat event, pEventParam is MI_U8*
    E_MI_SAR_EVENT_KEYPAD_RELEASE = MI_BIT(2), ///< notify keypad release event, pEventParam is MI_U8*
}MI_SAR_EventType_e;

typedef enum
{
    E_MI_SAR_ATTR_TYPE_DEFAULT_KEYPAD = 0x80000000, //0x80000000: use default keypad config
    E_MI_SAR_ATTR_TYPE_FACTORY_KEYPAD ,  //0x80000001: use factory keypad config
}MI_SAR_AttrType_e;

//------------------------------------------------------------------------------
//  Structures
//------------------------------------------------------------------------------

/// define SAR Keypad Configuration
typedef struct MI_SAR_KeypadConfig_s
{
    MI_SAR_Channel_e eSarChId;
    MI_U8 u8UpBnd;
    MI_U8 u8LoBnd;
    MI_U8 u8KeyLevelNum;
    MI_U8 au8KeyThreshold[8];
    MI_U8 au8KeyCode[8];
} MI_SAR_KeypadConfig_t;


typedef struct MI_SAR_GetKeyCode_s
{
    MI_U8   u8Key;
    MI_U8   u8Repeat;
} MI_SAR_GetKeyCode_t;

typedef struct MI_SAR_InitParams_s
{
    MI_U8 u8Reserved;
} MI_SAR_InitParams_t;

typedef struct MI_SAR_KeypadInfo_s
{
    MI_U8 u8TriggerMode              : 1; // SAR trigger mode. 0: edge trigger, 1: level trigger
    MI_U8 u8SingleChannelEnable      : 1; // SAR single channel enable
    MI_U8 u8DigitalOperationMode     : 1; // SAR operation mode. 0: one-shot, 1: free run
    MI_U8 u8AtopFreeRun              : 1; // SAR atop freerun mode. 0: controlled by digital, 1: free run
    MI_U8 u8DigitalPowerDown         : 1; // SAR digital power down
    MI_U8 u8AtopPowerDown            : 1; // SAR atop power down
    MI_U8 u8HighChannelEnable        : 1; // SAR high channel enable
    MI_U8 u8InterruptEnable          : 1; // SAR interrupt enable
    MI_U8 u8ConfigUsedChannelS       : 3; // SAR configured channels
    MI_U8 u8MaxKeypadSupportChannelS : 3; // SAR IP max keypad channels supported
    MI_U8 u8Reserved                 : 2; // RFU1
    MI_U8 u8MaxKeypadChannel         : 3; // SAR driver max keypad channels provided
    MI_U8 u8MaxKeypadChannelLevel    : 5; // SAR driver max keypad channel levels provided
} MI_SAR_KeypadInfo_t;

typedef struct MI_SAR_Keypad_s
{
    MI_SAR_KeypadConfig_t *pstKeypadConfig;
    MI_U8 u8ChannelNum;
} MI_SAR_Keypad_t;

typedef struct MI_SAR_Gpio_s
{
    MI_SAR_Channel_e eChannel;
} MI_SAR_Gpio_t;

typedef struct MI_SAR_Adc_s
{
    MI_SAR_Channel_e eChannel;
} MI_SAR_Adc_t;

typedef struct MI_SAR_Hsync_s
{
    MI_SAR_Channel_e eChannel;
} MI_SAR_Hsync_t;

typedef struct MI_SAR_OpenParams_s
{
    MI_SAR_UsageType_e eUsageType;
    union
    {
        MI_SAR_Keypad_t stKeypad;
        MI_SAR_Adc_t stAdc;
        MI_SAR_Gpio_t stGpio;
        MI_SAR_Hsync_t stHsync;
    };
} MI_SAR_OpenParams_t;

typedef struct MI_SAR_QueryHandleParams_s
{
    MI_SAR_Channel_e eChannel;
}MI_SAR_QueryHandleParams_t;

typedef MI_RESULT (*MI_SAR_EventCallback)(MI_HANDLE hSar, MI_U32 u32Event, void* pEventParams, void* pUserParams);

typedef struct MI_SAR_CallbackInputParams_s
{
    MI_U64 u64CallbackId;                   ///[IN]: for multi-callback, use 0 for first register or single callback.
    MI_SAR_EventCallback pfEventCallback;   ///[IN]: callback function pointer.
    MI_U32 u32EventFlags;                   ///[IN]: registered events which are bitwise OR operation.
    void * pUserParams;                     ///[IN]: for passing user-defined parameters.
} MI_SAR_CallbackInputParams_t;

typedef struct MI_SAR_CallbackOutputParams_s
{
    MI_U64 u64CallbackId;                   ///[OUT]: the returned ID for update or unregister callback.
} MI_SAR_CallbackOutputParams_t;

typedef struct MI_SAR_Voltage_s
{
    MI_SAR_UsageType_e eAttr;
    MI_U8   u8VolPin[SAR_PLATFORM_VOLPIN_MAX_NUM];
} MI_SAR_Voltage_t;

//------------------------------------------------------------------------------
//  Global Functions
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
/// @brief Initialize the Sar module
/// @param[in] pstInitParams: Parameter to init Sar module
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED or other value : Failure
//------------------------------------------------------------------------------
MI_RESULT MI_SAR_Init(const MI_SAR_InitParams_t *pstInitParams);

//------------------------------------------------------------------------------
/// @brief DeInit Sar.
/// @param void
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED or other value : Failure
//------------------------------------------------------------------------------
MI_RESULT MI_SAR_DeInit(void);

//------------------------------------------------------------------------------
/// @brief open sar handle
/// @param[in] MI_SAR_OpenParams_t.
/// @param[out] phSar.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED or other value : Failure
//------------------------------------------------------------------------------
MI_RESULT MI_SAR_Open(const MI_SAR_OpenParams_t *pstOpenParams, MI_HANDLE *phSar);

//------------------------------------------------------------------------------
/// @brief Close sar handle
/// @param[in] hSar.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED or other value : Failure
//------------------------------------------------------------------------------
MI_RESULT MI_SAR_Close(MI_HANDLE hSar);

//------------------------------------------------------------------------------
/// @brief Get Handle of the SAR module.
/// @param[in]  pstQueryParams: A pointer to structure MI_SAR_QueryHandleParams_t.
/// @param[out] phSar: phSar for retrieve an instance of SAR interface.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: UART module Get Handle failed.
/// @return MI_ERR_INVALID_PARAMETR: Parameters is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_SAR_GetHandle(const MI_SAR_QueryHandleParams_t* pstQueryParams, MI_HANDLE* phSar);

//------------------------------------------------------------------------------
/// @brief Register the callback function for receiving the events of SAR related.
/// @param[in] hSar: A Handle of a created SAR instance.
/// @param[in] pstInputParams: A pointer to structure MI_SAR_CallbackInputParams_t for events registered.
/// @param[out] pstOutputParams: A pointer to structure MI_SAR_CallbackOutputParams_t.
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE: hanlde is invalid.
/// @return MI_ERR_INVALID_PARAMETER: parameters is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_SAR_RegisterCallback(MI_HANDLE hSar, const MI_SAR_CallbackInputParams_t *pstInputParams, MI_SAR_CallbackOutputParams_t *pstOutputParams);

//------------------------------------------------------------------------------
/// @brief UnRegister the callback function for receiving the events of SAR related.
/// @param[in] hSar: A Handle of a created SAR instance.
/// @param[in] pstInputParams: A pointer to structure MI_SAR_CallbackInputParams_t for events registered.
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE: hanlde is invalid.
/// @return MI_ERR_INVALID_PARAMETER: parameters is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_SAR_UnRegisterCallback(MI_HANDLE hSar, const MI_SAR_CallbackInputParams_t *pstInputParams);

//------------------------------------------------------------------------------
/// @brief Get SAR Keypad key code function.
/// @param [in] hSar: sar handle.
/// @param [in] pointer to get keycode:pstGetKeyCode
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED or other value : Failure
//------------------------------------------------------------------------------
MI_RESULT MI_SAR_GetKeyCode(MI_HANDLE hSar, MI_SAR_GetKeyCode_t* pstGetKeyCode);

//------------------------------------------------------------------------------
/// @brief Set SAR 2.0V / 3.3V Level
/// @param [in] hSar: sar handle.
/// @param [in] eSarVoltageLevel:  E_MI_SAR_VOLTAGE_LEVEL_33V: 3.3V, E_MI_SAR_VOLTAGE_LEVEL_20V: 2.0V
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED or other value : Failure
//------------------------------------------------------------------------------
MI_RESULT MI_SAR_SetVoltageLevel(MI_HANDLE hSar, MI_SAR_VoltageLevel_e eSarVoltageLevel);

//------------------------------------------------------------------------------
/// @brief config SAR channel as ADC mode or gpio mode.
/// @param [in] hSar: sar handle.
/// @param [in] eConfigMode:  enum to  MI_SAR_ConfigMode_e
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED or other value : Failure
//------------------------------------------------------------------------------
MI_RESULT MI_SAR_ConfigMode(MI_HANDLE hSar, MI_SAR_ConfigMode_e eConfigMode);

//------------------------------------------------------------------------------
/// @brief Select keypad config, default or factory
/// @param [in] hSar: sar handle.
/// @param [in] eAttrType:  enum to  MI_SAR_AttrType_e
/// @param [in] pAttrParams: variable
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED or other value : Failure
//------------------------------------------------------------------------------
MI_RESULT MI_SAR_SetAttr(MI_HANDLE hSar, MI_SAR_AttrType_e eAttrType, const void *pAttrParams);

//------------------------------------------------------------------------------
/// @brief Get ADC value function for each SAR channel.
/// @param [in] hSar: sar handle.
/// @param [out] u8 pointer to get adc value: pu8Value
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED or other value : Failure
//------------------------------------------------------------------------------
MI_RESULT MI_SAR_AdcGetValue(MI_HANDLE hSar, MI_U8* pu8Value );

//------------------------------------------------------------------------------
/// @brief Get Platform Voltage value function for SAR 7 channel.
/// @param [in] hSar: sar handle.
/// @param [out] array get voltage value: pstSARVolInof
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED or other value : Failure
//------------------------------------------------------------------------------
MI_RESULT MI_SAR_VoltageGetInfo(MI_HANDLE hSar, MI_SAR_Voltage_t* pstSARVolInfo);

//------------------------------------------------------------------------------
/// @brief Set SAR High channel function for RGB HSync application
/// @param [in] hSar: sar handle.
/// @param [in] bEnable: 1: enable high channel, 0: disable high channel
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED or other value : Failure
//------------------------------------------------------------------------------
MI_RESULT MI_SAR_AdcSetHSyncChEn(MI_HANDLE hSar, MI_BOOL bEnable);

//------------------------------------------------------------------------------
/// @brief Switch RGB HSync MUX to direct signal to SAR High channel
/// @param [in] hSar: sar handle.
/// @param [in] u8HsynCh: HSync channel: 0, 1, 2, 3
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED or other value : Failure
//------------------------------------------------------------------------------
MI_RESULT MI_SAR_AdcSetHSyncCh(MI_HANDLE hSar);

//------------------------------------------------------------------------------
/// @brief Get SAR Keypad driver information function.
/// @param [in] hSar: sar handle.
/// @param [in] MI_SAR_KeypadInfo_t pointer:pstKeypadInfo
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED or other value : Failure
//------------------------------------------------------------------------------
MI_RESULT MI_SAR_KeypadGetInfo(MI_HANDLE hSar, MI_SAR_KeypadInfo_t* pstKeypadInfo);

//------------------------------------------------------------------------------
/// @brief Get Kpd Inited Status
/// @param [in] hSar: sar handle.
/// @param [in] eKpdStatus:pointer to get kpd status
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED or other value : Failure
//------------------------------------------------------------------------------
MI_RESULT MI_SAR_KeypadGetStatus(MI_HANDLE hSar, MI_SAR_KeypadStatus_e* peKpdStatus);

//------------------------------------------------------------------------------
/// @brief Set SAR as GPIO channel.
/// @param [in] hSar: sar handle.
/// @param [in] u8InOut: 1: Input, 0:output
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED or other value : Failure
//------------------------------------------------------------------------------
MI_RESULT MI_SAR_GpioConfigDirection(MI_HANDLE hSar, MI_BOOL bInOut);

//------------------------------------------------------------------------------
/// @brief Set SAR GPIO channel High/Low
/// @param [in] hSar: sar handle.
/// @param [in] bHighLow: 1: High, 0:low
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED or other value : Failure
//------------------------------------------------------------------------------
MI_RESULT MI_SAR_GpioSetOutput(MI_HANDLE hSar, MI_BOOL bHighLow);

//------------------------------------------------------------------------------
/// @brief Get SAR GPIO channel High/Low
/// @param [in] hSar: sar handle.
/// @param [out] pbResult:   pointer to get Input level
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED or other value : Failure
//------------------------------------------------------------------------------
MI_RESULT MI_SAR_GpioGetInput(MI_HANDLE hSar, MI_BOOL* pbResult);

//------------------------------------------------------------------------------
/// @brief  Set SAR Interrupt mask
/// @param [in] hSar: sar handle.
/// @param [in] bEnable:  1: enable interrupt, 0: disable interrupt
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED or other value : Failure
//------------------------------------------------------------------------------
MI_RESULT MI_SAR_ConfigInterrupt(MI_HANDLE hSar, MI_BOOL bEnable);

//------------------------------------------------------------------------------
/// @brief  Clear SAR Status
/// @param [in] hSar: sar handle.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED or other value : Failure
//------------------------------------------------------------------------------
MI_RESULT MI_SAR_ClearInterrupt(MI_HANDLE hSar);

//------------------------------------------------------------------------------
/// @brief  Get SAR Status
/// @param [in] hSar: sar handle.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED or other value : Failure
//------------------------------------------------------------------------------
MI_RESULT MI_SAR_GetInterruptStatus(MI_HANDLE hSar);

//------------------------------------------------------------------------------
/// @brief Set SAR debug function level.
/// @param[in] u32DebugLevel: MI_DBG_NONE /MI_DBG_ERR/MI_DBG_WRN/MI_DBG_INFO/MI_DBG_ALL
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED : Failure
//------------------------------------------------------------------------------
MI_RESULT MI_SAR_SetDebugLevel(MI_DBG_LEVEL u32DebugLevel);

#ifdef __cplusplus
}
#endif

#endif///_MI_SAR_H_
