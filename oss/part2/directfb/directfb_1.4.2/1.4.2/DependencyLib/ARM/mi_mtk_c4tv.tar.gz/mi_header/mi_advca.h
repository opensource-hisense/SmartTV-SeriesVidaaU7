/*------------------------------------------------------------------------------
 * MediaTek Inc. (C) 2018. All rights reserved.
 *
 * Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 *----------------------------------------------------------------------------*/
//------------------------------------------------------------------------------
// Use GetXxx/SetXxx only
//------------------------------------------------------------------------------

#ifndef _MI_ADVCA_H_
#define _MI_ADVCA_H_

#ifdef __cplusplus
extern "C" {
#endif

#include "mi_dsc.h"

//-------------------------------------------------------------------------------------------------
//  Defines
//-------------------------------------------------------------------------------------------------

//-------------------------------------------------------------------------------------------------
//  Structures
//-------------------------------------------------------------------------------------------------
typedef enum
{
    E_MI_ADVCA_OTP_ITEM_NULL = 0,

    E_MI_ADVCA_OTP_ITEM_SCW,
    E_MI_ADVCA_OTP_ITEM_MSID,
    E_MI_ADVCA_OTP_ITEM_DEACTIVE_HCPU_TO_DMA,
    E_MI_ADVCA_OTP_ITEM_HASH0_VERSION,
    E_MI_ADVCA_OTP_ITEM_HASH2_VERSION,

    E_MI_ADVCA_OTP_ITEM_MAX
} MI_ADVCA_OtpItem_e;

typedef enum
{
    E_MI_ADVCA_NULL = 0,

    E_MI_ADVCA_BESTCAS,
    E_MI_ADVCA_CONAX,
    E_MI_ADVCA_CTI,
    E_MI_ADVCA_DRE,
    E_MI_ADVCA_IRDETO,
    E_MI_ADVCA_LATENS,
    E_MI_ADVCA_NAGRA,
    E_MI_ADVCA_NDS,
    E_MI_ADVCA_NSTV,
    E_MI_ADVCA_PANACCESS,
    E_MI_ADVCA_SMI,
    E_MI_ADVCA_SUMAVISION,
    E_MI_ADVCA_VIACCESS,
    E_MI_ADVCA_VMX,
    E_MI_ADVCA_ECHOSTAR,

    E_MI_ADVCA_MAX
} MI_ADVCA_Vendor_e;

typedef enum
{
    E_MI_ADVCA_DEBUG_PORT_JTAG = 0,
    E_MI_ADVCA_DEBUG_PORT_I2C,
    E_MI_ADVCA_DEBUG_PORT_SCAN,

    E_MI_ADVCA_DEBUG_PORT_MAX
} MI_ADVCA_DebugPort_e;

typedef enum
{
    E_MI_ADVCA_DEBUG_MODE_OPEN = 0,
    E_MI_ADVCA_DEBUG_MODE_PASSWD,
    E_MI_ADVCA_DEBUG_MODE_CLOSE,

    E_MI_ADVCA_DEBUG_MODE_MAX
} MI_ADVCA_DebugMode_e;

typedef enum
{
    E_MI_ADVCA_IFCP_CMD_SET_DSC_KEY,                        /// parameter type is a pointer to MI_ADVCA_IfcpInfo_t
    E_MI_ADVCA_IFCP_CMD_SET_PVR_SESSION_KEY,                /// parameter type is a pointer to MI_ADVCA_IfcpInfo_t

    E_MI_ADVCA_IFCP_CMD_MAX,
} MI_ADVCA_IfcpCmdType_e;

typedef struct MI_ADVCA_InitParams_s
{
    MI_U8 u8Reserved;           ///[IN]: Reserved
} MI_ADVCA_InitParams_t;

typedef struct MI_ADVCA_OpenParams_s
{
    MI_U8 u8Reserved;           ///[IN]: Reserved
} MI_ADVCA_OpenParams_t;

typedef struct MI_ADVCA_OtpData_s
{
    MI_ADVCA_OtpItem_e eOtpItem;                                 ///[IN]: OTP Item
    MI_U32 u32OtpVal;                                           ///[IN]: OTP Val
} MI_ADVCA_OtpData_t;

typedef struct MI_ADVCA_ChipsetConfigParams_s
{
    MI_ADVCA_OtpData_t astOtpData[E_MI_ADVCA_OTP_ITEM_MAX];    ///[IN]: OTP Value Array.
    MI_U8 u8OtpDataNum;                                                              ///[IN]: OTP Data Real Number
} MI_ADVCA_ChipsetConfigParams_t;

typedef struct MI_ADVCA_IfcpLoadInfo_s
{
    MI_U32 u32ActivationMsgLen;   ///[IN]: Activation Message Length
    MI_U8 *pu8ActivationMsgBuf;         ///[IN]: Activation Message
    MI_U32 u32ImageLen;                ///[IN]: Image Length
    MI_U8 *pu8ImageBuf;                      ///[IN]: Image.
} MI_ADVCA_IfcpLoadInfo_t;


typedef struct MI_ADVCA_IfcpInfo_s
{
    MI_HANDLE hDsc;                                 ///[IN]:Key ladder information
    MI_DSC_KeyType_e eKeyType;                      ///[IN]:Key ladder information
    MI_DSC_Algo_e eAlgorithm;                       ///[IN]:Key ladder information
    MI_U32 u32HeaderLen;                            ///[IN]:Key ladder information
    MI_U8 *pu8HeaderBuf;                               ///[IN]:Key ladder information
    MI_U32 u32ExtraDataLen;                         ///[IN]:Key ladder information
    MI_U8 *pu8ExtraDataBuf;                            ///[IN]:Key ladder information
    MI_U32 u32PayloadLen;                           ///[IN]:Key ladder information
    MI_U8 *pu8PayloadBuf;                              ///[IN]:Key ladder information
    MI_U32 u32OutputDataLen;                        ///[IN]:Key ladder information
    MI_U8 *pu8OutputDataBuf;                           ///[IN]:Key ladder information
    MI_U32 u32AppHeaderLen;                         ///[IN]:Application control information: optional
    MI_U8 *pu8AppHeaderBuf;                            ///[IN]:Application control information: optional
    MI_U32 u32AppPayloadLen;                        ///[IN]:Application control information: optional
    MI_U8 *pu8AppPayloadBuf;                           ///[IN]:Application control information: optional
    MI_U32 u32AppOutputDataLen;                     ///[IN]:Application control information: optional
    MI_U8 *pu8AppOutputDataBuf;                        ///[IN]:Application control information: optional
} MI_ADVCA_IfcpInfo_t;


typedef struct MI_ADVCA_IfcpCmdInfo_s
{
    MI_ADVCA_IfcpCmdType_e eCmdType; ///[IN]: OTP Value Array.
    MI_ADVCA_IfcpInfo_t stIfcpInfo; ///[IN]: OTP Value Array.
} MI_ADVCA_IfcpCmdInfo_t;


typedef struct MI_ADVCA_DumpInfoParams_s
{
    MI_U8 u8Reversed;       ///[IN]: Reserve
}MI_ADVCA_DumpInfoParams_t;

//-------------------------------------------------------------------------------------------------
//  Global Functions
//-------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------
/// @brief Init advanced CA module.
/// @param[in] pstInitParams: A pointer to structure MI_ADVCA_InitParams_t for initialization.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_ADVCA_Init(const MI_ADVCA_InitParams_t *pstInitParams);

//------------------------------------------------------------------------------
/// @brief Finalize advanced CA module.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_ADVCA_DeInit(void);

//------------------------------------------------------------------------------
/// @brief Open a Advca handle.
/// @param[in] pstOpenParam: A pointer to structure MI_ADVCA_OpenParams_t for open advca module.
/// @param[out] phAdvca: A handle pointer to retrieve an instance of a created advca module.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_RESOURCES: No available resource.
//------------------------------------------------------------------------------
MI_RESULT MI_ADVCA_Open(const MI_ADVCA_OpenParams_t *pstOpenParams, MI_HANDLE *phAdvca);

//------------------------------------------------------------------------------
/// @brief Close a Advca handle.
/// @param[in] hAdvca: An instance of a created Advca module.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_ADVCA_Close(MI_HANDLE hAdvca);

//------------------------------------------------------------------------------
/// @brief Read value from OTP by input address.
/// @param[in] hAdvca: An instance of a created Advca module.
/// @param[in] u32Addr: indicate the address in OTP to read, address from 0x0000 to 0x1ffc.
/// @param[out] pu32Value: A pointer to a buffer for reading, size is 4 byte.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_ADVCA_ReadOtp(MI_HANDLE hAdvca, MI_U32 u32Addr, MI_U32 *pu32Value);

//------------------------------------------------------------------------------
/// @brief Write value into OTP by input address.
/// @param[in] hAdvca: An instance of a created Advca module.
/// @param[in] u32Addr: indicate the address in OTP to write, address from 0x0000 to 0x1ffc.
/// @param[in] u32Value: A pointer to a buffer for writing, size is 4 byte.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_ADVCA_WriteOtp(MI_HANDLE hAdvca, MI_U32 u32Addr, MI_U32 u32Value);

//------------------------------------------------------------------------------
/// @brief Get device ID.
/// @param[in] hAdvca: An instance of a created Advca module.
/// @param[out] pu8DeviceIdBuf: A pointer to a buffer for getting device ID.
/// @param[in] u32BufSize indicate the size of buffer(pu8DeviceIdBuf).
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_ADVCA_GetDeviceId(MI_HANDLE hAdvca, MI_U8 *pu8DeviceIdBuf, MI_U32 u32BufSize);

//------------------------------------------------------------------------------
/// @brief Set device ID.
/// @param[in] hAdvca: An instance of a created Advca module.
/// @param[in] pu8DeviceIdBuf: A pointer to a buffer for setting device ID.
/// @param[in] u32BufSize indicate the size of buffer(pu8DeviceIdBuf).
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_ADVCA_SetDeviceId(MI_HANDLE hAdvca, MI_U8 *pu8DeviceIdBuf, MI_U32 u32BufSize);

//------------------------------------------------------------------------------
/// @brief Get market ID.
/// @param[in] hAdvca: An instance of a created Advca module.
/// @param[out] pu32MarketId: A pointer to a buffer for getting market ID.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_ADVCA_GetMarketId(MI_HANDLE hAdvca, MI_U32 *pu32MarketId);

//------------------------------------------------------------------------------
/// @brief Set market ID.
/// @param[in] hAdvca: An instance of a created Advca module.
/// @param[in] u32MarketId: the value of market ID.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_ADVCA_SetMarketId(MI_HANDLE hAdvca, MI_U32 u32MarketId);

//------------------------------------------------------------------------------
/// @brief Get debug mode by input port.
/// @param[in] hAdvca: An instance of a created Advca module.
/// @param[in] eDebugPort: indicate the port to get debug mode.
/// @param[out] peDebugMode: A pointer to enumeration MI_ADVCA_DebugMode_e.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_ADVCA_GetDebugMode(MI_HANDLE hAdvca, MI_ADVCA_DebugPort_e eDebugPort, MI_ADVCA_DebugMode_e *peDebugMode);

//------------------------------------------------------------------------------
/// @brief Set debug mode by input port.
/// @param[in] hAdvca: An instance of a created Advca module.
/// @param[in] eDebugPort: indicate the port to set debug mode.
/// @param[in] eDebugMode: the value of enumeration MI_ADVCA_DebugMode_e.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_ADVCA_SetDebugMode(MI_HANDLE hAdvca, MI_ADVCA_DebugPort_e eDebugPort, MI_ADVCA_DebugMode_e eDebugMode);

//------------------------------------------------------------------------------
/// @brief Check if the secure boot is enable or not.
/// @param[in] hAdvca: An instance of a created Advca module.
/// @param[out] pbEnable: A pointer to a flag which indicate the secure boot is enable or not.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_ADVCA_IsSecureBootEnable(MI_HANDLE hAdvca, MI_BOOL *pbEnable);

//------------------------------------------------------------------------------
/// @brief Enable secure boot.
/// @param[in] hAdvca: An instance of a created Advca module.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_ADVCA_EnableSecureBoot(MI_HANDLE hAdvca);

//------------------------------------------------------------------------------
/// @brief Check if force secure CW is enable or not.
/// @param[in] hAdvca: An instance of a created Advca module.
/// @param[out] pbEnable: A pointer to a flag which indicate the secure CW is enable or not.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_ADVCA_IsSecureCwModeEnable(MI_HANDLE hAdvca, MI_BOOL *pbEnable);

//------------------------------------------------------------------------------
/// @brief Enable force secure CW.
/// @param[in] hAdvca: An instance of a created Advca module.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_ADVCA_EnableSecureCwMode(MI_HANDLE hAdvca);

//------------------------------------------------------------------------------
/// @brief Check chipset CA setting clean for MP .
/// @param[in] hAdvca: An instance of a created Advca module.
/// @param[in] eCaVendor: Ca vendor.
/// @param[in] pstChipsetConfigParams: A pointer to structure MI_ADVCA_IsChipsetConfig for checking chipset.
/// @return MI_OK: Chipset is clean.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_NOT_SUPPORT: Not supported yet.
/// @return MI_ERR_FAILED: Chipset config is done or other error.
//------------------------------------------------------------------------------
MI_RESULT MI_ADVCA_IsChipsetClean(MI_HANDLE hAdvca, MI_ADVCA_Vendor_e eCaVendor, MI_ADVCA_ChipsetConfigParams_t* pstChipsetConfigParams);

//------------------------------------------------------------------------------
/// @brief Config chipset for MP.
/// @param[in] hAdvca: An instance of a created Advca module.
/// @param[in] eCaVendor: Ca vendor.
/// @param[in] pstOtpParams: A pointer to structure MI_ADVCA_ConfigChipset for setting chipset.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_NOT_SUPPORT: Not supported yet.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_ADVCA_ConfigChipset(MI_HANDLE hAdvca, MI_ADVCA_Vendor_e eCaVendor, MI_ADVCA_ChipsetConfigParams_t* pstChipsetConfigParams);

//------------------------------------------------------------------------------
/// @brief Send Command for TEE.
/// @param[in] hAdvca: An instance of a created Advca module.
/// @param[in] pCmdParams: A pointer to structure according to eCmd.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_NOT_SUPPORT: Not supported yet.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_ADVCA_IfcpSendCmd(MI_HANDLE hAdvca, MI_ADVCA_IfcpCmdInfo_t *pstIfcpCmdInfo);

//------------------------------------------------------------------------------
/// @brief Load Image for TEE.
/// @param[in] hAdvca: An instance of a created Advca module.
/// @param[in] pCmdParams: A pointer to structure according to eCmd.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_NOT_SUPPORT: Not supported yet.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_ADVCA_IfcpLoadImage(MI_HANDLE hAdvca, MI_ADVCA_IfcpLoadInfo_t *pstIfcpLoadInfo);

//------------------------------------------------------------------------------
/// @brief Dump advanced CA Info.
/// @param[in] pstDumpInfoParams: struct for printing resources .
/// @return MI_OK: Dump information success.
//------------------------------------------------------------------------------
MI_RESULT MI_ADVCA_DumpInfo(const MI_ADVCA_DumpInfoParams_t* pstDumpInfoParams);

//------------------------------------------------------------------------------
/// @brief get CA vendor list that chipset support.
/// @param[in] hAdvca: An instance of a created Advca module.
/// @param[out] ppeCaVendorList: a pointer to an array of supported CA list.
/// @param[out] pu8Size: a pointer to indicate the number of supported CA in the list.
/// @return MI_OK: Read CA Vendor Ok.
//------------------------------------------------------------------------------
MI_RESULT MI_ADVCA_GetSupportCa(MI_HANDLE hAdvca, MI_ADVCA_Vendor_e **ppeCaVendorList, MI_U8 *pu8Size);

//------------------------------------------------------------------------------
/// @brief Set Advanced CA debug level.
/// @param[in] u32DbgLevel.
/// @return MI_OK: Set debug level success.
//------------------------------------------------------------------------------
MI_RESULT MI_ADVCA_SetDebugLevel(MI_DBG_LEVEL u32DebugLevel);


#ifdef __cplusplus
}
#endif

#endif///_MI_ADVCA_H_


