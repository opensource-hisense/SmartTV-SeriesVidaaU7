/*------------------------------------------------------------------------------
 * MediaTek Inc. (C) 2018. All rights reserved.
 *
 * Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 *----------------------------------------------------------------------------*/

#ifndef _MI_FLASH_H_
#define _MI_FLASH_H_

#ifdef __cplusplus
extern "C" {
#endif

//-------------------------------------------------------------------------------------------------
//  Defines
//-------------------------------------------------------------------------------------------------
#define MI_FLASH_ENV_SIZE (0x10000)
#define MI_FLASH_ENV_DATA_SIZE (MI_FLASH_ENV_SIZE - sizeof(MI_U32))

#define MI_FLASH_ENV_NAME_LEN_MAX    256
#define MI_FLASH_ENV_VALUE_LEN_MAX  2048

#define MI_FLASH_UBI_VOL_NAME_MAX         (127)
#define MI_FLASH_UBI_MAX_VOLUMES          (128)


typedef enum
{
    E_MI_FLASH_TYPE_SPI =0,
    E_MI_FLASH_TYPE_NAND,
    E_MI_FLASH_TYPE_EMMC,
    E_MI_FLASH_TYPE_MAX,
} MI_FLASH_Type_e;

typedef enum
{
    E_MI_FLASH_PROTECTION_MODE_NONE=0,///<user none mode, it will disable all protection mechanism. it is free to access and speed up.
    E_MI_FLASH_PROTECTION_MODE_BY_DEFAULT, ///<system default mode, system will unprotect before write, and protect whole after write
    E_MI_FLASH_PROTECTION_MODE_BY_BLOCK_PROTECTION_BITS, ///<BP0~BPx bit protection, user can only protect memory region from TOP or Bottom to a specified address. control by Flash BP0~BPx
    E_MI_FLASH_PROTECTION_MODE_BY_INDIVIDUAL_BLOCK,///<individual block lock, protection unit of block or sector.
    E_MI_FLASH_PROTECTION_MODE_MAX, ///< invalid
} MI_FLASH_ProtectionMode_e;

typedef enum
{
    E_MI_FLASH_ATTR_TYPE_MIN=0,
    E_MI_FLASH_ATTR_TYPE_SPI_MIN,
    E_MI_FLASH_ATTR_TYPE_SPI_ID = E_MI_FLASH_ATTR_TYPE_SPI_MIN,              //use MI_FLASH_IdInfo_t as para
    E_MI_FLASH_ATTR_TYPE_SPI_TOTAL_SIZE,      //total size in bytes
    E_MI_FLASH_ATTR_TYPE_SPI_SECTION_SIZE,        //Section size
    E_MI_FLASH_ATTR_TYPE_SPI_SECTION_NUM,        //Number of Sections
    E_MI_FLASH_ATTR_TYPE_SPI_MAX,
    E_MI_FLASH_ATTR_TYPE_NAND_MIN,
    E_MI_FLASH_ATTR_TYPE_NAND_ID = E_MI_FLASH_ATTR_TYPE_NAND_MIN,
    E_MI_FLASH_ATTR_TYPE_NAND_TOTALSIZE,
    E_MI_FLASH_ATTR_TYPE_NAND_PARTITION_SIZE,
    E_MI_FLASH_ATTR_TYPE_NAND_MAX,
    E_MI_FLASH_ATTR_TYPE_ENV_MIN,
    E_MI_FLASH_ATTR_TYPE_ENV_LOCATION = E_MI_FLASH_ATTR_TYPE_ENV_MIN,
    E_MI_FLASH_ATTR_TYPE_ENV_MAX,
    E_MI_FLASH_ATTR_TYPE_PROTECTION_MIN,
    E_MI_FLASH_ATTR_TYPE_PROTECTION_MODE = E_MI_FLASH_ATTR_TYPE_PROTECTION_MIN, ///<access flash protection mode, parameter type is a pointer to MI_FLASH_ProtectionMode_e
    E_MI_FLASH_ATTR_TYPE_PROTECTION_RANGE_ALIGNMENT, ///<get protect area alignment, parameter type is a pointer to MI_FLASH_MemAttr_t. pass desired range, the return range will be alignment
    E_MI_FLASH_ATTR_TYPE_PROTECTION_LOCK, ///<set protect area, parameter type is a pointer to MI_FLASH_MemAttr_t. the range should be aligned to flash protection layout.
    E_MI_FLASH_ATTR_TYPE_PROTECTION_UNLOCK, ///<remove protect area, parameter type is a pointer to MI_FLASH_MemAttr_t. the range should be aligned to flash protection layout.
    E_MI_FLASH_ATTR_TYPE_PROTECTION_MAX,
    E_MI_FLASH_ATTR_TYPE_OTP_MIN,
    E_MI_FLASH_ATTR_TYPE_OTP_RANGE_ALIGNMENT = E_MI_FLASH_ATTR_TYPE_OTP_MIN,///<get otp area alignment, parameter type is a pointer to MI_FLASH_MemAttr_t. pass desired range, the return range will be alignment
    E_MI_FLASH_ATTR_TYPE_OTP_LOCK, ///<lock flash otp range, parameter type is a pointer to MI_FLASH_MemAttr_t. the range should be aligned to OTP layout
    E_MI_FLASH_ATTR_TYPE_OTP_MAX,
    E_MI_FLASH_ATTR_TYPE_UBI_MIN,
    E_MI_FLASH_ATTR_TYPE_UBI_BLOCK_SIZE = E_MI_FLASH_ATTR_TYPE_UBI_MIN,
    E_MI_FLASH_ATTR_TYPE_UBI_TOTAL_SIZE,
    E_MI_FLASH_ATTR_TYPE_MTD_ID_BY_PART_NAME,
    E_MI_FLASH_ATTR_TYPE_UBI_VOLUME_SIZE,
    E_MI_FLASH_ATTR_TYPE_UBI_VOLUME_COUNT,
    E_MI_FLASH_ATTR_TYPE_UBI_VOLUME_BLOCK_COUNT,
    E_MI_FLASH_ATTR_TYPE_UBI_VOLUME_NAME_BY_ID,
    E_MI_FLASH_ATTR_TYPE_UBI_VOLUME_ID_BY_NAME,
    E_MI_FLASH_ATTR_TYPE_UBI_VOLUME_IS_EXIST,
    E_MI_FLASH_ATTR_TYPE_UBI_DEVICE_ATTACH,
    E_MI_FLASH_ATTR_TYPE_UBI_DEVICE_DETACH,
    E_MI_FLASH_ATTR_TYPE_UBI_VOLUME_CREATE,
    E_MI_FLASH_ATTR_TYPE_UBI_VOLUME_DESTROY,
    E_MI_FLASH_ATTR_TYPE_UBI_VOLUME_RESIZE,
    E_MI_FLASH_ATTR_TYPE_UBI_MAX,
    E_MI_FLASH_ATTR_TYPE_MAX,
} MI_FLASH_AttrType_e;

typedef enum
{
    E_MI_FLASH_NAND_ACCESS_TYPE_RW_ADDR,
    E_MI_FLASH_NAND_ACCESS_TYPE_RW_PARTITION,
    E_MI_FLASH_NAND_ACCESS_TYPE_UBI,
    E_MI_FLASH_NAND_ACCESS_TYPE_MAX,
} MI_FLASH_NandAccessType_e;

typedef enum
{
    E_MI_FLASH_NAND_ERASE_TYPE_ADDR,
    E_MI_FLASH_NAND_ERASE_TYPE_PARTITION,
    E_MI_FLASH_NAND_ERASE_TYPE_PHYSICAL_BLOCK,
    E_MI_FLASH_NAND_ERASE_TYPE_MAX,
} MI_FLASH_NandEraseType_e;

//-------------------------------------------------------------------------------------------------
//  Structures
//-------------------------------------------------------------------------------------------------
typedef struct MI_FLASH_IdInfo_s
{
    MI_U8 *pu8FlashId;
    MI_U32 u32Length;
} MI_FLASH_IdInfo_t;

typedef struct MI_FLASH_PartInfo_s
{
    MI_U32 u32PartType;
    MI_U32 u32PartSize;
} MI_FLASH_PartInfo_t;

typedef struct MI_FLASH_SpiAccess_s
{
    MI_U32 u32StartAddr;
    MI_U8 *pu8Buf;
    MI_U32 u32Length;
} MI_FLASH_SpiAccess_t;

typedef struct MI_FLASH_NandRwAddrParams_s
{
    MI_U32 u32StartAddr;
    MI_U8 *pu8Buf;
    MI_U32 u32Length;
} MI_FLASH_NandRwAddrParams_t;

typedef struct MI_FLASH_NandRwPartParams_s
{
    MI_U32 u32PartitionNum;
    MI_U32 u32StartAddr;
    MI_U8 *pu8Buf;
    MI_U32 u32Length;
} MI_FLASH_NandRwPartParams_t;

typedef struct MI_FLASH_NandRwVolParams_s
{
    MI_U8 *pszPartitionName;
    MI_U8 *pszVolumeName;
    MI_U32 u32StartAddr;
    MI_U8 *pu8Buf;
    MI_U32 u32Length;
} MI_FLASH_NandRwVolParams_t;

typedef struct MI_FLASH_NandAccess_s
{
    MI_FLASH_NandAccessType_e eAccessType;
    union
    {
        MI_FLASH_NandRwAddrParams_t stRwAddrParams;
        MI_FLASH_NandRwPartParams_t stRwPartParams;
        MI_FLASH_NandRwVolParams_t  stRwVolParams;
    };
} MI_FLASH_NandAccess_t;

typedef struct{
    union
    {
        MI_U8 *pszPartitionName;
        MI_U8 u8PartitionIdx; //for ecos
    };
    MI_U32 u32StartAddr;
    MI_U8 *pu8Buf;
    MI_U32 u32Length;
}MI_FLASH_EmmcAccess_t;

typedef struct MI_FLASH_EepromAccess_s
{
    MI_U32 u32StartAddress;
    MI_U8 *pu8Buf;
    MI_U32 u32Length;
} MI_FLASH_EepromAccess_t;

typedef struct MI_FLASH_ReadParams_s
{
    MI_FLASH_Type_e eType;
    union
    {
        MI_FLASH_SpiAccess_t stSpiAccess;
        MI_FLASH_NandAccess_t stNandAccess;
        MI_FLASH_EmmcAccess_t stEmmcAccess;
        MI_FLASH_EepromAccess_t stEepromAccess;
    };
} MI_FLASH_ReadParams_t;
typedef struct MI_FLASH_ReadOutputParams_s
{
    MI_U8 *pu8Buf;
    MI_U32 u32Length;
}MI_FLASH_ReadOutputParams_t;

typedef MI_FLASH_ReadParams_t MI_FLASH_WriteParams_t;
typedef struct MI_FLASH_WriteOutputParams_s
{
    MI_U32 u32Length;
}MI_FLASH_WriteOutputParams_t;

typedef struct MI_FLASH_SpiErase_s
{
    MI_U32 u32StartAddr;
    MI_U32 u32Length;
} MI_FLASH_SpiErase_t;

typedef struct MI_FLASH_NandEraseAddr_s
{
    MI_U32 u32StartAddr;
    MI_U32 u32Length;
} MI_FLASH_NandEraseAddr_t;

typedef struct MI_FLASH_NandErasePartition_s
{
    MI_U16 u16PartType;
} MI_FLASH_NandErasePartition_t;

typedef struct
{
    MI_U8 *pszPartitionName;
    MI_U32 u32StartAddr;
    MI_U32 u32Length;
} MI_FLASH_EmmcErase_t;

typedef struct MI_FLASH_NandErasePhyBlk_s
{
    MI_U16 u16BlkIdx;
} MI_FLASH_NandErasePhyBlk_t;

typedef struct MI_FLASH_NandErase_s
{
    MI_FLASH_NandEraseType_e eEraseType;
    union
    {
        MI_FLASH_NandEraseAddr_t stEraseAddrParams;
        MI_FLASH_NandErasePartition_t stErasePartParams;
        MI_FLASH_NandErasePhyBlk_t stErasePhyBlkParams;
    };
} MI_FLASH_NandErase_t;

typedef struct MI_FLASH_Erase_s
{
    MI_FLASH_Type_e eType;
    union
    {
        MI_FLASH_SpiErase_t stSpiErase;
        MI_FLASH_NandErase_t stNandErase;
        MI_FLASH_EmmcErase_t stEmmcErase;
    };
} MI_FLASH_Erase_t;

typedef struct MI_FLASH_EnvInfo_s
{
    MI_U32 u32Crc;//CRC32 over data bytes
    MI_U8 au8Data[MI_FLASH_ENV_DATA_SIZE];
} MI_FLASH_EnvInfo_t;
typedef struct MI_FLASH_GetEnvVarInput_s
{
    MI_FLASH_EnvInfo_t *pstCurEnv;
    MI_U8 *pszName;
}MI_FLASH_GetEnvVarInput_t;
typedef struct MI_FLASH_GetEnvVarOutput_s
{
    MI_U8 szValue[MI_FLASH_ENV_VALUE_LEN_MAX];
}MI_FLASH_GetEnvVarOutput_t;

typedef struct MI_FLASH_SetEnvVar_s
{
    MI_FLASH_EnvInfo_t *pstCurEnv;
    MI_U8 *pszName;
    MI_U8 *pszValue;
}MI_FLASH_SetEnvVar_t;

typedef struct MI_FLASH_UnfdParams_s
{
    MI_U8 *pu8NandInfo;
    MI_U8 *pu8PartitionInfo;
} MI_FLASH_UnfdParams_t;

typedef struct MI_FLASH_InitParams_s
{
    MI_FLASH_UnfdParams_t stUnfdParam;
} MI_FLASH_InitParams_t;

typedef struct MI_FLASH_MemAttr_s
{
    MI_FLASH_Type_e eType;      ///< flash type, SPI NOR or NAND Flash
    MI_BOOL bLocked;                      ///< lock status, 0 is no lock and free to write, 1 means locked
    MI_U32 u32LowerBound;       /// <range lower bound
    MI_U32 u32UpperBound;       ///<  range upper bound
} MI_FLASH_MemAttr_t;

typedef struct
{
    MI_FLASH_Type_e eType;
    MI_FLASH_NandAccessType_e eNandAccessType;
    MI_U8 szPartName[MI_FLASH_UBI_VOL_NAME_MAX];
} MI_FLASH_OpenParams_t;
typedef MI_FLASH_OpenParams_t MI_FLASH_QueryHandleParams_t;

typedef struct
{
    MI_U8 szVolName[MI_FLASH_UBI_VOL_NAME_MAX];
    MI_U64 u64VolByteSize;
} MI_FLASH_UBICreateVolumeAttr_t;
typedef struct
{
    MI_U8 szVolName[MI_FLASH_UBI_VOL_NAME_MAX];
    MI_S32 s32Size;
} MI_FLASH_UBIResizeVolumeAttr_t;


//-------------------------------------------------------------------------------------------------
//  Global Functions
//-------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------
///// @brief Init flash module
///// @param[in] : pstInitParam
///// @return MI_OK: Process success.
///// @return MI_HAS_INITED: Module had inited.
///// @return MI_ERR_RESOURCES: No available resource.
///// @sa
///// @note
////-----------------------------------------------------------------------------
MI_RESULT MI_FLASH_Init(const MI_FLASH_InitParams_t *pstInitParams);

//------------------------------------------------------------------------------
///// @brief DeInit the SPI flash
///// @param[in] : none
///// @return MI_OK: Process success
///// @sa
///// @note
////-----------------------------------------------------------------------------
MI_RESULT MI_FLASH_DeInit(void);

//------------------------------------------------------------------------------
/// @brief open flash handle
/// @param[in] MI_FLASH_OpenParams_t.
/// @param[out] phFlash.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_FLASH_Open(const MI_FLASH_OpenParams_t *pstOpenParams, MI_HANDLE *phFlash);

//------------------------------------------------------------------------------
/// @brief Get FLASH handle
/// @param[in] MI_FLASH_QueryHandleParams_t: GetHandle Params
/// @param[out] phFlash: get FLASH handle
/// @return MI_OK: Get FLASH handle success.
/// @return MI_ERR_FAILED: Get FLASH handle fail.
//------------------------------------------------------------------------------
MI_RESULT MI_FLASH_GetHandle(const MI_FLASH_QueryHandleParams_t *pstQueryParams, MI_HANDLE *phFlash);

//------------------------------------------------------------------------------
/// @brief Close flash handle
/// @param[in] hFlash.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_FLASH_Close(MI_HANDLE hFlash);

//------------------------------------------------------------------------------
///// @brief Load current env data from SPI flash
///// @param[in] hFlash. flash handle to process
///// @param[out] pstGetCurEnv: pointer to get current env
///// @return MI_OK: Process success
///// @return MI_ERR_FAILED: Process failure
///// @return MI_ERR_INVALID_PARAMETER: Parameter invalid
///// @return MI_ERR_NOT_INITED: Module not inited
///// @sa
///// @note : Load env info from SPI first.
////-----------------------------------------------------------------------------
MI_RESULT MI_FLASH_LoadEnv(MI_HANDLE hFlash, MI_FLASH_EnvInfo_t *pstGetCurEnv);

//------------------------------------------------------------------------------
///// @brief MI_FLASH_StoreEnv : Store env data into SPI flash
///// @param[in] hFlash. flash handle to process
///// @param[in] pstPutNewEnv: the env info to be stored
///// @return MI_OK: Process success
///// @return MI_ERR_FAILED: Process failure
///// @return MI_ERR_INVALID_PARAMETER: Parameter invalid
///// @return MI_ERR_NOT_INITED: Module not inited
///// @sa
///// @note : Store env info into SPI.
////-----------------------------------------------------------------------------
MI_RESULT MI_FLASH_StoreEnv(MI_HANDLE hFlash, MI_FLASH_EnvInfo_t *pstPutNewEnv);

//------------------------------------------------------------------------------
///// @brief Get an environment variable from current env info
///// @param[in] hFlash. flash handle to process
///// @param[in] pFlashInputParams: Input Params.
///// @param[out] pFlashOutputParams : Output Params.
///// @return MI_OK: Process success
///// @return MI_ERR_FAILED: Process failure
///// @return MI_ERR_INVALID_PARAMETER: Parameter invalid
///// @return MI_ERR_NOT_INITED: Module not inited
///// @sa
///// @note : Load env info from SPI first, then get an env variable from env info.
////-----------------------------------------------------------------------------
MI_RESULT MI_FLASH_GetEnvVar(MI_HANDLE hFlash, const MI_FLASH_GetEnvVarInput_t *pstFlashInputParams, MI_FLASH_GetEnvVarOutput_t *pstFlashOutputParams);

//------------------------------------------------------------------------------
///// @brief Add/Modify an environment variable.
///// @param[in] hFlash. flash handle to process
///// @param[in] pstFlashParams: Input Params
///// @return MI_OK: Process success
///// @return MI_ERR_FAILED: Process failure
///// @return MI_ERR_NOT_INITED: Module not inited
///// @sa
///// @note : Load env info from SPI first, then modify an env variable in env info .
////-----------------------------------------------------------------------------
MI_RESULT MI_FLASH_SetEnvVar(MI_HANDLE hFlash, MI_FLASH_SetEnvVar_t *pstFlashParams);

//------------------------------------------------------------------------------
///// @brief Write data into flash.
///// @param[in] hFlash. flash handle to process
///// @param[in] pstWriteParam: pointer to the write data parameter
///// @param[in] pstOutputParams: pointer to the write data output
///// @return MI_OK: Process success
///// @return MI_ERR_FAILED: Process failure
///// @return MI_ERR_NOT_INITED: Module not inited
///// @return MI_ERR_INVALID_PARAMETER: Parameter invalid
///// @sa
///// @note
////-----------------------------------------------------------------------------
MI_RESULT MI_FLASH_Write(MI_HANDLE hFlash, const MI_FLASH_WriteParams_t *pstWriteParams, MI_FLASH_WriteOutputParams_t *pstOutputParams);

//------------------------------------------------------------------------------
///// @brief Write data into flash without erase.
///// @param[in] hFlash. flash handle to process
///// @param[in] ptWriteParam: pointer to the write data parameter
///// @param[out] pstOutputParams: pointer to the write data output
///// @return MI_OK: Process success
///// @return MI_ERR_FAILED: Process failure
///// @return MI_ERR_NOT_INITED: Module not inited
///// @return MI_ERR_INVALID_PARAMETER: Parameter invalid
///// @sa
///// @note The caller should ensure the data only change from 1->0
////-----------------------------------------------------------------------------
MI_RESULT MI_FLASH_WriteWithoutErase(MI_HANDLE hFlash, const MI_FLASH_WriteParams_t *pstWriteParam, MI_FLASH_WriteOutputParams_t *pstOutputParams);

//------------------------------------------------------------------------------
///// @brief Read data from flash.
///// @param[in] hFlash. flash handle to process
///// @param[in] pstReadParam: pointer to the read data parameter
///// @param[out] pstOutputParams: pointer to the data to read
///// @return MI_OK: Process success
///// @return MI_ERR_FAILED: Process failure
///// @return MI_ERR_NOT_INITED: Module not inited
///// @return MI_ERR_INVALID_PARAMETER: Parameter invalid
///// @sa
///// @note
////-----------------------------------------------------------------------------
MI_RESULT MI_FLASH_Read(MI_HANDLE hFlash, const MI_FLASH_ReadParams_t *pstReadParams, MI_FLASH_ReadOutputParams_t *pstOutputParams);

//------------------------------------------------------------------------------
///// @brief Erase flash data.
///// @param[in] hFlash. flash handle to process
///// @param[in] pstEraseParam: pointer to the erase parameter
///// @return MI_OK: Process success
///// @return MI_ERR_FAILED: Process failure
///// @return MI_ERR_NOT_INITED: Module not inited
///// @return MI_ERR_INVALID_PARAMETER: Parameter invalid
///// @sa
///// @note
////-----------------------------------------------------------------------------
MI_RESULT MI_FLASH_Erase(MI_HANDLE hFlash, MI_FLASH_Erase_t *pstEraseParam);

//------------------------------------------------------------------------------
///// @brief Get attribute from flash.
///// @param[in] hFlash. flash handle to process
///// @param[in] eAttrType : the attribute that you want to get in FLASH module.
///// @param[in] pInputParams: the pointer to parameters of eAttrType.
///// @param[in] pOutputParams: the pointer to MI_FLASH_AttrType_e's member that wants to get in FLASH module.
///// @return MI_OK: Process success
///// @return MI_ERR_FAILED: Process failure
///// @return MI_ERR_NOT_INITED: Module not inited
///// @return MI_ERR_INVALID_PARAMETER: Parameter invalid
///// @sa
///// @note
////-----------------------------------------------------------------------------
MI_RESULT MI_FLASH_GetAttr(MI_HANDLE hFlash, MI_FLASH_AttrType_e eAttrType, const void * pInputParams, void * pOutputParams);
//------------------------------------------------------------------------------
///// @brief Set attribute from flash.
///// @param[in] hFlash. flash handle to process
///// @param[in] eAttrType: Infomation type
///// @param[out] pParam: pointer to get the attribute
///// @return MI_OK: Process success
///// @return MI_ERR_FAILED: Process failure
///// @return MI_ERR_NOT_INITED: Module not inited
///// @return MI_ERR_INVALID_PARAMETER: Parameter invalid
///// @return MI_ERR_RESOURCES: specified range is not allowed to be set
///// @sa
///// @note
////-----------------------------------------------------------------------------
MI_RESULT MI_FLASH_SetAttr(MI_HANDLE hFlash, MI_FLASH_AttrType_e eAttrType, const void * pAttrParams);

//------------------------------------------------------------------------------
///// @brief Write data into flash otp space.
///// @param[in] hFlash. flash handle to process
///// @param[in] pstWriteParam: pointer to the write data parameter
///// @param[out] pstOutputParams: pointer to the write data output
///// @return MI_OK: Process success
///// @return MI_ERR_FAILED: Process failure
///// @return MI_ERR_NOT_INITED: Module not inited
///// @return MI_ERR_INVALID_PARAMETER: Parameter invalid
///// @sa
///// @note
////-----------------------------------------------------------------------------
MI_RESULT MI_FLASH_OtpWrite(MI_HANDLE hFlash, const MI_FLASH_WriteParams_t *pstWriteParam, MI_FLASH_WriteOutputParams_t *pstOutputParams);

//------------------------------------------------------------------------------
///// @brief Read data from flash otp space.
///// @param[in] hFlash. flash handle to process
///// @param[in] pstReadParam: pointer to the read data parameter
///// @param[out] pstOutputParams: pointer to the data to read
///// @return MI_OK: Process success
///// @return MI_ERR_FAILED: Process failure
///// @return MI_ERR_NOT_INITED: Module not inited
///// @return MI_ERR_INVALID_PARAMETER: Parameter invalid
///// @sa
///// @note
////-----------------------------------------------------------------------------
MI_RESULT MI_FLASH_OtpRead(MI_HANDLE hFlash, const MI_FLASH_ReadParams_t *pstReadParams, MI_FLASH_ReadOutputParams_t *pstOutputParams);

//------------------------------------------------------------------------------
///// @brief Set Debug level for flash module
///// @param[in] : eDbgLevel
///// @return MI_OK: Process success.
///// @sa
///// @note
////-----------------------------------------------------------------------------
MI_RESULT MI_FLASH_SetDebugLevel(MI_DBG_LEVEL u32DebugLevel);

#ifdef __cplusplus
}
#endif

#endif///_MI_FLASH_H_
