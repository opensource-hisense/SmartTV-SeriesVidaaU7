/*------------------------------------------------------------------------------
 * MediaTek Inc. (C) 2018. All rights reserved.
 *
 * Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 *----------------------------------------------------------------------------*/

#ifndef _MI_IIC_H_
#define _MI_IIC_H_

#ifdef __cplusplus
extern "C" {
#endif

//-------------------------------------------------------------------------------------------------
//  Defines
//-------------------------------------------------------------------------------------------------

//-------------------------------------------------------------------------------------------------
//  Structures
//-------------------------------------------------------------------------------------------------
typedef enum
{
    E_MI_IIC_PORT_0 = 0, /// port 0_0 //disable port 0
    E_MI_IIC_PORT0_1,    /// port 0_1
    E_MI_IIC_PORT0_2,    /// port 0_2
    E_MI_IIC_PORT0_3,    /// port 0_3
    E_MI_IIC_PORT0_4,    /// port 0_4
    E_MI_IIC_PORT0_5,    /// port 0_5
    E_MI_IIC_PORT0_6,    /// port 0_6
    E_MI_IIC_PORT0_7,    /// port 0_7

    E_MI_IIC_PORT_1 = 8, /// port 1_0 //disable port 1
    E_MI_IIC_PORT1_1,    /// port 1_1
    E_MI_IIC_PORT1_2,    /// port 1_2
    E_MI_IIC_PORT1_3,    /// port 1_3
    E_MI_IIC_PORT1_4,    /// port 1_4
    E_MI_IIC_PORT1_5,    /// port 1_5
    E_MI_IIC_PORT1_6,    /// port 1_6
    E_MI_IIC_PORT1_7,    /// port 1_7

    E_MI_IIC_PORT_2 = 16,/// port 2_0 //disable port 2
    E_MI_IIC_PORT2_1,    /// port 2_1
    E_MI_IIC_PORT2_2,    /// port 2_2
    E_MI_IIC_PORT2_3,    /// port 2_3
    E_MI_IIC_PORT2_4,    /// port 2_4
    E_MI_IIC_PORT2_5,    /// port 2_5
    E_MI_IIC_PORT2_6,    /// port 2_6
    E_MI_IIC_PORT2_7,    /// port 2_7

    E_MI_IIC_PORT_3 = 24,/// port 3_0 //disable port 3
    E_MI_IIC_PORT3_1,    /// port 3_1
    E_MI_IIC_PORT3_2,    /// port 3_2
    E_MI_IIC_PORT3_3,    /// port 3_3
    E_MI_IIC_PORT3_4,    /// port 3_4
    E_MI_IIC_PORT3_5,    /// port 3_5
    E_MI_IIC_PORT3_6,    /// port 3_6
    E_MI_IIC_PORT3_7,    /// port 3_7

    E_MI_IIC_SW_PORT_0 = 1024, /// swiic port0
    E_MI_IIC_SW_PORT_1,        /// swiic port1
    E_MI_IIC_SW_PORT_2,        /// swiic port2
    E_MI_IIC_SW_PORT_3,        /// swiic port3
    E_MI_IIC_SW_PORT_4,        /// swiic port4
    E_MI_IIC_SW_PORT_5,        /// swiic port5
    E_MI_IIC_SW_PORT_6,        /// swiic port6
    E_MI_IIC_SW_PORT_7,        /// swiic port7

    E_MI_IIC_PORT_NOSUP  /// non-support port

} MI_IIC_Port_e;

typedef enum
{
    E_MI_IIC_DEVICE_INVALID = 0,
    E_MI_IIC_DEVICE_TUNER_1,
    E_MI_IIC_DEVICE_MAX,
}MI_IIC_DeviceId_e;

typedef enum
{
    E_MI_IIC_CLOCK_HIGH = 0,  /// high speed
    E_MI_IIC_CLOCK_NORMAL,    /// normal speed
    E_MI_IIC_CLOCK_SLOW,      /// slow speed
    E_MI_IIC_CLOCK_VSLOW,     /// very slow
    E_MI_IIC_CLOCK_USLOW,     /// ultra slow
    E_MI_IIC_CLOCK_UVSLOW,    /// ultra-very slow
    E_MI_IIC_CLOCK_NOSUP      /// non-support speed
} MI_IIC_Clock_e;

typedef enum
{
    E_MI_IIC_READ_MODE_DEFAULT = 0,   ///< slave address + reg address in write mode, direction change to read mode, repeat start slave address in read mode, data from device
    E_MI_IIC_READ_MODE_DIRECT,        ///< first transmit slave address + reg address and then start receive the data */
    E_MI_IIC_READ_MODE_DIRECTION_CHANGE_STOP_START,   ///< slave address + reg address in write mode + stop, direction change to read mode, repeat start slave address in read mode, data from device
    E_MI_IIC_READ_MODE_MAX
}MI_IIC_ReadMode_e;

typedef struct MI_IIC_Access_s
{
    MI_U16 u16BusNumSlaveId;        ///[IN]: iic_bus <<8 | (slave_id<<1 +bit0 (W/R))
    MI_U8  u8AddrCnt;               ///[IN]: control reg count
    MI_U8* pu8Addr;                 ///[IN]: control reg addr
    MI_U16 u16Size;                 ///[IN]: W/R data size
    MI_U8* pu8Buf;                  ///[IN]: W/R data buffer
} MI_IIC_Access_t;

typedef struct MI_IIC_InitParams_s
{
    MI_U8 u8Reserved;               ///[IN]: reserved
} MI_IIC_InitParams_t;

typedef struct MI_IIC_OpenParams_s
{
    MI_IIC_Port_e ePort;            ///[IN]: open parameters iic port enum
} MI_IIC_OpenParams_t;

typedef MI_IIC_OpenParams_t MI_IIC_QueryHandleParams_t;

typedef struct MI_IIC_ReadParams_s
{
    MI_U16 u16BusNumSlaveId;        ///[IN]: iic_bus <<8 | (slave_id<<1 +bit0 (W/R))
    MI_U8  u8AddrCnt;               ///[IN]: control reg count
    MI_U8* pu8Addr;                 ///[IN]: control reg addr
    MI_U16 u16Size;                 ///[IN]: W/R data size
    MI_IIC_ReadMode_e eReadMode;    ///[IN]: iic read mode
}MI_IIC_ReadParams_t;

typedef struct MI_IIC_ReadOutputParams_s
{
    MI_U8* pu8Buf;                  ///[out]: read data buffer
}MI_IIC_ReadOutputParams_t;

typedef struct MI_IIC_WriteParams_s
{
    MI_IIC_Access_t stWriteData;    ///[IN]: iic write data struct
}MI_IIC_WriteParams_t;

typedef struct MI_IIC_WriteOutputParams_s
{
    MI_U8 u8Reserved;              ///[IN]: reserved
}MI_IIC_WriteOutputParams_t;

typedef struct MI_IIC_DeviceInfo_s
{
    MI_IIC_Port_e ePort;            ///[IN]: iic bus port
    MI_U16 u16BusNumSlaveId;        ///[IN]: iic bus number <<8  | iic slave id
}MI_IIC_DeviceInfo_t;
//-------------------------------------------------------------------------------------------------
//  Global Functions
//-------------------------------------------------------------------------------------------------

//------------------------------------------------------------------------------
/// @brief Init IIC module.
/// @param[in] pstInitParams : A pointer to structure MI_IIC_InitParams_t for initialization.
/// @return MI_OK: Process success.
/// @return MI_HAS_INITED: Module has inited.
/// @return MI_ERR_FAILED: Process fail..
//------------------------------------------------------------------------------
MI_RESULT MI_IIC_Init(const MI_IIC_InitParams_t* pstInitParams);

//------------------------------------------------------------------------------
/// @brief Finalize the IIC module.
/// @param[None].
/// @return MI_OK: Process success.
//------------------------------------------------------------------------------
MI_RESULT MI_IIC_DeInit(void);

//------------------------------------------------------------------------------
/// @brief get iic info from iic deviceID.
/// @param[in] eDeviceId : iic device ID.
/// @param[out] pstDeviceInfo : A pointer to structure MI_IIC_DeviceInfo_t for iic device info.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail..
//------------------------------------------------------------------------------
MI_RESULT MI_IIC_GetDeviceInfo(MI_IIC_DeviceId_e eDeviceId, MI_IIC_DeviceInfo_t * pstDeviceInfo);

//------------------------------------------------------------------------------
/// @brief Open new IIC port.
/// @param[in] pstOpenParam. : Selection the using IIC port
/// @param[in] phIic : return the IIC handle
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not inted.
/// @return MI_ERR_INVALID_PARAMETER: parameter error.
/// @return MI_ERR_RESOURCES: No available resource.
//------------------------------------------------------------------------------
MI_RESULT MI_IIC_Open(const MI_IIC_OpenParams_t* pstOpenParams, MI_HANDLE* phIic);

//------------------------------------------------------------------------------
/// @brief Close IIC port.
/// @param[in] hIic : IIC handle to be closed
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not inted.
/// @return MI_ERR_INVALID_PARAMETER: parameter error.
/// @return MI_ERR_INVALID_HANDLE: Illigel handle.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_IIC_Close(MI_HANDLE hIic);

//------------------------------------------------------------------------------
/// @brief Get Handle of the IIC module.
/// @param[in]  pstQueryParams: A pointer to structure MI_IIC_QueryHandleParams_t.
/// @param[out] phIic: phIic for retrieve an instance of IIC interface.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: IIC module Get Handle failed.
/// @return MI_ERR_INVALID_PARAMETR: Parameters is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_IIC_GetHandle(const MI_IIC_QueryHandleParams_t* pstQueryParams, MI_HANDLE* phIic);

//------------------------------------------------------------------------------
/// @brief Read Data through IIC.
/// @param[in] hIic : IIC handle to read
/// @param[in] pstReadParams. : A pointer to structure MI_IIC_ReadParams_t iic for reading input data
/// @param[out] pstOutputParams. : A pointer to structure MI_IIC_ReadOutputParams_t for reading putput data
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not inted.
/// @return MI_ERR_INVALID_HANDLE: Illigel handle.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_IIC_Read(MI_HANDLE hIic, const MI_IIC_ReadParams_t *pstReadParams, MI_IIC_ReadOutputParams_t *pstOutputParams);

//------------------------------------------------------------------------------
/// @brief Write data through IIC.
/// @param[in] hIic : IIC handle to write
/// @param[in] pstWriteParams. : A pointer to structure MI_IIC_WriteParams_t  for writing input data
/// @param[out] pstOutputParams. : A pointer to structure MI_IIC_WriteOutputParams_t for writing output data
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not inted.
/// @return MI_ERR_INVALID_HANDLE: Illigel handle.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_IIC_Write(MI_HANDLE hIic, const MI_IIC_WriteParams_t *pstWriteParams, MI_IIC_WriteOutputParams_t *pstOutputParams);

//------------------------------------------------------------------------------
/// @brief Set IIC Speed.
/// @param[in] hIic : IIC handle to set speed
/// @param[in] eSpeed. : setting speed
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not inted.
/// @return MI_ERR_INVALID_PARAMETER: parameter error.
/// @return MI_ERR_INVALID_HANDLE: Illigel handle.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_IIC_SetSpeed(MI_HANDLE hIic, MI_IIC_Clock_e eSpeed);

//------------------------------------------------------------------------------
/// @brief Set IIC debug level.
/// @param[in] eDbgLevel.
/// @return MI_OK: Set debug level success.
//------------------------------------------------------------------------------
MI_RESULT MI_IIC_SetDebugLevel(MI_DBG_LEVEL u32DebugLevel);

#ifdef __cplusplus
}
#endif

#endif///_DAPI_IIC_H_

