/*------------------------------------------------------------------------------
 * MediaTek Inc. (C) 2018. All rights reserved.
 *
 * Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 *----------------------------------------------------------------------------*/
//----------------------------------------------------------------------------------------
//  GetXxx/SetXxx and GetAttr/SetAttr coexit
//----------------------------------------------------------------------------------------

#if (ENABLE_PVR_PACKAGE == 1)
#ifndef _MI_PVR_H_
#define _MI_PVR_H_

#ifdef __cplusplus
extern "C" {
#endif

#include "mi_dmx.h"
#include "mi_video.h"
#include "mi_audio.h"
#include "mi_cipher.h"


//-------------------------------------------------------------------------------------------------
//  Defines
//-------------------------------------------------------------------------------------------------
#define MI_PVR_AUDIO_NUM                                (16)        ///< max recordable Audio pids
#define MI_PVR_SUBT_NUM                                 (12)        ///< max recordable Subtitle pids
#define MI_PVR_TTX_NUM                                  (12)        ///< max recordable Teletext pids
#define MI_PVR_ENCRYPT_KEY_SIZE                         (4)

//-------------------------------------------------------------------------------------------------
//  Structures
//-------------------------------------------------------------------------------------------------
typedef enum
{
    E_MI_PVR_FS_UNKNOWN = 0,                            ///< unknown file system
    E_MI_PVR_FS_JFFS2,                                  ///< jffs2 file system
    E_MI_PVR_FS_VFAT,                                   ///< fat, fat32 file system
    E_MI_PVR_FS_EXT2,                                   ///< ext2 file system
    E_MI_PVR_FS_EXT3,                                   ///< ext3 file system
    E_MI_PVR_FS_MSDOS,                                  ///< msdos file system
    E_MI_PVR_FS_NTFS,                                   ///< ntfs file system

    E_MI_PVR_FS_MAX
} MI_PVR_FileSystemType_e;

typedef enum
{
    E_MI_PVR_PLAYBACK_SPEED_32XFB    = -32000,          /// < -32 X for fast backward
    E_MI_PVR_PLAYBACK_SPEED_16XFB    = -16000,          /// < -16 X for fast backward
    E_MI_PVR_PLAYBACK_SPEED_8XFB     =  -8000,          /// < - 8 X for fast backward
    E_MI_PVR_PLAYBACK_SPEED_4XFB     =  -4000,          /// < - 4 X for fast backward
    E_MI_PVR_PLAYBACK_SPEED_2XFB     =  -2000,          /// < - 2 X for fast backward
    E_MI_PVR_PLAYBACK_SPEED_1XFB     =  -1000,          /// < - 1 X for fast backward
    E_MI_PVR_PLAYBACK_SPEED_0X       =      0,          /// < Freeze for PAUSE
    E_MI_PVR_PLAYBACK_SPEED_FF_1_32X =     32,          /// < 1 / 32 X for slow forward
    E_MI_PVR_PLAYBACK_SPEED_FF_1_16X =     64,          /// < 1 / 16 X for slow forward
    E_MI_PVR_PLAYBACK_SPEED_FF_1_8X  =    125,          /// < 1 / 8  X for slow forward
    E_MI_PVR_PLAYBACK_SPEED_FF_1_4X  =    250,          /// < 1 / 4  X for slow forward
    E_MI_PVR_PLAYBACK_SPEED_FF_1_2X  =    500,          /// < 1 / 2  X for slow forward
    E_MI_PVR_PLAYBACK_SPEED_1X       =   1000,          /// <     1  X for normal playback
    E_MI_PVR_PLAYBACK_SPEED_2XFF     =   2000,          /// <     2  X for fast forward
    E_MI_PVR_PLAYBACK_SPEED_4XFF     =   4000,          /// <     4  X for fast forward
    E_MI_PVR_PLAYBACK_SPEED_8XFF     =   8000,          /// <     8  X for fast forward
    E_MI_PVR_PLAYBACK_SPEED_16XFF    =  16000,          /// <    16  X for fast forward
    E_MI_PVR_PLAYBACK_SPEED_32XFF    =  32000,          /// <    32  X for fast forward
} MI_PVR_PlaybackSpeed_e;

typedef enum
{
    E_MI_PVR_JUMP_FROM_START = 0,                       ///< jump from start position
    E_MI_PVR_JUMP_FROM_CURRENT,                         ///< jump from current position
    E_MI_PVR_JUMP_FROM_END                              ///< jump from end position

} MI_PVR_JumpPosition_e;

typedef enum
{
    E_MI_PVR_RECORD_EVENT_RECORD_TIME = MI_BIT(0),             ///< record time updating, event param pEventParam is a pointer to MI_U32 to retrieve the current record time in seconds.
    E_MI_PVR_RECORD_EVENT_RECORD_SIZE = MI_BIT(1),             ///< record size updating, event param pEventParam is a pointer to MI_U32 to retrieve the current record size in KBytes.
    E_MI_PVR_RECORD_EVENT_STOP_X_WRITE_FAILED = MI_BIT(2),     ///< stop record due to write failed, event param pEventParam = NULL
    E_MI_PVR_RECORD_EVENT_STOP_X_NO_DISK_SPACE = MI_BIT(3),    ///< stop record due to NO DISK space(USB plug out?), event param pEventParam = NULL
    E_MI_PVR_RECORD_EVENT_SETUP_KEY_LADDER = MI_BIT(4),        ///< setup key ladder for generating key to AESDMA (cipher text)
    E_MI_PVR_RECORD_EVENT_NO_DATA = MI_BIT(5),                 ///< record status, no data for recording.
    E_MI_PVR_RECORD_EVENT_SETUP_CIPHER_KEY = MI_BIT(6),        ///< setup cipher key to AESDMA (plain text), event param pEventParam is a pointer to MI_PVR_KeyIndexParams_t
    E_MI_PVR_RECORD_EVENT_BUFFER_OVERRUN = MI_BIT(7),            ///< record status, buffer overrun happens, , event param pEventParam is a pointer to MI_PVR_BufferOverrunInfo_t.
    E_MI_PVR_RECORD_EVENT_ALL = 0xFFFFFFFF,                 ///< all record events

} MI_PVR_RecordEvent_e;

typedef enum
{
    E_MI_PVR_PLAYBACK_EVENT_CA_AUTH_METADATA = MI_BIT(0),      ///< notify ca mw metadata is prepared for authentication, event param pEventParam is a pointer to MI_PVR_CallbackCaMetadata_t
    E_MI_PVR_PLAYBACK_EVENT_PLAYBACK_TIME = MI_BIT(16),        ///< playback time updating, event param pEventParam is a pointer to MI_U32 to retrieve the current playback time in seconds.
    E_MI_PVR_PLAYBACK_EVENT_PLAYBACK_SIZE = MI_BIT(17),        ///< playback size updating, event param pEventParam is a pointer to MI_U32 to retrieve the current playback size in KBytes.
    E_MI_PVR_PLAYBACK_EVENT_RESTART_X_FILE_HEAD = MI_BIT(18),  ///< restart playback due to FB reach to the head of file, event param pEventParam = NULL
    E_MI_PVR_PLAYBACK_EVENT_STOP_X_FILE_END = MI_BIT(19),      ///< stop playback due to end of file, event param pEventParam = NULL
    E_MI_PVR_PLAYBACK_EVENT_STOP_X_READ_FAILED = MI_BIT(20),   ///< stop playback due to read failed, event param pEventParam = NULL
    E_MI_PVR_PLAYBACK_EVENT_STOP_X_NO_DISK_SPACE = MI_BIT(21), ///< stop playback due to NO DISK space(USB plug out?), event param pEventParam = NULL
    E_MI_PVR_PLAYBACK_EVENT_SETUP_KEY_LADDER = MI_BIT(22),     ///< setup key ladder for generating key to AESDMA (cipher text), event param pEventParam = NULL
    E_MI_PVR_PLAYBACK_EVENT_SETUP_CIPHER_KEY = MI_BIT(23),     ///< setup cipher key to AESDMA (plain text), event param pEventParam is a pointer to MI_PVR_KeyIndexParams_t
    E_MI_PVR_PLAYBACK_EVENT_START_NEXT_CHUNK = MI_BIT(24),     ///< notify the playback transitions between chunks success

    E_MI_PVR_PLAYBACK_EVENT_ALL = 0xFFFFFFFF,               ///< all playback events
} MI_PVR_PlaybackEvent_e;

typedef enum
{
    E_MI_PVR_ENCRYPT_TYPE_KEYLADDER = 0,                ///Encrypt key is from key ladder
    E_MI_PVR_ENCRYPT_TYPE_DEFAULT,                      ///Encrypt key is defined in MI_PVR
    E_MI_PVR_ENCRYPT_TYPE_USER,                         ///Encrypt key is user defined in au32EncryptKey[]
    E_MI_PVR_ENCRYPT_TYPE_DYNAMIC_KEY,                  ///Encrypt key is dynamic changed
    E_MI_PVR_ENCRYPT_TYPE_MAX,
} MI_PVR_EncryptType_e;

typedef enum
{
    E_MI_PVR_ATTR_TYPE_GLOBAL_MIN            = 0x00000000,
    E_MI_PVR_ATTR_TYPE_CRYPTO_CA_VENDOR_ID   = E_MI_PVR_ATTR_TYPE_GLOBAL_MIN,   ///< configure cavid for crypto engine; parameter is a pointer to MI_CIPHER_CaVid_e
    E_MI_PVR_ATTR_TYPE_DISPLAY_WINDOW,                                          ///< configure display window; parameter is a pointer to MI_HANDLE

    E_MI_PVR_ATTR_TYPE_RECORD_MIN            = 0x10000000,
    E_MI_PVR_ATTR_TYPE_TIMESHIFT_TO_RECORD   = E_MI_PVR_ATTR_TYPE_RECORD_MIN,   ///< enable tiemshift to record (save files); parameter is a pointer to NULL

    E_MI_PVR_ATTR_TYPE_PLAYBACK_MIN          = 0x20000000,
    E_MI_PVR_ATTR_TYPE_TIMESHIFT_AUTO_RESUME = E_MI_PVR_ATTR_TYPE_PLAYBACK_MIN, ///< timeshift auto resume normal playback when FF to the file end; parameter is a pointer to MI_BOOL
    E_MI_PVR_ATTR_TYPE_PLAYBACK_ENABLE_AD,                                      ///< enable/disable AD playback; parameter is a pointer to MI_BOOL
    E_MI_PVR_ATTR_TYPE_PLAYBACK_DMX_PATH_PARAMS,
    E_MI_PVR_ATTR_TYPE_PLAYBACK_CHUNK_NUM,                                      ///< total chunks number in list; parameter is a pointer to MI_U32
    E_MI_PVR_ATTR_TYPE_MAX,
} MI_PVR_AttrType_e;

typedef enum
{
    E_MI_PVR_PLAYBACK_CA_RETURN_STATUS_AUTH_FAILED = 0,      ///< CA notify metadata authentication failed
    E_MI_PVR_PLAYBACK_CA_RETURN_STATUS_AUTH_SUCCESS,         ///< CA notify metadata authentication success

    E_MI_PVR_PLAYBACK_CA_RETURN_STATUS_MAX,
} MI_PVR_PlaybackCaReturnStatus_e;

typedef enum
{
    E_MI_PVR_CA_EVENT_RECORD_OPEN = MI_BIT(0),           ///< record open, event param pEventParams is a pointer to MI_PVR_CaNotifyEventState_t
    E_MI_PVR_CA_EVENT_RECORD_CLOSE = MI_BIT(1),          ///< record close, event param pEventParams is a pointer to MI_PVR_CaNotifyEventState_t
    E_MI_PVR_CA_EVENT_RECORD_PID_OPEN = MI_BIT(2),       ///< record pid open, event param pEventParams is a pointer to MI_PVR_CaNotifyEventPidInfo_t
    E_MI_PVR_CA_EVENT_RECORD_PID_CLOSE = MI_BIT(3),      ///< record pid close, event param pEventParams is a pointer to MI_PVR_CaNotifyEventPidInfo_t
    E_MI_PVR_CA_EVENT_RECORD_PMT_CHANGE = MI_BIT(4),     ///< record pmt change, event param pEventParams is a pointer to MI_PVR_CaNotifyEventState_t
    E_MI_PVR_CA_EVENT_PLAYBACK_OPEN = MI_BIT(16),        ///< playback open, event param pEventParams is a pointer to MI_PVR_CaNotifyEventState_t
    E_MI_PVR_CA_EVENT_PLAYBACK_CLOSE = MI_BIT(17),       ///< playback close, event param pEventParams is a pointer to MI_PVR_CaNotifyEventState_t
    E_MI_PVR_CA_EVENT_PLAYBACK_PID_OPEN = MI_BIT(18),    ///< playback pid open, event param pEventParams is a pointer to MI_PVR_CaNotifyEventPidInfo_t
    E_MI_PVR_CA_EVENT_PLAYBACK_PID_CLOSE = MI_BIT(19),   ///< playback pid close, event param pEventParams is a pointer to MI_PVR_CaNotifyEventPidInfo_t

    E_MI_PVR_CA_EVENT_ALL = 0xFFFFFFFF,
} MI_PVR_CaEvent_e;

typedef MI_RESULT (*MI_PVR_EventCallback)(MI_HANDLE hPvr, MI_U32 u32Event, void *pEventParams, void *pUserParams);   ///< The prototype of event callback function
typedef struct MI_PVR_CallbackInputParams_s
{
    MI_U64 u64CallbackId;                              ///[IN]: for multi-callback, use 0 for first register or single callback.
    MI_PVR_EventCallback pfEventCallback;              ///[IN]: callback function pointer.
    MI_U32 u32EventFlags;                              ///[IN]: registered events which are bitwise OR operation.
    void * pUserParams;                                ///[IN]: for passing user-defined parameters.
} MI_PVR_CallbackInputParams_t;

typedef struct MI_PVR_CallbackOutputParams_s
{
    MI_U64 u64CallbackId;                              ///[OUT]: the returned ID for update or unregister callback.
} MI_PVR_CallbackOutputParams_t;


typedef struct MI_PVR_Caps_s
{
    MI_S32 s32MaxRecordNum;                             ///< [OUT]: max recorders that MI can support simultaneously
    MI_S32 s32MaxPlaybackNum;                           ///< [OUT]: max playback that MI can support simultaneously
} MI_PVR_Caps_t;

typedef struct MI_PVR_InitParams_s
{
    MI_PVR_FileSystemType_e eFsType;                    ///< [IN]: type of file system
    MI_U8 *pszMountPath;                                ///< [IN]: mount path of storage(USB)
    MI_BOOL bUseUnicode;                                ///< [IN]: TRUE for using unicode for filename, FALSE for using ascii code
    MI_BOOL bTimeshiftSeamless;                         ///< [IN]: support seamless timeshift
    MI_U8 u8MaxRecordNum;                               ///< [IN]: max record number that APP will be used at same time
    MI_U8 u8MaxPlaybackNum;                             ///< [IN]: max playback number that APP will be used at same time
} MI_PVR_InitParams_t;

typedef struct MI_PVR_AudioInfo_s
{
    MI_U8  au8IsoLangCode[3];                           ///< [IN]: audio ISO639 language code
    MI_U8  u8IsoAudioMode;                              ///< [IN]: 0x00: Stereo, 0x01: Mono right, 0x02: Mono left
    MI_U8  u8IsoAudioType;                              ///< [IN]: 0x00:Undefined,
    ///     0x01:Clean effects,
    ///     0x02: Hearing impaired,
    ///     0x03: Visual impaired commentary,
    ///     0x04~0xFF: Reserved.
    MI_BOOL  bIsoIsValid;                               ///< [IN]: Valid or not
    MI_U16 u16AudioPid;                                 ///< [IN]: Audio PID
    MI_AUDIO_CodecType_e  eAudioCodec;                  ///< [IN]: MI_AUDIO_CodecType_e
                                                        ///< it is OUT when used for _MI_DEMO_PVR_RecordSetProgInfo
} MI_PVR_AudioInfo_t;

typedef struct MI_PVR_SubtInfo_s
{
    MI_U8  au8IsoLangCode[3];                           ///< [IN]: Subtitle ISO639 language code
    MI_U8  u8SubtitlingType;                            ///< [IN]: Subtitling type
    MI_U16 u16CompositionPageId;                        ///< [IN]: Subtitle composition page id
    MI_U16 u16AncillaryPageId;                          ///< [IN]: Subtitle ancillary page id
    MI_U16 u16SubtitlePid;                              ///< [IN]: Subtitle PID
                                                        ///< it is OUT when used for _MI_DEMO_PVR_RecordSetProgInfo
} MI_PVR_SubtInfo_t;

typedef struct MI_PVR_TtxInfo_s
{
    MI_U8  au8IsoLangCode[3];                           ///< [IN]: Teletext ISO639 language code
    MI_U8  u8TeletextType;                              ///< [IN]: Teletext type
    MI_U16 u16MagNum;                                   ///< [IN]: Teletext magazine number
    MI_U16 u16PageNum;                                  ///< [IN]: Teletext page number
    MI_U16 u16TeletextPid;                              ///< [IN]: Teletext PID
                                                        ///< it is OUT when used for _MI_DEMO_PVR_RecordSetProgInfo
} MI_PVR_TtxInfo_t;

typedef struct MI_PVR_MetaData_s
{
    MI_U32 u32Lcn;                                      ///< [IN]: LCN, Logic Channel Numbers of the program
    MI_VIDEO_CodecType_e eVideoCodec;                   ///< [IN]: MI_VIDEO_CodecType_e
    MI_AUDIO_CodecType_e eAudioCodec;                   ///< [IN]: MI_AUDIO_CodecType_e for default track
    MI_U16 u16VideoPid;                                 ///< [IN]: pid of video
    MI_U16 u16AudioPid;                                 ///< [IN]: pid of audio for default track
    MI_U16 u16PcrPid;                                   ///< [IN]: pid of PCR
    MI_U16 u16PmtPid;                                   ///< [IN]: pid of pmt
    MI_U8 u8AudioInfoNum;                               ///< [IN]: number of array astAudioInfo[]
    MI_PVR_AudioInfo_t astAudioInfo[MI_PVR_AUDIO_NUM];   ///< [IN]: detail audio pids info
    MI_U8 u8SubtInfoNum;                                ///< [IN]: number of array astSubtInfo[]
    MI_PVR_SubtInfo_t astSubtInfo[MI_PVR_SUBT_NUM];      ///< [IN]: detail subtitle pids info
    MI_U8 u8TtxInfoNum;                                 ///< [IN]: number of array astTtxInfo[]
    MI_PVR_TtxInfo_t astTtxInfo[MI_PVR_TTX_NUM];         ///< [IN]: detail teletext pids info
    MI_U8 *pszFileName;                                 ///< [IN]: Output file name
    MI_U8 u8Age;                                        ///< [IN]: parental rating
    MI_U64 u64FileSize;                                 ///< [IN]: file size(unit is byte)
    MI_U32 u32Duration;                                 ///< [IN]: duration(unit is second)
    MI_PVR_EncryptType_e eEncryptType;                  ///< [IN]: encrypt type
    MI_U32 au32EncryptKey[MI_PVR_ENCRYPT_KEY_SIZE];     ///< [IN]: encrypt key, valid when eEncryptType is E_MI_PVR_ENCRYPT_TYPE_USER
    MI_CIPHER_Algo_e eCipherAlgo;                       ///< [IN]: Algorithm of cipher module
                                                        ///< it is OUT when used for _MI_DEMO_PVR_RecordSetProgInfo
} MI_PVR_MetaData_t;

typedef struct MI_PVR_TimeshiftToRecord_s
{
    MI_BOOL bEnable;                ///< [IN]: Support timeshift to record or not
} MI_PVR_TimeshiftToRecord_t;

typedef struct MI_PVR_Timeshift_s
{
    MI_U64 u64TimeshiftMaxSizeInKb;                     ///< [IN]: Max size in KB for timeshift
    MI_U64 u64TimeshiftMaxTimeInSec;                    ///< [IN]: Max time in second for timeshift. If both timeshift file duration and size is set, timeshift file size dominate to which condition first achieve.
    MI_BOOL bTimeshift;                                 ///< [IN]: Is this record for timeshift or record
    MI_BOOL bTimeshiftAutoFreezeAv;                     ///< [IN]: auto freeze video & audio when start to record timehsifting and unfreeze when start to playback timeshifting
    MI_PVR_TimeshiftToRecord_t stTimeshiftRec;          ///< [IN]: Configuration of timeshift to record
    MI_HANDLE hLiveVideo;                               ///< [IN]: Live Video Handle
    MI_HANDLE hLiveAudio;                               ///< [IN]: Live Audio Handle
} MI_PVR_Timeshift_t;

typedef struct MI_PVR_RecordParams_s
{
    MI_U8 *pszName;                                     ///< [IN]: Custom defined module instance name which is a string with zero terminated.
    MI_PVR_MetaData_t stMetaData;                       ///< [IN]: The metadata of program for record
    MI_BOOL bRecordAppend;                              ///< [IN]: append last record file
    MI_DMX_PathParams_t stPathParams;                   ///< [IN]: the selection of record path
    MI_U64 u64FileSliceSizeInKb;                        ///< [IN]: File slice size in Kbyte
    MI_PVR_Timeshift_t stTimeshift;                     ///< [IN]: Timeshift information
} MI_PVR_RecordParams_t;

typedef struct MI_PVR_RecordTimeInfo_s
{
    MI_U32 u32RecStartTime;                             ///< [OUT]: record start time
    MI_U32 u32RecTime;                                  ///< [OUT]: record duration time
} MI_PVR_RecordTimeInfo_t;

typedef struct MI_PVR_PlaybackParams_s
{
    MI_HANDLE hPvrRec;                                  ///< [IN]: handle of record instance for playback
    MI_U8 *pszName;                                     ///< [IN]: Custom defined module instance name which is a string with zero terminated.
    MI_U8 *pszFileName;                                 ///< [IN]: filename for playback. If both hPvrRec & pszFileName are set, the MI_PVR will choose hPvrRec for first priority.
    MI_U32 u32PlayStartTimeInSec;                       ///< [IN]: start time for playback. Set 0 for playback from head of file.
    MI_HANDLE hVideo;                                   ///< [IN]: handle of video instance for playback,if hVideo == NULL,means mi_pvr will create a new video handle for playback.
} MI_PVR_PlaybackParams_t;

typedef struct MI_PVR_JumpParams_s
{
    MI_PVR_JumpPosition_e ePos;                         ///< [IN]: jump position
    MI_U32 u32Hour;                                     ///< [IN]: hour of jump time from
    MI_U8 u8Minute;                                     ///< [IN]: minutes of jump time, should be between 0 to 59
    MI_U8 u8Second;                                     ///< [IN]: seconds of jump time, should be between 0 to 59
} MI_PVR_JumpParams_t;

typedef struct MI_PVR_AbLoopParams_s
{
    MI_U32 u32BeginTimeInSec;                           ///< [IN]: begin time in seconds of AB loop
    MI_U32 u32EndTimeInSec;                             ///< [IN]: end time in seconds of AB loop
} MI_PVR_AbLoopParams_t;

typedef struct MI_PVR_SkipParams_s
{
    MI_U32 u32BeginTimeInSec;                           ///< [IN]: begin time in seconds of skip time interval
    MI_U32 u32EndTimeInSec;                             ///< [IN]: end time in seconds of skip time interval
} MI_PVR_SkipParams_t;

typedef struct MI_PVR_PlaybackTimeInfo_s
{
    MI_U32 u32CurrentTimeInSec;                         ///< [OUT]: current time of playback
    MI_U32 u32DurationTimeInSec;                        ///< [OUT]: total duration of playback file
} MI_PVR_PlaybackTimeInfo_t;

typedef struct MI_PVR_FileInfo_s
{
    MI_PVR_MetaData_t stMetaData;                       ///< [IN]: The metadata of record file
    MI_PVR_CallbackInputParams_t stEventCallback;       ///< [IN]: callback function pointer.
} MI_PVR_FileInfo_t;

typedef struct MI_PVR_CaMetadataObj_s
{
    MI_U32 u32Length;       ///< [IN]: Length of raw data of metadata obj
    MI_U8 *pu8Data;         ///< [IN]: A pointer to raw data of metadata obj
} MI_PVR_CaMetadataObj_t;

typedef struct MI_PVR_CallbackCaMetadata_s
{
    MI_PVR_CaMetadataObj_t stDataObj;               ///< [IN]: Ca metadata
    MI_U32 u32Timestamp;                            ///< [IN]: Timestamp of metadata object
    MI_PVR_PlaybackCaReturnStatus_e eReturnStatus;  ///< [OUT]: Access status notified by CA
} MI_PVR_CallbackCaMetadata_t;

typedef struct MI_PVR_CipherParams_s
{
    MI_U32 u32KeySize;                  ///< [IN]: size of input key
    MI_U32 *pu32Key;                    ///< [IN]: A pointer to encryption/decryption key
} MI_PVR_CipherParams_t;

typedef struct MI_PVR_KeyIndexParams_s
{
    MI_U32 u32KeyIndex;                 ///< [IN]: key index
} MI_PVR_KeyIndexParams_t;

/// PVR Query Handle Parameters
typedef struct MI_PVR_QueryHandleParams_s
{
    MI_U8 * pszName;                           ///[IN]: pvr handle with string name.
}MI_PVR_QueryHandleParams_t;

typedef struct MI_PVR_BufferOverrunInfo_s
{
    MI_U8 u8Reserved;
} MI_PVR_BufferOverrunInfo_t;

typedef struct MI_PVR_CaNotifyEventState_s
{
    MI_U8 u8Index;                           ///< [OUT]: Record Index or playback index according to MI_PVR_CaEvent_e.
    MI_BOOL bUseUnicode;                     ///< [OUT]: TRUE for using unicode for filename, FALSE for using ascii code
    MI_BOOL bTimeshift;                      ///< [OUT]: Indicate is timeshift or not
    MI_BOOL bTimeshiftSeamless;              ///< [OUT]: TRUE for seamless timeshift, FALSE for normal timeshift
    MI_U8 *pszMountPath;                     ///< [OUT]: mount path of storage (USB)
    MI_PVR_MetaData_t stMetaData;            ///< [OUT]: The metadata of record file
    MI_HANDLE hTsio;                         ///< [OUT]: MI TSIO handle
} MI_PVR_CaNotifyEventState_t;

typedef struct MI_PVR_CaNotifyEventPidInfo_s
{
    MI_U8 u8Index;                                 ///< [OUT]: Record Index or playback index according to MI_PVR_CaEvent_e.
    MI_U16 u16Pid;                                 ///< [OUT]: Record Pid or playback PID according to MI_PVR_CaEvent_e.
    MI_HANDLE hDmx;                                ///< [OUT]: MI DMX handle
    MI_HANDLE hTsr;                                ///< [OUT]: MI TSR handle
} MI_PVR_CaNotifyEventPidInfo_t;

typedef struct MI_PVR_ChunkInfo_s
{
    MI_U8 *pszFileName;                            ///< [IN]: filename for playback
    MI_U16 u16VideoPid;                            ///< [IN]: video pid of program
    MI_U16 u16AudioPid;                            ///< [IN]: audio pid of program
} MI_PVR_ChunkInfo_t;

typedef struct MI_PVR_ChunkList_s
{
    MI_U32 u32ChunkNum;                            ///< [IN]: total chunks number, the array size of MI_PVR_ChunkInfo_t allocated by user.
    MI_PVR_ChunkInfo_t *pstChunkInfo;              ///< [OUT]: current chunk list
} MI_PVR_ChunkList_t;

//-------------------------------------------------------------------------------------------------
//  Global Functions
//-------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------
/// @brief Get PVR module capibilities.
/// @param[out] pstPvrCaps: A pointer to structure MI_PVR_Caps_t to retrieve the information of PVR capabilities
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_PVR_GetCaps(MI_PVR_Caps_t *pstCaps);

//------------------------------------------------------------------------------
/// @brief Init PVR module.
/// @param[in] pstInitParams.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_PVR_Init(const MI_PVR_InitParams_t *pstInitParams);

//------------------------------------------------------------------------------
/// @brief Finalize PVR module.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_PVR_DeInit(void);

//------------------------------------------------------------------------------
/// @brief Set PVR specific attribure
/// @param[in] hPvr: A handle of a PVR recorder or playback instance
/// @param[in] eAttrType: An attribute type to setup PVR settings
/// @param[in] pAttrParams: A pointer to the value of the corresponding attribute type
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Invalid parameter
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_PVR_SetAttr(MI_HANDLE hPvr, MI_PVR_AttrType_e eAttrType, const void *pAttrParams);

//------------------------------------------------------------------------------
/// @brief Get the attribute/information of a created PVR instance.
/// @param[in] hPvr: A Handle of a created PVR instance.
/// @param[in] eAttrType: The parameter type for getting attribute.
/// @param[in] pInputParams:  A pointer to retrieve the attribute corresponding to the eAttrType. The prototype of pInputputParam plz see the description of enum MI_PVR_AttrType_e
/// @param[out] pOutputParam: A pointer to retrieve the attribute corresponding to the eAttrType. The prototype of pOutputParam plz see the description of enum MI_PVR_AttrType_e
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_SUPPORT: eParamType is not supported.
/// @return MI_ERR_INVALID_HANDLE: hanlde is invalid.
/// @return MI_ERR_INVALID_PARAMETER: parameters is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_PVR_GetAttr(MI_HANDLE hPvr, MI_PVR_AttrType_e eAttrType, const void *pInputParams, void *pOutputParams);

//------------------------------------------------------------------------------
/// @brief Set PVR record(encrypt) and playback(decrypt) key
/// @param[in] hPvr: A handle of a PVR recorder or playback instance
/// @param[in] pstCipherParams: A pointer to struct MI_PVR_CipherParams_t to configure key size and input key
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE: Invalid handle
/// @return MI_ERR_INVALID_PARAMETER: Invalid parameter
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_PVR_SetCipherKey(MI_HANDLE hPvr, const MI_PVR_CipherParams_t *pstCipherParams);

//------------------------------------------------------------------------------
/// @brief Set PVR record(encrypt) key index
/// @param[in] hPvr: A handle of a PVR recorder instance
/// @param[in] pstKeyIndexParams: A pointer to structure MI_PVR_KeyIndexParams_t for key index related settings
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE: Invalid handle
/// @return MI_ERR_INVALID_PARAMETER: Invalid parameter
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_PVR_SetKeyIndex(MI_HANDLE hPvr, const MI_PVR_KeyIndexParams_t *pstKeyIndexParams);

//------------------------------------------------------------------------------
/// @brief Register the callback function for global usage.
/// @param[in] hPvrPlaybk: A Handle of a global instance.
/// @param[in] pstInputParams Input Parameters
/// @param[out] pstOutputParams Output parameters
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE: hanlde is invalid.
/// @return MI_ERR_INVALID_PARAMETER: parameters is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_PVR_RegisterCallback(MI_HANDLE hPvr, const MI_PVR_CallbackInputParams_t *pstInputParams, MI_PVR_CallbackOutputParams_t *pstOutputParams);

//------------------------------------------------------------------------------
/// @brief UnRegister the callback function for for global usage.
/// @param[in] hPvrPlaybk: A Handle of a global instance.
/// @param[in] pstInputParams Input parameters
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE: hanlde is invalid.
/// @return MI_ERR_INVALID_PARAMETER: parameters is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_PVR_UnRegisterCallback(MI_HANDLE hPvr, const MI_PVR_CallbackInputParams_t *pstInputParams);

//------------------------------------------------------------------------------
/// @brief Register the CA callback function for global usage.
/// @param[in] hPvr: A Handle of a global instance.
/// @param[in] pstInputParams: Input Parameters
/// @param[out] pstOutputParams: Output parameters
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Invalid parameter
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_PVR_RegisterCaCallback(MI_HANDLE hPvr, const MI_PVR_CallbackInputParams_t *pstInputParams, MI_PVR_CallbackOutputParams_t *pstOutputParams);

//------------------------------------------------------------------------------
/// @brief UnRegister the CA callback function for for global usage.
/// @param[in] hPvr: A Handle of a global instance.
/// @param[in] pstInputParams: Input Parameters
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Invalid parameter
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_PVR_UnRegisterCaCallback(MI_HANDLE hPvr, const MI_PVR_CallbackInputParams_t *pstInputParams);

//------------------------------------------------------------------------------
/// @brief Check USB speed. The result will be shown in debug UART.
/// @param[out] pu32BestWriteSpeedKb: A pointer to MI_U32 retrieve the best speed of USB write perforamcen.
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Invalid parameter
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_PVR_CheckUsbSpeed(MI_U32 *pu32BestWriteSpeedKb);

//------------------------------------------------------------------------------
/// @brief Get the PVR file information of a PVR record file.
/// @param[in] pszFileName: The filename of PVR record file.
/// @param[out] pstFileInfo: A pointer to struct MI_PVR_FileInfo_t to retrieve the PVR file information.
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Invalid parameter
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_PVR_GetFileInfo(MI_U8 *pszFileName, MI_PVR_FileInfo_t *pstFileInfo);

//------------------------------------------------------------------------------
/// @brief Remove a PVR record file. All the metadata of the corresponding PVR record file will be removed also.
/// @param[in] pszFileName: The filename of PVR record file.
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Invalid parameter
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_PVR_RemoveFile(MI_U8 *pszFileName);

//------------------------------------------------------------------------------
/// @brief Rename a PVR record file. All the metadata of the corresponding PVR record file will be renamed also.
/// @param[in] pszFileName: The filename of PVR record file.
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Invalid parameter
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_PVR_RenameFile(MI_U8 *pszFileName, MI_U8 *pszNewFileName);

//------------------------------------------------------------------------------
/// @brief Set PVR debug level.
/// @param[in] u32DebugLevel
/// @return MI_OK: Set debug level success.
//------------------------------------------------------------------------------
MI_RESULT MI_PVR_SetDebugLevel(MI_DBG_LEVEL u32DebugLevel);


//-------------------------------------------------------------------------------------------------
//  Record Functions
//-------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------
/// @brief Open a recorder instance.
/// @param[in] pstRecParams: A pointer to struct MI_PVR_RecordParams_t for configuring the source streams to be recorded.
/// @param[out] phPvrRec: A pointer to retrieve a handle of a PVR recorder instance.
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Invalid parameter
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_PVR_RecorderOpen(const MI_PVR_RecordParams_t *pstRecParams, MI_HANDLE *phPvrRec);

//------------------------------------------------------------------------------
/// @brief Close a recorder instance.
/// @param[in] hPvrRec: A handle of a PVR recorder instance to be closed.
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Invalid parameter
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_PVR_RecorderClose(MI_HANDLE hPvrRec);

//------------------------------------------------------------------------------
/// @brief Register the callback function for receiving the events of record related.
/// @param[in] hPvrRec: A Handle of a created record instance.
/// @param[in] pstInputParams Input Parameters
/// @param[out] pstOutputParams Output parameters
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE: hanlde is invalid.
/// @return MI_ERR_INVALID_PARAMETER: parameters is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_PVR_RecorderRegisterCallback(MI_HANDLE hPvrRec, const MI_PVR_CallbackInputParams_t *pstInputParams,MI_PVR_CallbackOutputParams_t *pstOutputParams);

//------------------------------------------------------------------------------
/// @brief UnRegister the callback function for receiving the events of record related.
/// @param[in] hPvrRec: A Handle of a created record instance.
/// @param[in] pstCallbackInputParams Input Parameters
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE: hanlde is invalid.
/// @return MI_ERR_INVALID_PARAMETER: parameters is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_PVR_RecorderUnRegisterCallback(MI_HANDLE hPvrRec, const MI_PVR_CallbackInputParams_t * pstInputParams);

//------------------------------------------------------------------------------
/// @brief Start to record.
/// @param[in] hPvrRec: A handle of a PVR recorder instance.
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Invalid parameter
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_PVR_RecorderStart(MI_HANDLE hPvrRec);

//------------------------------------------------------------------------------
/// @brief Stop record.
/// @param[in] hPvrRec: A handle of a PVR recorder instance.
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Invalid parameter
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_PVR_RecorderStop(MI_HANDLE hPvrRec);

//------------------------------------------------------------------------------
/// @brief Pause to record.
/// @param[in] hPvrRec: A handle of a PVR recorder instance.
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Invalid parameter
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_PVR_RecorderPause(MI_HANDLE hPvrRec);

//------------------------------------------------------------------------------
/// @brief Resume record from PAUSE state
/// @param[in] hPvrRec: A handle of a PVR recorder instance.
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Invalid parameter
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_PVR_RecorderResume(MI_HANDLE hPvrRec);

//------------------------------------------------------------------------------
/// @brief Get time information of record
/// @param[in] hPvrRec: A handle of a PVR recorder instance.
/// @param[out] pstTimeInfo: A pointer to struct MI_PVR_RecordTimeInfo_t to retrieve record time information.
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Invalid parameter
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_PVR_RecorderGetTimeInfo(MI_HANDLE hPvrRec, MI_PVR_RecordTimeInfo_t *pstTimeInfo);

//------------------------------------------------------------------------------
/// @brief Update metadata from CA MW when recording.
/// @param[in] hPvr: A handle of a PVR record instance.
/// @param[in] MI_PVR_CaMetadataObj_t: A pointer to the structure MI_PVR_CaMetadataObj_t to write to file when recording.
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE: hanlde is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Invalid parameter.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_PVR_RecorderUpdateCaMetadata(MI_HANDLE hPvrRec, const MI_PVR_CaMetadataObj_t *pstCaMetadataObj);

//------------------------------------------------------------------------------
/// @brief Update program PIDs information when PMT version change.
/// @param[in] hPvrRec: A handle of a PVR recorder instance.
/// @param[in] pstMetaData: A pointer to struct MI_PVR_MetaData_t to update program info.
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Invalid parameter
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_PVR_RecorderProgInfoChange(MI_HANDLE hPvrRec, const MI_PVR_MetaData_t *pstMetaData);

//------------------------------------------------------------------------------
/// @brief Get information of recorded program.
/// @param[in] hPvrRec: A handle of a PVR recorder instance.
/// @param[out] pstMetaData: A pointer to struct MI_PVR_MetaData_t to update program info.
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Invalid parameter
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_PVR_RecorderGetMetadata(MI_HANDLE hPvrRec, MI_PVR_MetaData_t *pstMetaData);

//------------------------------------------------------------------------------
/// @brief get PVR Record handle.
/// @param[in]  pstQueryParams: Query parameters
/// @param[out] phPvrRec: A pointer to retrieve a handle of a PVR recorder instance.
/// @return MI_OK: Get dsc handle success.
/// @return MI_ERR_FAILED: pvr general failed
/// @return MI_ERR_INVALID_PARAMETER: parameter null
//------------------------------------------------------------------------------
MI_RESULT MI_PVR_RecorderGetHandle(const MI_PVR_QueryHandleParams_t *pstQueryParams, MI_HANDLE *phPvrRec);

//------------------------------------------------------------------------------
/// @brief Switch PVR Recorder to next chunk file.
/// @param[in] hPvrRec: A handle of a PVR recorder instance.
/// @param[in] pstMetaData: A pointer to struct MI_PVR_MetaData_t to update program info.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: record next chunk failed
/// @return MI_ERR_INVALID_PARAMETER: parameter null
//------------------------------------------------------------------------------
MI_RESULT MI_PVR_RecorderNextChunk(MI_HANDLE hPvrRec, const MI_PVR_MetaData_t *pstMetaData);

//-------------------------------------------------------------------------------------------------
//  Playback Functions
//-------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------
/// @brief Open a playback instance.
/// @param[in] pstPlaybackParams: A pointer to struct MI_PVR_PlaybackParams_t for for playback.
/// @param[out] phPvrPlaybk: A pointer to retrieve a handle of a PVR playback instance.
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Invalid parameter
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_PVR_PlaybackOpen(const MI_PVR_PlaybackParams_t *pstPlaybackParams, MI_HANDLE *phPvrPlaybk);

//------------------------------------------------------------------------------
/// @brief Close a plaayback instance.
/// @param[in] hPvrPlaybk: A handle of a PVR playback instance to be closed.
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Invalid parameter
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_PVR_PlaybackClose(MI_HANDLE hPvrPlaybk);

//------------------------------------------------------------------------------
/// @brief Register the callback function for receiving the events of playback related.
/// @param[in] hPvrPlaybk: A Handle of a created playback instance.
/// @param[in] pstInputParams Input Parameters
/// @param[out] pstOutputParams Output parameters
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE: hanlde is invalid.
/// @return MI_ERR_INVALID_PARAMETER: parameters is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_PVR_PlaybackRegisterCallback(MI_HANDLE hPvrPlaybk, const MI_PVR_CallbackInputParams_t * pstInputParams, MI_PVR_CallbackOutputParams_t *pstOutputParams);

//------------------------------------------------------------------------------
/// @brief UnRegister the callback function for receiving the events of playback related.
/// @param[in] hPvrPlaybk: A Handle of a created playback instance.
/// @param[in] pstInputParams Input parameters
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE: hanlde is invalid.
/// @return MI_ERR_INVALID_PARAMETER: parameters is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_PVR_PlaybackUnRegisterCallback(MI_HANDLE hPvrPlaybk, const MI_PVR_CallbackInputParams_t * pstInputParams);

//------------------------------------------------------------------------------
/// @brief Start playback.
/// @param[in] hPvrPlaybk: A handle of a PVR playback instance.
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Invalid parameter
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_PVR_PlaybackStart(MI_HANDLE hPvrPlaybk);

//------------------------------------------------------------------------------
/// @brief Stop playback.
/// @param[in] hPvrPlaybk: A handle of a PVR playback instance.
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Invalid parameter
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_PVR_PlaybackStop(MI_HANDLE hPvrPlaybk);

//------------------------------------------------------------------------------
/// @brief Pause playback.
/// @param[in] hPvrPlaybk: A handle of a PVR playback instance.
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Invalid parameter
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_PVR_PlaybackPause(MI_HANDLE hPvrPlaybk);

//------------------------------------------------------------------------------
/// @brief Resume playback from PAUSE/FF/FB...non-normal state.
/// @param[in] hPvrPlaybk: A handle of a PVR playback instance.
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Invalid parameter
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_PVR_PlaybackResume(MI_HANDLE hPvrPlaybk);

//------------------------------------------------------------------------------
/// @brief Step In playback.
/// @param[in] hPvrPlaybk: A handle of a PVR playback instance.
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Invalid parameter
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_PVR_PlaybackStepIn(MI_HANDLE hPvrPlaybk);

//------------------------------------------------------------------------------
/// @brief Set speed control for playback.
/// @param[in] hPvrPlaybk: A handle of a PVR playback instance.
/// @param[in] eSpeed: Speed control for playback.
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Invalid parameter
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_PVR_PlaybackSetSpeed(MI_HANDLE hPvrPlaybk, MI_PVR_PlaybackSpeed_e eSpeed);

//------------------------------------------------------------------------------
/// @brief Get speed of playback.
/// @param[in] hPvrPlaybk: A handle of a PVR playback instance.
/// @param[out] peSpeed: Speed info of playback.
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Invalid parameter
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_PVR_PlaybackGetSpeed(MI_HANDLE hPvrPlaybk, MI_PVR_PlaybackSpeed_e *peSpeed);

//------------------------------------------------------------------------------
/// @brief Jump to the speicifed time.
/// @param[in] hPvrPlaybk: A handle of a PVR playback instance.
/// @param[in] pstJumpParams: A pointer to struct MI_PVR_JumpParams_t describes the speicified jump destination.
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Invalid parameter
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_PVR_PlaybackJumpToTime(MI_HANDLE hPvrPlaybk, const MI_PVR_JumpParams_t *pstJumpParams);

//------------------------------------------------------------------------------
/// @brief Set the AB loop time interval
/// @param[in] hPvrPlaybk: A handle of a PVR playback instance.
/// @param[in] pstAbLoopParams: A pointer to struct MI_PVR_AbLoopParams_t describes the AB loop time interval.
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Invalid parameter
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_PVR_PlaybackAbLoop(MI_HANDLE hPvrPlaybk, const MI_PVR_AbLoopParams_t *pstAbLoopParams);

//------------------------------------------------------------------------------
/// @brief Cancel the AB loop time interval
/// @param[in] hPvrPlaybk: A handle of a PVR playback instance.
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Invalid parameter
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_PVR_PlaybackResetAbLoop(MI_HANDLE hPvrPlaybk);

//------------------------------------------------------------------------------
/// @brief Add a skip time interval for playback
/// @param[in] hPvrPlaybk: A handle of a PVR playback instance.
/// @param[in] pstSkipTime: A pointer to struct MI_PVR_SkipParams_t describes the time interval for skip while playback.
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Invalid parameter
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_PVR_PlaybackAddSkipTime(MI_HANDLE hPvrPlaybk, const MI_PVR_SkipParams_t *pstSkipTime);

//------------------------------------------------------------------------------
/// @brief Remove a skip time interval for playback
/// @param[in] hPvrPlaybk: A handle of a PVR playback instance.
/// @param[in] pstSkipTime: A pointer to struct MI_PVR_SkipParams_t describes the time interval for remove from the table of skip time intervals.
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Invalid parameter
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_PVR_PlaybackRemoveSkipTime(MI_HANDLE hPvrPlaybk, const MI_PVR_SkipParams_t *pstSkipTime);

//------------------------------------------------------------------------------
/// @brief Get time information of playback.
/// @param[in] hPvrPlaybk: A handle of a PVR playback instance.
/// @param[out] pstTimeInfo: A pointer to struct MI_PVR_PlaybackTimeInfo_t to retrieve playback time information.
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Invalid parameter
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_PVR_PlaybackGetTimeInfo(MI_HANDLE hPvrPlaybk, MI_PVR_PlaybackTimeInfo_t *pstTimeInfo);

//------------------------------------------------------------------------------
/// @brief Change audio track when playback.
/// @param[in] hPvrPlaybk: A handle of a PVR playback instance.
/// @param[in] u16NewAudPid: New audio PID for playback.
/// @param[in] eNewAudCodec: New audio codec for playback.
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Invalid parameter
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_PVR_PlaybackChangeAudTrack(MI_HANDLE hPvrPlaybk, MI_U16 u16NewAudPid, MI_AUDIO_CodecType_e eNewAudCodec);

//------------------------------------------------------------------------------
/// @brief get PVR Playback handle.
/// @param[in]  pstQueryParams: Query parameters
/// @param[out] phPvrRec: A pointer to retrieve a handle of a PVR playback instance.
/// @return MI_OK: Get dsc handle success.
/// @return MI_ERR_FAILED: pvr general failed
/// @return MI_ERR_INVALID_PARAMETER: parameter null
//------------------------------------------------------------------------------
MI_RESULT MI_PVR_PlaybackGetHandle(const MI_PVR_QueryHandleParams_t *pstQueryParams, MI_HANDLE *phPvrPlaybk);

//------------------------------------------------------------------------------
/// @brief Add a chunk file to Chunk list.
/// @param[in] hPvrPlaybk: A handle of a PVR playback instance.
/// @param[in] pstChunkInfo: A pointer to struct MI_PVR_ChunkInfo_t.
/// @param[in] u32ChunkIndex: the index of chunk to be added.
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Invalid parameter
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_PVR_PlaybackAddChunk(MI_HANDLE hPvrPlaybk, const MI_PVR_ChunkInfo_t *pstChunkInfo, MI_U32 u32ChunkIndex);

//------------------------------------------------------------------------------
/// @brief Remove a chunk file from Chunk list.
/// @param[in] hPvrPlaybk: A handle of a PVR playback instance.
/// @param[in] u32ChunkIndex: the index of chunk to be removed.
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Invalid parameter
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_PVR_PlaybackRemoveChunk(MI_HANDLE hPvrPlaybk, MI_U32 u32ChunkIndex);

//------------------------------------------------------------------------------
/// @brief Get current chunk list.
/// @param[in] hPvrPlaybk: A handle of a PVR playback instance.
/// @param[out] pstChunkList: A pointer to struct MI_PVR_ChunkList_t.
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Invalid parameter
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_PVR_PlaybackGetChunkList(MI_HANDLE hPvrPlaybk, MI_PVR_ChunkList_t *pstChunkList);

//------------------------------------------------------------------------------
/// @brief Jump to the speicifed time of chunk.
/// @param[in] hPvrPlaybk: A handle of a PVR playback instance.
/// @param[in] u32ChunkIndex: the index of destination chunk.
/// @param[in] pstJumpParams: A pointer to struct MI_PVR_JumpParams_t describes the speicified jump destination.
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Invalid parameter
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_PVR_PlaybackJumpToChunk(MI_HANDLE hPvrPlaybk, MI_U32 u32ChunkIndex, const MI_PVR_JumpParams_t *pstJumpParams);

#ifdef __cplusplus
}
#endif

#endif///_MI_PVR_H_

#endif  // end of #if (ENABLE_PVR_PACKAGE == 1)

