/*------------------------------------------------------------------------------
 * MediaTek Inc. (C) 2018. All rights reserved.
 *
 * Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 *----------------------------------------------------------------------------*/

#ifndef _MI_GPIO_H_
#define _MI_GPIO_H_

#ifdef __cplusplus
extern "C" {
#endif

//-------------------------------------------------------------------------------------------------
//  Structures
//-------------------------------------------------------------------------------------------------
typedef enum
{
    E_MI_GPIO_LEVEL_ON = 0,          //LEVEL on is equal to level high if not invert, but equal to level low if invert
    E_MI_GPIO_LEVEL_OFF,             //LEVEL off is equal to level low if not invert, but equal to level high if invert
} MI_GPIO_Level_e;

typedef enum
{
    E_MI_GPIO_DIRECTION_OUTPUT = 0,  //gpio output status
    E_MI_GPIO_DIRECTION_INPUT,       //gpio input status
} MI_GPIO_Direction_e;

typedef enum
{
    E_MI_GPIO_EVENT_TYPE_ISR_CALLBACK = MI_BIT(0),   ///< notify Isr callback, pEventParam is NULL
    E_MI_GPIO_EVENT_TYPE_TASK_CALLBACK = MI_BIT(1),  ///< notify task callback, pEventParam is NULL
}MI_GPIO_EventType_e;

typedef enum
{
    E_MI_GPIO_INTERRUPT_STATUS_DISABLE = 0,
    E_MI_GPIO_INTERRUPT_STATUS_ENABLE,
    E_MI_GPIO_INTERRUPT_STATUS_NOT_SUPPORT,
    E_MI_GPIO_INTERRUPT_STATUS_MAX,
} MI_GPIO_InterruptStatus_e;

typedef struct MI_GPIO_InterruptParams_s
{
    MI_BOOL bPolarity;                // gpio interrupt trigger mode (0:rising edge mode,1:falling edge mode)
} MI_GPIO_InterruptParams_t;

typedef struct MI_GPIO_InitParams_s
{
    MI_U8 u8Reserved;
} MI_GPIO_InitParams_t;

typedef struct MI_GPIO_OpenParams_s
{
    MI_U16 u16GpioNum;      //open gpio index number
} MI_GPIO_OpenParams_t;

typedef struct MI_GPIO_QueryHandleParams_s
{
    MI_U16 u16GpioNum;      //gpio index number
} MI_GPIO_QueryHandleParams_t;

typedef MI_RESULT (*MI_GPIO_EventCallback)(MI_HANDLE hTsmux, MI_U32 u32Event, void *pEventParams, void *pUserParams);

typedef struct MI_GPIO_CallbackInputParams_s
{
    MI_U64 u64CallbackId;                           ///[IN]: Use 0 for first register, other valid value(returned by MI_GPIO_CallbackOutputParams_t) for update callback event.
    MI_GPIO_EventCallback pfEventCallback;          ///[IN]: Event callback function pointer.
    MI_U32 u32EventFlags;                           ///[IN]: Registered events MI_TSMUX_Event_e which are bitwise OR operation.
    void *pUserParams;                              ///[IN]: For passing user-defined parameters.
} MI_GPIO_CallbackInputParams_t;

typedef struct MI_GPIO_CallbackOutputParams_s
{
    MI_U64 u64CallbackId;                           ///[OUT]: the returned ID for update or unregister callback.
} MI_GPIO_CallbackOutputParams_t;

//-------------------------------------------------------------------------------------------------
//  Global Functions
//-------------------------------------------------------------------------------------------------

//------------------------------------------------------------------------------
/// @brief Init the gpio module.
/// @param[in] pstInitParam. Parameters to init the gpio module
/// @return MI_OK: Process success.
/// @return MI_HAS_INITED: GPIO module inited before.
//------------------------------------------------------------------------------
MI_RESULT MI_GPIO_Init(const MI_GPIO_InitParams_t *pstInitParams);

//------------------------------------------------------------------------------
/// @brief Finalize the gpio module.
/// @return MI_OK: Process success.
//------------------------------------------------------------------------------
MI_RESULT MI_GPIO_DeInit(void);

//------------------------------------------------------------------------------
/// @brief open gpio handle
/// @param[in] MI_GPIO_OpenParams_t.
/// @param[out] phGpio.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_GPIO_Open(const MI_GPIO_OpenParams_t *pstOpenParams, MI_HANDLE *phGpio);

//------------------------------------------------------------------------------
/// @brief Close gpio handle
/// @param[in] hGpio.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_GPIO_Close(MI_HANDLE hGpio);

//------------------------------------------------------------------------------
/// @brief Get Handle of the GPIO module.
/// @param[in]  pstQueryParams: A pointer to structure MI_GPIO_QueryHandleParams_t.
/// @param[out] phGpio: phGpio for retrieve an instance of GPIO interface.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: GPIO module Get Handle failed.
/// @return MI_ERR_INVALID_PARAMETR: Parameters is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_GPIO_GetHandle(const MI_GPIO_QueryHandleParams_t *pstQueryParams, MI_HANDLE *phGpio);

//------------------------------------------------------------------------------
/// @brief Set the gpio number to invert
/// @param[in] hGpio.
/// @param[in] bInvert.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_GPIO_SetInvert(MI_HANDLE hGpio, MI_BOOL bInvert);

//------------------------------------------------------------------------------
/// @brief Set the gpio direction to input.
/// @param[in] hGpio.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_GPIO_SetInput(MI_HANDLE hGpio);

//------------------------------------------------------------------------------
/// @brief Set the gpio direction to Output and set Level.
/// @param[in] hGpio.
/// @param[in] eLevel.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_GPIO_SetOutput(MI_HANDLE hGpio, MI_GPIO_Level_e eLevel);

//------------------------------------------------------------------------------
/// @brief Get the gpio level and invert info.
/// @param[in] hGpio.
/// @param[out] peLevel.
/// @param[out] pbInvert.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_GPIO_GetInput(MI_HANDLE hGpio, MI_GPIO_Level_e *peLevel, MI_BOOL *pbInvert);

//------------------------------------------------------------------------------
/// @brief Get the gpio direction.
/// @param[in] hGpio.
/// @param[out] peDirection. Get the gpio direction
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_GPIO_GetDirection(MI_HANDLE hGpio, MI_GPIO_Direction_e *peDirection);

//------------------------------------------------------------------------------
/// @brief Enable GPIO interrupt
/// @param[in] hGpio.
/// @param[in] stGpioIntr.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_RESOURCES: No available resource.
/// @return MI_ERR_MEMORY_ALLOCATE: Memory allocate fail
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_GPIO_EnableInterrupt(MI_HANDLE hGpio,MI_GPIO_InterruptParams_t stInterruptParams);

//------------------------------------------------------------------------------
/// @brief Disable GPIO interrupt & remove all callback
/// @param[in] hGpio.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_GPIO_DisableInterrupt(MI_HANDLE hGpio);

//------------------------------------------------------------------------------
/// @brief Register the callback function for receiving the events of GPIO related.
/// @param[in] hTsmux: A Handle of a created GPIO instance.
/// @param[in] pstInputParams: A pointer to structure MI_GPIO_CallbackInputParams_t for events registered.
/// @param[out] pstOutputParams: A pointer to structure MI_GPIO_CallbackOutputParams_t.
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE: hanlde is invalid.
/// @return MI_ERR_INVALID_PARAMETER: parameters is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_GPIO_RegisterCallback(MI_HANDLE hGpio, const MI_GPIO_CallbackInputParams_t *pstInputParams, MI_GPIO_CallbackOutputParams_t *pstOutputParams);

//------------------------------------------------------------------------------
/// @brief UnRegister the callback function for receiving the events of GPIO related.
/// @param[in] hTsmux: A Handle of a created GPIO instance.
/// @param[in] pstInputParams: A pointer to structure MI_GPIO_CallbackInputParams_t for events registered.
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE: hanlde is invalid.
/// @return MI_ERR_INVALID_PARAMETER: parameters is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_GPIO_UnRegisterCallback(MI_HANDLE hGpio, const MI_GPIO_CallbackInputParams_t *pstInputParams);

//------------------------------------------------------------------------------
///// @brief Get gpio interrupt status(enable/disable/not support).
///// @param[in] hGpio. gpio handle to process
///// @param[out] peInterruptStatus : interrupts status with enum MI_GPIO_InterruptStatus_e.
///// @return MI_OK: Process success
///// @return MI_ERR_FAILED: Process failure
///// @return MI_ERR_NOT_INITED: Module not inited
///// @return MI_ERR_INVALID_PARAMETER: Parameter invalid
////-----------------------------------------------------------------------------
MI_RESULT MI_GPIO_GetInterruptStatus(MI_HANDLE hGpio, MI_GPIO_InterruptStatus_e* peInterruptStatus);

//------------------------------------------------------------------------------
/// @brief Set GPIO module debug level.
/// @param[in] eDbgLevel.
/// @return MI_OK: Set debug level success.
//------------------------------------------------------------------------------
MI_RESULT MI_GPIO_SetDebugLevel(MI_DBG_LEVEL u32DebugLevel);

#ifdef __cplusplus
}
#endif

#endif///_MI_GPIO_H_
