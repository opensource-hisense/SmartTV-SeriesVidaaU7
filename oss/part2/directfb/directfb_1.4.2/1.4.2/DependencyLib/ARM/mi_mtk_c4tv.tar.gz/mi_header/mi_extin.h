/*------------------------------------------------------------------------------
 * MediaTek Inc. (C) 2018. All rights reserved.
 *
 * Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 *----------------------------------------------------------------------------*/

#ifndef _MI_EXTIN_H_
#define _MI_EXTIN_H_

#ifdef __cplusplus
extern "C" {
#endif

#define   MI_EXTIN_HDMI_PACKET_DATA_LENGTH   (28)
#define   MI_EXTIN_SAD_INFO_LENGTH   (14)
//-------------------------------------------------------------------------------------------------
//  Structures
//-------------------------------------------------------------------------------------------------
/// External input
typedef enum
{
    E_MI_EXTIN_TYPE_HDMI,
    E_MI_EXTIN_TYPE_COMPONENT,
    E_MI_EXTIN_TYPE_VGA,
    E_MI_EXTIN_TYPE_CVBS,
    E_MI_EXTIN_TYPE_SVIDEO,
    E_MI_EXTIN_TYPE_SCART,
    E_MI_EXTIN_TYPE_ATV,
    E_MI_EXTIN_TYPE_MAX
} MI_EXTIN_Type_e;

typedef enum
{
    // HDMI
    E_MI_EXTIN_ATTR_TYPE_HDMI_MIN = 0x0,
    //set only. pUsrParam is pointer to MI_EXTIN_HdmiHdcpKeyInfo_t struct
    E_MI_EXTIN_ATTR_TYPE_HDMI_HDCP_KEY = E_MI_EXTIN_ATTR_TYPE_HDMI_MIN,
    //set only. pUsrParam is pointer to MI_EXTIN_HdmiEdidInfo_t struct
    E_MI_EXTIN_ATTR_TYPE_HDMI_EDID,
    //set only. pUsrParam is pointer to MI_BOOL
    E_MI_EXTIN_ATTR_TYPE_HDMI_BYPASS,
    //Get and Set, pParam is a pointer to MI_EXTIN_HdmiType_e struct
    E_MI_EXTIN_ATTR_TYPE_HDMI_TYPE,
    //Get Only, pParam is a pointer to MI_EXTIN_HdmiPacket_t struct
    E_MI_EXTIN_ATTR_TYPE_HDMI_RAW_PACKET,
    //Get Only, pParam is a pointer to MI_EXTIN_AviInfoFrame_t struct
    E_MI_EXTIN_ATTR_TYPE_HDMI_AVI_INFO_FRAME,
    //Get Only, pParam is a pointer to MI_EXTIN_HdmiVersionRevision_t struct
    E_MI_EXTIN_ATTR_TYPE_HDMI_VERSION,
    //Set only. pParam is a pointer to MI_EXTIN_SadInfo_t struct
    E_MI_EXTIN_ATTR_TYPE_HDMI_SAD_INFO,
    //Get only. pParam is a pointer to MI_EXTIN_HdmiEdidVersion_e
    E_MI_EXTIN_ATTR_TYPE_EDID_VERSION,
    //Set only. pParam is pointer to MI_EXTIN_HdmiHpdControl_t
    E_MI_EXTIN_ATTR_TYPE_HDMI_PLUG_CONTROL,
    //Get Only, pParam is a pointer to MI_BOOL: TRUE:ALLM Mode; FALSE:Not ALLM Mode
    E_MI_EXTIN_ATTR_INPUT_HDMI_ALLM_MODE,
    //Get only. pParam is a pointer to MI_EXTIN_PortHdcpInfo_t
    E_MI_EXTIN_ATTR_TYPE_HDMI_HDCP_STATUS,
    E_MI_EXTIN_ATTR_TYPE_HDMI_MAX,

    // PC
    E_MI_EXTIN_ATTR_TYPE_PC_MIN = 0x1000,
    //Get Only, pParam is a pointer to MI_U8 u8ModeIndex;
    E_MI_EXTIN_ATTR_TYPE_PC_MODE_INDEX = E_MI_EXTIN_ATTR_TYPE_PC_MIN,
    //Get and Set, pParam is a pointer to MI_EXTIN_PcPosition_t struct
    E_MI_EXTIN_ATTR_TYPE_PC_POSITION,
    //Get Only, pParam is a pointer to MI_EXTIN_PcClockRange_t struct
    E_MI_EXTIN_ATTR_TYPE_PC_CLOCK_RANGE,
    //Get Only, pParam is a pointer to MI_EXTIN_PcPhaseRange_t struct
    E_MI_EXTIN_ATTR_TYPE_PC_PHASE_RANGE,
    E_MI_EXTIN_ATTR_TYPE_PC_MAX,

    // ATV
    E_MI_EXTIN_ATTR_TYPE_ATV_MIN = 0x2000,
    //Get Only, pParam is a pointer to MI_BOOL: TRUE:lock audio carrier; FALSE:not lock audio carrier
    E_MI_EXTIN_ATTR_TYPE_ATV_LOCK_AUDIO_CARRIER = E_MI_EXTIN_ATTR_TYPE_ATV_MIN,
    //Get Only, pParam is a pointer to MI_U16
    E_MI_EXTIN_ATTR_TYPE_ATV_VPS_RAW_DATA,
    //Set Only, pParam is a pointer to MI_BOOL: TRUE:start auto detect; FALSE:stop auto detect
    E_MI_EXTIN_ATTR_TYPE_ATV_AUTO_DETECT_TV_SYSTEM,
    E_MI_EXTIN_ATTRTYPE_ATV_VERTICAL_FREQENCY,
    E_MI_EXTIN_ATTRTYPE_ATV_CHANNEL_CHANGE,
    E_MI_EXTIN_ATTRTYPE_ATV_SCAN_MODE,
    E_MI_EXTIN_ATTR_TYPE_ATV_MAX,

    // 0x3000~0x7000 keep for future.

    // Misc
    E_MI_EXTIN_ATTR_TYPE_MIN = 0x8000,
    //Get and Set, pParam is a pointer to MI_EXTIN_ScartType_e struct
    E_MI_EXTIN_ATTR_TYPE_SCART_TYPE = E_MI_EXTIN_ATTR_TYPE_MIN,
    //Get Only, pParam is a pointer to MI_EXTIN_ScartArInfo_e struct
    E_MI_EXTIN_ATTR_TYPE_SCART_AR_INFO,
    //Get Only, pParam is a pointer to MI_EXTIN_VideoInfo_t struct
    E_MI_EXTIN_ATTR_TYPE_VIDEO_INFO,
    //Get Only, pParam is a pointer to MI_EXTIN_AdcPhase_t struct
    E_MI_EXTIN_ATTR_TYPE_ADC_PHASE,
    //Get Only, pParam is a pointer to MI_EXTIN_AdcGainOffset_t struct
    E_MI_EXTIN_ATTR_TYPE_ADC_GAIN_OFFSET,
    //Get Only, pParam is a pointer to MI_U32
    E_MI_EXTIN_ATTR_TYPE_ADC_CLOCK,
    //Get Only, pParam is a pointer to MI_U16
    E_MI_EXTIN_ATTR_TYPE_WSS_RAW_DATA,
    //Get Only, pParam is a pointer to MI_EXTIN_ArInfo_e
    E_MI_EXTIN_ATTR_TYPE_WSS_ASPECT_RATIO,
    //Get Only, pParam is a pointer to MI_EXTIN_SignalStatus_t
    E_MI_EXTIN_ATTR_TYPE_SIGNAL_STATUS,
    //Get Only, pParam is a pointer to MI_BOOL: TRUE:hw cable connected; FALSE:hw cable disconnected
    E_MI_EXTIN_ATTR_TYPE_CONNECT_STATUS,
    //Get Only, pParam is a pointer to MI_EXTIN_AdcGainOffset_t
    E_MI_EXTIN_ATTR_TYPE_ADC_FIXED_HW_GAIN_OFFSET,
    //Set and Get, pParam is a pointer to MI_EXTIN_AdcGainOffset_t
    E_MI_EXTIN_ATTR_TYPE_ADC_DEFAULT_GAIN_OFFSET,
    //Get Only, pParam is a pointer to MI_EXTIN_SetWindowInfo_t
    E_MI_EXTIN_ATTR_TYPE_SETWINDOW_INFO,
    E_MI_EXTIN_ATTR_TYPE_MAX
} MI_EXTIN_AttrType_e;

typedef enum
{
    E_MI_EXTIN_HDMI_HDCP_STATUS_DISABLE = 0,
    E_MI_EXTIN_HDMI_HDCP_STATUS_FAIL,
    E_MI_EXTIN_HDMI_HDCP_STATUS_SUCCESS,
    E_MI_EXTIN_HDMI_HDCP_STATUS_PROCESS,
} MI_EXTIN_HdmiHdcpStatus_e;

typedef struct MI_EXTIN_PortHdcpInfo_s
{
    MI_EXTIN_HdmiHdcpStatus_e eHdcp14Status;
    MI_EXTIN_HdmiHdcpStatus_e eHdcp22Status;
} MI_EXTIN_PortHdcpInfo_t;

typedef enum
{
    E_MI_EXTIN_ATV_SIGNAL_RELIABLE_LEVEL_HIGH = 0,
    E_MI_EXTIN_ATV_SIGNAL_RELIABLE_LEVEL_MIDDLE = 1,
    E_MI_EXTIN_ATV_SIGNAL_RELIABLE_LEVEL_LOW = 2,
} MI_EXTIN_AtvSignalReliableLevel_e;

typedef enum
{
    E_MI_EXTIN_HDMI_EDID_INTERNAL,
    E_MI_EXTIN_HDMI_EDID_CUSTOMER,
    E_MI_EXTIN_HDMI_EDID_MAX,
} MI_EXTIN_HdmiEdidType_e;

typedef enum
{
    E_MI_EXTIN_TV_SYSTEM_NTSC,
    E_MI_EXTIN_TV_SYSTEM_NTSC_443,
    E_MI_EXTIN_TV_SYSTEM_NTSC_J,
    E_MI_EXTIN_TV_SYSTEM_PAL_M,
    E_MI_EXTIN_TV_SYSTEM_PAL_N,
    E_MI_EXTIN_TV_SYSTEM_PAL_NC,
    E_MI_EXTIN_TV_SYSTEM_PAL,
    E_MI_EXTIN_TV_SYSTEM_SECAM,
    E_MI_EXTIN_TV_SYSTEM_NTSC_M,
    E_MI_EXTIN_TV_SYSTEM_PAL_60,
    E_MI_EXTIN_TV_SYSTEM_NONE,
    E_MI_EXTIN_TV_SYSTEM_AUTO,
    E_MI_EXTIN_TV_SYSTEM_NUM
} MI_EXTIN_TvSystem_e;

typedef enum
{
    E_MI_EXTIN_SIGNAL_STATUS_LOCK,
    E_MI_EXTIN_SIGNAL_STATUS_UNLOCK,
    E_MI_EXTIN_SIGNAL_STATUS_NOT_SUPPORT,
} MI_EXTIN_SignalStatus_e;

typedef enum
{
    E_MI_EXTIN_SCART_AR_NONE = 0, //Pin8 0v~2v
    E_MI_EXTIN_SCART_AR_16_9 = 1, //Pin8 5v~8v
    E_MI_EXTIN_SCART_AR_4_3  = 2, //Pin8 9.5v~12v
} MI_EXTIN_ScartArInfo_e;

//aspect ratio
typedef enum
{
    E_MI_EXTIN_AR_4X3_FULL,                                            ///< Aspect ratio 4:3 Full
    E_MI_EXTIN_AR_14X9_LETTERBOX_CENTER,                 ///< Aspect ratio 14:9 letterbox center
    E_MI_EXTIN_AR_14X9_LETTERBOX_TOP,                      ///< Aspect ratio 14:9 letterbox TOP
    E_MI_EXTIN_AR_16X9_LETTERBOX_CENTER,                ///< Aspect ratio 16:9 letterbox center
    E_MI_EXTIN_AR_16X9_LETTERBOX_TOP,                     ///< Aspect ratio 16:9 letterbox TOP
    E_MI_EXTIN_AR_ABOVE_16X9_LETTERBOX_CENTER,   ///< Aspect ratio Above 16:9 letterbox center
    E_MI_EXTIN_AR_14X9_FULL_CENTER,                         ///< Aspect ratio 14:9 full center
    E_MI_EXTIN_AR_16X9_ANAMORPHIC,                         ///< Aspect ratio 16:9 anamorphic
    E_MI_EXTIN_AR_INVALID                                           ///< Invalid Aspect ratio
} MI_EXTIN_ArInfo_e;

typedef enum
{
    E_MI_EXTIN_COLOR_FORMAT_RGB        = 0,
    E_MI_EXTIN_COLOR_FORMAT_YUV422     = 1,
    E_MI_EXTIN_COLOR_FORMAT_YUV444     = 2,
    E_MI_EXTIN_COLOR_FORMAT_YUV420     = 3,
} MI_EXTIN_ColorFormat_e;

typedef enum
{
    E_MI_EXTIN_HDMI_TYPE_HDMI      = 0x00,
    E_MI_EXTIN_HDMI_TYPE_DVI,
    E_MI_EXTIN_HDMI_TYPE_MHL,
} MI_EXTIN_HdmiType_e;

typedef enum
{
    E_MI_EXTIN_SCART_TYPE_RGB      = 0x00,
    E_MI_EXTIN_SCART_TYPE_CVBS,
} MI_EXTIN_ScartType_e;

typedef enum
{
    E_MI_EXTIN_HDMI_PACKET_TYPE_VENDOR_SPECIFIC_INFO_FRAME,
    E_MI_EXTIN_HDMI_PACKET_TYPE_AVI_INFO_FRAME,
    E_MI_EXTIN_HDMI_PACKET_TYPE_SPD_INFO_FRAME,
    E_MI_EXTIN_HDMI_PACKET_TYPE_AUDIO_INFO_FRAME,
    E_MI_EXTIN_HDMI_PACKET_TYPE_MPEG_SOURCE_INFO_FRAME,
    E_MI_EXTIN_HDMI_PACKET_TYPE_MAX,
} MI_EXTIN_HdmiPacketType_e;

/// Define HDMI RX EDID Version
typedef enum
{
    E_MI_EXTIN_HDMI_EDID_VER_DEFAULT = 0,
    E_MI_EXTIN_HDMI_EDID_VER_1_4,
    E_MI_EXTIN_HDMI_EDID_VER_2_0,
    E_MI_EXTIN_HDMI_EDID_VER_AUTO_DETECT,
} MI_EXTIN_HdmiEdidVersion_e;

typedef enum
{
    E_MI_EXTIN_AVI_INFO_FRAME_COLOR_FORMAT_RGB = 0,
    E_MI_EXTIN_AVI_INFO_FRAME_COLOR_FORMAT_YCBCR_422,
    E_MI_EXTIN_AVI_INFO_FRAME_COLOR_FORMAT_YCBCR_444,
    E_MI_EXTIN_AVI_INFO_FRAME_COLOR_FORMAT_YCBCR_420,
    E_MI_EXTIN_AVI_INFO_FRAME_COLOR_FORMAT_YCBCR_RESERVED,
} MI_EXTIN_AviInfoFrameColorformat_e;

typedef enum
{
    E_MI_EXTIN_AVI_INFO_FRAME_AFD_ACTIVE_INFO_INVALID = 0,
    E_MI_EXTIN_AVI_INFO_FRAME_AFD_ACTIVE_INFO_VALID,
} MI_EXTIN_AviInfoFrameAfdActiveInfo_e;

typedef enum
{
    E_MI_EXTIN_AVI_INFO_FRAME_BAR_INFO_INVALID,
    E_MI_EXTIN_AVI_INFO_FRAME_BAR_INFO_VERT_VALID,
    E_MI_EXTIN_AVI_INFO_FRAME_BAR_INFO_HORIZ_VALID,
    E_MI_EXTIN_AVI_INFO_FRAME_BAR_INFO_VERT_HORIZ_VALID,
} MI_EXTIN_AviInfoFrameBarInfo_e;

typedef enum
{
    E_MI_EXTIN_AVI_INFO_FRAME_SCAN_INFO_NODATA,
    E_MI_EXTIN_AVI_INFO_FRAME_SCAN_INFO_OVERSCAN,
    E_MI_EXTIN_AVI_INFO_FRAME_SCAN_INFO_UNDERSCAN,
} MI_EXTIN_AviInfoFrameScanInfo_e;

typedef enum
{
    E_MI_EXTIN_AVI_INFO_FRAME_COLORIMETRY_NODATA = 0,
    E_MI_EXTIN_AVI_INFO_FRAME_COLORIMETRY_SMPTE170,
    E_MI_EXTIN_AVI_INFO_FRAME_COLORIMETRY_ITUR709,
    E_MI_EXTIN_AVI_INFO_FRAME_COLORIMETRY_EXTEND,
} MI_EXTIN_AviInfoFrameColorimetry_e;

typedef enum
{
    E_MI_EXTIN_AVI_INFO_FRAME_PICTURE_AR_NODATA = 0,
    E_MI_EXTIN_AVI_INFO_FRAME_PICTURE_AR_4_3,
    E_MI_EXTIN_AVI_INFO_FRAME_PICTURE_AR_16_9,
    E_MI_EXTIN_AVI_INFO_FRAME_PICTURE_AR_RESERVED,
} MI_EXTIN_AviInfoFramePicAr_e;

typedef enum
{
    E_MI_EXTIN_AVI_INFO_FRAME_AFD_SAME_AS_PICTURE = 8,
    E_MI_EXTIN_AVI_INFO_FRAME_AFD_4_3_CENTER = 9,
    E_MI_EXTIN_AVI_INFO_FRAME_AFD_16_9_CENTER = 10,
    E_MI_EXTIN_AVI_INFO_FRAME_AFD_14_9_CENTER = 11,
    E_MI_EXTIN_AVI_INFO_FRAME_AFD_4_3_WITH_SHOOT_14_9_CENTER = 13,
    E_MI_EXTIN_AVI_INFO_FRAME_AFD_16_9_WITH_SHOOT_14_9_CENTER = 14,
    E_MI_EXTIN_AVI_INFO_FRAME_AFD_16_9_WITH_SHOOT_4_3_CENTER = 15,
    E_MI_EXTIN_AVI_INFO_FRAME_AFD_OTHER = 0
} MI_EXTIN_AviInfoFrameAfd_e;

typedef enum
{
    E_MI_EXTIN_AVI_INFO_FRAME_PICTURE_SCALE_NO = 0,
    E_MI_EXTIN_AVI_INFO_FRAME_PICTURE_SCALE_H,
    E_MI_EXTIN_AVI_INFO_FRAME_PICTURE_SCALE_V,
    E_MI_EXTIN_AVI_INFO_FRAME_PICTURE_SCALE_HV
} MI_EXTIN_AviInfoFramePicScale_e;

typedef enum
{
    E_MI_EXTIN_AVI_INFO_FRAME_IT_CONTENT_NODATA = 0,
    E_MI_EXTIN_AVI_INFO_FRAME_IT_CONTENT_ITCONTENT = 1
} MI_EXTIN_AviInfoFrameItContent_e;

typedef enum
{
    E_MI_EXTIN_AVI_INFO_FRAME_EXTEND_COLORIMETRY_XVYCC601 = 0,
    E_MI_EXTIN_AVI_INFO_FRAME_EXTEND_COLORIMETRY_XVYCC709,
    E_MI_EXTIN_AVI_INFO_FRAME_EXTEND_COLORIMETRY_SYCC601,
    E_MI_EXTIN_AVI_INFO_FRAME_EXTEND_COLORIMETRY_ADOBE_YCC601,
    E_MI_EXTIN_AVI_INFO_FRAME_EXTEND_COLORIMETRY_ADOBE_RGB,
    E_MI_EXTIN_AVI_INFO_FRAME_EXTEND_COLORIMETRY_BT2020_YCBCR,
    E_MI_EXTIN_AVI_INFO_FRAME_EXTEND_COLORIMETRY_BT2020_RGB_OR_YCBCR,
    E_MI_EXTIN_AVI_INFO_FRAME_EXTEND_COLORIMETRY_RESERVED,
} MI_EXTIN_AviInfoFrameExtColorimetry_e;

typedef enum
{
    E_MI_EXTIN_AVI_INFO_FRAME_RGB_QUANT_RANGE_DEFAULT = 0,
    E_MI_EXTIN_AVI_INFO_FRAME_RGB_QUANT_RANGE_LIMITED = 1,
    E_MI_EXTIN_AVI_INFO_FRAME_RGB_QUANT_RANGE_FULL = 2,
    E_MI_EXTIN_AVI_INFO_FRAME_RGB_QUANT_RANGE_RESERVED = 3
} MI_EXTIN_AviInfoFrameRgbQuantRange_e;

typedef enum
{
    E_MI_EXTIN_AVI_INFO_FRAME_CONTENT_GRAPHICS = 0,
    E_MI_EXTIN_AVI_INFO_FRAME_CONTENT_PHOTO,
    E_MI_EXTIN_AVI_INFO_FRAME_CONTENT_CINEMA,
    E_MI_EXTIN_AVI_INFO_FRAME_CONTENT_GAME,
    E_MI_EXTIN_AVI_INFO_FRAME_CONTENT_MAX,
} MI_EXTIN_AviInfoFrameContentType_e;

typedef enum
{
    E_MI_EXTIN_AVI_INFO_FRAME_YCC_QUANT_RANGE_LIMITED = 0,
    E_MI_EXTIN_AVI_INFO_FRAME_YCC_QUANT_RANGE_FULL,
    E_MI_EXTIN_AVI_INFO_FRAME_YCC_QUANT_RANGE_RESERVED,
    E_MI_EXTIN_AVI_INFO_FRAME_YCC_QUANT_RANGE_MAX,
} MI_EXTIN_AviInfoFrameYccQuantRange_e;

typedef enum
{
    E_MI_EXTIN_FACTORY_ANALOG_DECODER_MIN = 0,
    E_MI_EXTIN_FACTORY_ANALOG_DECODER_DEBUG_GROUP_1,                   //DebugGroup1
    E_MI_EXTIN_FACTORY_ANALOG_DECODER_DEBUG_GROUP_2,                   //DebugGroup2
    E_MI_EXTIN_FACTORY_ANALOG_DECODER_H_SYNC_PLL_SPEED_DPL_MAX,        //Set Hsync PLL Speed dpl MAX
    E_MI_EXTIN_FACTORY_ANALOG_DECODER_RF_LOW_H_SYNC_PATCH,             //Enable/Disable RF LOW HSYNC PATCH
    E_MI_EXTIN_FACTORY_ANALOG_DECODER_H_SYNC_PLL_SPEED_DPL_K1,         //Set Hsync PLL Speed dpl k1
    E_MI_EXTIN_FACTORY_ANALOG_DECODER_H_SYNC_PLL_SPEED_DPL_K2,         //Set Hsync PLL Speed dpl k2
    E_MI_EXTIN_FACTORY_ANALOG_DECODER_FIX_H_V_SLICE_LEVEL,             //Enable/Disable H/VSLISEL is controlled by DSP
    E_MI_EXTIN_FACTORY_ANALOG_DECODER_V_SLICE_LEVEL,                   //Set V slice level
    E_MI_EXTIN_FACTORY_ANALOG_DECODER_H_SLICE_LEVEL,                   //Set H slice level
    E_MI_EXTIN_FACTORY_ANALOG_DECODER_FIX_GAIN,                        //Enable/Disable Fix gain
    E_MI_EXTIN_FACTORY_ANALOG_DECODER_FINE_GAIN,                       //Set Fine gain
    E_MI_EXTIN_FACTORY_ANALOG_DECODER_STANDARD_DETECTION_FLAG,         //Enable/Disable  Standard Detection Flag
    E_MI_EXTIN_FACTORY_ANALOG_DECODER_INPUT_TYPE,                      //Set input type
    E_MI_EXTIN_FACTORY_ANALOG_DECODER_JILIN_PATCH,                     //Enable/Disable Jilin Patch
    E_MI_EXTIN_FACTORY_ANALOG_DECODER_COLOR_KILL_HIGH_BOUND,           //Set Color Kill High Bound
    E_MI_EXTIN_FACTORY_ANALOG_DECODER_COLOR_KILL_LOW_BOUND,            //Set Color Kill Low Bound
    E_MI_EXTIN_FACTORY_ANALOG_DECODER_MAX,                             //Out of the range of VD factory commands
} MI_EXTIN_FactoryType_e;

typedef struct MI_EXTIN_InitParams_s
{
    MI_U8 u8Reserved;

} MI_EXTIN_InitParams_t;

/// hdmi capability
typedef struct MI_EXTIN_HdmiCaps_s
{
    MI_U32 u32HdmiCount;
    /// Bitwise indicate HDMI index support MHL capability. Bit 0 indicate index 0 capbility.
    MI_U32 u32MhlSupport;

} MI_EXTIN_HdmiCaps_t;

/// Component capability
typedef struct MI_EXTIN_ComponentCaps_s
{
    MI_U32 u32ComponentCount;

} MI_EXTIN_ComponentCaps_t;

/// Vga capability
typedef struct MI_EXTIN_VgaCaps_s
{
    MI_U32 u32VgaCount;

} MI_EXTIN_VgaCaps_t;

/// Cvbs capability
typedef struct MI_EXTIN_CvbsCaps_s
{
    MI_U32 u32CvbsCount;

} MI_EXTIN_CvbsCaps_t;

/// Svideo capability
typedef struct MI_EXTIN_SvideoCaps_s
{
    MI_U32 u32SvideoCount;

} MI_EXTIN_SvideoCaps_t;

/// Scart capability
typedef struct MI_EXTIN_ScartCaps_s
{
    MI_U32 u32ScartCount;

} MI_EXTIN_ScartCaps_t;

/// Scart capability
typedef struct MI_EXTIN_AtvCaps_s
{
    MI_U32 u32AtvCount;

} MI_EXTIN_AtvCaps_t;

typedef struct MI_EXTIN_Caps_s
{
    MI_EXTIN_HdmiCaps_t      stHdmiCaps;
    MI_EXTIN_ComponentCaps_t stComponentCaps;
    MI_EXTIN_VgaCaps_t       stVgaCaps;
    MI_EXTIN_CvbsCaps_t      stCvbsCaps;
    MI_EXTIN_SvideoCaps_t    stSvideoCaps;
    MI_EXTIN_ScartCaps_t     stScartCaps;
    MI_EXTIN_AtvCaps_t       stAtvCaps;
} MI_EXTIN_Caps_t;

typedef struct MI_EXTIN_HdmiHdcpKeyInfo_s
{
    MI_U8* pu8HdmiHdcpKey;                                ///<HDMI Rx HDCP Key
    MI_U16 u16HdmiHdcpKeySize;                            ///<Size of HDMI Rx HDCP key
    MI_U8* pu8HdmiHdcp2Key;                               ///<HDMI Rx HDCP2.2 Key
    MI_U16 u16HdmiHdcp2KeySize;                           ///<Size of HDMI Rx HDCP2.2 key
} MI_EXTIN_HdmiHdcpKeyInfo_t;

typedef struct MI_EXTIN_HdmiEdidInfo_s
{
    MI_EXTIN_HdmiEdidType_e  eHdmiEdidType;
    MI_EXTIN_HdmiEdidVersion_e eHdmiEdidVersion;    ///Define EDID Version
    MI_U8* pu8CusDefEdid;                           ///customer defined EDID
    MI_U16 u16CusDefEdidSize;                       ///customer defined EDID size
} MI_EXTIN_HdmiEdidInfo_t;

typedef struct MI_EXTIN_OpenParams_s
{
    MI_EXTIN_Type_e eExtInType;
    MI_U32 u32Index;
} MI_EXTIN_OpenParams_t;

typedef struct MI_EXTIN_PcPosition_s
{
    MI_U32 u32X;
    MI_U32 u32Y;
} MI_EXTIN_PcPosition_t;

typedef struct MI_EXTIN_PcClockRange_s
{
    MI_U32 u32MaxClock;
    MI_U32 u32MinClock;
} MI_EXTIN_PcClockRange_t;

typedef struct MI_EXTIN_PcPhaseRange_s
{
    MI_U32 u32MaxPhase;
    MI_U32 u32MinPhase;
} MI_EXTIN_PcPhaseRange_t;

typedef struct MI_EXTIN_AdcPhase_s
{
    MI_U32 u32PhaseRV;
    MI_U32 u32PhaseGY;
    MI_U32 u32PhaseBU;
} MI_EXTIN_AdcPhase_t;

typedef struct MI_EXTIN_PcAutoTable_s
{
    MI_U8 u8ModeIndex;
    MI_U32 u32AdcClock;
    MI_EXTIN_AdcPhase_t stAdcPhase;
    MI_EXTIN_PcPosition_t stPcPosition;
} MI_EXTIN_PcAutoTable_t;

typedef struct MI_EXTIN_VideoInfo_s
{
    MI_U32 u32Width;        // Source Width
    MI_U32 u32Height;        // Source Height
    MI_BOOL bInterlace;   // 0: Progressive 1: interlace
    MI_U32 u32FrameRate;    // Actual framerate * 100. Ex: This will be 5995 if framerate is 59.95Hz
    MI_EXTIN_ColorFormat_e eColorFormat; // Input source color space
} MI_EXTIN_VideoInfo_t;

typedef struct MI_EXTIN_SetWindowInfo_s
{
    MI_U32 u32X;            // Source x
    MI_U32 u32Y;            // Source Y
    MI_U32 u32Width;        // Source Width
    MI_U32 u32Height;       // Source Height

    //-------------
    // Timing
    //-------------
    MI_BOOL bInterlace;     // 0: Progressive 1: interlace
    MI_BOOL bHDuplicate;    // <flag for vop horizontal duplicate, for MVD, YPbPr, indicate input double sampled or not
    MI_U32 u32FrameRate;    // Actual framerate * 100. Ex: This will be 5995 if framerate is 59.95Hz
    MI_U32 u32InputVTotal;  // <Input Vertical total, for calculate output panel timing
    MI_U32 u32DefaultHtotal;// <Default Htotal for VGA/YPbPr input
    MI_U32 u32DefaultPhase; // <Obsolete

    //-------------
    //Color sapce
    //-------------
    MI_EXTIN_ColorFormat_e eColorFormat; // Input source color space
} MI_EXTIN_SetWindowInfo_t;

typedef struct MI_EXTIN_HdmiPacket_s
{
    MI_EXTIN_HdmiPacketType_e ePacketType;
    MI_U8  au8DataBytes[MI_EXTIN_HDMI_PACKET_DATA_LENGTH];
} MI_EXTIN_HdmiPacket_t;

typedef struct MI_EXTIN_AviInfoFrame_s
{
    MI_EXTIN_AviInfoFrameColorformat_e  eColorformat;
    MI_EXTIN_AviInfoFrameAfdActiveInfo_e  eActiveInfo;
    MI_EXTIN_AviInfoFrameBarInfo_e eBarInfo;
    MI_EXTIN_AviInfoFrameScanInfo_e eScanInfo;
    MI_EXTIN_AviInfoFrameColorimetry_e eColorimetry;
    MI_EXTIN_AviInfoFramePicAr_e ePictureAr;
    MI_EXTIN_AviInfoFrameAfd_e eAfd;
    MI_EXTIN_AviInfoFramePicScale_e ePicScale;
    MI_U8 u8VideoIdCode;
    MI_U8 u8PixelRepeat;
    MI_EXTIN_AviInfoFrameItContent_e eItContent;
    MI_EXTIN_AviInfoFrameExtColorimetry_e eExtColorimetry;
    MI_EXTIN_AviInfoFrameRgbQuantRange_e eRgbQuantRange;
    MI_EXTIN_AviInfoFrameContentType_e eContentType;
    MI_EXTIN_AviInfoFrameYccQuantRange_e eYccQuantRange;
    MI_U16  u16TopBarEndLineNumber;
    MI_U16  u16BottomBarStartLineNumber;
    MI_U16  u16LeftBarEndPixelNumber;
    MI_U16  u16RightBarStartPixelNumber;
} MI_EXTIN_AviInfoFrame_t;

typedef struct MI_EXTIN_AdcGainOffset_s
{
    MI_U32 u32GainRV;
    MI_U32 u32GainGY;
    MI_U32 u32GainBU;
    MI_U32 u32OffsetRV;
    MI_U32 u32OffsetGY;
    MI_U32 u32OffsetBU;
} MI_EXTIN_AdcGainOffset_t;

typedef struct MI_EXTIN_ConnectInputParams_s
{
    MI_U8 u8Reserved;
} MI_EXTIN_ConnectInputParams_t;

typedef struct MI_EXTIN_QueryHandleParams_s
{
    MI_EXTIN_Type_e eExtInType;
    MI_U32 u32Index;

} MI_EXTIN_QueryHandleParams_t;

typedef struct MI_EXTIN_SignalStatus_s
{
    MI_BOOL bStable;
    MI_BOOL bSupportTiming;
} MI_EXTIN_SignalStatus_t;

typedef struct MI_EXTIN_GetSignalStatusParams_s
{
    /// ATV only: Reliable level is about Tv system result from auto detect.
    MI_EXTIN_AtvSignalReliableLevel_e eReliableLevel;
} MI_EXTIN_GetSignalStatusParams_t;

typedef struct MI_EXTIN_GetTvSystemParams_s
{
    /// ATV only: Reliable level is about Tv system result from auto detect.
    MI_EXTIN_AtvSignalReliableLevel_e eReliableLevel;
} MI_EXTIN_GetTvSystemParams_t;

typedef struct MI_EXTIN_ConnectedConds_s
{
    MI_BOOL bIsInput;
    MI_U32 u32Module;

    //if need other conditions add here
} MI_EXTIN_ConnectedConds_t;

typedef struct MI_EXTIN_HdmiVersionRevision_s
{
    MI_U32 u32Version;
    MI_U32 u32Revision;
} MI_EXTIN_HdmiVersionRevision_t;

typedef struct MI_EXTIN_SadInfo_s
{
    MI_U8 u8SadLength;
    MI_U8 au8SadInfo[MI_EXTIN_SAD_INFO_LENGTH];
} MI_EXTIN_SadInfo_t;

typedef struct MI_EXTIN_HdmiHpdControl_s
{
    MI_BOOL bSetHpd;
    MI_U8 u8HdmiPortNum;
} MI_EXTIN_HdmiHpdControl_t;

//-------------------------------------------------------------------------------------------------
//  Global Functions
//-------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------
/// @brief Init extin module.
/// @param[in] pstInitParams: Init module parameters.
/// @return MI_OK: Process success.
/// @return MI_ERR_RESOURCES: get resource fail.
//------------------------------------------------------------------------------
MI_RESULT MI_EXTIN_Init(const MI_EXTIN_InitParams_t *pstInitParams);

//------------------------------------------------------------------------------
/// @brief Finalize extin module.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_NOT_INITED: Display module not initialized.
//------------------------------------------------------------------------------
MI_RESULT MI_EXTIN_DeInit(void);

//------------------------------------------------------------------------------
/// @brief Get extin module capbility.
/// @param[out] pstCaps: A pointer to structure MI_EXTIN_Caps_t to retrieve the information of extin capabilities
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_INVALID_PARAMETER: Invalid param.
/// @return MI_ERR_NOT_INITED: Display module not initialized.
//------------------------------------------------------------------------------
MI_RESULT MI_EXTIN_GetCaps(MI_EXTIN_Caps_t *pstCaps);

//------------------------------------------------------------------------------
/// @brief Open extin device handle
/// @param[in]  pstOpenParams: Pointer to MI_EXTIN_OpenParams_t for creating a extin device.
/// @param[out] phExtin: A handle pointer to retrieve an instance of a created extin device.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_EXTIN_Open(const MI_EXTIN_OpenParams_t *pstOpenParams, MI_HANDLE *phExtin);

//------------------------------------------------------------------------------
/// @brief Get a extin handle with device index
/// @param[in] pstQueryParams: Get the specified handle by the parameters info.
/// @param[out] phExtin: An handle of extin device
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_EXTIN_GetHandle(const MI_EXTIN_QueryHandleParams_t *pstQueryParams, MI_HANDLE *phExtin);

//------------------------------------------------------------------------------
/// @brief Close a extin handle.
/// @param[in] hExtin: An instance of a created extin interface.
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_EXTIN_Close(MI_HANDLE hExtin);

//------------------------------------------------------------------------------
/// @brief Set external input debug level.
/// @param[in] u32DebugLevel: Debug level.
/// @return MI_OK: Set debug level success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_INVALID_PARAMETER: Parameter is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_EXTIN_SetDebugLevel(MI_DBG_LEVEL u32DebugLevel);

//------------------------------------------------------------------------------
/// @brief  set attribute of the speicfied extin
/// @param[in] hExtin:Handle of a created extin device.
/// @param[in] eAttrType:set the type of extin attribute.
/// @param[in] pAttrParams:set the attibute.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_EXTIN_SetAttr(MI_HANDLE hExtin, MI_EXTIN_AttrType_e eAttrType, const void *pAttrParams);

//------------------------------------------------------------------------------
/// @brief  get attribute of the speicfied extin
/// @param[in] hExtin:Handle of a created extin device.
/// @param[in] eAttrType:set the type of extin attribute.
/// @param[in] pInputParams:attribute parameters.
/// @param[out] pOutputParams:get the attibute.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_EXTIN_GetAttr(MI_HANDLE hExtin, MI_EXTIN_AttrType_e eAttrType, const void *pInputParams, void *pOutputParams);

//------------------------------------------------------------------------------
/// @brief  update pc mode table from user DB by index
/// @param[in] hExtin:Handle of a created extin device.
/// @param[in] pstUserTable: user pc mode table.
/// @param[in] u8TableCount: point out table number.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_EXTIN_UpdatePcModeTable(MI_HANDLE hExtin, MI_EXTIN_PcAutoTable_t *pstUserTable, MI_U8 u8TableCount);

//------------------------------------------------------------------------------
/// @brief force set user TV system for analog source
/// @param[in] hExtin:Handle of a created extin device.
/// @param[in] eTvSystem:set the type of TV system.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_EXTIN_SetTvSystem(MI_HANDLE hExtin, MI_EXTIN_TvSystem_e eTvSystem);

//------------------------------------------------------------------------------
/// @brief get one input source signal is stable.
/// @param[in] hExtInHandle: An instance of a created extin interface.
/// @param[out] eSignalStatus: signal stable enum pointer.
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_EXTIN_GetSignalStatus(MI_HANDLE hExtin, MI_EXTIN_SignalStatus_e *peSignalStatus);

//------------------------------------------------------------------------------
/// @brief detect TV system for Analog Source
/// @param[in] hExtInHandle:Handle of a created extin device.
/// @param[in] bDirect: TRUE: detect directly from VD; FALSE: detect a debouncing TV system
/// @param[out] peTvSystemType:detect the type of TV system.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_EXTIN_DetectTvSystem(MI_HANDLE hExtin, MI_BOOL bDirect, MI_EXTIN_TvSystem_e *peTvSystemType);

//------------------------------------------------------------------------------
/// @brief Get user TV system for analog source
/// @param[in] hExtin:Handle of a created extin device.
/// @param[in] pstInputParams: parameters for get tv system.
/// @param[out] peTvSystem:get the type of TV system.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_EXTIN_GetTvSystem(MI_HANDLE hExtin, const MI_EXTIN_GetTvSystemParams_t *pstInputParams,  MI_EXTIN_TvSystem_e *peTvSystem);

//------------------------------------------------------------------------------
/// @brief Do PC Auto
/// @param[in] hExtin:Handle of a created extin device.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_EXTIN_PcAuto(MI_HANDLE hExtin);

//------------------------------------------------------------------------------
/// @brief Do auto calibration
/// @param[in] hExtin:Handle of a created extin device.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_EXTIN_AutoGainOffset(MI_HANDLE hExtin);

//------------------------------------------------------------------------------
/// @brief Get the number of connected input handle.
/// @param[in] hExtin:Handle of a created extin device.
/// @param[in] pstExtinConds: bIsinput-The direction for finding the connected module.
///                           u32ModuleType-The module type of connected with extin. it defined in mi_common.h with prefix MI_MODULE_TYPE_XXX.
///                                         If it is MI_MODULE_TYPE_NONE it find all type of connected modules.
///                                         e.g. MI_EXTIN_GetConnectedNum(hExtin, FALSE, MI_MODULE_TYPE_DISP, pu32ConnectedNum)
/// @param[out] pu32ConnectedNum: The number of connected handle
/// @return MI_OK: Process success.
//------------------------------------------------------------------------------
MI_RESULT MI_EXTIN_GetConnectedNum(const MI_HANDLE hExtin, const MI_EXTIN_ConnectedConds_t *pstExtinConds, MI_U32 *pu32ConnectedNum);

//------------------------------------------------------------------------------
/// @brief Get the element which is connected to the specified element.
/// @param[in] hExtin:Handle of a created extin device.
/// @param[in] pstExtinConds: bIsinput-The direction for finding the connected module.
///                                        u32ModuleType-The module type of connected with EXTIN. it defined in mi_common.h with prefix MI_MODULE_TYPE_XXX.
///                                        If it is MI_MODULE_TYPE_NONE it find all type of connected modules.
///                                        e.g. MI_EXTIN_GetConnected(hExtIn, FALSE, MI_MODULE_TYPE_DISP, u32ConnectedNum, phConnectedArray)
/// @param[in] u32ConnectedNum: The number of get handle
/// @param[out] phConnectedArray: Pointer to handle buffer to retrieve the handle of MI module which is connected to the specified element with the specified direction.
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_FAILED: Process fail, no connection is available.
//------------------------------------------------------------------------------
MI_RESULT MI_EXTIN_GetConnected(const MI_HANDLE hExtin, const MI_EXTIN_ConnectedConds_t *pstExtinConds, const MI_U32 u32ConnectedNum , MI_HANDLE *phConnectedArray);

//------------------------------------------------------------------------------
/// @brief Factory get information
/// @param[in] hExtin: Handle of a created extin device.
/// @param[in] eFactoryType: set the type of extin attribute.
/// @param[in] pInputParams: input params,set NULL if not necessary.
/// @param[out]  pOutputParams: Pointer to struct to retrieve the information accroding to eFactoryCmdType
/// @return MI_OK: Process success
/// @return MI_ERR_FAILED: Process failure
/// @sa
/// @note
//------------------------------------------------------------------------------
MI_RESULT MI_EXTIN_FactoryGetAttr(MI_HANDLE hExtin, MI_EXTIN_FactoryType_e eFactoryType, const void * pInputParams, void * pOutputParams);

//------------------------------------------------------------------------------
/// @brief Factory set information
/// @param[in] hExtin:Handle of a created extin device.
/// @param[in] eFactoryType: set the type of extin attribute.
/// @param[in] pAttrParams:set the attibute.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_EXTIN_FactorySetAttr(MI_HANDLE hExtin, MI_EXTIN_FactoryType_e eFactoryType, const void *pAttrParams);

#ifdef __cplusplus
}
#endif

#endif///_MI_EXTIN_H_

