/*------------------------------------------------------------------------------
 * MediaTek Inc. (C) 2018. All rights reserved.
 *
 * Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 *----------------------------------------------------------------------------*/
#ifndef _MI_PWM_H_
#define _MI_PWM_H_

#ifdef __cplusplus
extern "C" {
#endif
#include "mi_common.h"

typedef enum
{
    E_MI_PWM_CH_MIN = 0,   //Channel 0 of PWM Channels
    E_MI_PWM_CH0 = E_MI_PWM_CH_MIN,   //Channel 0 of PWM Channels
    E_MI_PWM_CH1,       //Channel 1 of PWM Channels
    E_MI_PWM_CH2,       //Channel 2 of PWM Channels
    E_MI_PWM_CH3,       //Channel 3 of PWM Channels
    E_MI_PWM_CH4,       //Channel 4 of PWM Channels
    E_MI_PWM_CH5,       //Channel 5 of PWM Channels
    E_MI_PWM_CH6,       //Channel 6 of PWM Channels
    E_MI_PWM_CH7,       //Channel 7 of PWM Channels
    E_MI_PWM_CH8,       //Channel 8 of PWM Channels
    E_MI_PWM_CH_MAX,
    E_MI_PWM_PM_CH_MIN,
    E_MI_PWM_PM_CH0 = E_MI_PWM_PM_CH_MIN,
    E_MI_PWM_PM_CH1,
    E_MI_PWM_PM_CH2,
    E_MI_PWM_PM_CH3,
    E_MI_PWM_PM_CH4,
    E_MI_PWM_PM_CH5,
    E_MI_PWM_PM_CH6,
    E_MI_PWM_PM_CH7,
    E_MI_PWM_PM_CH8,
    E_MI_PWM_PM_CH_MAX,
    E_MI_PWM_NUM,       //Total num of PWM Channels
} MI_PWM_Channel_e;

typedef enum
{
    E_MI_PWM_RESET_MODE_VSYNC = 0,
    E_MI_PWM_RESET_MODE_HSYNC,
}MI_PWM_ResetMode_e;

typedef enum
{
    E_MI_PWM_RESET_SOURCE_VSYNC = 0,
    E_MI_PWM_RESET_SOURCE_LRSYNC_RISING,
    E_MI_PWM_RESET_SOURCE_LRSYNC_FALLING,
    E_MI_PWM_RESET_SOURCE_LRSYNC_BOTH_EDGE,
}MI_PWM_ResetSource_e;

typedef enum
{
    E_MI_PWM_ATTR_TYPE_MIN = 0,

    //Set/Get PWM period,
    //no pInputParams,
    //pOutputParams&pAttrParams type is a pointer to MI_U32
    E_MI_PWM_ATTR_TYPE_PERIOD = E_MI_PWM_ATTR_TYPE_MIN,
    //Set/Get PWM duty cycle,
    //no pInputParams,
    //pOutputParams&pAttrParams type is a pointer to MI_U32
    E_MI_PWM_ATTR_TYPE_DUTY_CYCLE,
    //Set/Get PWM divider,
    //no pInputParams,
    //pOutputParams&pAttrParams type is a pointer to MI_U16
    E_MI_PWM_ATTR_TYPE_DIVIDER,
    //Set/Get PWM polarity,
    //no pInputParams,
    //pOutputParams&pAttrParams type is a pointer to MI_BOOL
    E_MI_PWM_ATTR_TYPE_POLARITY,
    //Set/Get PWM shift,
    //no pInputParams,
    //pOutputParams&pAttrParams type is a pointer to MI_U32
    E_MI_PWM_ATTR_TYPE_SHIFT,
    //Set/Get PWM double buffer enable bit,
    //no pInputParams,
    //pOutputParams&pAttrParams type is a pointer to MI_BOOL
    E_MI_PWM_ATTR_TYPE_DOUBLE_BUFFER_ENABLE,
    //Set/Get PWM vsync double buffer enable bit,
    //no pInputParams,
    //pOutputParams&pAttrParams type is a pointer to MI_BOOL
    E_MI_PWM_ATTR_TYPE_VSYNC_DOUBLE_BUFFER_ENABLE,
    //Set/Get PWM output enable bit,
    //no pInputParams,
    //pOutputParams&pAttrParams type is a pointer to MI_BOOL
    E_MI_PWM_ATTR_TYPE_OUTPUT_ENABLE,
    //Set/Get PWM reset by 'Vsync or Hsync' enable bit,
    //no pInputParams,
    //pOutputParams&pAttrParams type is a pointer to MI_BOOL
    E_MI_PWM_ATTR_TYPE_RESET_ENABLE,
    //Set/Get PWM reset mode,
    //no pInputParams,
    //pOutputParams&pAttrParams type is a pointer to MI_PWM_ResetMode_e
    E_MI_PWM_ATTR_TYPE_RESET_MODE,
    //Set/Get PWM reset source,
    //no pInputParams,
    //pOutputParams&pAttrParams type is a pointer to MI_PWM_ResetSource_e
    E_MI_PWM_ATTR_TYPE_RESET_SOURCE,
    //Set/Get PWM reset count,PWM will reset by count+1 times of reset source,
    //no pInputParams,
    //pOutputParams&pAttrParams type is a pointer to MI_U8
    E_MI_PWM_ATTR_TYPE_RESET_COUNT,
    //Set/Get PWM reset n pulse enable bit,
    //no pInputParams,
    //pOutputParams&pAttrParams type is a pointer to MI_BOOL
    E_MI_PWM_ATTR_TYPE_RESET_N_PULSE_ENABLE,

    E_MI_PWM_ATTR_TYPE_MAX,

} MI_PWM_AttrType_e;

typedef struct MI_PWM_InitParams_s
{
    MI_U8 u8Reserved;        ///[IN]: reserved
} MI_PWM_InitParams_t;

typedef struct MI_PWM_OpenParams_s
{
    MI_PWM_Channel_e ePwmChannel;
} MI_PWM_OpenParams_t;
typedef MI_PWM_OpenParams_t MI_PWM_QueryHandleParams_t;

//-------------------------------------------------------------------------------------------------
//  Global Functions
//-------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------
/// @brief Init the PWM module.
/// @param[in]  pstInitParams: A pointer to structure MI_PWM_InitParams_t.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: PWM module initialization failed.
//------------------------------------------------------------------------------
MI_RESULT MI_PWM_Init(const MI_PWM_InitParams_t *pstInitParams);

//------------------------------------------------------------------------------
/// @brief finalize the pwm module.
/// @return MI_OK: Process success.
//------------------------------------------------------------------------------
MI_RESULT MI_PWM_DeInit(void);

//------------------------------------------------------------------------------
/// @brief Open the PWM module.
/// @param[in]  pstOpenParam: A pointer to structure MI_PWM_OpenParams_t.
/// @param[out] phPwm: phPwm for retrieve an instance of PWM interface.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: PWM module open failed.
/// @return MI_ERR_INVALID_PARAMETR: Parameters is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_PWM_Open(const MI_PWM_OpenParams_t *pstOpenParams, MI_HANDLE *phPwm);

//------------------------------------------------------------------------------
/// @brief Get Handle of the PWM module.
/// @param[in]  pstQueryParams: A pointer to structure MI_PWM_QueryHandleParams_t.
/// @param[out] phPwm: phPwm for retrieve an instance of PWM interface.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: PWM module Get Handle failed.
/// @return MI_ERR_INVALID_PARAMETR: Parameters is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_PWM_GetHandle(const MI_PWM_QueryHandleParams_t *pstQueryParams, MI_HANDLE *phPwm);

//------------------------------------------------------------------------------
/// @brief Close the PWM module.
/// @param[in]  hPwm: A instance of PWM interface.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: PWM module close failed.
//------------------------------------------------------------------------------
MI_RESULT MI_PWM_Close(MI_HANDLE hPwm);

//------------------------------------------------------------------------------
/// @brief Set PWM module attributes
/// @param[in]  hPwm: A instance to PWM interface.
/// @param[in]  eAttrType : the attribute that you want to set in PWM module.
/// @param[in] *pAttrParams: the pointer to MI_PWM_Attribute_t's member that wants to set in PWM module.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: process failed.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_PWM_SetAttr(MI_HANDLE hPwm, MI_PWM_AttrType_e eAttrType, const void *pAttrParams);

//------------------------------------------------------------------------------
/// @brief Get PWM module attributes
/// @param[in]  hPwm: A instance to PWM interface.
/// @param[in]  eAttrType : the attribute that you want to get in PWM module.
/// @param[in] *pInputParams: the pointer to parameters of eAttrType.
/// @param[in] *pOutputParams: the pointer to MI_PWM_AttrType_e's member that wants to get in PWM module.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: process failed.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_PWM_GetAttr(MI_HANDLE hPwm, MI_PWM_AttrType_e eAttrType, const void * pInputParams, void * pOutputParams);

//------------------------------------------------------------------------------
/// @brief Set PWM module debug level.
/// @param[in] u32DebugLevel.
/// @return MI_OK: Set debug level success.
///------------------------------------------------------------------------------
MI_RESULT MI_PWM_SetDebugLevel(MI_DBG_LEVEL u32DebugLevel);

#ifdef __cplusplus
}
#endif

#endif  // _MI_PWM_H_

