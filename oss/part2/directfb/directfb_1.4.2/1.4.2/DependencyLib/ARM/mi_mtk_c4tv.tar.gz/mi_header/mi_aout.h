/*------------------------------------------------------------------------------
 * MediaTek Inc. (C) 2018. All rights reserved.
 *
 * Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 *----------------------------------------------------------------------------*/
//------------------------------------------------------------------------------
//GetXxx/SetXxx and GetAttr/SetAttr coexist
//------------------------------------------------------------------------------

#ifndef _MI_AOUT_H_
#define _MI_AOUT_H_

#ifdef __cplusplus
extern "C" {
#endif

//-------------------------------------------------------------------------------------------------
//  Defines
//-------------------------------------------------------------------------------------------------

//Basic sound effect
#define MI_AOUT_EQ_BAND_MAX                 (5)
#define MI_AOUT_PEQ_BAND_MAX                (5)
#define MI_AOUT_BASIC_SND_EFFECT_MAX        (12)

///Advance sound effect: DAP
#define MI_AOUT_MAX_DAP_BAND_NUM                    (20)
#define MI_AOUT_MAX_DAP_IEQ_BAND_NUM                MI_AOUT_MAX_DAP_BAND_NUM
#define MI_AOUT_MAX_DAP_GEQ_BAND_NUM                MI_AOUT_MAX_DAP_BAND_NUM
#define MI_AOUT_MAX_DAP_REG_BAND_NUM                MI_AOUT_MAX_DAP_BAND_NUM
#define MI_AOUT_MAX_DAP_OPT_BAND_NUM                MI_AOUT_MAX_DAP_BAND_NUM
#define MI_AOUT_MAX_DAP_CHANNEL_NUM                 (6)

///Advance sound effect: DBX
#define MI_AOUT_DBX_DM_NUM                  (95)
#define MI_AOUT_DBX_PM_NUM                  (100)
#define MI_AOUT_DBX_TOTAL_VOLUME_GROUP_NUM  (2)

// Maximum number of MI_AOUT_ChannelMappingType_e
#define MI_AOUT_CHANNEL_MAPPING_MAX_NUM 13

//-------------------------------------------------------------------------------------------------
//  Structures
//-------------------------------------------------------------------------------------------------
typedef enum
{
    E_MI_AOUT_PATH_NONE = 0xFF,

    E_MI_AOUT_PATH_ALL = 0,      // Control all device

    E_MI_AOUT_PATH_LR,           // Box analog amplifier
    E_MI_AOUT_PATH_SPDIF,        // SPDIF
    E_MI_AOUT_PATH_HDMI_TX,      // HDMI Tx

    E_MI_AOUT_PATH_MAIN_SPEAKER, // Tv speaker of analog or I2S amplifier
    E_MI_AOUT_PATH_HEADPHONE,    // headphone
    E_MI_AOUT_PATH_LINEOUT,      // lineout
    E_MI_AOUT_PATH_HDMI_ARC,     // HDMI Audio Return Channel
    E_MI_AOUT_PATH_SCART,        // scart

    E_MI_AOUT_PATH_MAX,

} MI_AOUT_Path_e;

typedef enum
{
    E_MI_AOUT_DIGITAL_MODE_NONE = 0xFF,

    E_MI_AOUT_DIGITAL_MODE_PCM           = 0x0,  //PCM
    E_MI_AOUT_DIGITAL_MODE_AUTO,                 //Auto
    E_MI_AOUT_DIGITAL_MODE_TRANSCODE,            //Transcode
    E_MI_AOUT_DIGITAL_MODE_BYPASS,               //Bypass
    E_MI_AOUT_DIGITAL_MODE_ATMOS,                // ATMOS

    E_MI_AOUT_DIGITAL_MODE_MAX,
} MI_AOUT_DigitalMode_e;

typedef enum
{
    E_MI_AOUT_DELAY_NONE =  0xFF,

    E_MI_AOUT_DELAY_PCM =  0x0,                  //All Path delay for lipsync case(audio main delay)
    E_MI_AOUT_DELAY_RAW_DATA = 0x1,              //Extra Delay for Digital Output (SPDIF/ARC PCM/NonPcm delay),ex: for UI control
    E_MI_AOUT_DELAY_SPEAKER_EXTRA = 0x2,         //Extra Delay for Speaker, ex: for UI control

    E_MI_AOUT_DELAY_MAX,
} MI_AOUT_DelayType_e;

typedef enum
{
    E_MI_AOUT_TRACK_MODE_NONE = 0xFF,

    E_MI_AOUT_TRACK_MODE_STEREO = 0,
    E_MI_AOUT_TRACK_MODE_LEFT,
    E_MI_AOUT_TRACK_MODE_RIGHT,
    E_MI_AOUT_TRACK_MODE_MIXED,

    E_MI_AOUT_TRACK_MODE_MAX,
} MI_AOUT_TrackMode_e;

typedef enum
{
    E_MI_AOUT_MUTE_BY_NONE = 0xFF,

    E_MI_AOUT_MUTE_BY_USER = 0x0,
    E_MI_AOUT_MUTE_BY_DECODER,
    E_MI_AOUT_MUTE_BY_INTERVAL,

    E_MI_AOUT_MUTE_MAX,
} MI_AOUT_MuteType_e;

// SPDIF Serial Copy Management System
typedef enum
{
    E_MI_AOUT_SPDIF_SCMS_COPY_FREELY = 0,
    E_MI_AOUT_SPDIF_SCMS_COPY_ONCE,
    E_MI_AOUT_SPDIF_SCMS_COPY_NEVER,
} MI_AOUT_SpdifScmsMode_e;

/// HDMI supported codec in edid
typedef enum
{
    E_MI_AOUT_CODEC_NONE                          = 0x0,
    E_MI_AOUT_CODEC_LPCM                          = 0x1,      ///< Support LPCM
    E_MI_AOUT_CODEC_DD                            = 0x2,      ///< Support DD
    E_MI_AOUT_CODEC_MPEG1                         = 0x3,      ///< Support MPEG1
    E_MI_AOUT_CODEC_MP3                           = 0x4,      ///< Support MP3
    E_MI_AOUT_CODEC_MPEG2                         = 0x5,      ///< Support MPEG2
    E_MI_AOUT_CODEC_AAC                           = 0x6,      ///< Support AAC
    E_MI_AOUT_CODEC_DTS                           = 0x7,      ///< Support DTS
    E_MI_AOUT_CODEC_ATRAC                         = 0x8,      ///< Support ATRAC
    E_MI_AOUT_CODEC_ONE_BIT_AUDIO                 = 0x9,      ///< Support One-Bit Audio
    E_MI_AOUT_CODEC_DDP                           = 0xA,      ///< Support DDP
    E_MI_AOUT_CODEC_DTSHD                         = 0xB,      ///< Support DTSHD
    E_MI_AOUT_CODEC_TRUEHD                        = 0xC,      ///< Support MLP/TRUE-HD
    E_MI_AOUT_CODEC_DST                           = 0xD,      ///< Support DST
    E_MI_AOUT_CODEC_WMA_PRO                       = 0xE,      ///< Support WMA-Pro
    E_MI_AOUT_CODEC_ATMOS                         = 0xF,      ///< Support ATMOS
    E_MI_AOUT_CODEC_MAX
} MI_AOUT_CodecType_e;

typedef struct MI_AOUT_CodecTypeCapability_s
{
    MI_U8 u8Size;
    MI_AOUT_CodecType_e aeCodecType[E_MI_AOUT_CODEC_MAX];
} MI_AOUT_CodecTypeCapability_t;

typedef enum
{
    E_MI_AOUT_BASIC_SND_NONE     = 0xFF,

    E_MI_AOUT_BASIC_SND_PRESCALE = 0,//Prescale
    E_MI_AOUT_BASIC_SND_EQ,          //Equalizer
    E_MI_AOUT_BASIC_SND_PEQ,         //Parameter Equalizer
    E_MI_AOUT_BASIC_SND_TREBLE,      //Treble
    E_MI_AOUT_BASIC_SND_BASS,        //Bass
    E_MI_AOUT_BASIC_SND_AVC,         //Auto Volume Control
    E_MI_AOUT_BASIC_SND_SURROUND,    //Surround
    E_MI_AOUT_BASIC_SND_BALANCE,     //Balance
    E_MI_AOUT_BASIC_SND_DRC,         //Dynamic Range Control
    E_MI_AOUT_BASIC_SND_ECHO,        //Echo (For KTV used)
    E_MI_AOUT_BASIC_SND_NR,          //Noise Reduction
    E_MI_AOUT_BASIC_SND_HPF,         //High Pass Filter
    E_MI_AOUT_BASIC_SND_LIMITER,     //Volume Limiter
    E_MI_AOUT_BASIC_SND_ABSOLUTE_EQ, //Absolute EQ

    E_MI_AOUT_BASIC_SND_MAX,
}MI_AOUT_BasicSndType_e;

typedef enum
{
    E_MI_AOUT_LIMITER_MODE_PEAK,    // Peak Mode: threshold is for peak
    E_MI_AOUT_LIMITER_MODE_RMS,     // RMS Mode: threshold is for RMS(root-mean-square)
}MI_AOUT_LimiterMode_e;

typedef enum
{
    ///< Invalid advanced sound effect
    E_MI_AOUT_ADV_SND_NONE          = 0xFF,
    ///< DTS advanced sound effect min
    E_MI_AOUT_ADV_SND_DTS_MIN       = 0,
    ///< SRS True Surround HD
    E_MI_AOUT_ADV_SND_SRS_TSHD      = E_MI_AOUT_ADV_SND_DTS_MIN,
    ///< SRS Theater Sound
    E_MI_AOUT_ADV_SND_SRS_THEATER_SND,
    ///< SRS PureSound.
    E_MI_AOUT_ADV_SND_SRS_PURE_SND,
    ///< DTS VirtualX sound effect
    E_MI_AOUT_ADV_SND_DTS_VIRTUALX_SND,
    ///< DTS Studio Sound II
    E_MI_AOUT_ADV_SND_DTS_SS_II_SND,
    ///< DTS advanced sound effect max
    E_MI_AOUT_ADV_SND_DTS_MAX,
    ///< Dolby advanced sound effect min
    E_MI_AOUT_ADV_SND_DOLBY_MIN     = 0x30,
    ///< Dolby Volume
    E_MI_AOUT_ADV_SND_DOLBY_VOLUME  = E_MI_AOUT_ADV_SND_DOLBY_MIN,
    ///< Dolby DAP
    E_MI_AOUT_ADV_SND_DOLBY_DAP,
    ///< Dolby advanced sound effect max
    E_MI_AOUT_ADV_SND_DOLBY_MAX,
    ///< Other advanced sound effect min
    E_MI_AOUT_ADV_SND_OTHER_MIN     = 0x60,
    ///< DBX
    E_MI_AOUT_ADV_SND_DBX           = E_MI_AOUT_ADV_SND_OTHER_MIN,
    ///< Sonic Emotion
    E_MI_AOUT_ADV_SND_SONIC_EMOTION,
    ///< Other advanced sound effect max
    E_MI_AOUT_ADV_SND_OTHER_MAX,
    ///< Advanced sound effect max
    E_MI_AOUT_ADV_SND_MAX,
}MI_AOUT_AdvSndType_e;

typedef enum
{
    ///< Invalid attribut
    E_MI_AOUT_ATTR_TYPE_NONE            = 0xFF,
    ///< Common attribut min
    E_MI_AOUT_ATTR_TYPE_COMMON_MIN      = 0,
    ///< Set hw mute by amplifier, parameter type is a pointer to MI_BOOL.
    E_MI_AOUT_ATTR_TYPE_AMPLIFIER_MUTE  = E_MI_AOUT_ATTR_TYPE_COMMON_MIN,
    ///< Set the output path inside the handle to output AD, parameter is a pointer to MI_BOOL, default is ENABLE(TRUE).
    E_MI_AOUT_ATTR_TYPE_AD_OUTPUT_ENABLE,
    ///< Set mute of AOUT device, intput parameter type is a pointer to MI_AOUT_MultiMuteParams_t.
    E_MI_AOUT_ATTR_TYPE_MULTI_MUTE,
    ///< Set the volume table of the specific path, parameter type is a pointer to MI_AOUT_VolumeTableParams_t.
    E_MI_AOUT_ATTR_TYPE_VOLUME_TABLE,
    ///
    E_MI_AOUT_ATTR_TYPE_CSP_VOLUME_CURVE,
    ///< Common attribut max
    E_MI_AOUT_ATTR_TYPE_COMMON_MAX,
    ///< Sound effect attribut min
    E_MI_AOUT_ATTR_TYPE_SND_MIN         = 0x1000,
    ///< Bypass soundeffect module ,parameter type is a pointer to MI_BOOL.
    E_MI_AOUT_ATTR_TYPE_SND_BYPASS      = E_MI_AOUT_ATTR_TYPE_SND_MIN,
    ///< Set the basic sound effect, parameter type is a pointer to MI_AOUT_BasicSndParams_t.
    ///< Get the basic sound effect, input paramter type is a pointer to MI_AOUT_BasicSndType_e, output paramter is a pointer to MI_AOUT_BasicSndParams_t.
    E_MI_AOUT_ATTR_TYPE_BASIC_SND,
    ///< Set the advanced sound effect enable or diable, parameter type is a pointer to MI_AOUT_AdvSndEnableParams_t.
    E_MI_AOUT_ATTR_TYPE_ADV_SND_ENABLE,
    ///< Set the advanced sound effect diable, parameter type is a pointer to MI_AOUT_AdvSndEnableParams_t.
    E_MI_AOUT_ATTR_TYPE_ADV_SND_DISABLE,
    ///< Set the advanced sound effect, parameter type is a pointer to MI_AOUT_AdvSndParams_t.
    ///< Get the advanced sound effect, intput parameter type is a pointer to MI_AOUT_AdvSndType_e, output paramter type is a pointer to MI_AOUT_AdvSndParams_t.
    E_MI_AOUT_ATTR_TYPE_ADV_SND,
    ///< Gets the maximum spectrum value of each band currently playing, input parameter type is a pointer to MI_U32(BandNum), output parameter type is a pointer to MI_AOUT_SpectrumParams_t.
    E_MI_AOUT_ATTR_TYPE_SND_SPECTRUM,
    ///< Sound effect attribut max
    E_MI_AOUT_ATTR_TYPE_SND_MAX,
    ///< Digital output attribut min
    E_MI_AOUT_ATTR_TYPE_DIGITAL_MIN     = 0x1200,
    ///< Enable(/Disable) S/PDIF output (Hardware), parameter type is a pointer to MI_BOOL.
    E_MI_AOUT_ATTR_TYPE_SPDIF_HWCONFIG  = E_MI_AOUT_ATTR_TYPE_DIGITAL_MIN,
    ///< Spdif Serial Copy Management System, parameter type is a pointer to E_MI_AOUT_SpdifScmsMode_e.
    E_MI_AOUT_ATTR_TYPE_SPDIF_SCMS_MODE,
    ///< Set/Get HDMI device capability setting, parameter type is a pointer to MI_AOUT_HdmiCapabilityParams_t;
    E_MI_AOUT_ATTR_TYPE_HDMI_CAPABILITY,
    ///< Set Hdmi Tx monitor on/off, parameter type is a pointer to MI_BOOL;
    E_MI_AOUT_ATTR_TYPE_HDMI_TX_MONITOR,
    ///< Set Digital output force transcoding mode, parameter type is a pointer to MI_BOOL;
    E_MI_AOUT_ATTR_TYPE_FORCE_TRANSCODE_MODE,
    ///< Set HDMITx ARC Output, parameter type is a pointer to MI_BOOL;
    E_MI_AOUT_ATTR_TYPE_HDMI_TX_ARC,
    ///< Set the digital mode to be lock and thus it can not to be set to other digital modes, parameter type is a pointer to MI_BOOL;
    E_MI_AOUT_ATTR_TYPE_LOCK_DIGITAL_MODE,
    ///< Get always encode capability, output parameter type is a pointer to MI_AOUT_CodecTypeCapability_t;
    E_MI_AOUT_ATTR_TYPE_ALWAYS_ENCODE_FORMAT_CAPABILITY,
    ///< Get the latency of the ARC and Spdif encoder, parameter type is a pointer to MI_AOUT_EncoderPathLatency_t
    E_MI_AOUT_ATTR_TYPE_ENCODER_PATH_LATENCY,
    ///< Digital output attribut max
    E_MI_AOUT_ATTR_TYPE_DIGITAL_MAX,
    ///< Set to support mute in bypass mode for specific case, parameter type is a pointer to MI_BOOL;
    E_MI_AOUT_ATTR_TYPE_SUPPORT_MUTE_IN_BYPASS,
    ///< Attribut max
    E_MI_AOUT_ATTR_TYPE_MAX,
} MI_AOUT_AttrType_e;

typedef enum
{
    E_MI_AOUT_SRS_TSHD_TRUBASS,                     ///< TruSurround HD TruBass.
    E_MI_AOUT_SRS_TSHD_DIALOG_CLARITY,              ///< TruSurround HD Dialog Clarity.
    E_MI_AOUT_SRS_TSHD_DEFINITION,                  ///< TruSurround HD Definition.
    E_MI_AOUT_SRS_TSHD_SURROUND,                    ///< TruSurround HD Surround.
    E_MI_AOUT_SRS_TSHD_TRUBASS_LEVEL_INDEPENDENT,   ///< TruSurround HD TrueBass level independent

    E_MI_AOUT_SRS_TSHD_MAX,
} MI_AOUT_SrsTshdSubProcess_e;

typedef enum
{
    ///< DTS Theatre Sound main function Enable/Disable.
    E_MI_AOUT_SRS_THEATER_SND_ALL               = 0x0,
    ///< TruVolume Sub Process Min
    E_MI_AOUT_SRS_THEATER_SND_TRUVOLUME_HD_MIN,
    ///< TruVolume Enable/Disable.
    E_MI_AOUT_SRS_THEATER_SND_TRUVOLUME_HD      = E_MI_AOUT_SRS_THEATER_SND_TRUVOLUME_HD_MIN,
    ///< TruVolume Smooth..
    E_MI_AOUT_SRS_THEATER_SND_TRUVOLUME_HD_SMOOTH,
    ///< TruVolume Normalizer Enable/Disable.
    E_MI_AOUT_SRS_THEATER_SND_TRUVOLUME_HD_NORMALIZER,
    ///< TruVolume Sub Process Max
    E_MI_AOUT_SRS_THEATER_SND_TRUVOLUME_HD_MAX,
    ///< CC3D Sub Process Min
    E_MI_AOUT_SRS_THEATER_SND_CC3D_MIN          = 0x10,
    ///< CC3D processing Enable/Disable.
    E_MI_AOUT_SRS_THEATER_SND_CC3D              = E_MI_AOUT_SRS_THEATER_SND_CC3D_MIN,
    ///< Depth processing in CC3D Enable/Disable.
    E_MI_AOUT_SRS_THEATER_SND_CC3D_DEPTH_PROCESS,
    ///< CC3D 3D Surround Boost.
    E_MI_AOUT_SRS_THEATER_SND_CC3D_3D_SURROUND_BOOST,
    ///< CC3D TSHD Mix.
    E_MI_AOUT_SRS_THEATER_SND_CC3D_TSHD_MIX,
    ///< CC3D Fade.
    E_MI_AOUT_SRS_THEATER_SND_CC3D_FADE,
    ///< TruBass HDX low frequency compensation processing Enable/Disable.
    E_MI_AOUT_SRS_THEATER_SND_CC3D_TRUBASS_HDX,
    ///< CC3D Sub Process Max
    E_MI_AOUT_SRS_THEATER_SND_CC3D_MAX,
    ///< Theatre Sound common sub process min
    E_MI_AOUT_SRS_THEATER_SND_COMMON_MIN        = 0x20,
    ///< TruSurround HD.
    E_MI_AOUT_SRS_THEATER_SND_TSHD              = E_MI_AOUT_SRS_THEATER_SND_COMMON_MIN,
    ///< Graphic EQ Enable/Disable.
    E_MI_AOUT_SRS_THEATER_SND_GEQ,
    ///< TruDialog Enable/Disable.
    E_MI_AOUT_SRS_THEATER_SND_TRUDIALOG,
    ///< CS decoder.
    E_MI_AOUT_SRS_THEATER_SND_CS,
    ///< Theatre Sound common sub process max
    E_MI_AOUT_SRS_THEATER_SND_COMMON_MAX,
    ///< Theatre Sound sub process max
    E_MI_AOUT_SRS_THEATER_SND_MAX,
} MI_AOUT_SrsTheaterSndSubProcess_e;

typedef enum
{
    /// headphone detection event, pEventParam is pointer to MI_BOOL(True: plug-out to plug in, False: plug-in to plug-out)
    E_MI_AOUT_EVENT_HEADPHONE_DETECTION = MI_BIT(0),
} MI_AOUT_CallbackEvent_e;

typedef enum
{
    E_MI_AOUT_SRS_PURE_SND_HARD_LIMITER,     ///< Puresnd HardLimiter Enable/Disable.
    E_MI_AOUT_SRS_PURE_SND_ACTIVE_EQ,        ///< Puresnd Active EQ Enable/Disable.
    E_MI_AOUT_SRS_PURE_SND_HPF,              ///< Puresnd HPF Enable/Disable.
    E_MI_AOUT_SRS_PURE_SND_TRUBASS_HD,

    E_MI_AOUT_SRS_PURE_SND_MAX,
} MI_AOUT_SrsPureSndSubProcess_e;

typedef enum
{
    E_MI_AOUT_DAP_ALL,          ///< DAP
    E_MI_AOUT_DAP_ATMOS,        ///< DAP ATMOS.

    E_MI_AOUT_DAP_MAX,
} MI_AOUT_DapSubProcess_e;

typedef enum
{
    E_MI_AOUT_DTS_VIRTUALX_SND_TRUSRNDX,        ///< TrueSurround X
    E_MI_AOUT_DTS_VIRTUALX_SND_TBHDX,           ///< TruBass HDX
    E_MI_AOUT_DTS_VIRTUALX_SND_MBHL,            ///< MultiBand HardLimiter
    E_MI_AOUT_DTS_VIRTUALX_SND_TRUVOLUMEHD,     ///< TruVolume HD

    E_MI_AOUT_DTS_VIRTUALX_MAX,
} MI_AOUT_DtsVirtualXSubProcess_e;

typedef enum
{
    E_MI_AOUT_DTS_SS_II_SND_TRUSRNDX,           ///< TrueSurround X
    E_MI_AOUT_DTS_SS_II_SND_TBHDX,              ///< TruBass HDX
    E_MI_AOUT_DTS_SS_II_SND_MBHL,               ///< MultiBand HardLimiter
    E_MI_AOUT_DTS_SS_II_SND_TRUVOLUMEHD,        ///< TruVolume HD

    E_MI_AOUT_DTS_SS_II_MAX,
} MI_AOUT_DtsSsIiSubProcess_e;

typedef enum
{
    E_MI_AOUT_SONIC_EMOTION_SND_DIALOG_ENHANCEMENT,    // Dialog Enhancement
    E_MI_AOUT_SONIC_EMOTION_SND_BASS_ENHANCEMENT,      // Bass Enhancement
    E_MI_AOUT_SONIC_EMOTION_SND_ABSOLUTE_3D_SOUND,     // Absolute 3D Sound

    E_MI_AOUT_SONIC_EMOTION_MAX,
} MI_AOUT_SonicEmotionSubProcess_e;

typedef enum
{
    E_MI_AOUT_ADV_SND_PARAM_DOLBY_VOLUME_LEVELER_AMOUNT,    //Dolby Volume leveler amount.
    E_MI_AOUT_ADV_SND_PARAM_DOLBY_VOLUME_MAX,
} MI_AOUT_AdvSndParamDolbyVolumeType_e;

//-------------------------------------------------------------------------------------------------DTS TSHD
typedef enum
{
    E_MI_AOUT_ADV_SND_PARAM_SRS_TSHD_MAIN_MIN                 = 0x00, ///<Main Control
    E_MI_AOUT_ADV_SND_PARAM_SRS_TSHD_INPUT_MODE,
    E_MI_AOUT_ADV_SND_PARAM_SRS_TSHD_OUTPUT_MODE,
    E_MI_AOUT_ADV_SND_PARAM_SRS_TSHD_INPUT_GAIN,                         ///<Trusurround input gain. Input Gain. Adjusts the level of the signal at the input to TSHD processing.
    E_MI_AOUT_ADV_SND_PARAM_SRS_TSHD_OUTPUT_GAIN,                        ///<Trusurround output gain. Output Gain. Adjusts the level of the signal at the output to TSHD processing.
    E_MI_AOUT_ADV_SND_PARAM_SRS_TSHD_BYPASS_GAIN,
    E_MI_AOUT_ADV_SND_PARAM_SRS_TSHD_SPEAKER_SIZE,
    E_MI_AOUT_ADV_SND_PARAM_SRS_TSHD_LIMITER_CONTROL,
    E_MI_AOUT_ADV_SND_PARAM_SRS_TSHD_SURROUND_LEVEL_CONTROL,            ///<Trusurround surround level. Surround Level. Controls the overall mix level of the surround channels.
    E_MI_AOUT_ADV_SND_PARAM_SRS_TSHD_MAIN_MAX,

    E_MI_AOUT_ADV_SND_PARAM_SRS_TSHD_TRUBASS_MIN              = 0x10,
    E_MI_AOUT_ADV_SND_PARAM_SRS_TSHD_TRUBASS_CONTROL,                   ///<Trubass HD front level control.
    E_MI_AOUT_ADV_SND_PARAM_SRS_TSHD_TRUBASS_SPEAKER_SIZE,
    E_MI_AOUT_ADV_SND_PARAM_SRS_TSHD_TRUBASS_COMPRESSOR_CONTROL,
    E_MI_AOUT_ADV_SND_PARAM_SRS_TSHD_TRUBASS_PROCESS_MODE,
    E_MI_AOUT_ADV_SND_PARAM_SRS_TSHD_TRUBASS_SPEAKER_AUDIO,
    E_MI_AOUT_ADV_SND_PARAM_SRS_TSHD_TRUBASS_SPEAKER_ANALYSIS,
    E_MI_AOUT_ADV_SND_PARAM_SRS_TSHD_TRUBASS_MAX,

    E_MI_AOUT_ADV_SND_PARAM_SRS_TSHD_DEFINITION_MIN           = 0x20,
    E_MI_AOUT_ADV_SND_PARAM_SRS_TSHD_DEFINITION_CONTROL,                ///<Trusurround definition control. Definition Level. Controls the level of high frequency enhancement.
    E_MI_AOUT_ADV_SND_PARAM_SRS_TSHD_DEFINITION_MAX,

    E_MI_AOUT_ADV_SND_PARAM_SRS_TSHD_DIALOG_CLARITY_MIN       = 0x30,
    E_MI_AOUT_ADV_SND_PARAM_SRS_TSHD_DIALOG_CLARITY_CONTROL,            ///<Trusurround dialog clarity control. Dialog Clarity Level. Establishes the amount of dialog clarity enhancement that is applied to the audio signal.
    E_MI_AOUT_ADV_SND_PARAM_SRS_TSHD_DIALOG_CLARITY_MAX,

    E_MI_AOUT_ADV_SND_PARAM_SRS_TSHD_MAX,
} MI_AOUT_AdvSndParamSrsTshdType_e;

//-------------------------------------------------------------------------------------------------DTS Pure Sound
typedef enum
{
    E_MI_AOUT_ADV_SND_PARAM_SRS_PURE_SND_MAIN_MIN                        = 0x00,///< Main Control
    E_MI_AOUT_ADV_SND_PARAM_SRS_PURE_SND_INPUT_GAIN,
    E_MI_AOUT_ADV_SND_PARAM_SRS_PURE_SND_OUTPUT_GAIN,
    E_MI_AOUT_ADV_SND_PARAM_SRS_PURE_SND_BYPASS_GAIN,
    E_MI_AOUT_ADV_SND_PARAM_SRS_PURE_SND_MAIN_MAX,

    E_MI_AOUT_ADV_SND_PARAM_SRS_PURE_SND_HARD_LIMITER_MIN                = 0x10,///< Hard Limiter
    E_MI_AOUT_ADV_SND_PARAM_SRS_PURE_SND_HARD_LIMITER_INPUT_GAIN,                 ///<Adjust the value used for adjusting the audio level before the HardLimiter process.
    E_MI_AOUT_ADV_SND_PARAM_SRS_PURE_SND_HARD_LIMITER_OUTPUT_GAIN,                ///<Adjust the value used for adjusting the audio level after the HardLimiter process.
    E_MI_AOUT_ADV_SND_PARAM_SRS_PURE_SND_HARD_LIMITER_BYPASS_GAIN,                ///<Adjust the value used for adjusting the audio level when disable the HardLimiter process.
    E_MI_AOUT_ADV_SND_PARAM_SRS_PURE_SND_HARD_LIMITER_LIMITER_BOOST_GAIN,         ///<Modifies the signal level within the context of the HardLimter, so that the signal will not exceed the HardLimit level paramter.
    E_MI_AOUT_ADV_SND_PARAM_SRS_PURE_SND_HARD_LIMITER_LIMITER_CONTROL,            ///<HardLimiter limit level.
    E_MI_AOUT_ADV_SND_PARAM_SRS_PURE_SND_HARD_LIMITER_DELAY_LENGTH,               ///<Specifies the length of the look-ahead delay line utilized in the HardLimiter algorithm
    E_MI_AOUT_ADV_SND_PARAM_SRS_PURE_SND_HARD_LIMITER_MAX,

    E_MI_AOUT_ADV_SND_PARAM_SRS_PURE_SND_ACTIVE_EQ_MIN                   = 0x20,///<Active EQ
    E_MI_AOUT_ADV_SND_PARAM_SRS_PURE_SND_ACTIVE_EQ_INPUT_GAIN,                    ///<Adjust the value used for adjusting the audio level before the AEQ process.
    E_MI_AOUT_ADV_SND_PARAM_SRS_PURE_SND_ACTIVE_EQ_OUTPUT_GAIN,                   ///<Adjust the value used for adjusting the audio level after the AEQ process.
    E_MI_AOUT_ADV_SND_PARAM_SRS_PURE_SND_ACTIVE_EQ_BYPASS_GAIN,                   ///<Adjust the value used for adjusting the audio level when disable the AEQ process.
    E_MI_AOUT_ADV_SND_PARAM_SRS_PURE_SND_ACTIVE_EQ_MAX,

    E_MI_AOUT_ADV_SND_PARAM_SRS_PURE_SND_TRUBASS_HD_MIN                  = 0x30,///<TruBass HD
    E_MI_AOUT_ADV_SND_PARAM_SRS_PURE_SND_TRUBASS_HD_CONTROL_LEVEL,
    E_MI_AOUT_ADV_SND_PARAM_SRS_PURE_SND_TRUBASS_HD_SPEAKER_SIZE,
    E_MI_AOUT_ADV_SND_PARAM_SRS_PURE_SND_TRUBASS_HD_SPEAKER_AUDIO,
    E_MI_AOUT_ADV_SND_PARAM_SRS_PURE_SND_TRUBASS_HD_SPEAKER_ANALYSIS,
    E_MI_AOUT_ADV_SND_PARAM_SRS_PURE_SND_TRUBASS_HD_COMPRESSOR_CONTROL,
    E_MI_AOUT_ADV_SND_PARAM_SRS_PURE_SND_TRUBASS_HD_LEVEL_INDEPENDENT_ENABLE,
    E_MI_AOUT_ADV_SND_PARAM_SRS_PURE_SND_TRUBASS_HD_MAX,

    E_MI_AOUT_ADV_SND_PARAM_SRS_PURE_SND_HPF_MIN                         = 0x40,///<HPF
    E_MI_AOUT_ADV_SND_PARAM_SRS_PURE_SND_HPF_FREQUENCY,
    E_MI_AOUT_ADV_SND_PARAM_SRS_PURE_SND_HPF_MAX,

   E_MI_AOUT_ADV_SND_PARAM_SRS_PURE_SND_MAX,
} MI_AOUT_AdvSndParamSrsPureSndType_e;

//-------------------------------------------------------------------------------------------------DTS Theater Sound
typedef enum
{
    E_MI_AOUT_ADV_SND_PARAM_SRS_THEATER_SND_MAIN_MIN                   = 0x000, ///<Main Control
    E_MI_AOUT_ADV_SND_PARAM_SRS_THEATER_SND_INPUT_GAIN,
    E_MI_AOUT_ADV_SND_PARAM_SRS_THEATER_SND_OUTPUT_GAIN,
    E_MI_AOUT_ADV_SND_PARAM_SRS_THEATER_SND_BYPASS_GAIN,                         ///<Main contorl. Adjusts the signal level when TheaterSound processing is tuned off.
    E_MI_AOUT_ADV_SND_PARAM_SRS_THEATER_SND_HEADROOM_GAIN,                       ///<Main contorl. Provides headroom for intermediate calculations so as to avoid clipping.
    E_MI_AOUT_ADV_SND_PARAM_SRS_THEATER_SND_INPUT_MODE,
    E_MI_AOUT_ADV_SND_PARAM_SRS_THEATER_SND_CC3D_PROCESS_PATH,                   ///<Main contorl. Select the processing path in CC3D,0:none 1: path0 2:path1
    E_MI_AOUT_ADV_SND_PARAM_SRS_THEATER_SND_MAIN_MAX,

    E_MI_AOUT_ADV_SND_PARAM_SRS_THEATER_SND_TRUVOLUME_HD_MIN           = 0x10, ///<TruVolume HD
    E_MI_AOUT_ADV_SND_PARAM_SRS_THEATER_SND_TRUVOLUME_HD_INPUT_GAIN,
    E_MI_AOUT_ADV_SND_PARAM_SRS_THEATER_SND_TRUVOLUME_HD_OUT_GAIN,
    E_MI_AOUT_ADV_SND_PARAM_SRS_THEATER_SND_TRUVOLUME_HD_BYPASS_GAIN,
    E_MI_AOUT_ADV_SND_PARAM_SRS_THEATER_SND_TRUVOLUME_HD_MODE,                   ///<TruVolume HD Mode 0:light  1:normal.
    E_MI_AOUT_ADV_SND_PARAM_SRS_THEATER_SND_TRUVOLUME_HD_REFERENCE_LEVEL,        ///<LKFS.Sets the desired absolute loudness level of the signal.
    E_MI_AOUT_ADV_SND_PARAM_SRS_THEATER_SND_TRUVOLUME_HD_MAX_GAIN,               ///<Controls the maximum amount that the signal may be increased.
    E_MI_AOUT_ADV_SND_PARAM_SRS_THEATER_SND_TRUVOLUME_HD_NORMALIZE_THRESHOLD,    ///<Determines if the gain boost value is greater than 1 or not.
    E_MI_AOUT_ADV_SND_PARAM_SRS_THEATER_SND_TRUVOLUME_HD_MAX,

    E_MI_AOUT_ADV_SND_PARAM_SRS_THEATER_SND_CS_MIN                     = 0x20, ///<CS
    E_MI_AOUT_ADV_SND_PARAM_SRS_THEATER_SND_CS_INPUT_GAIN,                       ///<Adjust the level of the signal at the input to CS Decoder.
    E_MI_AOUT_ADV_SND_PARAM_SRS_THEATER_SND_CS_PROCESS_MODE,                     ///<Specifies the format of the source material. 0:cinema 1:music
    E_MI_AOUT_ADV_SND_PARAM_SRS_THEATER_SND_CS_LR_OUTPUT_GAIN,                   ///<Control the output level of the front channel of CS Decoder
    E_MI_AOUT_ADV_SND_PARAM_SRS_THEATER_SND_CS_LSRS_OUTPUT_GAIN,                 ///<Control the output level of the surround channel of CS Decoder
    E_MI_AOUT_ADV_SND_PARAM_SRS_THEATER_SND_CS_CENTER_OUTPUT_GAIN,               ///<Control the output level of the center channel of CS Decoder
    E_MI_AOUT_ADV_SND_PARAM_SRS_THEATER_SND_CS_MAX,

    E_MI_AOUT_ADV_SND_PARAM_SRS_THEATER_SND_TRUDIALOG_MIN              = 0x30, ///<TruDialog
    E_MI_AOUT_ADV_SND_PARAM_SRS_THEATER_SND_TRUDIALOG_INPUT_GAIN,                ///<Adjusts the level of the signal at the input.
    E_MI_AOUT_ADV_SND_PARAM_SRS_THEATER_SND_TRUDIALOG_OUTPUT_GAIN,
    E_MI_AOUT_ADV_SND_PARAM_SRS_THEATER_SND_TRUDIALOG_BYPASS_GAIN,
    E_MI_AOUT_ADV_SND_PARAM_SRS_THEATER_SND_TRUDIALOG_PROCESS_GAIN,              ///<Controls how much of he calculated final output gain is applied to the output singnal.
    E_MI_AOUT_ADV_SND_PARAM_SRS_THEATER_SND_TRUDIALOG_CLARITY_GAIN,              ///<Adjusts the amount of vocal enhancement that is applied to the audio signal.
    E_MI_AOUT_ADV_SND_PARAM_SRS_THEATER_SND_TRUDIALOG_MAX,

    E_MI_AOUT_ADV_SND_PARAM_SRS_THEATER_SND_CC3D_MIN                   = 0x40, ///<CC3D
    E_MI_AOUT_ADV_SND_PARAM_SRS_THEATER_SND_CC3D_INPUT_GAIN,                     ///<Adjust the level of the signal at the input to CC3D processing.
    E_MI_AOUT_ADV_SND_PARAM_SRS_THEATER_SND_CC3D_OUTPUT_GAIN,
    E_MI_AOUT_ADV_SND_PARAM_SRS_THEATER_SND_CC3D_BYPASS_GAIN,
    E_MI_AOUT_ADV_SND_PARAM_SRS_THEATER_SND_CC3D_APERTURE,
    E_MI_AOUT_ADV_SND_PARAM_SRS_THEATER_SND_CC3D_GAIN_LIMIT,
    E_MI_AOUT_ADV_SND_PARAM_SRS_THEATER_SND_CC3D_FF_DEPTH,
    E_MI_AOUT_ADV_SND_PARAM_SRS_THEATER_SND_CC3D_NF_DEPTH,
    E_MI_AOUT_ADV_SND_PARAM_SRS_THEATER_SND_CC3D_TSHD_SURROUND_MODE,
    E_MI_AOUT_ADV_SND_PARAM_SRS_THEATER_SND_CC3D_TSHD_MIX_FADE_CTRL,
    E_MI_AOUT_ADV_SND_PARAM_SRS_THEATER_SND_CC3D_MAX,

    E_MI_AOUT_ADV_SND_PARAM_SRS_THEATER_SND_CC3D_TBHDX_MIN              = 0x50,//<TruBass HDX
    E_MI_AOUT_ADV_SND_PARAM_SRS_THEATER_SND_CC3D_TBHDX_INPUT_GAIN,               ///<Adjust the level of the signal at the input to TruBass HDX processing.
    E_MI_AOUT_ADV_SND_PARAM_SRS_THEATER_SND_CC3D_TBHDX_BASS_LEVEL,               ///<Determines the level of psychoacoustic bass enhancement.
    E_MI_AOUT_ADV_SND_PARAM_SRS_THEATER_SND_CC3D_TBHDX_SPEAKER_SIZE,             ///<The range of low frequency limitations in the speakers that TruBass HDX is compensating for.
    E_MI_AOUT_ADV_SND_PARAM_SRS_THEATER_SND_CC3D_TBHDX_MODE,                     ///<Determines if the left and right signals are summed and processed then sent to both channels or if the left and right channels are processed by TruBass HDX separetely.0 mono 1:stereo.
    E_MI_AOUT_ADV_SND_PARAM_SRS_THEATER_SND_CC3D_TBHDX_DYNAMICS,                 ///<Modifies the amount of dynamics processing applied to the signal.The ratio/range of the compressor is dynamically adjusted as the incoming signal is monitored.
    E_MI_AOUT_ADV_SND_PARAM_SRS_THEATER_SND_CC3D_TBHDX_HIGH_PASS_ORDER,          ///<The slope of the filter that removes the low frequencies that cannot be replicated by the speaker is adjusted with this control.
    E_MI_AOUT_ADV_SND_PARAM_SRS_THEATER_SND_CC3D_TBHDX_CUSTOM_FILTER,
    E_MI_AOUT_ADV_SND_PARAM_SRS_THEATER_SND_CC3D_TBHDX_MAX,

    E_MI_AOUT_ADV_SND_PARAM_SRS_THEATER_SND_GEQ_MIN                     = 0x60,///<GEQ
    E_MI_AOUT_ADV_SND_PARAM_SRS_THEATER_SND_GEQ_INPUT_GAIN,                      ///<Adjust the level of the signal at the input to Graphic EQ processing.
    E_MI_AOUT_ADV_SND_PARAM_SRS_THEATER_SND_GEQ_BAND0_GAIN,                      ///<Adjust the gain for band 0.
    E_MI_AOUT_ADV_SND_PARAM_SRS_THEATER_SND_GEQ_BAND1_GAIN,                      ///<Adjust the gain for band 1.
    E_MI_AOUT_ADV_SND_PARAM_SRS_THEATER_SND_GEQ_BAND2_GAIN,                      ///<Adjust the gain for band 2.
    E_MI_AOUT_ADV_SND_PARAM_SRS_THEATER_SND_GEQ_BAND3_GAIN,                      ///<Adjust the gain for band 3.
    E_MI_AOUT_ADV_SND_PARAM_SRS_THEATER_SND_GEQ_BAND4_GAIN,                      ///<Adjust the gain for band 4.
    E_MI_AOUT_ADV_SND_PARAM_SRS_THEATER_SND_GEQ_MAX,

    E_MI_AOUT_ADV_SND_PARAM_SRS_THEATER_SND_MAX,

} MI_AOUT_AdvSndParamSrsTheaterSndType_e;

//------------------------------------------------------------------------------------------------- DBX
// DBX Total Sonics modes
typedef enum
{
    E_MI_AOUT_DBX_TOTAL_SONIC_ON        = 0,
    E_MI_AOUT_DBX_TOTAL_SONIC_OFF,
} MI_AOUT_DbxTotalSonicMode_e;

//DBX Total Volume modes
typedef enum
{
    E_MI_AOUT_DBX_TOTAL_VOLUME_NORMAL    = 0,
    E_MI_AOUT_DBX_TOTAL_VOLUME_NIGHT,
    E_MI_AOUT_DBX_TOTAL_VOLUME_OFF,
} MI_AOUT_DbxTotalVolumeMode_e;

//DBX Total Surround modes
typedef enum
{
    E_MI_AOUT_DBX_TOTAL_SURROUND_ON        = 0,
    E_MI_AOUT_DBX_TOTAL_SURROUND_OFF,
} MI_AOUT_DbxTotalSurroundMode_e;

typedef enum
{
    E_MI_AOUT_CHANNEL_MAPPING_NONE = 0x00,                  ///< No channel is mapping.
    E_MI_AOUT_CHANNEL_MAPPING_FRONT_LEFT = MI_BIT(0),       ///< Front left channel. Left channel in stereo.
    E_MI_AOUT_CHANNEL_MAPPING_FRONT_RIGHT  = MI_BIT(1),     ///< Front right channel. Right channel in stereo.
    E_MI_AOUT_CHANNEL_MAPPING_FRONT_CENTER = MI_BIT(2),     ///< Front center channel.
    E_MI_AOUT_CHANNEL_MAPPING_LOW_FREQUENCY = MI_BIT(3),    ///< Low frequency channel.
    E_MI_AOUT_CHANNEL_MAPPING_BACK_LEFT  = MI_BIT(4),       ///< Back left channel.
    E_MI_AOUT_CHANNEL_MAPPING_BACK_RIGHT  = MI_BIT(5),      ///< Back right channel.
    E_MI_AOUT_CHANNEL_MAPPING_BACK_CENTER = MI_BIT(6),      ///< Back center channel.
    E_MI_AOUT_CHANNEL_MAPPING_SIDE_LEFT = MI_BIT(7),        ///< Side left channel.
    E_MI_AOUT_CHANNEL_MAPPING_SIDE_RIGHT = MI_BIT(8),       ///< Side right channel.
    E_MI_AOUT_CHANNEL_MAPPING_TOP_FRONT_LEFT = MI_BIT(9),   ///< Top front left channel.
    E_MI_AOUT_CHANNEL_MAPPING_TOP_FRONT_RIGHT = MI_BIT(10), ///< Top front right channel.
    E_MI_AOUT_CHANNEL_MAPPING_TOP_BACK_LEFT = MI_BIT(11),   ///< Top back left channel.
    E_MI_AOUT_CHANNEL_MAPPING_TOP_BACK_RIGHT = MI_BIT(12),  ///< Top back right channel.
} MI_AOUT_ChannelMappingType_e;

//-------------------------------------------------------------------------------------------------Basic Sound Effect
typedef struct MI_AOUT_BasicSndPreScaleParams_s
{
    MI_U16    u16PreScale;      ///< [IN]: PreScale the Volume. Range from 0x01 to 0xFF , gain: -13.75db to +18db (0.125 db per step). 0 is disabled.
}MI_AOUT_BasicSndPreScaleParams_t;

typedef struct MI_AOUT_BasicSndEqParams_s
{
    MI_U8     u8BandNum;                        ///< [IN]: the quantity of band.
    MI_U16    au16Level[MI_AOUT_EQ_BAND_MAX];   ///< [IN]: level array,max is 5.
}MI_AOUT_BasicSndEqParams_t;

typedef struct MI_AOUT_BasicSndPeqParams_s
{
    MI_U8     u8BandNum;                           ///< [IN]: The quantity of band.
    MI_U16    au16Gain[MI_AOUT_PEQ_BAND_MAX];      ///< [IN]: Set the gain of peq.
    MI_U16    au16Frequency[MI_AOUT_PEQ_BAND_MAX]; ///< [IN]: center-frequency.
    MI_U16    au16Qvalue[MI_AOUT_PEQ_BAND_MAX];    ///< [IN]: u16Qvalue value lead to Narrower band-width, and vice versa.
}MI_AOUT_BasicSndPeqParams_t;

typedef struct MI_AOUT_BasicSndTrebleParams_s
{
    MI_U16    u16Level;                           ///< [IN]: Level for basic sound treble.
}MI_AOUT_BasicSndTrebleParams_t;

typedef struct MI_AOUT_BasicSndBassParams_s
{
    MI_U16    u16Level;                           ///< [IN]: Level for basic sound bass.
}MI_AOUT_BasicSndBassParams_t;

typedef struct MI_AOUT_BasicSndAvcParams_s
{
    MI_U16    u16Threshold;                         ///< [IN]: Threshold of AVC.
    MI_U16    u16AttachTime;                        ///< [IN]: Attach time.
    MI_U16    u16ReleaseTime;                       ///< [IN]: Release time.
}MI_AOUT_BasicSndAvcParams_t;

typedef struct MI_AOUT_BasicSndSurroundParams_s
{
    MI_U16    u16Xa;                              ///< [IN]: Xa is a param of Mstar Surround.
    MI_U16    u16Xb;                              ///< [IN]: Xb is a param of Mstar Surround.
    MI_U16    u16Xk;                              ///< [IN]: Xk is a param of Mstar Surround.
    MI_U16    u16LpfGain;                         ///< [IN]: Gain of low pass filter.
}MI_AOUT_BasicSndSurroundParams_t;

typedef struct MI_AOUT_BasicSndBalanceParams_s
{
    MI_U16    u16Balance;                         ///< [IN]: Balance is used to balance the output Level of left/right channel.
}MI_AOUT_BasicSndBalanceParams_t;

typedef struct MI_AOUT_BasicSndDrcParams_s
{
    MI_U16    u16Threshold;                       ///< [IN]: u16Threshold is used to clipping output level.
}MI_AOUT_BasicSndDrcParams_t;

typedef struct MI_AOUT_BasicSndEchoParams_s
{
    MI_U16    u16Time;                            ///< [IN]: u16Time is the time of echo.
}MI_AOUT_BasicSndEchoParams_t;

typedef struct MI_AOUT_BasicSndNrParams_s
{
    MI_U16    u16Threshold;                       ///< [IN]: The threshold of Noise Reduction.
}MI_AOUT_BasicSndNrParams_t;

typedef struct MI_AOUT_BasicSndHpfParams_s
{
    MI_BOOL    bEnable;                           ///< [IN]: bEnable is used to open or close high pass filter.
}MI_AOUT_BasicSndHpfParams_t;

typedef struct MI_AOUT_BasicSndLimiterParams_s
{
    MI_AOUT_LimiterMode_e eLimiterMode;           ///< [IN]: limiter mode (0:peak mode, 1:RMS mode)
    MI_U32 u32Threshold;                          ///< [IN]: limiter threshold (0 ~ 0x7ffff)
}MI_AOUT_BasicSndLimiterParams_t;

typedef struct MI_AOUT_BasicSndAbsoluteEqParams_s
{
    MI_U8 u8BandNum;                            ///< [IN]: The quantity of band.
    MI_S8 as8AbsoluteDb[MI_AOUT_EQ_BAND_MAX];   ///< [IN]: 0xD0 ~ 0x30 mapping to +12 ~ -12 dB.
}MI_AOUT_BasicSndAbsoluteEqParams_t;

typedef struct MI_AOUT_SpectrumParams_s
{
    MI_U32 u32BandNum;                            ///< [OUT]: The u32BandNum is the array num of pu32BandValue.(range: 1 ~ 15)
    MI_U32 *pu32BandValue;                        ///< [OUT]: A pointer to an array. It is used to store each spectrum value. (pu32BandValue[u32BandNum])
}MI_AOUT_SpectrumParams_t;

typedef struct MI_AOUT_BasicSndParams_s
{
    MI_AOUT_BasicSndType_e eBasicSndType;                   ///< [IN]: The type of sound effect,both used in get and set.
    MI_BOOL bEnable;                                        ///< [IN]: bEnable is used to open or close the appointed sound effect.

    union{
        MI_AOUT_BasicSndPreScaleParams_t     stPreScaleParams;      ///< [IN]: Structure member for basic sounc effect-PreScale.
        MI_AOUT_BasicSndEqParams_t           stEqParams;            ///< [IN]: Structure member for basic sounc effect-Eq.
        MI_AOUT_BasicSndPeqParams_t          stPeqParams;           ///< [IN]: Structure member for basic sounc effect-Peq.
        MI_AOUT_BasicSndTrebleParams_t       stTrebleParams;        ///< [IN]: Structure member for basic sounc effect-Treble.
        MI_AOUT_BasicSndBassParams_t         stBassParams;          ///< [IN]: Structure member for basic sounc effect-Bass.
        MI_AOUT_BasicSndAvcParams_t          stAvcParams;           ///< [IN]: Structure member for basic sounc effect-AVC.
        MI_AOUT_BasicSndSurroundParams_t     stSurroundParams;      ///< [IN]: Structure member for basic sounc effect-Surround.
        MI_AOUT_BasicSndBalanceParams_t      stBalanceParams;       ///< [IN]: Structure member for basic sounc effect-Balance.
        MI_AOUT_BasicSndDrcParams_t          stDrcParams;           ///< [IN]: Structure member for basic sounc effect-DRC.
        MI_AOUT_BasicSndEchoParams_t         stEchoParams;          ///< [IN]: Structure member for basic sounc effect-Echo.
        MI_AOUT_BasicSndNrParams_t           stNrParams;            ///< [IN]: Structure member for basic sounc effect-NR.
        MI_AOUT_BasicSndHpfParams_t          stHpfParams;           ///< [IN]: Structure member for basic sounc effect-Hpf.
        MI_AOUT_BasicSndLimiterParams_t      stLimiterParams;       ///< [IN]: Structure member for basic sounc effect-Limiter.
        MI_AOUT_BasicSndAbsoluteEqParams_t   stAbsoluteEqParams;    ///< [IN]: Structure member for basic sounc effect-Absolute Eq.
    } attr;
}MI_AOUT_BasicSndParams_t;

typedef struct MI_AOUT_CspVolCurveParams_s
{
    MI_U8 *pszCspName;                /// [In]: Csp Ini file key to be read.
    MI_BOOL bEnable;                  /// [In]: Enable Csp volume curve setting
} MI_AOUT_CspVolCurveParams_t;

typedef struct MI_AOUT_VolumeConfig_s
{
    MI_BOOL bUseCusVolTbl;            ///< [IN]: Use volume table made by customer or not.
    MI_U16 *pu16VolTbl;               ///< [IN]: Volume table.
} MI_AOUT_VolumeConfig_t;

typedef struct MI_AOUT_VolumeDb_s
{
   MI_S32      s32Integer;          ///< [IN]: Integer part of volume. Range from -114 to +12 dB for MI_AOUT_SetVolumeDb and range from -64 to 0 dB for MI_AOUT_SetChannelVolumeDb.
   MI_S32      s32Fraction;         ///< [IN]: Fractional part of volume. It means (s32Fraction / 1000) dB. e.g., 125 means 0.125dB. resolution is 0.125 dB for MI_AOUT_SetVolumeDb and 0.25 dB for MI_AOUT_SetChannelVolumeDb.
} MI_AOUT_VolumeDb_t;

typedef struct MI_AOUT_ChannelVolumeDbParams_s
{
    MI_AOUT_ChannelMappingType_e eChannelMappingType;   ///< [IN]: Channel to be set.
    MI_AOUT_VolumeDb_t stVolumeDb;                      ///< [IN]: Volume in unit dB.
} MI_AOUT_ChannelVolumeDbParams_t;

typedef struct MI_AOUT_InitParams_s
{
    MI_U8 u8Reserved;                  ///< [IN]: Reserved.
} MI_AOUT_InitParams_t;

typedef struct MI_AOUT_OpenParams_s
{
    MI_U8 * pszName;                               ///< [IN]: Custom defined module instance name which is a string with zero terminated.
    MI_AOUT_Path_e          ePath;                 ///< [IN]: Path information for open_function.
    MI_AOUT_VolumeConfig_t  stVolCfg;              ///< [IN]: Volume configure.
} MI_AOUT_OpenParams_t;

typedef struct MI_AOUT_Caps_s
{
    MI_U32  u32PcmMaxDelayTime;             ///< [OUT]: The max delay time of pcm.
    MI_U32  u32PcmMinDelayTime;             ///< [OUT]: The min delay time of pcm.
} MI_AOUT_Caps_t;

typedef struct MI_AOUT_EncoderPathLatency_s
{
    MI_U32  u32HdmiEncLatency;             ///< [OUT]: The latency of encode hdmi.
    MI_U32  u32SpdifEncLatency;            ///< [OUT]: The latency of encode spdif.
} MI_AOUT_EncoderPathLatency_t;

typedef struct MI_AOUT_QueryHandleParams_s
{
    MI_AOUT_Path_e ePath;                   ///< [IN]: Path information for function gethandle.
} MI_AOUT_QueryHandleParams_t;

typedef struct MI_AOUT_MuteParams_s
{
    MI_AOUT_MuteType_e eType;               ///< [IN]: Mute type.
    MI_BOOL bMute;                          ///< [IN]: To be mute or unmute.
} MI_AOUT_MuteParams_t;

typedef struct MI_AOUT_DigitalModeParams_s
{
    MI_AOUT_Path_e ePath;                   ///< [IN]: Path information.
    MI_AOUT_DigitalMode_e eDigitalMode;     ///< [IN]: Digital mode type.
    MI_AOUT_CodecType_e eCodecType;         ///< [IN]: Codec type.
    MI_U8 *pszName;                         ///< [IN]: Custom defined name which is a string with zero terminated.
} MI_AOUT_DigitalModeParams_t;

typedef struct MI_AOUT_ConnectInputParams_s
{
    MI_U8 u8Reserved;                       ///< [IN]: Reserved.
}MI_AOUT_ConnectInputParams_t;

typedef struct MI_AOUT_HdmiCapability_s
{
    MI_BOOL bSupport;                        ///< [OUT]: True is support ,False is not support
    MI_U8   u8SupportChannel;                ///< [OUT]: Short_Audio_Descriptor Byte1 [0:2]
    MI_U8   u8SupportSampleRate;             ///< [OUT]: Short_Audio_Descriptor Byte2 [0:6]
    MI_U8   u8SupportSadByte3;               ///< [OUT]: Short_Audio_Descriptor Byte3 [0:7]
} MI_AOUT_HdmiCapability_t;

typedef struct MI_AOUT_HdmiCapabilityParams_s
{
      MI_AOUT_Path_e            ePath;                  ///< [IN]: Path information.
      MI_AOUT_CodecType_e       eCodecType;             ///< [IN]: Audio codec type.
      MI_AOUT_HdmiCapability_t  stHdmiCapability;       ///< [OUT]: HDMI capability description.
}MI_AOUT_HdmiCapabilityParams_t;

typedef struct MI_AOUT_AdvSndEnableParams_s
{
    MI_AOUT_AdvSndType_e eAdvSndType;                   ///< [IN]: Advanced Sound effect type.Mutually exclusive advanced sound effect
}MI_AOUT_AdvSndEnableParams_t;

//-------------------------------------------------------------------------------------------------Advance Sound Effect
typedef struct MI_AOUT_AdvSndSrsTshdParams_s
{
    MI_BOOL abEnableSubProcess[E_MI_AOUT_SRS_TSHD_MAX];            ///< [IN]: This param is used open or close subprocess.
    MI_U32  au32Param[E_MI_AOUT_ADV_SND_PARAM_SRS_TSHD_MAX];
}MI_AOUT_AdvSndSrsTshdParams_t;

typedef struct MI_AOUT_AdvSndSrsTheaterSndParams_s
{
    MI_BOOL abEnableSubProcess[E_MI_AOUT_SRS_THEATER_SND_MAX];      ///< [IN]: This param is used open or close subprocess.
    MI_U32  au32Param[E_MI_AOUT_ADV_SND_PARAM_SRS_THEATER_SND_MAX];
}MI_AOUT_AdvSndSrsTheaterSndParams_t;

typedef struct MI_AOUT_AdvSndDbxCoefficient_s
{
    MI_U32 au32TotalSonicDm[MI_AOUT_DBX_DM_NUM];
    MI_U32 au32TotalSonicPm[MI_AOUT_DBX_PM_NUM];
    MI_U32 au32TotalVolumeDm[MI_AOUT_DBX_TOTAL_VOLUME_GROUP_NUM][MI_AOUT_DBX_DM_NUM];
    MI_U32 au32TotalVolumePm[MI_AOUT_DBX_TOTAL_VOLUME_GROUP_NUM][MI_AOUT_DBX_PM_NUM];
    MI_U32 au32TotalSurroundDm[MI_AOUT_DBX_DM_NUM];
    MI_U32 au32TotalSurroundPm[MI_AOUT_DBX_PM_NUM];
}MI_AOUT_AdvSndDbxCoefficient_t;

typedef struct MI_AOUT_AdvSndDbxParams_s
{
    MI_AOUT_DbxTotalSonicMode_e    eTotalSonicMode;
    MI_AOUT_DbxTotalVolumeMode_e   eTotalVolumeMode;
    MI_AOUT_DbxTotalSurroundMode_e eTotalSurroundMode;
    MI_AOUT_AdvSndDbxCoefficient_t *pstParams;
}MI_AOUT_AdvSndDbxParams_t;

typedef struct MI_AOUT_AdvSndSrsPureSndParams_s
{
    MI_BOOL abEnableSubProcess[E_MI_AOUT_SRS_PURE_SND_MAX];         ///< [IN]: This param is used to open or close subprocess.
    MI_U32  au32Param[E_MI_AOUT_ADV_SND_PARAM_SRS_PURE_SND_MAX];
}MI_AOUT_AdvSndSrsPureSndParams_t;

typedef struct MI_AOUT_AdvSndDolbyVolumeParams_s
{
    MI_U32  au32Param[E_MI_AOUT_ADV_SND_PARAM_DOLBY_VOLUME_MAX];    ///< [IN]: This param is used to set params.
}MI_AOUT_AdvSndDolbyVolumeParams_t;

//-------------------------------------------------------------------------------------------------DAP
typedef struct MI_AOUT_DapGainParams_s
{
    MI_S32 s32PreGain;                 // System Pregain - Value in [-2080, 480] (4 fractional bits: [-130.00 dB, 30.00 dB])
    MI_S32 s32PostGain;                // System Postgain - Value in [-2080, 480] (4 fractional bits: [-130.00 dB, 30.00 dB])
    MI_S32 s32SystemGain;              // System Gain - Value in [-2080, 480] (4 fractional bits: [-130.00 dB, 30.00 dB])
}MI_AOUT_DapGainParams_t;

typedef struct MI_AOUT_DapSurroundVirtualizerParams_s
{
    MI_U32 u32SurroundDecoderEnable;   // Surround Decoder Enable - Value is a boolean (0 or 1)
    MI_U32 u32VirtualizerEnable;       // Virtualizer Enable - Value is a boolean (0 or 1)
    MI_S32 s32HeadphoneReverb;         // Headphone Virtualizer Reverb Gain - Value in [-2080, 192] (4 fractional bits: [-130.00 dB, 12.00 dB])
    MI_U32 u32SpeakerAngle;            // Speaker Virtualizer Angle - Value is an integer in [5, 30] (unit is degrees)
    MI_U32 u32SpeakerStart;            // Speaker Virtualizer Start Frequency - Value is an integer in [20, 20000] (unit is Hz)
    MI_U32 u32SurroundBoost;           // Surround Boost - Value in [0, 96] (4 fractional bits: [0.00 dB, 6.00 dB])
}MI_AOUT_DapSurroundVirtualizerParams_t;

typedef struct MI_AOUT_DapMiParams_s
{
    MI_U32 u32MiIeqEnable;             // MI Intelligent Equalizer Steering Enable - Value is a boolean (0 or 1)
    MI_U32 u32MiDvEnable;              // MI Volume Leveler Steering Enable - Value is a boolean (0 or 1)
    MI_U32 u32MiDeEnable;              // MI Dialog Enhancer Steering Enable - Value is a boolean (0 or 1)
    MI_U32 u32MiSurroundEnable;        // MI Surround Compressor Steering Enable - Value is a boolean (0 or 1)
}MI_AOUT_DapMiParams_t;

typedef struct MI_AOUT_DapCalibrationBoost_s
{
    MI_U32 u32CalibrationBoost;        // Calibration Boost - Value in [0, 192] (4 fractional bits: [0.00 dB, 12.00 dB])
}MI_AOUT_DapCalibrationBoost_t;

typedef struct MI_AOUT_DapLeveLerParams_s
{
    MI_U32 u32LevelerAmount;           // Volume Leveler Amount - Value is an integer in [0, 10]
    MI_S32 s32LevelerInput;            // Volume Leveler In Target - Value in [-640, 0] (4 fractional bits: [-40.00 dBFS, 0.00 dBFS])
    MI_S32 s32LevelerOutput;           // Volume Leveler Out Target - Value in [-640, 0] (4 fractional bits: [-40.00 dBFS, 0.00 dBFS])
    MI_U32 u32LevelerEnable;           // Volume Leveler Enable - Value is a boolean (0 or 1)
}MI_AOUT_DapLeveLerParams_t;

typedef struct MI_AOUT_DapModelerParams_s
{
    MI_U32 u32ModelerEnable;           // Volume Modeler Enable - Value is a boolean (0 or 1)
    MI_S32 s32ModelerCalibration;      // Volume Modeler Calibration - Value in [-320, 320] (4 fractional bits: [-20.00 dB, 20.00 dB])
}MI_AOUT_DapModelerParams_t;

typedef struct MI_AOUT_DapIeqParams_s
{
    MI_U32 u32IeqEnable;                            // Intelligent Equalizer Enable - Value is a boolean (0 or 1)
    MI_U32 u32IeqAmount;                            // Intelligent Equalizer Amount - Value in [0, 16] (4 fractional bits: [0.00, 1.00])
    MI_U32 u32IeqNbBands;                           // Intelligent Equalizer Custom Bands Frequencies and Targets - Array of 1 to 20 (Value1, Value2) pairs
    MI_U32 au32IeqBandCenter[MI_AOUT_MAX_DAP_IEQ_BAND_NUM]; // Value1 is an integer in [20, 20000] (unit is Hz)
    MI_S32 as32IeqBandTarget[MI_AOUT_MAX_DAP_IEQ_BAND_NUM]; // Value2 in [-480, 480] (4 fractional bits: [-30.00 dB, 30.00 dB])
}MI_AOUT_DapIeqParams_t;

typedef struct MI_AOUT_DapDeParams_s
{
    MI_U32 u32DeEnable;                // Dialog Enhancer Enable - Value is a boolean (0 or 1)
    MI_U32 u32DeAmount;                // Dialog Enhancer Amount - Value in [0, 16] (4 fractional bits: [0.00, 1.00])
    MI_U32 u32DeDucking;               // Dialog Enhancer Ducking - Value in [0, 16] (4 fractional bits: [0.00, 1.00])
}MI_AOUT_DapDeParams_t;

typedef struct MI_AOUT_DapVolMaxBoost_s
{
    MI_U32 u32VolMaxBoost;             // Volume Maximizer Boost - Value in [0, 192] (4 fractional bits: [0.00 dB, 12.00 dB])
}MI_AOUT_DapVolMaxBoost_t;

typedef struct MI_AOUT_DapGeqParams_s
{
    MI_U32 u32GeqEnable;                            // Graphic Equalizer Enable - Value is a boolean (0 or 1)
    MI_U32 u32GeqNbBands;                           // Graphic Equalizer Bands - Array of 1 to 20 (Value1, Value2) pairs
    MI_U32 au32GeqBandCenter[MI_AOUT_MAX_DAP_GEQ_BAND_NUM]; // Value1 is an integer in [20, 20000] (unit is Hz)
    MI_S32 as32GeqBandTarget[MI_AOUT_MAX_DAP_GEQ_BAND_NUM]; // Value2 in [-576, 576] (4 fractional bits: [-36.00 dB, 36.00 dB])
}MI_AOUT_DapGeqParams_t;

typedef struct MI_AOUT_DapOptimizerParams_s
{
    MI_U32 u32OptimizerEnable;                                         // Audio Optimizer Enable - Value is a boolean (0 or 1)
    MI_U32 u32OptimizerNbBands;                                        // Audio Optimizer Bands - Array of 1 to 20 (Value1, [Value2], [Value3], [Value4], [Value5], [Value6], [Value7], [Value8], [Value9])
    MI_U32 au32OptBandCenterFreq[MI_AOUT_MAX_DAP_OPT_BAND_NUM];                //Value1 is an integer in [20, 20000] (unit is Hz)
    MI_S32 as32OptBandGain[MI_AOUT_MAX_DAP_CHANNEL_NUM][MI_AOUT_MAX_DAP_OPT_BAND_NUM]; //Value2..Value9 in [-480, 480] (4 fractional bits: [-30.00 dB, 30.00 dB])
}MI_AOUT_DapOptimizerParams_t;

typedef struct MI_AOUT_DapBassParams_s
{
    MI_U32 u32BassEnable;              // Bass Enhancer Enable - Value is a boolean (0 or 1)
    MI_U32 u32BassBoost;               // Bass Enhancer Boost - Value in [0, 384] (4 fractional bits: [0.00 dB, 24.00 dB])
    MI_U32 u32BassCutoff;              // Bass Enhancer Cutoff Frequency - Value is an integer in [20, 2000] (unit is Hz)
    MI_U32 u32BassWidth;               // Bass Enhancer Width - Value in [2, 64] (4 fractional bits: [0.13 octaves, 4.00 octaves])
}MI_AOUT_DapBassParams_t;

typedef struct MI_AOUT_DapRegParams_s
{
    MI_U32 u32RegNbBands;                               // Audio Regulator bands - Array of 1 to 20 (Value1, Value2, Value3, Value4) tuples
    MI_U32 au32RegBandCenter[MI_AOUT_MAX_DAP_REG_BAND_NUM];     // Value1 is an integer in [20, 20000] (unit is Hz)
    MI_S32 as32RegLowThresholds[MI_AOUT_MAX_DAP_REG_BAND_NUM];  // Value2 in [-2080, 0] (4 fractional bits: [-130.00 dB, 0.00 dB])
    MI_S32 as32RegHighThresholds[MI_AOUT_MAX_DAP_REG_BAND_NUM]; // Value3 in [-2080, 0] (4 fractional bits: [-130.00 dB, 0.00 dB])
    MI_U32 au32RegIsolatedBands[MI_AOUT_MAX_DAP_REG_BAND_NUM];  // Value4 is a boolean (0 or 1)
}MI_AOUT_DapRegParams_t;

typedef struct MI_AOUT_DapRegulatorParams_s
{
    MI_U32 u32RegulatorOverdrive;      // Audio Regulator Overdrive - Value in [0, 192] (4 fractional bits: [0.00 dB, 12.00 dB])
    MI_U32 u32RegulatorTimbre;         // Audio Regulator Timbre Preservation Amount - Value in [0, 16] (4 fractionalbits: [0.00, 1.00])
    MI_U32 u32RegulatorDistortion;     // Audio Regulator Distortion Relaxation Amount - Value in [0, 144] (4 fractional bits: [0.00 dB, 9.00 dB])
    MI_U32 u32RegulatorMode;           // Audio Regulator Speaker Distortion Mode Enable - Value is a boolean (0 or 1) Peak Protection mode, Speaker Distortion mode
    MI_U32 u32RegulatorEnable;         // Audio Regulator Enable - Value is a boolean (0 or 1)
}MI_AOUT_DapRegulatorParams_t;

typedef struct MI_AOUT_DapVirtualBassParams_s
{
    MI_U32 u32VirtualBassMode;         // Virtual Bass Mode - Value is an integer in [0, 3]: 0 - delay only  1 - only 2nd order harmonics generated  2 - only 2nd and 3rd,order harmonics generated  3 - all of the 2nd,3rd,4th order harmonics generated
    MI_U32 u32VirtualBassLowSrcFreq;   // Virtual Bass Source Frequency Boundaries - Value is an integer in [30, 90] (unit is Hz)
    MI_U32 u32VirtualBassHighSrcFreq;  // Virtual Bass Source Frequency Boundaries - Value is an integer in [90, 270] (unit is Hz)
    MI_S32 s32VirtualBassOverallGain;  // Virtual Bass Overall Gain - Value in [-480, 0] (4 fractional bits: [-30.00 dB, 0.00 dB])
    MI_S32 s32VirtualBassSlopeGain;    // Virtual Bass Slope Gain - Value is an integer in [-3, 0] (unit is dB)
    MI_S32 as32VirtualBassSubGain[3];  // Virtual Bass Subgains - Array of exactly 3 values. Value in [-480, 0] (4 fractional bits: [-30.00 dB, 0.00 dB])
    MI_U32 u32VirtualBassMixLowFreq;   // Virtual Bass Mix Frequency Boundaries - Value is an integer in [0, 375] (unit is Hz)
    MI_U32 u32VirtualBassMixHighFreq;  // Virtual Bass Mix Frequency Boundaries - Value is an integer in [281, 938] (unit is Hz)
    MI_U32 u32VirtualBassEnable;       // Virtual Bass Enable - Value in [0, 1]:0 - disable  1 - enable
}MI_AOUT_DapVirtualBassParams_t;

typedef struct MI_AOUT_DapMs12v22Params_s
{
    MI_S32  as32OptBandGain2[2][MI_AOUT_MAX_DAP_OPT_BAND_NUM];  // channel 7,8 opimizer band gain, Value2..Value9 in [-480, 480] (4 fractional bits: [-30.00 dB, 30.00 dB])
    MI_U32  u32HeightFilterMode;                        // height filter mode - Value in [0,2]: 0 - disable, 1 - Height filter for front firing speakers, 2 - Height filter for up firing speakers
    MI_U32  u32LevelerIgnoreIlEnable;                   // leveler ignore intelligent loudness enable - Value in [0,1]: 0 - disable,  1 - enable
    MI_S32  s32LfeToLrGain;                             // lfe to LR gain - Value is an integer in [-96, 0] (unit is dB)
    MI_U32  u32LfeToLrEnable;                           // lfe to LR enable - Value in [0,1]: 0 - disable,  1 - enable
    MI_U32  u32Lfe10dbBoostEnable;                      // lfe 10dB boost enable - Value in [0,1]: 0 - disable,  1 - enable
    MI_U32  u32BassExtractionEnable;                    // DAP extract low frequency into LFE enale - Value in [0,1]: 0 - disable,  1 - enable
    MI_U32  u32BassExtractionCutoffFrequency;           // DAP cut-off frequency to extract low frequencies into LFE - Value is integer in [45,200](unit is Hz)
}MI_AOUT_DapMs12v22Params_t;

typedef struct MI_AOUT_AdvSndDolbyDapParams_s
{
    MI_BOOL abEnableSubProcess[E_MI_AOUT_DAP_MAX];

    MI_AOUT_DapGainParams_t                  stDapGainParam;
    MI_AOUT_DapSurroundVirtualizerParams_t   stDapSurroundVirtualizerParam;
    MI_AOUT_DapMiParams_t                    stDapMiParam;
    MI_AOUT_DapCalibrationBoost_t            stDapCalibrationBoost;
    MI_AOUT_DapLeveLerParams_t               stDapLevelerParam;
    MI_AOUT_DapModelerParams_t               stDapModelerParam;
    MI_AOUT_DapIeqParams_t                   stDapIeqParam;
    MI_AOUT_DapDeParams_t                    stDapDeParam;
    MI_AOUT_DapVolMaxBoost_t                 stDapVolMaxBoost;
    MI_AOUT_DapGeqParams_t                   stDapGeqParam;
    MI_AOUT_DapOptimizerParams_t             stDapOptimizerParam;
    MI_AOUT_DapBassParams_t                  stDapBassParam;
    MI_AOUT_DapRegParams_t                   stDapRegParam;
    MI_AOUT_DapRegulatorParams_t             stDapRegulatorParam;
    MI_AOUT_DapVirtualBassParams_t           stDapVirtualBassParam;
    MI_AOUT_DapMs12v22Params_t               stDapMs12V22Param;
}MI_AOUT_AdvSndDolbyDapParams_t;

typedef struct MI_AOUT_AdvSndDtsVirtualXParams_s
{
    MI_BOOL abEnableSubProcess[E_MI_AOUT_DTS_VIRTUALX_MAX];
}MI_AOUT_AdvSndDtsVirtualXParams_t;

typedef struct MI_AOUT_AdvSndDtsSsIiParams_s
{
    MI_BOOL abEnableSubProcess[E_MI_AOUT_DTS_SS_II_MAX];
}MI_AOUT_AdvSndDtsSsIiParams_t;

typedef struct MI_AOUT_AdvSndSonicEmotionParams_s
{
    MI_BOOL abEnableSubProcess[E_MI_AOUT_SONIC_EMOTION_MAX];
}MI_AOUT_AdvSndSonicEmotionParams_t;
//-------------------------------------------------------------------------------------------------

typedef struct MI_AOUT_AdvSndParams_s
{
    MI_AOUT_AdvSndType_e eAdvSndType;                                 ///< [IN]: Advaced sound effect type.

    union{
        MI_AOUT_AdvSndSrsTshdParams_t        stSrsTshdParams;         ///< [IN]: SRS TruSurround-HD
        MI_AOUT_AdvSndSrsTheaterSndParams_t  stSrsTheaterSndParams;   ///< [IN]: SRS TheaterSound

        MI_AOUT_AdvSndDbxParams_t            stDbxParams;             ///< [IN]: DBX
        MI_AOUT_AdvSndSrsPureSndParams_t     stSrsPureSndParams;      ///< [IN]: SRS PureSound
        MI_AOUT_AdvSndDolbyVolumeParams_t    stDolbyVolumeParams;     ///< [IN]: Dolby Volume
        MI_AOUT_AdvSndDolbyDapParams_t       stDolbyDapParams;        ///< [IN]: Dolby DAP
        MI_AOUT_AdvSndDtsVirtualXParams_t    stDtsVirtualXParams;     ///< [IN]: DTS VirtualX
        MI_AOUT_AdvSndDtsSsIiParams_t        stDtsSsIiParams;         ///< [IN]: DTS Studio Sound II
        MI_AOUT_AdvSndSonicEmotionParams_t   stSonicEmotionParams;    ///< [IN]: Sonic Emotion
    } attr;
}__attribute__((packed)) MI_AOUT_AdvSndParams_t;

typedef struct MI_AOUT_ConnectedConds_s
{
    MI_BOOL bIsInput;
    MI_U32 u32Module;

    //if need other conditions add here
} MI_AOUT_ConnectedConds_t;

typedef struct MI_AOUT_SineToneParams_s
{
    MI_U32 u32StartFreq;                    ///[IN]: SineTone start frequency. Range from 100 to 16000 HZ
    MI_U32 u32EndFreq;                      ///[IN]: SineTone end frequency. Range from 100 to 16000 HZ
    MI_U32 u32Gain;                         ///[IN]: SineTone gain. Range from 1 to 32767. represent 20 * log (u32Gain/32767) dBFS.
    MI_U32 u32Duration;                     ///[IN]: SineTone playing duration. Range from 1 to 170000 ms.
} MI_AOUT_SineToneParams_t;

typedef MI_RESULT (*MI_AOUT_EventCallback)(MI_HANDLE hAout, MI_U32 u32Event, void * pEventParams, void * pUserParams);

typedef struct MI_AOUT_CallbackInputParams_s
{
    MI_U64 u64CallbackId;                   ///[IN]: for multi-callback, use 0 for first register or single callback.
    MI_AOUT_EventCallback pfEventCallback; ///[IN]: callback function pointer.
    MI_U32 u32EventFlags;                   ///[IN]: registered events which are bitwise OR operation.Information refer to MI_AOUT_CallbackEvent_e.
    void *pUserParams;                      ///[IN]: for passing user-defined parameters,both used in get or set.
} MI_AOUT_CallbackInputParams_t;

typedef struct MI_AOUT_CallbackOutputParams_s
{
    MI_U64 u64CallbackId;               ///[OUT]: the returned ID for update or unregister callback.
} MI_AOUT_CallbackOutputParams_t;

typedef struct MI_AOUT_LoadAqParams_s
{
    const MI_U8 *pszFileName;                 /// [In]: Ini file name to be read.
} MI_AOUT_LoadAqParams_t;

typedef struct MI_AOUT_MultiMuteParams_s
{
    MI_U8   *pszMuteName;               ///< [IN]: Set Mute Event name.eg: "tts mute". Max length of name size: 64.
    MI_BOOL bMute;                      ///< [IN]: True: Mute; False Unmute;
    MI_U32  u32AutoUnmuteTimer;         ///< [IN]: Auto unmute audio in a period of millisecond. 0 is disable auto unmute.
} MI_AOUT_MultiMuteParams_t;

typedef struct MI_AOUT_VolumeTableParams_s
{
    MI_U16 *pu16VolTbl;                     /// [IN]: Volume table. Pointer to a array of 101 elements.
    const MI_U8 *pszVolumeTableName;                    /// [IN]: Volume table name.
} MI_AOUT_VolumeTableParams_t;

//-------------------------------------------------------------------------------------------------
//  Global Functions
//-------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------
/// @brief Init Aout module.
/// @param[in] *pstInitParams. Init parameter
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_AOUT_Init(const MI_AOUT_InitParams_t *pstInitParams);
//------------------------------------------------------------------------------
/// @brief Finalize Aout module.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_AOUT_DeInit(void);
//------------------------------------------------------------------------------
/// @brief Get aout capability.
/// @param[out] *pstCaps. Output aout capacities.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_AOUT_GetCaps(MI_AOUT_Caps_t *pstCaps);
//------------------------------------------------------------------------------
/// @brief Open a Aout handle.
/// @param[in] *pstOpenParams. Inputed open paramters.
/// @param[out] *phAout. Output aout handle.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_RESOURCES: No available resource.
//------------------------------------------------------------------------------
MI_RESULT MI_AOUT_Open(const MI_AOUT_OpenParams_t *pstOpenParams, MI_HANDLE *phAout);
//------------------------------------------------------------------------------
/// @brief Close a Aout handle.
/// @param[in] hAout. Aout handle to process.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_AOUT_Close(MI_HANDLE hAout);
//------------------------------------------------------------------------------
/// @brief Set track mode: Stereo/LL/RR.
/// @param[in] hAout. Aout handle to process.
/// @param[in] eMode. Trackmode to be setted.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_AOUT_SetTrackMode(MI_HANDLE hAout, MI_AOUT_TrackMode_e eMode);
//------------------------------------------------------------------------------
/// @brief Get track mode: Stereo/LL/RR.
/// @param[in] hAout. Aout handle to process.
/// @param[out] *peMode. Output Trackmode.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_AOUT_GetTrackMode(MI_HANDLE hAout, MI_AOUT_TrackMode_e *peMode);
//------------------------------------------------------------------------------
/// @brief Set volume, 0~100.
/// @param[in] hAout. Aout handle to process.
/// @param[in] ePath. Path to set volume.
/// @param[in] u8Volume. Value of volume.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_AOUT_SetVolume(MI_HANDLE hAout, MI_AOUT_Path_e ePath, MI_U8 u8Volume);
//------------------------------------------------------------------------------
/// @brief Get volume.
/// @param[in] hAout. Aout handle to process.
/// @param[in] ePath. Path to get volume.
/// @param[out] *pu8Volume. Output the value of volume.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_AOUT_GetVolume(MI_HANDLE hAout, MI_AOUT_Path_e ePath, MI_U8 *pu8Volume);
//------------------------------------------------------------------------------
/// @brief Set volume by dB, support -114dB~+12dB.
/// @param[in] hAout. Aout handle to process.
/// @param[in] ePath. Path to set VolumeDb.
/// @param[in] *pstVolumeDb : Gain index range from -114*8 ~ +12*8 (-114dB~+12db) ; 0.125dB/step.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_AOUT_SetVolumeDb(MI_HANDLE hAout, MI_AOUT_Path_e ePath, MI_AOUT_VolumeDb_t *pstVolumeDb);
//------------------------------------------------------------------------------
/// @brief Get volume by dB, support -114dB~+12dB.
/// @param[in] hAout. Aout handle to process.
/// @param[in] ePath. Path to get VolumeDb.
/// @param[out] *pstVolumeDb: Gain index range from -114*8 ~ +12*8 (-114dB~+12db) ; 0.125dB/step.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_AOUT_GetVolumeDb(MI_HANDLE hAout, MI_AOUT_Path_e ePath, MI_AOUT_VolumeDb_t *pstVolumeDb);
//------------------------------------------------------------------------------
/// @brief Set channel volume by dB, support -64dB~0dB.
/// @param[in] hAout. Aout handle to process.
/// @param[in] *pstChannelVolumeDbParams : channel volume dB parameter, including channel and volume gain.
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_AOUT_SetChannelVolumeDb(MI_HANDLE hAout, const MI_AOUT_ChannelVolumeDbParams_t *pstChannelVolumeDbParams);
//------------------------------------------------------------------------------
/// @brief Set mute.
/// @param[in] hAout. Aout handle to process.
/// @param[in] *pstMuteParams. Mute paramters,including mute type and mute status.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_AOUT_SetMute(MI_HANDLE hAout, MI_AOUT_MuteParams_t *pstMuteParams);
//------------------------------------------------------------------------------
/// @brief Get mute status.
/// @param[in] hAout. Aout handle to process.
/// @param[out] *pstMuteParams. Mute paramters,including mute type and mute status.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_AOUT_GetMute(MI_HANDLE hAout, MI_AOUT_MuteParams_t *pstMuteParams);
//------------------------------------------------------------------------------
/// @brief open FmTx output.
/// @param[in] hAout. Aout handle to process.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_AOUT_EnableFmTx(MI_HANDLE hAout);
//------------------------------------------------------------------------------
/// @brief close FmTx output.
/// @param[in] hAout. Aout handle.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_AOUT_DisableFmTx(MI_HANDLE hAout);
//------------------------------------------------------------------------------
/// @brief Set delay.
/// @param[in] hAout. Aout handle to process.
/// @param[in] eType. Delay type.
/// @param[in] u32DelayMs. Delay duration.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_AOUT_SetDelay(MI_HANDLE hAout, MI_AOUT_DelayType_e eType, MI_U32 u32DelayMs);
//------------------------------------------------------------------------------
/// @brief Get delay.
/// @param[in] hAout. Aout handle to process.
/// @param[in] eType. Delay type.
/// @param[out] *pu32DelayMs. Delay duration.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_AOUT_GetDelay(MI_HANDLE hAout, MI_AOUT_DelayType_e eType, MI_U32 *pu32DelayMs);
//------------------------------------------------------------------------------
/// @brief Set digital mode: PCM/nonPCM.
/// @param[in] hAout. Aout handle to process.
/// @param[in] * pstDigitalModeParams.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_AOUT_SetDigitalMode(MI_HANDLE hAout, MI_AOUT_DigitalModeParams_t *pstDigitalModeParams);
//------------------------------------------------------------------------------
/// @brief Get digital mode.
/// @param[in] hAout. Aout handle to process.
/// @param[out] * pstDigitalModeParams. Digital mode paramters.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_AOUT_GetDigitalMode(MI_HANDLE hAout, MI_AOUT_DigitalModeParams_t *pstDigitalModeParams);
//------------------------------------------------------------------------------
/// @brief Get aout attribute.
/// @param[in] hAout. Aout handle to process.
/// @param[in] eAttrType. Type of attribution.
/// @param[in] *pInputParams. Input paramters.
/// @param[out] *pOutputParams. Output paramters.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_AOUT_GetAttr(MI_HANDLE hAout, MI_AOUT_AttrType_e eAttrType, const void *pInputParams, void *pOutputParams);
//------------------------------------------------------------------------------
/// @brief Set aout attribute.
/// @param[in] hAout. Aout handle to process.
/// @param[in] eAttrType. Type of attribution.
/// @param[in] *pAttrParams. Input paramters.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_AOUT_SetAttr(MI_HANDLE hAout, MI_AOUT_AttrType_e eAttrType, const void *pAttrParams);
//------------------------------------------------------------------------------
/// @brief Get a Aout handle.
/// @param[in] *pstQueryParams. Paramters for getting handle.
/// @param[out] *phAout. Output aout handle.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_AOUT_GetHandle(const MI_AOUT_QueryHandleParams_t *pstQueryParams, MI_HANDLE *phAout);
//------------------------------------------------------------------------------
/// @brief Set debug level for mi_aout.c.
/// @param[in] u32DbgLevel. Debug level to be setted.
/// @return MI_OK: Process success.
//------------------------------------------------------------------------------
MI_RESULT MI_AOUT_SetDebugLevel(MI_DBG_LEVEL u32DebugLevel);

//------------------------------------------------------------------------------
/// @brief For Aout is a down stream module. Aout connect its input with hInputHdl, i.e. hInput --> hAudHandle
/// @param[in] hAout: Aout handle
/// @param[in] hInput: Handle of up stream to connect with Aout's input
/// @param[in] pstParams: Pointer to struct MI_AOUT_ConnectInputParams_t to speicified the parameters for Aout connect input with hUpHdl
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE: invalid handle.
/// @return MI_ERR_FAILED: Process failed
//------------------------------------------------------------------------------
MI_RESULT MI_AOUT_ConnectInput(MI_HANDLE hAout, MI_HANDLE hInput, const MI_AOUT_ConnectInputParams_t *pstParams);

//------------------------------------------------------------------------------
/// @brief For Aout is a down stream module. Aout disconnect its input hInputHdl, i.e. hInputHdl -X-> hAudHandle
/// @param[in] hAout: Aout handle
/// @param[in] hInput: Handle of up stream to connect with Aout's input
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE: invalid handle.
/// @return MI_ERR_FAILED: Process failed
//------------------------------------------------------------------------------
MI_RESULT MI_AOUT_DisconnectInput(MI_HANDLE hAout, MI_HANDLE hInput);

//------------------------------------------------------------------------------
/// @brief Get the element which is connected to the specified element.
/// @param[in] hAout: Aout handle
/// @param[in] pstDispConds: bIsinput-The direction for finding the connected module.
///                          u32ModuleType-The module type of connected with DISP. it defined in mi_common.h with prefix MI_MODULE_TYPE_XXX.
///                                        If it is MI_MODULE_TYPE_NONE it find all type of connected modules.
///                                        e.g. MI_DISP_GetConnected(hDisp, TRUE, MI_MODULE_TYPE_VIDEO, u32ConnectedNum, phConnectedArray)
/// @param[out] pu32ConnectedNum: The number of connected handle
/// @return MI_OK: Process success.
//------------------------------------------------------------------------------
MI_RESULT MI_AOUT_GetConnectedNum(const MI_HANDLE hAout, const MI_AOUT_ConnectedConds_t *pstAoutConds, MI_U32 *pu32ConnectedNum);

//------------------------------------------------------------------------------
/// @brief Get the element which is connected to the specified element.
/// @param[in] hDisp: display window handle
/// @param[in] pstDispConds: bIsinput-The direction for finding the connected module.
///                          u32ModuleType-The module type of connected with DISP. it defined in mi_common.h with prefix MI_MODULE_TYPE_XXX.
///                                        If it is MI_MODULE_TYPE_NONE it find all type of connected modules.
///                                        e.g. MI_DISP_GetConnected(hDisp, TRUE, MI_MODULE_TYPE_VIDEO, u32ConnectedNum, phConnectedArray)
/// @param[in] u32ConnectedNum: The number of get handle
/// @param[out] phConnectedArray: Pointer to handle buffer to retrieve the handle of MI module which is connected to the specified element with the specified direction.
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_FAILED: Process fail, no connection is available.
//------------------------------------------------------------------------------
MI_RESULT MI_AOUT_GetConnected(const MI_HANDLE hAout, const MI_AOUT_ConnectedConds_t *pstAoutConds, const MI_U32 u32ConnectedNum, MI_HANDLE *phConnectedArray);

/// @brief Start to play a sinetone.
/// @param[in] hAout. Aout handle
/// @param[in] *pstSineToneParams: Parameters of sinetone.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_AOUT_StartSineTone(MI_HANDLE hAout, const MI_AOUT_SineToneParams_t *pstSineToneParams);

//------------------------------------------------------------------------------
/// @brief Stop to play a sinetone.
/// @param[in] hAout. Aout handle
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_AOUT_StopSineTone(MI_HANDLE hAout);

//------------------------------------------------------------------------------
/// @brief Register aout event.
/// @param[in] hAout. aout handle
/// @param[in] *pstInputParams. Parameters of register callback
/// @param[out] *pstOutputParams. Parameters of output afer register callback.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_AOUT_RegisterCallback(MI_HANDLE hAout, const MI_AOUT_CallbackInputParams_t * pstInputParams, MI_AOUT_CallbackOutputParams_t *pstOutputParams);

//------------------------------------------------------------------------------
/// @brief Unregister aout event.
/// @param[in] hAout. Aout handle
/// @param[in] *pstInputParams.Parameters of unregister callback
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_AOUT_UnRegisterCallback(MI_HANDLE hAout, const MI_AOUT_CallbackInputParams_t * pstInputParams);

//------------------------------------------------------------------------------
/// @brief Load audio quality setting
/// @param[in] hAout: Aout handle
/// @param[in] *pstLoadAqParams: Audio quality parameters.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_AOUT_LoadAqParams(MI_HANDLE hAout, const MI_AOUT_LoadAqParams_t *pstLoadAqParams);

#ifdef __cplusplus
}
#endif

#endif///_MI_AOUT_H_

