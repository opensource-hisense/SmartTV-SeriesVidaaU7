/*------------------------------------------------------------------------------
 * MediaTek Inc. (C) 2018. All rights reserved.
 *
 * Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 *----------------------------------------------------------------------------*/
//------------------------------------------------------------------------------
// GetXxx/SetXxx and GetAttr/SetAttr coexist
//------------------------------------------------------------------------------

#ifndef _MI_TUNER_H_
#define _MI_TUNER_H_

#ifdef __cplusplus
extern "C" {
#endif

//-------------------------------------------------------------------------------------------------
//  Defines
//-------------------------------------------------------------------------------------------------
#define MI_TUNER_MAX_SATNAME_LEN   32

//-------------------------------------------------------------------------------------------------
//  Structures
//-------------------------------------------------------------------------------------------------
typedef enum
{
    E_MI_TUNER_DVB_TYPE_INVALID =-1,
    E_MI_TUNER_DVB_TYPE_NOT_SETTING =0,
    E_MI_TUNER_DVB_TYPE_DVBC = 1,
    E_MI_TUNER_DVB_TYPE_DVBT = 2,
    E_MI_TUNER_DVB_TYPE_DVBT2= 3,
    E_MI_TUNER_DVB_TYPE_INTERNAL_DVBT = 4,
    E_MI_TUNER_DVB_TYPE_ISDBT= 5,
    E_MI_TUNER_DVB_TYPE_INTERNAL_ISDBT= 6,
    E_MI_TUNER_DVB_TYPE_DVBS = 7,
    E_MI_TUNER_DVB_TYPE_DVBS2= 8,
    E_MI_TUNER_DVB_TYPE_ATSC = 9,
    E_MI_TUNER_DVB_TYPE_DTMB = 10,
    E_MI_TUNER_DVB_TYPE_J83B = 11,
    E_MI_TUNER_DVB_TYPE_NULL =255,
} MI_TUNER_DvbType_e;

/// Define converlution code rate for DVB-T and DVB-S
typedef enum
{
    E_MI_TUNER_ATV_TYPE_NOT_SETTING = 0,                                          /// ATV, NOT SETTING
    E_MI_TUNER_ATV_TYPE_PAL,                                                      /// ATV, PAL
    E_MI_TUNER_ATV_TYPE_SECAM_L_PRIME,                                            /// ATV, SECAM-L'
    E_MI_TUNER_ATV_TYPE_NTSC,                                                     /// ATV, NTSC
    E_MI_TUNER_ATV_TYPE_NULL=255,                                                 /// NULL
} MI_TUNER_AtvType_e;

/// Define converlution code rate for DVB-T and DVB-S
typedef enum
{
    E_MI_TUNER_CONV_CODE_RATE_TYPE_1_2 = 0,                                                ///< Code rate = 1/2
    E_MI_TUNER_CONV_CODE_RATE_TYPE_2_3,                                                ///< Code rate = 2/3
    E_MI_TUNER_CONV_CODE_RATE_TYPE_3_4,                                                ///< Code rate = 3/4
    E_MI_TUNER_CONV_CODE_RATE_TYPE_5_6,                                                ///< Code rate = 5/6
    E_MI_TUNER_CONV_CODE_RATE_TYPE_7_8,                                                ///< Code rate = 7/8
    E_MI_TUNER_CONV_CODE_RATE_TYPE_3_5,                                                ///< Code rate = 3/5
    E_MI_TUNER_CONV_CODE_RATE_TYPE_4_5,                                                ///< Code rate = 4/5
    E_MI_TUNER_CONV_CODE_RATE_TYPE_1_3,                                                ///< Code rate =  1/3
    E_MI_TUNER_CONV_CODE_RATE_TYPE_1_4,                                                ///< Code rate =  1/4
    E_MI_TUNER_CONV_CODE_RATE_TYPE_2_5,                                                ///< Code rate =  2/5
    E_MI_TUNER_CONV_CODE_RATE_TYPE_8_9,                                                ///< Code rate =  8/9
    E_MI_TUNER_CONV_CODE_RATE_TYPE_9_10,                                              ///< Code rate =  9/10
    E_MI_TUNER_CONV_CODE_RATE_TYPE_MAX,
} MI_TUNER_ConvCodeRateType_e;

/// Define terrestrial band width
typedef enum
{
    E_MI_TUNER_TER_BW_MODE_6MHZ = 0, ///< 6 MHz
    E_MI_TUNER_TER_BW_MODE_7MHZ,                                                          ///< 7 MHz
    E_MI_TUNER_TER_BW_MODE_8MHZ,                                                          ///< 8 MHz
    E_MI_TUNER_TER_BW_MODE_MAX
} MI_TUNER_TerBwMode_e;

/// Define terrestrial constellation type
typedef enum
{
    E_MI_TUNER_TER_CONSTEL_TYPE_QPSK =0,                                                             ///< QPSK type
    E_MI_TUNER_TER_CONSTEL_TYPE_QAM16,                                                          ///< QAM 16 type
    E_MI_TUNER_TER_CONSTEL_TYPE_QAM64,                                                          ///< QAM 64 type
    E_MI_TUNER_TER_CONSTEL_TYPE_QAM256,                                                          ///< QAM 256 type
    E_MI_TUNER_TER_CONSTEL_TYPE_MAX
} MI_TUNER_TerConstelType_e;

/// Define terrestrial hierarchy information
typedef enum
{
    E_MI_TUNER_TER_HIE_TYPE_NONE =0,                                                       ///< Non-hierarchy
    E_MI_TUNER_TER_HIE_TYPE_ALPHA_1,                                                    ///< Hierarchy alpha = 1
    E_MI_TUNER_TER_HIE_TYPE_ALPHA_2,                                                    ///< Hierarchy alpha = 2
    E_MI_TUNER_TER_HIE_TYPE_ALPHA_4,                                                    ///< Hierarchy alpha = 4
    E_MI_TUNER_TER_HIE_TYPE_ALPHA_MAX
} MI_TUNER_TerHieType_e;

/// Define terrestrial guard interval
typedef enum
{
    E_MI_TUNER_TER_GI_TYPE_1_32 = 0,                                                        ///< Guard interval value = 1/32
    E_MI_TUNER_TER_GI_TYPE_1_16,                                                        ///< Guard interval value = 1/16
    E_MI_TUNER_TER_GI_TYPE_1_8,                                                         ///< Guard interval value = 1/8
    E_MI_TUNER_TER_GI_TYPE_1_4,                                                         ///< Guard interval value = 1/4
    E_MI_TUNER_TER_GI_TYPE_1_128,                                                       ///< Guard interval value = 1/128
    E_MI_TUNER_TER_GI_TYPE_19_128,                                                      ///< Guard interval value = 19/128
    E_MI_TUNER_TER_GI_TYPE_19_256,                                                      ///< Guard interval value = 19/256
    E_MI_TUNER_TER_GI_TYPE_MAX,
} MI_TUNER_TerGiType_e;

/// Define terrestrial transmission mode
typedef enum
{
    E_MI_TUNER_TER_FFT_MODE_1K = 0,                                                    ///< 1k FFT mode
    E_MI_TUNER_TER_FFT_MODE_2K,                                                        ///< 2k FFT mode
    E_MI_TUNER_TER_FFT_MODE_4K,                                                        ///< 4k FET mode
    E_MI_TUNER_TER_FFT_MODE_8K,                                                        ///< 8k FFT mode
    E_MI_TUNER_TER_FFT_MODE_8K_GI_LONG,                                                ///< 8k with guard interval 1/32, 1/16,1/8,1/4
    E_MI_TUNER_TER_FFT_MODE_8K_GI_SHORT,                                               ///< 8k with guard interval 1/128, 19/256,19/128
    E_MI_TUNER_TER_FFT_MODE_16K,                                                       ///< 16k FFT mode
    E_MI_TUNER_TER_FFT_MODE_32K_GI_LONG,                                               ///< 32k with guard interval 1/32, 1/16,1/8
    E_MI_TUNER_TER_FFT_MODE_32K_GI_SHORT,                                              ///< 32k with guard interval 1/128, 19/256,19/128
    E_MI_TUNER_TER_FFT_MODE_MAX,
} MI_TUNER_TerFftMode_e;

/// Define terrestrial transmission mode
typedef enum
{
    E_MI_TUNER_TER_LEVEL_SEL_HP = 0,                                                         ///< High priority level selection
    E_MI_TUNER_TER_LEVEL_SEL_LP,                                                          ///< Low priority level selection
    E_MI_TUNER_TER_LEVEL_SEL_MAX,
} MI_TUNER_TerLevelSel_e;

/// Define DVB-C modulation scheme
typedef enum
{
    E_MI_TUNER_CAB_CONSTEL_TYPE_QAM16 = 0,                                                          ///< QAM 16
    E_MI_TUNER_CAB_CONSTEL_TYPE_QAM32,                                                          ///< QAM 32
    E_MI_TUNER_CAB_CONSTEL_TYPE_QAM64,                                                          ///< QAM 64
    E_MI_TUNER_CAB_CONSTEL_TYPE_QAM128,                                                         ///< QAM 128
    E_MI_TUNER_CAB_CONSTEL_TYPE_QAM256,                                                         ///< QAM 256
    E_MI_TUNER_CAB_CONSTEL_TYPE_QAMAUTO = 0x100,                                                ///< QAMAUTO
    E_MI_TUNER_CAB_CONSTEL_TYPE_MAX,
} MI_TUNER_CabConstelType_e;

/// Define DVB-S IQ tuning mode
typedef enum
{
    E_MI_TUNER_CAB_IQ_MODE_NORMAL = 0,                                                      ///< Normal
    E_MI_TUNER_CAB_IQ_MODE_INVERT,                                                       ///< Inverse
    E_MI_TUNER_CAB_IQ_MODE_MAX,
} MI_TUNER_CabIqMode_e;

typedef enum
{
    E_MI_TUNER_CAB_BW_6M = 0,
    E_MI_TUNER_CAB_BW_7M,
    E_MI_TUNER_CAB_BW_8M,
    E_MI_TUNER_CAB_BW_MAX
} MI_TUNER_CabBw_e;

/// Define DVB-S modulatiopn scheme
typedef enum
{
    E_MI_TUNER_SAT_CONSTEL_TYPE_QPSK = 0,                                                           ///< QPSK
    E_MI_TUNER_SAT_CONSTEL_TYPE_8PSK,                                                           ///< 8PSK
    E_MI_TUNER_SAT_CONSTEL_TYPE_QAM16,                                                           ///< QAM16
    E_MI_TUNER_SAT_CONSTEL_TYPE_MAX
} MI_TUNER_SatConstelType_e;

/// Define DVB-S Roll-Off factor
typedef enum
{
    E_MI_TUNER_SAT_ROLL_OFF_TYPE_35 = 0,                                                          ///< roll-off factor = 0.35
    E_MI_TUNER_SAT_ROLL_OFF_TYPE_25,                                                          ///< roll-off factor = 0.25
    E_MI_TUNER_SAT_ROLL_OFF_TYPE_20,                                                           ///< roll-off factor = 0.20
    E_MI_TUNER_SAT_ROLL_OFF_TYPE_MAX,
} MI_TUNER_SatRollOffType_e;

/// Define DVB-S IQ tuning mode
typedef enum
{
    E_MI_TUNER_SAT_IQ_MODE_NORMAL = 0,                                                      ///< Normal
    E_MI_TUNER_SAT_IQ_MODE_INVERSE,                                                      ///< Inverse
    E_MI_TUNER_SAT_IQ_MODE_MAX
} MI_TUNER_SatIqMode_e;

/// Define DVB-S Unicable generation
typedef enum
{
    E_MI_TUNER_SAT_UNICABLE_GEN_NONE = 0,                                      ///< Non-Unicable
    E_MI_TUNER_SAT_UNICABLE_GEN_SCD1,                                          ///< 1st generation single cable distribution system (SCD1)
    E_MI_TUNER_SAT_UNICABLE_GEN_SCD2,                                          // < 2nd generation single cable distribution system (SCD2)(JESS)
    E_MI_TUNER_SAT_UNICABLE_MAX
} MI_TUNER_UnicableGen_e;

/// Define tuning mode
/// NOTE: When this typedef is modified, the apiChScan should be rebuild.
typedef enum
{
    E_MI_TUNER_FE_TUNE_MODE_MANUAL = 0,                                                     ///< Manual tuning to carrier
    E_MI_TUNER_FE_TUNE_MODE_AUTO,                                                       ///< Auto tuning to carrier
    E_MI_TUNER_FE_TUNE_MODE_MAX,
} MI_TUNER_FeTuneMode_e;

/// the scan frequency step
typedef enum
{
    E_MI_TUNER_ATV_FREQ_STEP_INVALID = -1,                                              /// invalid
    E_MI_TUNER_ATV_FREQ_STEP_31P25KHZ = 0x0,                                            /// 31.25 KHz
    E_MI_TUNER_ATV_FREQ_STEP_50KHZ    = 0x01,                                           /// 50 KHz
    E_MI_TUNER_ATV_FREQ_STEP_62P5KHZ  = 0x02,                                           /// 62.5 KHz
    E_MI_TUNER_ATV_FREQ_STEP_MAX
} MI_TUNER_AtvFreqStep_e;

typedef enum
{
    E_MI_TUNER_SIF_STANDARD_TYPE_INVALID           = -1,
    E_MI_TUNER_SIF_STANDARD_TYPE_BG                    = 0x00,
    E_MI_TUNER_SIF_STANDARD_TYPE_BG_A2                 = 0x01,
    E_MI_TUNER_SIF_STANDARD_TYPE_BG_NICAM              = 0x02,
    E_MI_TUNER_SIF_STANDARD_TYPE_I                     = 0x03,
    E_MI_TUNER_SIF_STANDARD_TYPE_DK                    = 0x04,
    E_MI_TUNER_SIF_STANDARD_TYPE_DK1_A2                = 0x05,
    E_MI_TUNER_SIF_STANDARD_TYPE_DK2_A2                = 0x06,
    E_MI_TUNER_SIF_STANDARD_TYPE_DK3_A2                = 0x07,
    E_MI_TUNER_SIF_STANDARD_TYPE_DK_NICAM              = 0x08,
    E_MI_TUNER_SIF_STANDARD_TYPE_L                     = 0x09,
    E_MI_TUNER_SIF_STANDARD_TYPE_M                     = 0x0A,
    E_MI_TUNER_SIF_STANDARD_TYPE_M_BTSC                = 0x0B,
    E_MI_TUNER_SIF_STANDARD_TYPE_M_A2                  = 0x0C,
    E_MI_TUNER_SIF_STANDARD_TYPE_M_EIA_J               = 0x0D,
    E_MI_TUNER_SIF_STANDARD_TYPE_MAX
} MI_TUNER_SifStandardType_e;

typedef enum
{
    E_MI_TUNER_ATV_TUNE_MODE_PLAY = 0,
    E_MI_TUNER_ATV_TUNE_MODE_SCAN,
    E_MI_TUNER_ATV_TUNE_MODE_MAX,
}MI_TUNER_AtvTuneMode_e;

/// Define LNB power
typedef enum
{
    E_MI_TUNER_LNB_PWR_SWITCH_OFF = 0,
    E_MI_TUNER_LNB_PWR_SWITCH_13OR18V,
    E_MI_TUNER_LNB_PWR_SWITCH_13V,
    E_MI_TUNER_LNB_PWR_SWITCH_18V,
    E_MI_TUNER_LNB_PWR_SWITCH_MAX
} MI_TUNER_LnbPwrSwitch_e;

typedef enum
{
    E_MI_TUNER_LNB_TYPE_C = 0,
    E_MI_TUNER_LNB_TYPE_KU,
    E_MI_TUNER_LNB_TYPE_2LOF,
    E_MI_TUNER_LNB_TYPE_MAX,
} MI_TUNER_LnbType_e;

//diseqc
typedef enum
{
    E_MI_TUNER_DISEQC_LEVEL_OFF = 0,
    E_MI_TUNER_DISEQC_LEVEL_1_0,
    E_MI_TUNER_DISEQC_LEVEL_1_1,
    E_MI_TUNER_DISEQC_LEVEL_1_2,
    E_MI_TUNER_DISEQC_LEVEL_1_3,
    E_MI_TUNER_DISEQC_LEVEL_2_0,
    E_MI_TUNER_DISEQC_LEVEL_MULTI = 0x100,
    E_MI_TUNER_DISEQC_LEVEL_MAX,
} MI_TUNER_DiseqcLevel_e;

typedef enum
{
    E_MI_TUNER_TONE_BURST_TYPE_NONE = 0,
    E_MI_TUNER_TONE_BURST_TYPE_0,
    E_MI_TUNER_TONE_BURST_TYPE_1,
    E_MI_TUNER_TONE_BURST_TYPE_MAX
} MI_TUNER_ToneBurstType_e;

typedef enum
{
    E_MI_TUNER_SWT_PORT_OFF = 0,
    E_MI_TUNER_SWT_PORT_1,
    E_MI_TUNER_SWT_PORT_2,
    E_MI_TUNER_SWT_PORT_3,
    E_MI_TUNER_SWT_PORT_4,
    E_MI_TUNER_SWT_PORT_5,
    E_MI_TUNER_SWT_PORT_6,
    E_MI_TUNER_SWT_PORT_7,
    E_MI_TUNER_SWT_PORT_8,
    E_MI_TUNER_SWT_PORT_9,
    E_MI_TUNER_SWT_PORT_10,
    E_MI_TUNER_SWT_PORT_11,
    E_MI_TUNER_SWT_PORT_12,
    E_MI_TUNER_SWT_PORT_13,
    E_MI_TUNER_SWT_PORT_14,
    E_MI_TUNER_SWT_PORT_15,
    E_MI_TUNER_SWT_PORT_16,
    E_MI_TUNER_SWT_PORT_MAX,
} MI_TUNER_SwtPort_e;

typedef enum
{
    E_MI_TUNER_22K_SWITCH_OFF = 0,
    E_MI_TUNER_22K_SWITCH_ON,
    E_MI_TUNER_22K_SWITCH_AUTO,
    E_MI_TUNER_22K_SWITCH_MAX
} MI_TUNER_22kSwitch_e;

typedef enum
{
    E_MI_TUNER_0V_12V_SWITCH_OFF = 0,
    E_MI_TUNER_0V_12V_SWITCH_ON,
    E_MI_TUNER_0V_12V_SWITCH_MAX
} MI_TUNER_0v12vSwitch_e;

typedef enum
{
    E_MI_TUNER_LNB_CABLE_NOT_SET = 0,
    E_MI_TUNER_LNB_CABLE_1,
    E_MI_TUNER_LNB_CABLE_2,
}MI_TUNER_LnbCable_e;

typedef enum
{
    E_MI_TUNER_ATTR_TYPE_IS_OVER_CURRENT = 0,                                    ///Get DVBS Is Over Current, parameter type is a pointer to MI_BOOL
    E_MI_TUNER_ATTR_TYPE_RS_UNCORRECTED_PACKET_ERR_COUNT,                        ///Get RS(Reed Solomon) un-corrected error ratio, parameter type is a pointer to MI_U32
    E_MI_TUNER_ATTR_TYPE_ISDBT_BER,                                              ///Get ISDBT BER value, parameter type is a pointer to MI_TUNER_IsdbtBer_t
    E_MI_TUNER_ATTR_TYPE_ATV_FREQ_STEP,                                          ///Get frequency step,parameter type is a pointer to MI_U32
    E_MI_TUNER_ATTR_TYPE_ATV_VHF_LOW_MIN_FREQ,                                   ///Get VHF low minimum frequency, parameter type is a pointer to MI_U32
    E_MI_TUNER_ATTR_TYPE_ATV_UHF_MAX_FREQ,                                       ///Get UHF maximum frequency, parameter type is a pointer to MI_U32
    E_MI_TUNER_ATTR_TYPE_GET_CELL_ID,                                            ///Get CELL_ID, parameter type is a pointer to MI_U16
    E_MI_TUNER_ATTR_TYPE_GET_SATELLITE_22K_STATUS,                               ///Get 22K, parameter type is a pointer to MI_BOOL
    E_MI_TUNER_ATTR_TYPE_GET_TS_STREAMS_NUM,                                     ///Get fsc demod mode, parameter type is a pointer to MI_U8
    E_MI_TUNER_ATTR_TYPE_GET_TUNER_NAME,                                         ///Get tuner name, parameter type is a pointer to a MI_U8 array. Max length of tuner name is size 64.

    E_MI_TUNER_ATTR_TYPE_VIF_SOUND_SYSTEM = 0x100,                               ///Set VIF Sound System, parameter type is pointer to MI_TUNER_SifStandardType_e
    E_MI_TUNER_ATTR_TYPE_VIF_BYPASS_AUDIO_FILTER,                                ///Set VIF bypass audio filter, parameter type is pointer to MI_BOOL: TRUE: bypass; FALSE: not bypass
    E_MI_TUNER_ATTR_TYPE_VIF_RESET,                                              ///Set VIF reset, parameter type is pointer to NULL
    E_MI_TUNER_ATTR_TYPE_LNB_CABLE,                                              ///Set LNB Cable Index, parameter type is a pointer to MI_TUNER_LnbCable_e

    E_MI_TUNER_ATTR_TYPE_T_T2_SCAN_MODE,                                         ///Set T/T2 scan mode: TRUE is scan mode, FALSE is normal channel switching mode.

    E_MI_TUNER_ATTR_TYPE_MAX
} MI_TUNER_AttrType_e;

typedef enum
{
    E_MI_TUNER_FREQUENCY_OFFSET_TYPE_BELOW_MINUS_187P5KHZ = 0,                    //offset <= -187.5
    E_MI_TUNER_FREQUENCY_OFFSET_TYPE_MINUS_187P5KHZ_TO_MINUS_162P5KHZ,            //-187.5 < offset <= -162.5
    E_MI_TUNER_FREQUENCY_OFFSET_TYPE_MINUS_162P5KHZ_TO_MINUS_137P5KHZ,            //-162.5 < offset <= -137.5
    E_MI_TUNER_FREQUENCY_OFFSET_TYPE_MINUS_137P5KHZ_TO_MINUS_112P5KHZ,            //-137.5 < offset <= -112.5
    E_MI_TUNER_FREQUENCY_OFFSET_TYPE_MINUS_112P5KHZ_TO_MINUS_87P5KHZ,             //-112.5 < offset <= -87.
    E_MI_TUNER_FREQUENCY_OFFSET_TYPE_MINUS_87P5KHZ_TO_MINUS_62P5KHZ,              //-87.5 < offset <= -62.5
    E_MI_TUNER_FREQUENCY_OFFSET_TYPE_MINUS_62P5KHZ_TO_MINUS_37P5KHZ,              //-62.5 < offset <= -37.5
    E_MI_TUNER_FREQUENCY_OFFSET_TYPE_MINUS_37P5KHZ_TO_MINUS_12P5KHZ,              //-37.5 < offset <=-12.5
    E_MI_TUNER_FREQUENCY_OFFSET_TYPE_MINUS_12P5KHZ_TO_PLUS_12P5KHZ,               //-12.5 < offset <= 12.5
    E_MI_TUNER_FREQUENCY_OFFSET_TYPE_PLUS_12P5KHZ_TO_PLUS_37P5KHZ,                //12.5 < offset <=37.5
    E_MI_TUNER_FREQUENCY_OFFSET_TYPE_PLUS_37P5KHZ_TO_PLUS_62P5KHZ,                //37.5 < offset <= 62.5
    E_MI_TUNER_FREQUENCY_OFFSET_TYPE_PLUS_62P5KHZ_TO_PLUS_87P5KHZ,                //62.5 < offset <= 87.5
    E_MI_TUNER_FREQUENCY_OFFSET_TYPE_PLUS_87P5KHZ_TO_PLUS_112P5KHZ,               //87.5 < offset <= 112.5
    E_MI_TUNER_FREQUENCY_OFFSET_TYPE_PLUS_112P5KHZ_TO_PLUS_137P5KHZ,              //112.5 < offset <= 137.5
    E_MI_TUNER_FREQUENCY_OFFSET_TYPE_PLUS_137P5KHZ_TO_PLUS_162P5KHZ,              //137.5 < offset <= 162.5
    E_MI_TUNER_FREQUENCY_OFFSET_TYPE_PLUS_162P5KHZ_TO_PLUS_187P5KHZ,              //162.5 < offset <= 187.5
    E_MI_TUNER_FREQUENCY_OFFSET_TYPE_ABOVE_PLUS_187P5KHZ,                         //offset > 187.5
    E_MI_TUNER_FREQUENCY_OFFSET_TYPE_MAX,                                         //offset out of the limitation of VIF
} MI_TUNER_FrequencyOffsetType_e;

typedef enum
{
    E_MI_TUNER_CALLBACK_EVENT_LOCK = (1<<0),               // Callback function get event, FE status is lock, event param is NULL
    E_MI_TUNER_CALLBACK_EVENT_UNLOCK = (1<<1),             // Callback function get event, FE status is unlock, event param is NULL
} MI_TUNER_CallbackEventType_e;

typedef enum
{
    E_MI_TUNER_FACTORY_CMD_ATV_VIF_REINIT = 0,                            //Init ATV VIF again
    E_MI_TUNER_FACTORY_CMD_ATV_VIF_SET_DESCRAMBLER_BOX_DELAY,             //Set descramble box delay
    E_MI_TUNER_FACTORY_CMD_ATV_VIF_MAX,                                   //Out of the range of VIF factory commands
} MI_TUNER_FactoryCmdAtvVif_e;

typedef enum
{
    E_MI_TUNER_FACTORY_CMD_GET_DEMOD_NAME = 0,                           //Get demod name
    E_MI_TUNER_FACTORY_CMD_GET_DEMOD_VERSION,                            //Get demod version
    E_MI_TUNER_FACTORY_CMD_GET_DEMOD_BUILD_NUM,                          //Get demod build number
    E_MI_TUNER_FACTORY_CMD_GET_DEMOD_CHANGE_LIST,                        //Get demod change list
    E_MI_TUNER_FACTORY_CMD_MAX,                                          //Out of the range
} MI_TUNER_FactoryCmdType_e;

typedef enum
{
    E_MI_TUNER_DEMOD_LOCK = 0,
    E_MI_TUNER_DEMOD_CHECKING,
    E_MI_TUNER_DEMOD_UNLOCK,
    E_MI_TUNER_DEMOD_MAX,                                        //Out of the range
} MI_TUNER_DemodLockStatus_e;

typedef MI_RESULT (*MI_TUNER_EventCallback)(MI_HANDLE hTuner, MI_U32 u32Event, void *pEventParams, void *pUserParams);

typedef struct MI_TUNER_CallbackInputParams_s
{
    MI_U64 u64CallbackId;                   ///[IN]: for multi-callback, use 0 for first register or single callback.
    MI_TUNER_EventCallback pfEventCallback;    ///[IN]: callback function pointer.
    MI_U32 u32EventFlags;                   ///[IN]: registered events which are bitwise OR operation.
    void * pUserParams;                     ///[IN]: for passing user-defined parameters.
} MI_TUNER_CallbackInputParams_t;

typedef struct MI_TUNER_CallbackOutputParams_s
{
    MI_U64 u64CallbackId;                   ///[OUT]: the returned ID for update or unregister callback.
} MI_TUNER_CallbackOutputParams_t;


typedef struct MI_TUNER_Caps_s
{
    MI_U32 u32MaxTunerSlot;                               ///[OUT]: max supporting tuner slot number
} MI_TUNER_Caps_t;


typedef struct MI_TUNER_FrontendType_s
{
    MI_TUNER_DvbType_e eDvbType;                           ///[OUT]: DVB type
    MI_TUNER_AtvType_e eAtvType;                           ///[OUT]: Atv Type
} MI_TUNER_FrontendType_t;

typedef struct MI_TUNER_IsdbtBer_s
{
    MI_S32 s32BerLayerA;                                    ///[OUT]:Ber Layer A
    MI_S32 s32BerLayerB;                                    ///[OUT]:Ber Layer B
    MI_S32 s32BerLayerC;                                    ///[OUT]:Ber Layer C
} MI_TUNER_IsdbtBer_t;

typedef struct MI_TUNER_SatParams_s
{
    MI_U8 szSatName[MI_TUNER_MAX_SATNAME_LEN+1];                                  ///[IN] Sat Name
    MI_U16 u16LoLof;                                                              ///[IN] low LOF value,unit MHz
    MI_U16 u16HiLof;                                                              ///[IN] high LOF value,unit MHz
    MI_TUNER_LnbType_e eLnbType;                                                  ///[IN] Single LOF or Double LOF
    MI_TUNER_DiseqcLevel_e eDiseqcLevel;                                          ///[IN] Single LOF or Double LOF
    MI_TUNER_ToneBurstType_e eToneburstType;                                      ///[IN] Single LOF or Double LOF
    MI_TUNER_SwtPort_e  eSwt10Port;                                               ///[IN] Single LOF or Double LOF
    MI_TUNER_SwtPort_e  eSwt11Port;                                               ///[IN] Single LOF or Double LOF
    MI_TUNER_22kSwitch_e e22KSwitch;                                              ///[IN] Single LOF or Double LOF
    MI_TUNER_LnbPwrSwitch_e eLnbPwrSwitch;                                        ///[IN] Single LOF or Double LOF
    MI_TUNER_0v12vSwitch_e e0v12vSwitch;                                          ///[IN] Single LOF or Double LOF
    MI_U8 u8Position;                                                             ///[IN] Motor position  bit8 1:USALS 0:DISEQC1.2
    MI_U16 u16Angle;                                                              ///[IN] Angle
    MI_BOOL bPorInvert;                                                           ///[IN] PorInvert
    MI_U16  u16CrossoverFreq;                                                     ///[IN] Crossover frequency for separating high band and low band value,unit MHz
} MI_TUNER_SatParams_t;

typedef struct MI_TUNER_LnbPower_s
{
    MI_TUNER_LnbPwrSwitch_e eLnbPower;                                   ///[IN] Lnb Power
    MI_U8 u8Polarity;                                                    ///[IN] Polarity
    MI_BOOL bPorInvert;                                                  ///[IN] PorInvert
} MI_TUNER_LnbPower_t;

typedef struct MI_TUNER_UnicableParams_s
{
    MI_TUNER_UnicableGen_e eUnicableGen;                        ///[IN]: 0:None(Disable)   1:Unicable SCD1   2:Unicable SCD2 (JESS)
    MI_U32 u32CurUserBandFreq;                                  ///[IN]: Current user band frequency
    MI_U8* pu8CmdBuf;                                           ///[IN]: for passing the Unicable DiseqC Command for blind scan
    MI_U8  u8CmdSize;                                           ///[IN]: for passing  the  command size
} MI_TUNER_UnicableParams_t;


/// Define tuning paramter of DVB-T front-end
typedef struct MI_TUNER_TerCarrierParams_s
{
    MI_U8                                u8PlpId;                                  ///< PLP ID                                                                               [IN]: Used for MI_TUNER_Tune       [OUT]:Used for MI_TUNER_GetTpsInfo
    MI_TUNER_TerBwMode_e                 eBandWidth;                               ///< Band width                                                                           [IN]: Used for MI_TUNER_Tune       [OUT]:Used for MI_TUNER_GetTpsInfo
    MI_TUNER_TerConstelType_e            eConstellation;                           ///< Constellation type                                                                  [IN]: Used for MI_TUNER_Tune       [OUT]:Used for MI_TUNER_GetTpsInfo
    MI_TUNER_TerHieType_e                eHierarchy;                               ///< Hierarchy                                                                             [IN]: Used for MI_TUNER_Tune       [OUT]:Used for MI_TUNER_GetTpsInfo
    MI_TUNER_TerGiType_e                 eGuardInterval;                           ///< Guard interval                                                                       [IN]: Used for MI_TUNER_Tune       [OUT]:Used for MI_TUNER_GetTpsInfo
    MI_TUNER_TerFftMode_e                eFftMode;                                 ///< Transmission mode                                                                [IN]: Used for MI_TUNER_Tune       [OUT]:Used for MI_TUNER_GetTpsInfo
    MI_TUNER_ConvCodeRateType_e          eHpCodeRate;                              ///< HP code rate                                                                         [IN]: Used for MI_TUNER_Tune       [OUT]:Used for MI_TUNER_GetTpsInfo
    MI_TUNER_ConvCodeRateType_e          eLpCodeRate;                              ///< LP code rate                                                                         [IN]: Used for MI_TUNER_Tune       [OUT]:Used for MI_TUNER_GetTpsInfo
    MI_TUNER_TerLevelSel_e               eLevelSel;                                ///< Select HP or LP level                                                              [IN]: Used for MI_TUNER_Tune       [OUT]:Used for MI_TUNER_GetTpsInfo
} MI_TUNER_TerCarrierParams_t;

/// Define tuning paramter of DVB-C front-end
typedef struct MI_TUNER_CabCarrierParams_s
{
    MI_TUNER_CabConstelType_e            eConstellation;                           ///< Constellation type                                                                     [IN]: Used for MI_TUNER_Tune       [OUT]:Used for MI_TUNER_GetTpsInfo
    MI_U16                               u16SymbolRate;                            ///< Symbol rate (Ksym/sec)                                                            [IN]: Used for MI_TUNER_Tune       [OUT]:Used for MI_TUNER_GetTpsInfo
    MI_TUNER_CabIqMode_e                 eIqMode;                                  ///< Iq Mode                                                                                  [IN]: Used for MI_TUNER_Tune       [OUT]:Used for MI_TUNER_GetTpsInfo
    MI_U8                                u8TapAssign;                              ///< Tap assign                                                                              [IN]: Used for MI_TUNER_Tune       [OUT]:Used for MI_TUNER_GetTpsInfo
    MI_U32                               u32FreqOffset;                            ///< Deprecated                                                                             [IN]: Used for MI_TUNER_Tune       [OUT]:Used for MI_TUNER_GetTpsInfo
    MI_U8                                u8TuneFreqOffset;                         ///< Requeset tuner freq offset                                                          [IN]: Used for MI_TUNER_Tune       [OUT]:Used for MI_TUNER_GetTpsInfo
    MI_TUNER_CabBw_e                     eBandwidth;                               ///< Bandwidth setting(6M/8M)                                                          [IN]: Used for MI_TUNER_Tune       [OUT]:Used for MI_TUNER_GetTpsInfo
    MI_S32                               s32FreqOffset;                            ///< Carrier frequency offset(Khz),It may be positive or negative value.      [IN]: Used for MI_TUNER_Tune       [OUT]:Used for MI_TUNER_GetTpsInfo
} MI_TUNER_CabCarrierParams_t;

/// Define tuning paramter of DVB-S front-end
typedef struct MI_TUNER_SatCarrierParams_s
{
    MI_TUNER_SatConstelType_e             eConstellation;                          ///< Constellation type                                                                [IN]: Used for MI_TUNER_Tune       [OUT]:Used for MI_TUNER_GetTpsInfo
    MI_TUNER_SatRollOffType_e             eRollOff;                                ///< Roll-Off factor                                                                     [IN]: Used for MI_TUNER_Tune      [OUT]: Used forMI_TUNER_GetTpsInfo
    MI_TUNER_SatIqMode_e                  eIqMode;                                 ///< IQ mode                                                                            [IN]: Used for MI_TUNER_Tune      [OUT]:Used for MI_TUNER_GetTpsInfo
    MI_TUNER_ConvCodeRateType_e           eCodeRate;                               ///< Converlution code rate                                                          [IN]: Used for MI_TUNER_Tune       [OUT]:Used for MI_TUNER_GetTpsInfo
    MI_U16                                u16SymbolRate;                           ///< Symbol rate (Ksym/sec)                                                       [IN]: Used for MI_TUNER_Tune      [OUT]:Used for MI_TUNER_GetTpsInfo
    MI_U8                                 u8Polarity;                              ///<0: Horizon; > 0(default 1): Vertical;                                         [IN]: Used for MI_TUNER_Tune       [OUT]:Used for MI_TUNER_GetTpsInfo
    MI_U8                                 u8SatId;                                 ///<Satellite ID                                                                         [IN]: Used for MI_TUNER_Tune       [OUT]:Used for MI_TUNER_GetTpsInfo
    MI_TUNER_SatParams_t                  stSatTune;                               ///<Satellite Parameters                                                             [IN]: Used for MI_TUNER_Tune       [OUT]:Used for MI_TUNER_GetTpsInfo
    MI_S32                                s32FreqOffset;                           ///< Carrier frequency offset(Khz),It may be positive or negative value.   Used for  [IN]:  MI_TUNER_Tune      [OUT]: MI_TUNER_GetTpsInfo
} MI_TUNER_SatCarrierParams_t;

typedef struct MI_TUNER_AtvCarrierParams_s
{
    MI_TUNER_AtvType_e                  eAtvType;                     //Atv tuner mode when tune       [IN]: Used for MI_TUNER_Tune      [OUT]: Used for MI_TUNER_GetTpsInfo
    MI_TUNER_SifStandardType_e          eAtvAudioStandard;            //Atv audio standard             [IN]: Used for MI_TUNER_Tune      [OUT]: Used for MI_TUNER_GetTpsInfo
    MI_TUNER_AtvTuneMode_e              eAtvTuneMode;                 //Atv tune mode                  [IN]: Used for MI_TUNER_Tune      [OUT]: Used for MI_TUNER_GetTpsInfo
    MI_BOOL                             bInFineTune;
} MI_TUNER_AtvCarrierParams_t;

/// Define carrier paramter of digital tuner
/// NOTE: When this typedef is modified, the apiChScan should be rebuild.
typedef struct MI_TUNER_FeCarrierParams_s
{
    MI_TUNER_FeTuneMode_e   eMode;                              /// tuning mode                       [IN]:  Used for MI_TUNER_Tune      [OUT]: Used for MI_TUNER_GetTpsInfo
    MI_U32                                u32Frequency;         ///RF frequency in KHZ unit        [IN]:  Used for MI_TUNER_Tune      [OUT]: Used for MI_TUNER_GetTpsInfo
    union
    {
        MI_TUNER_TerCarrierParams_t        stTerParam;          ///Paramters for DVB-T front-end    [IN]: Used for MI_TUNER_Tune    [OUT]: Used for  MI_TUNER_GetTpsInfo
        MI_TUNER_CabCarrierParams_t        stCabParam;          ///Paramters for DVB-C front-end   [IN]:  Used for MI_TUNER_Tune    [OUT]: Used for  MI_TUNER_GetTpsInfo
        MI_TUNER_SatCarrierParams_t        stSatParam;          ///Paramters for DVB-S front-end   [IN]:  Used for MI_TUNER_Tune    [OUT]: Used for  MI_TUNER_GetTpsInfo
        MI_TUNER_AtvCarrierParams_t        stAtvParam;          ///Paramters for ATV front-end       [IN]:  Used for MI_TUNER_Tune    [OUT]: Used for  MI_TUNER_GetTpsInfo
    };
} MI_TUNER_FeCarrierParams_t;

//for dvbs
typedef struct MI_TUNER_BlindscanChannelOutput_s
{
    MI_U16 u16TpNum;                            ///[OUT]: the returned value of TP Number
    MI_TUNER_FeCarrierParams_t *pstTpTable;     ///[OUT]: the returned value of TP Table
} MI_TUNER_BlindscanChannelOutput_t;

//parameter structure to initialize the tuner
typedef struct MI_TUNER_InitParams_s
{
    MI_U8 u8Reserved;                           ///[IN]: for reserved
} MI_TUNER_InitParams_t;

//parameter structure to open tuner device
typedef struct MI_TUNER_OpenParams_s
{
    MI_U8 u8FrontEndIndex;                       ///[IN]: for passing the FrontEndIndex to open tuner device
    MI_TUNER_DvbType_e eDvbType;                 ///[IN]: for passing the DVB TYPE to open tuner device
    MI_TUNER_AtvType_e eAtvType;                 ///[IN]: for passing the ATV Type to open tuner device
} MI_TUNER_OpenParams_t;

typedef struct MI_TUNER_QueryHandleParams_s
{
    MI_U8 u8FrontEndIdx;      //FE index number
} MI_TUNER_QueryHandleParams_t;

typedef struct MI_TUNER_FrequencyOffset_s
{
    MI_TUNER_FrequencyOffsetType_e eOffsetType; ///[OUT]: the returned value of  frequency Offset Type
    MI_S32 s32OffsetHz;                         ///[OUT]: the returned value of Offset in Hz
}MI_TUNER_FrequencyOffset_t;

typedef struct MI_TUNER_DiseqcSendCommandParams_s
{
    MI_U8* pu8CmdBuf;                           ///[IN]: for passing the Command
    MI_U8 u8CmdSize;                            ///[IN]: for passing  the  command size
}MI_TUNER_DiseqcSendCommandParams_t;

typedef struct MI_TUNER_DiseqcReceiveCommandParams_s
{
    MI_U8* pu8CmdBuf;
    MI_U8 u8CmdSize;
}MI_TUNER_DiseqcReceiveCommandParams_t;

typedef struct MI_TUNER_BlindscanStartParams_s
{
    MI_TUNER_SatParams_t *pstSatParams;                                 ///[IN] Satellite Parameters
    MI_U8 u8Polarity;                                                   ///[IN] Polarity
    MI_BOOL bIsHiLof;                                                   ///[IN] Is HiLof
    MI_U16 u16CustomIfRangeStart;                                       ///[IN] Blind scan start IF, if the value of u16CustomIfRangeStart and u16CustomIfRangeEnd both are zero, then use LoLof and HiLof to calculate IF
    MI_U16 u16CustomIfRangeEnd;                                         ///[IN] Blind scan end IF
    MI_TUNER_UnicableParams_t stUnicableParam;                          ///[IN] Unicable Parameters for Blind Scan
} MI_TUNER_BlindscanStartParams_t;

typedef struct MI_TUNER_BlindscanFeq_s
{
    MI_U8 u8Progress;                          ///[OUT]: the returned value of Progress
    MI_U8 u8FindNum;                           ///[OUT]: the returned value of find numbers
    MI_U16 u16DetectFreq;                           ///[OUT]: the returned value of current detect frequency (MHz)
}MI_TUNER_BlindscanFeq_t;

typedef struct MI_TUNER_SetPlpGroupId_s
{
    MI_U8 u8PlpId;                            ///[IN]: for passing  the PLP ID
    MI_U8 u8GroupId;                          ///[IN]: for passing  the Group ID
}MI_TUNER_SetPlpGroupId_t;

typedef struct MI_TUNER_ConnectedConds_s
{
    MI_BOOL bIsInput;                         ///[IN]: for passing  the direction for finding the connected module.
    MI_U32 u32Module;                         ///[IN]: for passing  the  module type of connected with TUNER.
    //if need other conditions add here
} MI_TUNER_ConnectedConds_t;

//-------------------------------------------------------------------------------------------------
//  Global Functions
//-------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------
/// @brief Get TUNER module capibilities.
/// @param[out] pstCaps: A pointer to structure MI_TUNER_Caps_t to retrieve the information of TUNER capabilities
/// @return MI_OK: Process success.
//------------------------------------------------------------------------------
MI_RESULT MI_TUNER_GetCaps(MI_TUNER_Caps_t *pstCaps);

//------------------------------------------------------------------------------
/// @brief Initialize tuner
/// @param[in] pstInitParams: init parameter
/// @return MI_OK: Process success
/// @return MI_HAS_INITED: tuner module has inited
/// @sa
/// @note
//------------------------------------------------------------------------------
MI_RESULT MI_TUNER_Init(const MI_TUNER_InitParams_t *pstInitParams);

//------------------------------------------------------------------------------
/// @brief Deinit the tuner
/// @param[in] None
/// @return MI_OK: Process success
/// @return MI_ERR_FAILED: Process failure
/// @sa
/// @note
//------------------------------------------------------------------------------
MI_RESULT MI_TUNER_DeInit(void);

//------------------------------------------------------------------------------
/// @brief Open a tuner device.
/// @param[in] pstOpenParams. Parameter to open tuner device
/// @param[out] phTuner. return tuner handle after opening success
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not inted.
/// @return MI_ERR_INVALID_PARAMETER: parameter error.
/// @return MI_ERR_RESOURCES: No available resource.
/// @return MI_ERR_FAILED: Process failed
//------------------------------------------------------------------------------
MI_RESULT MI_TUNER_Open(const MI_TUNER_OpenParams_t *pstOpenParams, MI_HANDLE *phTuner);

//------------------------------------------------------------------------------
/// @brief Close a tuner device.
/// @param[in] hTuner. tuner handle to close
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not inted.
/// @return MI_ERR_INVALID_HANDLE: Invalid handle.
/// @return MI_ERR_FAILED: Process failed
//------------------------------------------------------------------------------
MI_RESULT MI_TUNER_Close(MI_HANDLE hTuner);

//------------------------------------------------------------------------------
/// @brief Get Handle of the Tuner module.
/// @param[in]  pstQueryParams: A pointer to structure MI_TUNER_QueryHandleParams_t.
/// @param[out] phTuner: phTuner for retrieve an instance of Tuner interface.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: TUNER module Get Handle failed.
/// @return MI_ERR_INVALID_PARAMETR: Parameters is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_TUNER_GetHandle(const MI_TUNER_QueryHandleParams_t *pstQueryParams, MI_HANDLE *phTuner);

//------------------------------------------------------------------------------
/// @brief get frequency offset
/// @param[in] hTuner: The handle of TUNER module
/// @param[out] pstFrequencyOffsetParams: frequency offset
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_TUNER_GetFrequencyOffset(MI_HANDLE hTuner,  MI_TUNER_FrequencyOffset_t *pstFrequencyOffsetParams);

//------------------------------------------------------------------------------
/// @brief Set digital tuner Power on,off
/// @param[in] hTuner. tuner handle to process
/// @param[in] bEnPower  Power on or off
/// @return MI_OK: Process success
/// @return MI_ERR_NOT_INITED: Module not inted.
/// @return MI_ERR_INVALID_HANDLE: Invalid handle.
/// @return MI_ERR_FAILED: Process failure
/// @sa
/// @note
//------------------------------------------------------------------------------
MI_RESULT MI_TUNER_SetPower(MI_HANDLE hTuner, MI_BOOL bEnPower);

//------------------------------------------------------------------------------
/// @brief Tune tuner to RF channel by auto or manual mode
/// @param[in] hTuner. tuner handle to process
/// @param[in] pstFeCarrierParams Carrier parameters
/// @return MI_OK: Process success
/// @return MI_ERR_NOT_INITED: Module not inted.
/// @return MI_ERR_INVALID_HANDLE: Invalid handle.
/// @return MI_ERR_INVALID_PARAMETER: Parameter invalid
/// @return MI_ERR_FAILED: Process failure
/// @sa
/// @note
//------------------------------------------------------------------------------
MI_RESULT MI_TUNER_Tune(MI_HANDLE hTuner, MI_TUNER_FeCarrierParams_t *pstFeCarrierParams);

//------------------------------------------------------------------------------
/// @brief Report Estimated Maximum Lock Time of Tune2RF mode
/// @param[in] hTuner. tuner handle to process
/// @param[in] eMode Tuning mode (Auto or Manual)
/// @param[out] *u32LockTime Max lock time
/// @return MI_OK: Process success
/// @return MI_ERR_NOT_INITED: Module not inted.
/// @return MI_ERR_INVALID_HANDLE: Invalid handle.
/// @return MI_ERR_INVALID_PARAMETER: Parameter invalid
/// @return MI_ERR_FAILED: Process failure
/// @sa
/// @note
//------------------------------------------------------------------------------
MI_RESULT MI_TUNER_GetMaxLockTime(MI_HANDLE hTuner, MI_TUNER_FeTuneMode_e eMode, MI_U32 *pu32LockTime);

//------------------------------------------------------------------------------
/// @brief Get tuner lock status
/// @param[in] hTuner. tuner handle to process
/// @return MI_OK: Process success
/// @return MI_ERR_NOT_INITED: Module not inted.
/// @return MI_ERR_INVALID_HANDLE: Invalid handle.
/// @return MI_ERR_FAILED: Process failure
/// @sa
/// @note
//------------------------------------------------------------------------------
MI_RESULT MI_TUNER_GetLock(MI_HANDLE hTuner);

//------------------------------------------------------------------------------
/// @brief Reset tuner EWBS area code
/// @param[in] hTuner. tuner handle to process
/// @param[in] u16EwbsAreaCode. area code to process
/// @return MI_OK: Process success
/// @return MI_ERR_NOT_INITED: Module not inted.
/// @return MI_ERR_INVALID_HANDLE: Invalid handle.
/// @return MI_ERR_FAILED: Process failure
/// @sa
/// @note
//------------------------------------------------------------------------------
MI_RESULT MI_TUNER_ResetEwbsAreaCode(MI_HANDLE hTuner, MI_U16 u16EwbsAreaCode);

//------------------------------------------------------------------------------
/// @brief Switch tuner EWBS mode
/// @param[in] hTuner. tuner handle to process
/// @return MI_OK: Process success
/// @return MI_ERR_NOT_INITED: Module not inted.
/// @return MI_ERR_INVALID_HANDLE: Invalid handle.
/// @return MI_ERR_FAILED: Process failure
/// @sa
/// @note
//------------------------------------------------------------------------------
MI_RESULT MI_TUNER_SwitchToEwbsMode(MI_HANDLE hTuner);

//------------------------------------------------------------------------------
/// @brief Set tuner suspend in EWBS mode
/// @param[in] hTuner. tuner handle to process
/// @return MI_OK: Process success
/// @return MI_ERR_NOT_INITED: Module not inted.
/// @return MI_ERR_INVALID_HANDLE: Invalid handle.
/// @return MI_ERR_FAILED: Process failure
/// @sa
/// @note
//------------------------------------------------------------------------------
MI_RESULT MI_TUNER_SuspendToEwbsMode(MI_HANDLE hTuner);

//------------------------------------------------------------------------------
/// @brief Get tuner EWBS status
/// @param[in] hTuner. tuner handle to process
/// @param[out] peEwbsStatus. return EWBS status.
/// @return MI_OK: Process success
/// @return MI_ERR_NOT_INITED: Module not inted.
/// @return MI_ERR_INVALID_HANDLE: Invalid handle.
/// @return MI_ERR_FAILED: Process failure
/// @sa
/// @note
//------------------------------------------------------------------------------
MI_RESULT MI_TUNER_GetEwbsStatus(MI_HANDLE hTuner, MI_TUNER_DemodLockStatus_e *peEwbsStatus);

//------------------------------------------------------------------------------
/// @brief Get tuner parameter setting
/// @param[in] hTuner. tuner handle to process
/// @param[out] *pstCarrierParam Carrier parameters
/// @return MI_OK: Process success
/// @return MI_ERR_NOT_INITED: Module not inted.
/// @return MI_ERR_INVALID_HANDLE: Invalid handle.
/// @return MI_ERR_INVALID_PARAMETER: Parameter invalid
/// @return MI_ERR_FAILED: Process failure
/// @sa
/// @note
//------------------------------------------------------------------------------
MI_RESULT MI_TUNER_GetTpsInfo(MI_HANDLE hTuner, MI_TUNER_FeCarrierParams_t *pstFeCarrierParams);

//------------------------------------------------------------------------------
/// @brief Get tuner Snr
/// @param[in] hTuner. tuner handle to process
/// @param[out] *pu32SNR return Signal noise ratio
/// @return MI_OK: Process success
/// @return MI_ERR_NOT_INITED: Module not inted.
/// @return MI_ERR_INVALID_HANDLE: Invalid handle.
/// @return MI_ERR_INVALID_PARAMETER: Parameter invalid
/// @return MI_ERR_FAILED: Process failure
/// @sa
/// @note
//------------------------------------------------------------------------------
MI_RESULT MI_TUNER_GetSnr(MI_HANDLE hTuner, MI_U16 *pu16Snr);

//------------------------------------------------------------------------------
/// @brief Get the value from 0~100 by sigal quality
/// @param[in] hTuner. tuner handle to process
/// @param[out] *pu16Quality return signal quality value
/// @return MI_OK: Process success
/// @return MI_ERR_NOT_INITED: Module not inted.
/// @return MI_ERR_INVALID_HANDLE: Invalid handle.
/// @return MI_ERR_INVALID_PARAMETER: Parameter invalid
/// @return MI_ERR_FAILED: Process failure
/// @sa
/// @note
//------------------------------------------------------------------------------
MI_RESULT MI_TUNER_GetSignalQuality(MI_HANDLE hTuner, MI_U16 *pu16Quality);

//------------------------------------------------------------------------------
/// @brief Get the value from 0~100 by signal strength
/// @param[in] hTuner. tuner handle to process
/// @param[out] *pu16Strength return signal strength value
/// @return MI_OK: Process success
/// @return MI_ERR_NOT_INITED: Module not inted.
/// @return MI_ERR_INVALID_HANDLE: Invalid handle.
/// @return MI_ERR_FAILED: Process failure
/// @return MI_ERR_INVALID_PARAMETER: Parameter invalid
/// @sa
/// @note
//------------------------------------------------------------------------------
MI_RESULT MI_TUNER_GetSignalStrength(MI_HANDLE hTuner, MI_U16 *pu16Strength);

//------------------------------------------------------------------------------
/// @brief Get tuner Signal Power Strength
/// @param[in] hTuner. tuner handle to process
/// @param[out] *ps16Pwr return Signal power strength
/// @return MI_OK: Process success
/// @return MI_ERR_FAILED: Process failure
/// @return MI_ERR_NOT_INITED: Module not inted.
/// @return MI_ERR_INVALID_PARAMETER: Parameter invalid
/// @return MI_ERR_INVALID_HANDLE: Invalid handle.
/// @sa
/// @note
//------------------------------------------------------------------------------
MI_RESULT MI_TUNER_GetPwr(MI_HANDLE hTuner, MI_S16* ps16Pwr);

//------------------------------------------------------------------------------
/// @brief Get Demod Clock Rate
/// @param[in] hTuner. tuner handle to process
/// @param[out] *pu32ClockRate return Demod clock rate
/// @return MI_OK: Process success
/// @return MI_ERR_FAILED: Process failure
/// @return MI_ERR_NOT_INITED: Module not inted.
/// @return MI_ERR_INVALID_PARAMETER: Parameter invalid
/// @return MI_ERR_INVALID_HANDLE: Invalid handle.
/// @sa
/// @note
//------------------------------------------------------------------------------
MI_RESULT MI_TUNER_GetClockRate(MI_HANDLE hTuner, MI_U32 *pu32ClockRate);

//------------------------------------------------------------------------------
/// @brief Get channel power from digital tuner
/// @param[in] phTuner. tuner handle to process
/// @param[out] *ps32Pwr Channel power level
/// @return MI_OK: Process success
/// @return MI_ERR_NOT_INITED: Module not inted.
/// @return MI_ERR_INVALID_HANDLE: Invalid handle.
/// @return MI_ERR_INVALID_PARAMETER: Parameter invalid
/// @return MI_ERR_FAILED: Process failure
/// @sa
/// @note
//------------------------------------------------------------------------------
MI_RESULT MI_TUNER_GetPwrFromTuner(MI_HANDLE hTuner, MI_S32 *ps32Pwr);

//------------------------------------------------------------------------------
/// @brief Get tuner BER
/// @param[in] hTuner. tuner handle to process
/// @param[out] *ps32Ber Bit error ratio (n * 2^-32)
/// @return MI_OK: Process success
/// @return MI_ERR_NOT_INITED: Module not inted.
/// @return MI_ERR_INVALID_HANDLE: Invalid handle.
/// @return MI_ERR_FAILED: Process failure
/// @return MI_ERR_INVALID_PARAMETER: Parameter invalid
/// @sa
/// @note
//------------------------------------------------------------------------------
MI_RESULT MI_TUNER_GetBer(MI_HANDLE hTuner, MI_S32 *ps32Ber);

//------------------------------------------------------------------------------
/// @brief Send DiSEqC command Params
/// @param[in] hTuner. tuner handle to process
/// @param[in] pstDiseqcSendCommandParams Command parameters
/// @return MI_OK: Process success
/// @return MI_ERR_NOT_INITED: Module not inted.
/// @return MI_ERR_INVALID_HANDLE: Invalid handle.
/// @return MI_ERR_FAILED: Process failure
/// @sa
/// @note
//------------------------------------------------------------------------------
MI_RESULT MI_TUNER_DiseqcSendCommand(MI_HANDLE hTuner, MI_TUNER_DiseqcSendCommandParams_t  *pstDiseqcSendCommandParams);

//------------------------------------------------------------------------------
/// @brief Get Rx from DiSeqC 2.0 switch
/// @param[in] phTuner. tuner handle to process
/// @param[in] pu8Cmd. pointer to Rx byte array
/// @param[in] pu8CmdSize. pointer to size of Rx byte array
/// @return MI_OK: Process success
/// @return MI_ERR_NOT_INITED: Module not inted.
/// @return MI_ERR_INVALID_HANDLE: Invalid handle.
/// @return MI_ERR_FAILED: Process failure
/// @sa
/// @note
//------------------------------------------------------------------------------
MI_RESULT MI_TUNER_DiseqcReceiveCommand(MI_HANDLE hTuner, MI_TUNER_DiseqcReceiveCommandParams_t *pstDiseqcReceiveCommandParams);

//------------------------------------------------------------------------------
/// @brief Set supply tone 22KHz or 0KHz in LNB (Low-Noise Block)
/// @param[in] hTuner. tuner handle to process
/// @param[in] b22KOn Set 22KHz or not
/// @return MI_OK: Process success
/// @return MI_ERR_NOT_INITED: Module not inted.
/// @return MI_ERR_INVALID_HANDLE: Invalid handle.
/// @return MI_ERR_FAILED: Process failure
/// @sa
/// @note
//------------------------------------------------------------------------------
MI_RESULT MI_TUNER_Set22K(MI_HANDLE hTuner, MI_BOOL b22KOn);

//------------------------------------------------------------------------------
/// @brief Set 22K tone burst type in LNB
/// @param[in] phTuner. tuner handle to process
/// @param[in] eToneBurstType Set 22K tone burst type
///              E_MI_TUNER_TONE_BURST_TYPE_NONE
///              E_MI_TUNER_TONE_BURST_TYPE_0
///              E_MI_TUNER_TONE_BURST_TYPE_1
///              E_MI_TUNER_TONE_BURST_TYPE_MAX
/// @return MI_OK: Process success
/// @return MI_ERR_NOT_INITED: Module not inted.
/// @return MI_ERR_INVALID_HANDLE: Invalid handle.
/// @return MI_ERR_FAILED: Process failure
/// @sa
/// @note
//------------------------------------------------------------------------------
MI_RESULT MI_TUNER_Set22KToneBurstType(MI_HANDLE hTuner, MI_TUNER_ToneBurstType_e eToneBurstType);


//------------------------------------------------------------------------------
/// @brief Set LNB power
/// @param[in] hTuner. tuner handle to process
/// @param[in] eLNBPower LNB power supply voltage
///             EN_LNBPWR_OFF,
///             EN_LNBPWR_13OR18V,
///             EN_LNBPWR_13V,
///             EN_LNBPWR_18V,
/// @param[in] u8Polarity Polarity setting
///             0: Vertical
///             1: Horizontal
/// @param[in] bPorInvert Invert polarity or not
/// @return MI_OK: Process success
/// @return MI_ERR_NOT_INITED: Module not inted.
/// @return MI_ERR_INVALID_HANDLE: Invalid handle.
/// @return MI_ERR_FAILED: Process failure
/// @sa
/// @note
//------------------------------------------------------------------------------
MI_RESULT MI_TUNER_SetLnbPower(MI_HANDLE hTuner, MI_TUNER_LnbPower_t stLnbPower);

//------------------------------------------------------------------------------
/// @brief Set satellite parameters through DiSEqC to let satellite go to the specific position
/// @param[in] hTuner. tuner handle to process
/// @param[in] *pstSatParams Satellite parameters
/// @return MI_OK: Process success
/// @return MI_ERR_FAILED: Process failure
/// @return MI_ERR_NOT_INITED: Module not inted.
/// @return MI_ERR_INVALID_HANDLE: Invalid handle.
/// @return MI_ERR_INVALID_PARAMETER: Parameter invalid
/// @return MI_ERR_FAILED: Process failure
/// @sa
/// @note
//------------------------------------------------------------------------------
MI_RESULT MI_TUNER_DiseqcGoSatPos(MI_HANDLE hTuner, MI_TUNER_SatParams_t *pstSatParams);

//------------------------------------------------------------------------------
/// @brief Satellite blind-scan settings
/// @param[in] hTuner. tuner handle to process
/// @param[in] *pstStartParams Satellite scaning parameters
/// @return MI_OK: Process success
/// @return MI_ERR_NOT_INITED: Module not inted.
/// @return MI_ERR_INVALID_HANDLE: Invalid handle.
/// @return MI_ERR_INVALID_PARAMETER: Parameter invalid
/// @return MI_ERR_FAILED: Process failure
/// @sa
/// @note
//------------------------------------------------------------------------------
MI_RESULT MI_TUNER_BlindscanStart(MI_HANDLE hTuner, const MI_TUNER_BlindscanStartParams_t *pstStartParams);

//------------------------------------------------------------------------------
/// @brief Switch to next frequency
/// @param[in] hTuner. tuner handle to process
/// @param[out] *pbBlindscanEnd The flag record blind scan ends or not
/// @return MI_OK: Process success
/// @return MI_ERR_NOT_INITED: Module not inted.
/// @return MI_ERR_INVALID_HANDLE: Invalid handle.
/// @return MI_ERR_INVALID_PARAMETER: Parameter invalid
/// @return MI_ERR_FAILED: Process failure
/// @sa
/// @note
//------------------------------------------------------------------------------
MI_RESULT MI_TUNER_BlindscanGetNextFreq(MI_HANDLE hTuner, MI_BOOL *pbBlindscanEnd);

//------------------------------------------------------------------------------
/// @brief Get for current frequency finish
/// @param[in] hTuner. tuner handle to process
/// @param *pstBlindscanFeqParams
///              u8Progress Progress
///              u8FindNum Find numbers
/// @return MI_OK: Process success
/// @return MI_ERR_NOT_INITED: Module not inted.
/// @return MI_ERR_INVALID_HANDLE: Invalid handle.
/// @return MI_ERR_INVALID_PARAMETER: Parameter invalid
/// @return MI_ERR_FAILED: Process failure
/// @sa
/// @note
//------------------------------------------------------------------------------
MI_RESULT MI_TUNER_BlindscanWaitCurFeqFinished(MI_HANDLE hTuner, MI_TUNER_BlindscanFeq_t *pstBlindscanFeqParams);

//------------------------------------------------------------------------------
/// @brief Get channel in blindscan
/// @param[in] hTuner. tuner handle to process
/// @param[in] u16ReadStart
/// @param[out] *pstChannelParams
/// @return MI_OK: Process success
/// @return MI_ERR_NOT_INITED: Module not inted.
/// @return MI_ERR_INVALID_HANDLE: Invalid handle.
/// @return MI_ERR_INVALID_PARAMETER: Parameter invalid
/// @return MI_ERR_FAILED: Process failure
/// @sa
/// @note
//------------------------------------------------------------------------------
MI_RESULT MI_TUNER_BlindscanGetChannel(MI_HANDLE hTuner, MI_U16 u16ReadStart, MI_TUNER_BlindscanChannelOutput_t *pstChannelParams);

//------------------------------------------------------------------------------
/// @brief Cancel the blindscan
/// @param[in] hTuner. tuner handle to process
/// @return MI_OK: Process success
/// @return MI_ERR_NOT_INITED: Module not inted.
/// @return MI_ERR_INVALID_HANDLE: Invalid handle.
/// @return MI_ERR_FAILED: Process failure
/// @sa
/// @note
//------------------------------------------------------------------------------
MI_RESULT MI_TUNER_BlindscanCancel(MI_HANDLE hTuner);

//------------------------------------------------------------------------------
/// @brief End the blindscan
/// @param[in] hTuner. tuner handle to process
/// @return MI_OK: Process success
/// @return MI_ERR_NOT_INITED: Module not inted.
/// @return MI_ERR_INVALID_HANDLE: Invalid handle.
/// @return MI_ERR_FAILED: Process failure
/// @sa
/// @note
//------------------------------------------------------------------------------
MI_RESULT MI_TUNER_BlindscanEnd(MI_HANDLE hTuner);

//------------------------------------------------------------------------------
/// @brief Get frontend type
/// @param[in] hTuner. tuner handle to process
/// @param[out] *pstTunerFrontendType: Frontend type
/// @return MI_OK: Process success
/// @return MI_ERR_NOT_INITED: Module not inted.
/// @return MI_ERR_INVALID_HANDLE: Invalid handle.
/// @return MI_ERR_INVALID_PARAMETER: Parameter invalid
/// @sa
/// @note
//------------------------------------------------------------------------------
MI_RESULT MI_TUNER_GetFrontendType(MI_HANDLE hTuner, MI_TUNER_FrontendType_t *pstTunerFrontendType);

//------------------------------------------------------------------------------
/// @brief Set digital tuner loop through
/// @param[in] hTuner. tuner handle to process
/// @param[in] bOn on or off
/// @return MI_OK: Process success
/// @return MI_ERR_NOT_INITED: Module not inted.
/// @return MI_ERR_INVALID_HANDLE: Invalid handle.
/// @return MI_ERR_FAILED: Process failure
/// @sa
/// @note
//------------------------------------------------------------------------------
MI_RESULT MI_TUNER_SetLoopThrough(MI_HANDLE hTuner, MI_BOOL bOn);

//------------------------------------------------------------------------------
/// @brief Get PLP group ID
/// @param[in] hTuner. tuner handle to process
/// @param[in] u8PlpId PLP Id
/// @param[out] *pu8GroupId Group ID
/// @return MI_OK: Process success
/// @return MI_ERR_NOT_INITED: Module not inted.
/// @return MI_ERR_INVALID_HANDLE: Invalid handle.
/// @return MI_ERR_INVALID_PARAMETER: Parameter invalid
/// @return MI_ERR_FAILED: Process failure
/// @sa
/// @note
//------------------------------------------------------------------------------
MI_RESULT MI_TUNER_GetPlpGroupId(MI_HANDLE hTuner, MI_U8 u8PlpId, MI_U8 *pu8GroupId);

//------------------------------------------------------------------------------
/// @brief Get PLP Bitmap
/// @param[in] hTuner. tuner handle to process
/// @param[out] pu8PlpBitMap The buffer saved PLP Bitmap
/// @return MI_OK: Process success
/// @return MI_ERR_NOT_INITED: Module not inted.
/// @return MI_ERR_INVALID_HANDLE: Invalid handle.
/// @return MI_ERR_INVALID_PARAMETER: Parameter invalid
/// @return MI_ERR_FAILED: Process failure
/// @sa
/// @note
//------------------------------------------------------------------------------
MI_RESULT MI_TUNER_GetPlpBitMap(MI_HANDLE hTuner, MI_U8 *pu8PlpBitMap);

//------------------------------------------------------------------------------
/// @brief Set PLP (Physical Layer Pipe) group ID in DVBT2
/// @param[in] hTuner. tuner handle to process
/// @param[in] stSetPlpGroupIdParams
/// @param[in] u8PlpId PLP ID
/// @param[in] u8GroupId Group ID
/// @return MI_OK: Process success
/// @return MI_ERR_NOT_INITED: Module not inted.
/// @return MI_ERR_INVALID_HANDLE: Invalid handle.
/// @return MI_ERR_FAILED: Process failure
/// @sa
/// @note
//------------------------------------------------------------------------------
MI_RESULT MI_TUNER_SetPlpGroupId(MI_HANDLE hTuner, MI_TUNER_SetPlpGroupId_t stSetPlpGroupIdParams);

//------------------------------------------------------------------------------
/// @brief Set current demodulator type, dvbt or dvbt2
/// @param[in] hTuner. tuner handle to process
/// @param[in] u8Type Demodulator type
///             1: dvbt
///             2/others: dvbt2
/// @return MI_OK: Process success
/// @return MI_ERR_NOT_INITED: Module not inted.
/// @return MI_ERR_INVALID_HANDLE: Invalid handle.
/// @return MI_ERR_FAILED: Process failure
/// @sa
/// @note
//------------------------------------------------------------------------------
MI_RESULT MI_TUNER_SetDemodType(MI_HANDLE hTuner, MI_U8 u8Type);

//------------------------------------------------------------------------------
/// @brief Set TSP-in is serial mode or parallel mode
/// @param[in] hTuner. tuner handle to process
/// @param[in] bSerial Set serial mode
/// @return MI_OK: Process success
/// @sa
/// @note
//------------------------------------------------------------------------------
MI_RESULT MI_TUNER_SetTsSerial(MI_HANDLE hTuner, MI_BOOL bSerial);

//------------------------------------------------------------------------------
/// @brief Do demod reset
/// @param[in] hTuner. tuner handle to process
/// @param[in] bReset Do reset or not
/// @return MI_OK: Process success
/// @return MI_ERR_FAILED: Process failure
/// @sa
/// @note
//------------------------------------------------------------------------------
MI_RESULT MI_TUNER_Reset(MI_HANDLE hTuner, MI_BOOL bReset);

//------------------------------------------------------------------------------
/// @brief Set tuner module debug level.
/// @param[in] u32DebugLevel.
/// @return MI_OK: Set debug level success.
//------------------------------------------------------------------------------
MI_RESULT MI_TUNER_SetDebugLevel(MI_DBG_LEVEL u32DebugLevel);

//------------------------------------------------------------------------------
/// @brief get attr
/// @param[in] hTuner. tuner handle to process
/// @param[in] eAttrType assign which attr. user want to get
/// @param[in]  pInputParams: input params,set NULL if not necessary.
/// @param[in]  pOutputParams: Pointer to struct to retrieve the information accroding to eParamType
/// @return MI_OK: Process success
/// @return MI_ERR_FAILED: Process failure
/// @sa
/// @note
//------------------------------------------------------------------------------
MI_RESULT MI_TUNER_GetAttr(MI_HANDLE hTuner, MI_TUNER_AttrType_e eAttrType, const void * pInputParams, void * pOutputParams);

//------------------------------------------------------------------------------
/// @brief set attr
/// @param[in] hTuner. tuner handle to process
/// @param[in] eAttrType assign which attr. user want to set
/// @param[in] pAttrParams for user to set
/// @return MI_OK: Process success
/// @return MI_ERR_FAILED: Process failure
/// @sa
/// @note
//------------------------------------------------------------------------------
MI_RESULT MI_TUNER_SetAttr(MI_HANDLE hTuner, MI_TUNER_AttrType_e eAttrType, const void * pAttrParams);

//------------------------------------------------------------------------------
/// @brief Register the callback function for receiving the events of TUNER related.
/// @param[in] hPm: A Handle of a created TUNER instance.
/// @param[in] pstInputParams: A pointer to structure MI_TUNER_CallbackInputParams_t for events registered.
/// @param[out] pstOutputParams: A pointer to structure MI_TUNER_CallbackOutputParams_t.
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE: hanlde is invalid.
/// @return MI_ERR_INVALID_PARAMETER: parameters is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_TUNER_RegisterCallback(MI_HANDLE hTuner, const MI_TUNER_CallbackInputParams_t *pstInputParams, MI_TUNER_CallbackOutputParams_t *pstOutputParams);

//------------------------------------------------------------------------------
/// @brief UnRegister the callback function for receiving the events of TUNER related.
/// @param[in] hTuner: A Handle of a created TUNER instance.
/// @param[in] pstInputParams: A pointer to structure MI_TUNER_CallbackInputParams_t for events registered.
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE: hanlde is invalid.
/// @return MI_ERR_INVALID_PARAMETER: parameters is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_TUNER_UnRegisterCallback(MI_HANDLE hTuner, const MI_TUNER_CallbackInputParams_t *pstInputParams);



//------------------------------------------------------------------------------
/// @brief Get the element which is connected to the specified element.
/// @param[in] hTuner. tuner handle to process
/// @param[in] pstTunerConds: bIsinput-The direction for finding the connected module.
///                           u32ModuleType-The module type of connected with TUNER. it defined in mi_common.h with prefix MI_MODULE_TYPE_XXX.
///                                         If it is MI_MODULE_TYPE_NONE it find all type of connected modules.
///                                         e.g. MI_TUNER_GetConnectedNum(hTuner, FALSE, MI_MODULE_TYPE_TSIO, pu32ConnectedNum)
/// @param[out] pu32ConnectedNum: The number of connected handle
/// @return MI_OK: Process success.
//------------------------------------------------------------------------------
MI_RESULT MI_TUNER_GetConnectedNum(const MI_HANDLE hTuner, const MI_TUNER_ConnectedConds_t *pstTunerConds, MI_U32 *pu32ConnectedNum);

//------------------------------------------------------------------------------
/// @brief Set tuner ATV VIF
/// @param[in] hTuner. tuner handle to process
/// @param[in] eAtvVifFactoryCmd. Use case of VIF
/// @return MI_OK: Process success
/// @sa
/// @note
//------------------------------------------------------------------------------
MI_RESULT MI_TUNER_FactoryCmdApplyVif(MI_HANDLE hTuner, MI_TUNER_FactoryCmdAtvVif_e eAtvVifFactoryCmd);

//------------------------------------------------------------------------------
/// @brief Get the element which is connected to the specified element.
/// @param[in] hTuner. tuner handle to process
/// @param[in] bIsinput: The direction for finding the connected module.
/// @param[in] pstTunerConds: bIsinput-The direction for finding the connected module.
///                                        u32ModuleType-The module type of connected with TUNER. it defined in mi_common.h with prefix MI_MODULE_TYPE_XXX.
///                                        If it is MI_MODULE_TYPE_NONE it find all type of connected modules.
///                                        e.g. MI_TUNER_GetConnected(hTuner, FALSE, MI_MODULE_TYPE_TSIO, u32ConnectedNum, phConnectedArray)
/// @param[in] u32ConnectedNum: The number of get handle
/// @param[out] phConnectedArray: Pointer to handle buffer to retrieve the handle of MI module which is connected to the specified element with the specified direction.
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_FAILED: Process fail, no connection is available.
//------------------------------------------------------------------------------
MI_RESULT MI_TUNER_GetConnected(const MI_HANDLE hTuner, const MI_TUNER_ConnectedConds_t *pstTunerConds, const MI_U32 u32ConnectedNum, MI_HANDLE *phConnectedArray);

//------------------------------------------------------------------------------
/// @brief Factory Command get information
/// @param[in] hTuner. tuner handle to process
/// @param[in] eFactoryCmdType assign which attr. user want to get
/// @param[in] pInputParams: input params,set NULL if not necessary.
/// @param[out]  pOutputParams: Pointer to struct to retrieve the information accroding to eFactoryCmdType
/// @return MI_OK: Process success
/// @return MI_ERR_FAILED: Process failure
/// @sa
/// @note
//------------------------------------------------------------------------------
MI_RESULT MI_TUNER_FactoryCmdGetAttr(MI_HANDLE hTuner, MI_TUNER_FactoryCmdType_e eFactoryCmdType, const void * pInputParams, void * pOutputParams);
#ifdef __cplusplus
}
#endif

#endif///_MI_TUNER_H_

