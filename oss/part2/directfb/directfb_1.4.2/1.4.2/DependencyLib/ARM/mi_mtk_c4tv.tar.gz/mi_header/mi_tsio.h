/*------------------------------------------------------------------------------
 * MediaTek Inc. (C) 2018. All rights reserved.
 *
 * Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 *----------------------------------------------------------------------------*/

#ifndef _MI_TSIO_H_
#define _MI_TSIO_H_

#ifdef __cplusplus
extern "C" {
#endif

//-------------------------------------------------------------------------------------------------
//  Structures
//-------------------------------------------------------------------------------------------------

typedef enum
{
    E_MI_TSIO_PATH_TYPE_LIVE = 0,   ///< Live-in playback path
    E_MI_TSIO_PATH_TYPE_TSO  = 1,   ///< TSO path
    E_MI_TSIO_PATH_TYPE_FILE = 2,   ///< File-in playback path
} MI_TSIO_PathType_e;

typedef struct MI_TSIO_Caps_s
{
    MI_S32 s32MaxLiveInNum;         ///< [OUT]: max supported livein path
    MI_S32 s32MaxFileInNum;         ///< [OUT]: max supported filein path
    MI_S32 s32MaxVideoOutputNum;    ///< [OUT]: max supported video playback
    MI_S32 s32MaxAudioOutputNum;    ///< [OUT]: max supported audio playback
    MI_S32 s32MaxPvrNum;            ///< [OUT]: max support recorders simultaneously
    MI_S32 s32MaxTsoNum;            ///< [OUT]: max supported tso  path
} MI_TSIO_Caps_t;

typedef struct MI_TSIO_InitParams_s
{
    MI_U8 u8Reserved;               ///< [IN]: reserved for future
} MI_TSIO_InitParams_t;

typedef struct MI_TSIO_OpenParams_s
{
    MI_U8 *pszName;                 ///< [IN]: Custom defined module instance name which is a string with zero terminated.
    MI_TSIO_PathType_e ePathType;   ///< [IN]: parameters of path type
} MI_TSIO_OpenParams_t;

typedef struct MI_TSIO_QueryHandleParams_s
{
    MI_U8 *pszName;                 ///< [IN]: tsio handle with string name
}MI_TSIO_QueryHandleParams_t;

typedef struct MI_TSIO_ConnectInputParams_s
{
    MI_U8 u8Reserved;               ///< [IN]: reserved for future
} MI_TSIO_ConnectInputParams_t;

typedef struct MI_TSIO_ConnectedConds_s
{
    MI_BOOL bIsInput;
    MI_U32 u32Module;

    //if need other conditions add here
} MI_TSIO_ConnectedConds_t;

typedef struct MI_TSIO_DumpInfoParams_s
{
    MI_BOOL bAll;
} MI_TSIO_DumpInfoParams_t;


//-------------------------------------------------------------------------------------------------
//  Global Functions
//-------------------------------------------------------------------------------------------------
/// @brief Get TSIO module capibilities.
/// @param[out] pstCaps: A pointer to structure MI_TSIO_Caps_t to retrieve the information of TSIO capabilities
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_TSIO_GetCaps(MI_TSIO_Caps_t *pstCaps);

//------------------------------------------------------------------------------
/// @brief Init TSIO module.
/// @param[in] pstInitParams: A pointer to structure MI_TSIO_InitParams_t for initialization.
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_RESOURCES: No available resource.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_TSIO_Init(const MI_TSIO_InitParams_t *pstInitParams);

//------------------------------------------------------------------------------
/// @brief Finalize TSIO module.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_TSIO_DeInit(void);

//------------------------------------------------------------------------------
/// @brief Create a TSIO handle.
/// @param[in] pstOpenParams: Pointer to MI_TSIO_OpenParams_t for opening or creating a TSIO resource.
/// @param[out] phTsio: A handle pointer to retrieve an instance of a opened or created TSIO resource.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_MEMORY_ALLOCATE: Allocate memory failed.
/// @return MI_ERR_RESOURCES: No available resource.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_TSIO_Open(const MI_TSIO_OpenParams_t *pstOpenParams, MI_HANDLE *phTsio);

//------------------------------------------------------------------------------
/// @brief Destroy a TSIO handle.
/// @param[in] hTsio: An instance of a TSIO resource.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_TSIO_Close(MI_HANDLE hTsio);

//------------------------------------------------------------------------------
/// @brief Get TSIO handle
/// @param[in] pstQueryParams: Pointer to struct MI_TSIO_QueryHandleParams_t to speicified the parameters for tsio handle
/// @param[out] phTsio: A tsio handle
/// @return MI_OK: success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_TSIO_GetHandle(const MI_TSIO_QueryHandleParams_t *pstQueryParams, MI_HANDLE *phTsio);

//------------------------------------------------------------------------------
/// @brief For TSIO is a down stream module. TSIO connect its input with hInput, i.e. hInput --> hTsio
/// @param[in] hTsio: An instance of a TSIO resource.
/// @param[in] hInput: Handle of up stream to connect with Tsio's input
/// @param[in] pstParams: Pointer to struct MI_TSIO_ConnectInputParams_t to speicified the parameters for tsio connect input with hUpHdl
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE: invalid handle.
/// @return MI_ERR_FAILED: Process failed
//------------------------------------------------------------------------------
MI_RESULT MI_TSIO_ConnectInput(MI_HANDLE hTsio, MI_HANDLE hInput, const MI_TSIO_ConnectInputParams_t *pstParams);

//------------------------------------------------------------------------------
/// @brief For TSIO is a down stream module. TSIO disconnect its input with hInput, i.e. hInput -X-> hTsio
/// @param[in] hTsio: An instance of a TSIO resource.
/// @param[in] hInput: Handle of up stream to connect with Tsio's input
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE: invalid handle.
/// @return MI_ERR_FAILED: Process failed
//------------------------------------------------------------------------------
MI_RESULT MI_TSIO_DisconnectInput(MI_HANDLE hTsio, MI_HANDLE hInput);

//------------------------------------------------------------------------------
/// @brief Get the element which is connected to the specified element.
/// @param[in] hTsio: An instance of a TSIO resource.
/// @param[in] pstTsioConds: bIsinput-The direction for finding the connected module.
///                          u32ModuleType-The module type of connected with TSIO. it defined in mi_common.h with prefix MI_MODULE_TYPE_XXX.
///                                        If it is MI_MODULE_TYPE_NONE it find all type of connected modules.
///                                        e.g. MI_TSIO_GetConnectedNum(hTsio, TRUE, MI_MODULE_TYPE_TUNER, pu32ConnectedNum)
/// @param[out] pu32ConnectedNum: The number of connected handle
/// @return MI_OK: Process success.
//------------------------------------------------------------------------------
MI_RESULT MI_TSIO_GetConnectedNum(const MI_HANDLE hTsio, const MI_TSIO_ConnectedConds_t *pstTsioConds, MI_U32 *pu32ConnectedNum);

//------------------------------------------------------------------------------
/// @brief Get the element which is connected to the specified element.
/// @param[in] hTsio: An instance of a TSIO resource.
/// @param[in] pstTsioConds: bIsinput-The direction for finding the connected module.
///                          u32ModuleType-The module type of connected with TSIO. it defined in mi_common.h with prefix MI_MODULE_TYPE_XXX.
///                                        If it is MI_MODULE_TYPE_NONE it find all type of connected modules.
///                                        e.g. MI_TSIO_GetConnected(hTsio, TRUE, MI_MODULE_TYPE_TUNER, u32ConnectedNum, phConnectedArray)
/// @param[in] u32ConnectedNum: The number of get handle
/// @param[out] phConnectedArray: Pointer to handle buffer to retrieve the handle of MI module which is connected to the specified element with the specified direction.
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_FAILED: Process fail, no connection is available.
//------------------------------------------------------------------------------
MI_RESULT MI_TSIO_GetConnected(const MI_HANDLE hTsio, const MI_TSIO_ConnectedConds_t *pstTsioConds, const MI_U32 u32ConnectedNum, MI_HANDLE *phConnectedArray);

//------------------------------------------------------------------------------
/// @brief Set TSIO debug level.
/// @param[in] u32DebugLevel: Debug level defined in enum type MI_DBG_LEVEL
/// @return MI_OK: Set debug level success.
//------------------------------------------------------------------------------
MI_RESULT MI_TSIO_SetDebugLevel(MI_DBG_LEVEL u32DebugLevel);

//------------------------------------------------------------------------------
/// @brief Dump TSIO Info.
/// @return MI_OK: Dump information success.
//------------------------------------------------------------------------------

MI_RESULT MI_TSIO_DumpInfo(const MI_TSIO_DumpInfoParams_t *pstDumpInfoParams);

#ifdef __cplusplus
}
#endif

#endif///_MI_TSIO_H_
