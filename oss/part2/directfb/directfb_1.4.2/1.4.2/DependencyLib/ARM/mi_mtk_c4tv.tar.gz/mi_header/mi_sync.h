/*------------------------------------------------------------------------------
 * MediaTek Inc. (C) 2018. All rights reserved.
 *
 * Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 *----------------------------------------------------------------------------*/
//-------------------------------------------------------------------------------------------------
//  GetXxx/SetXxx and GetAttr/SetAttr coexist
//-------------------------------------------------------------------------------------------------

#ifndef _MI_SYNC_H_
#define _MI_SYNC_H_

#ifdef __cplusplus
extern "C" {
#endif

#include "mi_dmx.h"

//-------------------------------------------------------------------------------------------------
//  Defines
//-------------------------------------------------------------------------------------------------

//-------------------------------------------------------------------------------------------------
//  Structures
//-------------------------------------------------------------------------------------------------
typedef enum
{
    E_MI_SYNC_MODE_FREERUN = 0,             ///< No parameter. Disable AV sync mechanism, video & audio freerun depends on frame rate & sampling rate.
    E_MI_SYNC_MODE_PCR_MASTER,              ///< Parameter of pointer to struct MI_SYNC_PcrMasterParams_t. Use PCR to synchronize STC.
    E_MI_SYNC_MODE_PCR_AUDIO_AUTO,          ///< Parameter of pointer to struct MI_SYNC_PcrAudAutoParams_t. Default use PCR to synchronize STC, if the PCR is too difference to do AV sync, the sync controller will auto switch to audio master mode.
    E_MI_SYNC_MODE_AUDIO_MASTER,            ///< Parameter of pointer to struct MI_SYNC_AudMasterParams_t. Use audio PTS to synchronize the STC.
    E_MI_SYNC_MODE_VIDEO_INIT_AUDIO_MASTER, ///< Parameter of pointer to struct MI_SYNC_VidInitAudMasterParams_t. Init the STC by current video PTS and switch to audio master mode to synchronize STC.
    E_MI_SYNC_MODE_FPTS_INIT_AUDIO_MASTER, ///< Parameter of struct MI_SYNC_FptsInitAudMasterParams_t. Init the STC by min of video and audio First PTS, and switch to audio master mode to synchronize STC.
    E_MI_SYNC_MODE_VIDEO_MASTER,              ///< Parameter of struct MI_SYNC_VideoMasterParams_t. Init the STC by video first PTS, and adjust STC when the diff between VPTS and STC is larger then a threshold.

    E_MI_SYNC_MODE_MAX,                     ///< max definition of sync mode

} MI_SYNC_SyncMode_e;

/// Parameter type for MI_SYNC_SetAttr/MI_SYNC_GetAttr
typedef enum
{
    ///Attr type get/set min
    E_MI_SYNC_ATTR_TYPE_MIN,
    ///< the threshold of difference between STC & Reference Clock for adjust STC,
    ///< pInputParams is NULL,and pOutputParams is a pointer of MI_U32 value of the threshold value in milli-seconds
    E_MI_SYNC_ATTR_TYPE_ADJUST_STC_THRESHOLD = E_MI_SYNC_ATTR_TYPE_MIN,
    ///Attr type get/set max
    E_MI_SYNC_ATTR_TYPE_MAX,

    ///Attr type set min
    E_MI_SYNC_ATTR_TYPE_SET_MIN = 0x200,
    ///< Set only, video sync threshold by user manual, pInputParams is NULL, and pOutputParams is a pointer to MI_SYNC_VideoSyncAttr_t
    E_MI_SYNC_ATTR_TYPE_VIDEO_MANUAL_SYNC_THRESHOLD = E_MI_SYNC_ATTR_TYPE_SET_MIN,
    ///< Set only, audio sync threshold by user manual, pInputParams is NULL, and pOutputParams is a pointer to MI_SYNC_AudioSyncAttr_t.
    E_MI_SYNC_ATTR_TYPE_AUDIO_MANUAL_SYNC_THRESHOLD,
    ///< Set only, update video handle, parameter is a pointer to MI_HANDLE
    E_MI_SYNC_ATTR_TYPE_VIDEO_HANDLE = 0x300,
    ///< Set only, update audio handle, parameter is a pointer to MI_HANDLE
    E_MI_SYNC_ATTR_TYPE_AUDIO_HANDLE,
    ///Attr type set max
    E_MI_SYNC_ATTR_TYPE_SET_MAX,

} MI_SYNC_AttrType_e;


/// Control type for MI_SYNC_SyncCtrl_t
typedef enum
{
    /// AV sync parameter
    E_MI_SYNC_CTRL_TYPE_SYNC_PARAM = MI_BIT(0),        ///< For MI_SYNC_VideoSyncAttr_t, indicates bSyncEnable, u32SyncDelay, u32SyncTolerance are valid.
    /// Freerun threshold
    E_MI_SYNC_CTRL_TYPE_FREERUN_THRESHOLD = MI_BIT(1), ///< For MI_SYNC_VideoSyncAttr_t, indicates u32FreerunTh is valid.

} MI_SYNC_CtrlType_e;

typedef struct MI_SYNC_Caps_s
{
    MI_U32 u32MaxHwStcNum;              ///< [Out]: Max number of HW STC engines(hardware dependency)
    MI_U32 u32MaxHwStcSpeed;            ///< [Out]: Max speed rate(x1000) of HW STC(hardware dependency), eg. 2500 for x2.5 times
    MI_U32 u32MinHwStcSpeed;            ///< [Out]: Min speed rate(x1000) of HW STC(hardware dependency), eg. 167 for x0.167 times

}MI_SYNC_Caps_t;

typedef struct MI_SYNC_InitParams_s
{
    MI_U8 u8Reserved;                               ///<[IN]: reserved for future
} MI_SYNC_InitParams_t;

typedef struct MI_SYNC_OpenParams_s
{
    MI_U8 *pszName;                     ///<[IN]: custom defined sync name which is a string with zero terminated.

} MI_SYNC_OpenParams_t;

typedef struct MI_SYNC_QueryHandleParams_s
{
    MI_U8 *pszName;                     ///<[IN]: Query sync handle by finding the custom defined sync name which is a string with zero terminated.
    MI_HANDLE hVidDec;              ///<[IN]: Query sync handle by finding video handle
    MI_HANDLE hAudDec;              ///<]IN]: Query sync handle by finding audio handle
}MI_SYNC_QueryHandleParams_t;

typedef struct MI_SYNC_PcrMasterParams_s
{
    MI_DMX_PathParams_t stPathParams;   ///<[IN]: The DMX path includes the livein source where the PCR belongs to.
    MI_HANDLE hDmx;                     ///<[IN]: Always set to MI_HANDLE_NULL, reserved for internal using.
    MI_U16 u16PcrPid;                   ///<[IN]: PID of PCR timer

    MI_HANDLE hVidDec;                  ///<[IN]: Handle of MI_VIDEO, for notifying video decoder which STC engine is used
    MI_HANDLE hAudDec;                  ///<[IN]: Handle of MI_AUDIO, for notifying audio decoder which STC engine is used
} MI_SYNC_PcrMasterParams_t;

typedef struct MI_SYNC_AvMasterParams_s
{
    MI_HANDLE hVidDec;                  ///<[IN]: Handle of MI_VIDEO maybe used for getting current PTS info while playback
    MI_HANDLE hAudDec;                  ///<[IN]: Handle of MI_AUDIO used for getting current PTS info while playback

} MI_SYNC_AvMasterParams_t;

typedef struct MI_SYNC_SyncModeParams_s
{
    union
    {
        MI_SYNC_PcrMasterParams_t stPcrMst; ///<[IN]: Parameters of PCR_MASTER/PCR_AUDIO_AUTO/
        MI_SYNC_AvMasterParams_t stAvMst;   ///<[IN]: Parameters of AUDIO_MASTER/VIDEO_INIT_AUDIO_MASTER/FPTS_INIT_AUDIO_MASTER/VIDEO_MASTER
    };

} MI_SYNC_SyncModeParams_t;

typedef struct MI_SYNC_VideoSyncAttr_s
{
    MI_BOOL bManual;                                ///<[IN]: Video sync threshold by user manual setting
    MI_BOOL bSyncEnable;                            ///<[IN]: Video sync enable
    MI_U32 u32SyncDelay;                            ///<[IN]: Video sync delay time
    MI_U32 u32SyncTolerance;                        ///<[IN]: Video sync tolerance
    MI_U32 u32FreerunTh;                            ///<[IN]: Video freerun threshold
    MI_SYNC_CtrlType_e eCtrlType;                   ///<[IN]: Video sync control type
} MI_SYNC_VideoSyncAttr_t;

typedef struct MI_SYNC_AudioSyncAttr_s
{
    MI_U32 u32SyncDelay;                            ///<[IN]: Audio sync delay time. (unit: ms)
} MI_SYNC_AudioSyncAttr_t;

typedef struct MI_SYNC_StartParams_s
{
    MI_U8 u8Reserved;                               ///[IN]: reserved.
} MI_SYNC_StartParams_t;

typedef struct MI_SYNC_DumpInfoParams_s
{
    MI_BOOL bAll;                       ///[IN]: TRUE for print all resources, FALSE for print opened resources only.

}MI_SYNC_DumpInfoParams_t;

//-------------------------------------------------------------------------------------------------
//  Global Functions
//-------------------------------------------------------------------------------------------------

//------------------------------------------------------------------------------
/// @brief Get SYNC module capibilities.
/// @param[out] pstCaps: A pointer to structure MI_SYNC_Caps_t to retrieve the information of SYNC related capabilities
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_SYNC_GetCaps(MI_SYNC_Caps_t *pstCaps);

//------------------------------------------------------------------------------
/// @brief Initialize the SYNC module.
/// @param[in] pstInitParams: A pointer to structure MI_SYNC_InitParams_t for initialize MI_SYNC module.
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_FAILED: Process fail.
/// @note Please call this API before operating any other MI_SYNC interfaces
//------------------------------------------------------------------------------
MI_RESULT MI_SYNC_Init(const MI_SYNC_InitParams_t *pstInitParams);

//------------------------------------------------------------------------------
/// @brief Uninitialize the SYNC module, release internal resource.
/// @param[in] None
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_FAILED: Process fail.
/// @note Please call this API if the application doesn't need to use MI_SYNC module anymore.
//------------------------------------------------------------------------------
MI_RESULT MI_SYNC_DeInit(void);

//------------------------------------------------------------------------------
/// @brief Open a AV sync controller for the specified playback path and sync method.
/// @param[in] pstSyncParams: A pointer to structure MI_SYNC_OpenParams_t for opening a sync AV controller
/// @param[out] phSync: A pointer to retrieve a handle of a sync control
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_SYNC_Open(const MI_SYNC_OpenParams_t *pstOpenParams, MI_HANDLE *phSync);

//------------------------------------------------------------------------------
/// @brief Close a AV sync controller.
/// @param[in] hSync: A handle of a created AV sync controller
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_SYNC_Close(MI_HANDLE hSync);

//------------------------------------------------------------------------------
/// @brief Set a new AV sync mode.
/// @param[in] hSync: A handle of a created AV sync controller
/// @param[in] eSyncMode: A new AV sync mode to be selected
/// @param[in] pSyncModeParams: Pointer to struct MI_SYNC_SyncModeParams_t, detail plz see the definitation of MI_SYNC_SyncMode_e
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_SYNC_SetMode(MI_HANDLE hSync, MI_SYNC_SyncMode_e eSyncMode, MI_SYNC_SyncModeParams_t *pstSyncModeParams);

//------------------------------------------------------------------------------
/// @brief Get a AV sync mode from a created sync controller
/// @param[in] hSync: A handle of a created AV sync controller
/// @param[out] peSyncMode: Pointer to enum MI_SYNC_SyncMode_e to retrieve the sync mode of the specified sync controller.
/// @param[out] pSyncModeParams: Pointer to MI_SYNC_SyncModeParams_t to retrieve the parameters corresponding to the eSyncMode, detail plz see the definitation of MI_SYNC_SyncMode_e
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_SYNC_GetMode(MI_HANDLE hSync, MI_SYNC_SyncMode_e *peSyncMode, MI_SYNC_SyncModeParams_t *pstSyncModeParams);

//------------------------------------------------------------------------------
/// @brief Start run a AV sync controller
/// @param[in] hSync: A handle of a created AV sync controller
/// @param[in] pstStartParams:Pointer to MI_SYNC_StartParams_t set start parameters
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_SYNC_Start(MI_HANDLE hSync, const MI_SYNC_StartParams_t *pstStartParams);

//------------------------------------------------------------------------------
/// @brief Stop the AV sync controller
/// @param[in] hSync: A handle of a created AV sync controller
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_SYNC_Stop(MI_HANDLE hSync);

//------------------------------------------------------------------------------
/// @brief Restart the sync statemachine.
/// @param[in] hSync: A handle of a created AV sync controller
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_SYNC_ReSync(MI_HANDLE hSync);

//------------------------------------------------------------------------------
/// @brief Set a configuration for a created sync controller
/// @param[in] hSync: A handle of a created AV sync controller
/// @param[in] eAttrType: The parameter type to be set
/// @param[in] pAttrParams: The specified parameter correspoing to the enum type MI_SYNC_AttrType_e.
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_SYNC_SetAttr(MI_HANDLE hSync, MI_SYNC_AttrType_e eAttrType, const void *pAttrParams);

//------------------------------------------------------------------------------
/// @brief Get the a current configuration for a created sync controller
/// @param[in] hSync: A handle of a created AV sync controller
/// @param[in] eAttrType: The attribute type to be set
/// @param[in] pInputParams:A pointer of input parameters
/// @param[out] pOutputParams: The specified parameter correspoing to the enum type MI_SYNC_AttrType_e to retrieve the attribute.
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_SYNC_GetAttr(MI_HANDLE hSync, MI_SYNC_AttrType_e eAttrType, const void *pInputParams, void *pOutputParams);

//------------------------------------------------------------------------------
/// @brief Set the currenly STC value
/// @param[in] hSync: A handle of a created AV sync controller
/// @param[in] u64Stc: The current STC value with 90KHz unit
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_NOT_SUPPORT: Not supported.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_SYNC_SetStc(MI_HANDLE hSync, MI_U64 u64Stc);

//------------------------------------------------------------------------------
/// @brief Get the currenly STC value
/// @param[in] hSync: A handle of a created AV sync controller
/// @param[out] pu64Stc: A pointer to retrieve the current STC value with 90KHz unit
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_SYNC_GetStc(MI_HANDLE hSync, MI_U64 *pu64Stc);

//------------------------------------------------------------------------------
/// @brief Adjust the STC rate, base on 90KHz, i.e. STC rate = 90K * u32Rate / u32Scale
/// @param[in] hSync: A handle of a created AV sync controller
/// @param[in] u32Rate: adjust rate of STC
/// @param[in] u32Scale: unit of adjust rate, be careful that the scale is a global unit control for all STC engines.
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_SYNC_AdjustStcRate(MI_HANDLE hSync, MI_U32 u32Rate, MI_U32 u32Scale);

//------------------------------------------------------------------------------
/// @brief Get the currenly PCR value
/// @param[in] hSync: A handle of a created AV sync controller
/// @param[out] pu64Pcr: A pointer to retrieve the current PCR value with 90KHz unit
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_SYNC_GetPcr(MI_HANDLE hSync, MI_U64 *pu64Stc);

//------------------------------------------------------------------------------
/// @brief Get the exist sync handle corresponding to the specified ePlaybkPath
/// @param[in] pstQueryParams: a ponint to struct MI_SYNC_QueryHandleParams_t to specified the paramsters for querying a existed sync
/// @param[out] phSync: A pointer to retrieve the current STC value with 90KHz unit
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_SYNC_GetHandle(const MI_SYNC_QueryHandleParams_t *pstQueryParams, MI_HANDLE *phSync);

//------------------------------------------------------------------------------
/// @brief Dump SYNC Info.
/// @param[in] pstDumpInfoParams: A pointer to structure MI_SYNC_DumpInfoParams_t for info dump.
/// @return MI_OK: Dump information success.
/// @return MI_ERR_NOT_SUPPORT: MI_ENABLE_DBG config is not defined as 1
//------------------------------------------------------------------------------
MI_RESULT MI_SYNC_DumpInfo(const MI_SYNC_DumpInfoParams_t *pstDumpInfoParams);

/// @brief Set SYNC debug level.
/// @param[in] u32DebugLevel: Debug level defined in enum type MI_DBG_LEVEL
/// @return MI_OK: Set debug level success.
//------------------------------------------------------------------------------
MI_RESULT MI_SYNC_SetDebugLevel(MI_DBG_LEVEL u32DebugLevel);






#ifdef __cplusplus
}
#endif

#endif///_MI_SYNC_H_


