/*------------------------------------------------------------------------------
 * MediaTek Inc. (C) 2018. All rights reserved.
 *
 * Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 *----------------------------------------------------------------------------*/
//-------------------------------------------------------------------------------------------------
//  Use GetAttr/SetAttrr only
//-------------------------------------------------------------------------------------------------

#ifndef _MI_DSC_H_
#define _MI_DSC_H_

#ifdef __cplusplus
extern "C" {
#endif

#include "mi_dmx.h"

//-------------------------------------------------------------------------------------------------
//  Defines - Constant
//-------------------------------------------------------------------------------------------------
#define MI_DSC_ENGINE_ID_MASK                       (0xFFF00000)
#define MI_DSC_ENGINE_ID_TEE_MANAGE                 (0x3C800000)    /// < Specify the DSC engine for the secure world using
#define MI_DSC_ENGINE_ID_REE_MANAGE                 (0x3C200000)    /// < Specify the DSC engine for the normal world using
#define MI_DSC_ENGINE_ID_TEE_ALLOCATE               (0x3C400000)    /// < Get the free DSC engine from the normal world, and for secure world using

//-------------------------------------------------------------------------------------------------
//  Defines - Macros
//-------------------------------------------------------------------------------------------------

//-------------------------------------------------------------------------------------------------
//  Types - Enums
//-------------------------------------------------------------------------------------------------
typedef enum
{
    E_MI_DSC_ALGO_CSA_MIN,                                  /// < Descramble algorithm: CSA Min
    E_MI_DSC_ALGO_CSA = E_MI_DSC_ALGO_CSA_MIN,              /// < Descramble algorithm: CSA
    E_MI_DSC_ALGO_CSA3,                                     /// < Descramble algorithm: CSA3
    E_MI_DSC_ALGO_CSA_CONFORMANCE,                          /// < Descramble algorithm: CSA Conformance Mode
    E_MI_DSC_ALGO_CSA_MAX,                                  /// < Descramble algorithm: CSA Max

    E_MI_DSC_ALGO_AES_MIN = 0x100,                          /// < Descramble algorithm: AES Min
    E_MI_DSC_ALGO_AES_CBC = E_MI_DSC_ALGO_AES_MIN,          /// < Descramble algorithm: AES CBC
    E_MI_DSC_ALGO_AES_ECB,                                  /// < Descramble algorithm: AES ECB
    E_MI_DSC_ALGO_AES_SCTE52,                               /// < Descramble algorithm: AES SCTE52
    E_MI_DSC_ALGO_AES_MAX,                                  /// < Descramble algorithm: AES Max

    E_MI_DSC_ALGO_TDES_MIN = 0x200,                         /// < Descramble algorithm: TDES Min
    E_MI_DSC_ALGO_TDES_ECB = E_MI_DSC_ALGO_TDES_MIN,        /// < Descramble algorithm: TDES ECB
    E_MI_DSC_ALGO_TDES_SCTE52,                              /// < Descramble algorithm: TDES SCTE52
    E_MI_DSC_ALGO_TDES_MAX,                                 /// < Descramble algorithm: TDES Max

    E_MI_DSC_ALGO_DES_MIN = 0x300,                          /// < Descramble algorithm: DES Min
    E_MI_DSC_ALGO_DES = E_MI_DSC_ALGO_DES_MIN,              /// < Descramble algorithm: DES ECB
    E_MI_DSC_ALGO_DES_MAX,                                  /// < Descramble algorithm: DES Max

    E_MI_DSC_ALGO_MULTI2_MIN = 0x400,                       /// < Descramble algorithm: Multi2 Min
    E_MI_DSC_ALGO_MULTI2 = E_MI_DSC_ALGO_MULTI2_MIN,        /// < Descramble algorithm: Multi2
    E_MI_DSC_ALGO_MULTI2_MAX,                               /// < Descramble algorithm: Multi2 Max

    E_MI_DSC_ALGO_MAX,
} MI_DSC_Algo_e;

typedef enum
{
    E_MI_DSC_KEY_TYPE_EVEN = 0,                                      /// < Even key type
    E_MI_DSC_KEY_TYPE_ODD,                                           /// < Odd key type
} MI_DSC_KeyType_e;

typedef enum
{
    ///Attr type set min
    E_MI_DSC_ATTR_TYPE_SET_MIN,
    ///Only SET, Set multi2 systemkey, paramter is a pointer to struct MI_DSC_Multi2SystemKeyInfo_t
    E_MI_DSC_ATTR_TYPE_MULTI2_SYSTEM_KEY = E_MI_DSC_ATTR_TYPE_SET_MIN,
    ///Only SET, Set multi2 round, paramter is a pointer to MI_U32
    E_MI_DSC_ATTR_TYPE_MULTI2_ROUND,
    ///Attr type set max
    E_MI_DSC_ATTR_TYPE_SET_MAX,

    ///Attr type get min
    E_MI_DSC_ATTR_TYPE_GET_MIN = 0x100,
    ///Only GET, Get driver dscmb id, parameter is a pointer to MI_U32
    E_MI_DSC_ATTR_TYPE_GET_DSC_ID = E_MI_DSC_ATTR_TYPE_GET_MIN,
    ///Only GET, Get driver dscmb engine ID, parameter is a pointer to MI_U32
    E_MI_DSC_ATTR_TYPE_GET_DSC_ENGINE_ID,
    ///Attr type get max
    E_MI_DSC_ATTR_TYPE_GET_MAX,

    ///Attr type get/set min
    E_MI_DSC_ATTR_TYPE_MIN = 0x200,
    ///Attr type get/set max
    E_MI_DSC_ATTR_TYPE_MAX,
} MI_DSC_AttrType_e;

typedef enum
{
    E_MI_DSC_CA_VENDOR_ID_INVALID     = 0,
    E_MI_DSC_CA_VENDOR_ID_NDS         = 1,
    E_MI_DSC_CA_VENDOR_ID_NAGRA       = 2,
    E_MI_DSC_CA_VENDOR_ID_VIACCESS    = 3,
    E_MI_DSC_CA_VENDOR_ID_IRDETO      = 4,
    E_MI_DSC_CA_VENDOR_ID_VMX         = 5,
    E_MI_DSC_CA_VENDOR_ID_SMI         = 6,     /// < for SMI and CRI
    E_MI_DSC_CA_VENDOR_ID_CONAX       = 7,
    E_MI_DSC_CA_VENDOR_ID_LATENS      = 8,
    E_MI_DSC_CA_VENDOR_ID_ECHOSTAR    = 9,
    E_MI_DSC_CA_VENDOR_ID_DRM         = 10,
    E_MI_DSC_CA_VENDOR_ID_DRE         = 11,
    E_MI_DSC_CA_VENDOR_ID_CTI         = 12,
    E_MI_DSC_CA_VENDOR_ID_SUMA        = 13,
    E_MI_DSC_CA_VENDOR_ID_TFCA        = 14,
    E_MI_DSC_CA_VENDOR_ID_NSTV        = 15,
    E_MI_DSC_CA_VENDOR_ID_BESTCAS     = 16,
    E_MI_DSC_CA_VENDOR_ID_DEFAULT     = 17,
    E_MI_DSC_CA_VENDOR_ID_MAX,
} MI_DSC_CaVendorId_e;

typedef enum
{
    E_MI_DSC_PURPOSE_LIVE_PLAYBACK,
    E_MI_DSC_PURPOSE_PVR_RECORD,
    E_MI_DSC_PURPOSE_FILE_PLAYBACK,
    E_MI_DSC_PURPOSE_MAX,
} MI_DSC_Purpose_e;

typedef enum
{
    E_MI_DSC_SCRAMBLE_TYPE_SCRAMBLE,
    E_MI_DSC_SCRAMBLE_TYPE_RESCRAMBLE,
} MI_DSC_ScramleType_e;

typedef enum
{
    E_MI_DSC_ENG_DSCMB,                                    /// < Engine type of decrambler
    E_MI_DSC_ENG_SCMB,                                     /// < Engine type of scrambler, for using re-scramble feature
} MI_DSC_EngType_e;

//-------------------------------------------------------------------------------------------------
//  Types - Structures
//-------------------------------------------------------------------------------------------------
typedef struct MI_DSC_InitParams_s
{
    MI_U8 u8Reserved;           ///[IN]: Reserved
} MI_DSC_InitParams_t;

typedef struct MI_DSC_OpenParams_s
{
    MI_U8 * pszName;                                        ///[IN] < Custom defined module instance name which is a string with zero terminated.
    MI_U32 u32DscId;                                        ///[IN] < descrambler ID
    MI_DSC_Algo_e eDscAlgo;                                 ///[IN] < Config algorithm of descrambler
    MI_DMX_PathParams_t stPathParams;                       ///[IN] < Indicate the data path of DMX pid filter, identical with MI_DMX_Path_e
    MI_DSC_CaVendorId_e eCaVendorId;
    MI_DSC_Purpose_e ePurpose;                              ///[IN] < To distinguish Live Playback or PVR Record
} MI_DSC_OpenParams_t;

typedef struct MI_DSC_ConnectParams_s
{
    MI_U16 u16Pid;                                          ///[IN] < The PID used to connect/disconnect dscrambler and DMX pid filter
} MI_DSC_ConnectParams_t;

typedef struct MI_DSC_KeyInfo_s
{
    MI_DSC_KeyType_e eKeyType;                              ///[IN] < Key type of CW
    MI_U32 u32Len;                                          ///[IN] < Key length of CW
    MI_U8 *pu8Cw;                                           ///[IN] < Control word
    MI_DSC_EngType_e eDscEngType;                           ///[IN] < Engine type: DSCMB or SCMB
} MI_DSC_KeyInfo_t;

typedef struct MI_DSC_Iv_s
{
    MI_DSC_KeyType_e eKeyType;                              ///[IN] < Key type of IV
    MI_U32 u32Len;                                          ///[IN] < Key length of IV
    MI_U8 *pu8Iv;                                           ///[IN] < Initial vector
    MI_DSC_EngType_e eDscEngType;                           ///[IN] < Engine type: DSCMB or SCMB
} MI_DSC_Iv_t;

typedef struct MI_DSC_Multi2SystemKeyInfo_s
{
    MI_U32 u32Len;                                          ///[IN] < Key length of multi2 systemkey
    MI_U8 *pu8SystemKey;                                    ///[IN] < System key
} MI_DSC_Multi2SystemKeyInfo_t;

typedef struct MI_DSC_DumpInfoParams_s
{
    MI_BOOL bAll;                             ///[IN] on to dump info
}MI_DSC_DumpInfoParams_t;

typedef struct MI_DSC_ScrambleParams_s
{
    MI_DSC_Algo_e eDscAlgo;                                 ///[IN] < Config algorithm of scrambler
    MI_DSC_ScramleType_e eScramleType;                      ///[IN] < Config Scramle Type of scrambler
}MI_DSC_ScrambleParams_t;


typedef struct MI_DSC_QueryHandleParams_s
{
    MI_U8 *pszName;                                    ///[IN]: dsc handle with string name.
}MI_DSC_QueryHandleParams_t;

//-------------------------------------------------------------------------------------------------
//  Functions
//-------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------
/// @brief Init DSC module.
/// @param[in] pstInitParam: A pointer to structure MI_DSC_InitParams_t for initialization.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_DSC_Init(const MI_DSC_InitParams_t *pstInitParams);

//------------------------------------------------------------------------------
/// @brief Finalize DSC module.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_DSC_DeInit(void);

//------------------------------------------------------------------------------
/// @brief Open a DSC handle.
/// @param[in] pstOpenParam: A pointer to structure MI_DSC_OpenParams_t for open descrambler.
/// @param[out] phDsc: A handle pointer to retrieve an instance of a created descrambler.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_RESOURCES: No available resource.
//------------------------------------------------------------------------------
MI_RESULT MI_DSC_Open(const MI_DSC_OpenParams_t *pstOpenParams, MI_HANDLE *phDsc);

//------------------------------------------------------------------------------
/// @brief Close a DSC handle.
/// @param[in] hDsc: An instance of a created descrambler.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_DSC_Close(MI_HANDLE hDsc);

//------------------------------------------------------------------------------
/// @brief Connect descrambler with a certain PID filter.
/// @param[in] hDsc: An instance of a created descrambler.
/// @param[in] pstParam: A pointer to structure MI_DSC_ConnectParams_t for connecting with DMX pid filter.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_DSC_Connect(MI_HANDLE hDsc, MI_DSC_ConnectParams_t *pstParams);

//------------------------------------------------------------------------------
/// @brief Disconnect descrambler with a certain PID filter.
/// @param[in] hDsc: An instance of a created descrambler.
/// @param[in] pstParam: A pointer to structure MI_DSC_ConnectParams_t for disconnecting with DMX pid filter.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_DSC_Disconnect(MI_HANDLE hDsc, MI_DSC_ConnectParams_t *pstParams);

//------------------------------------------------------------------------------
/// @brief Set control word to dscrambler handle.
/// @param[in] hDsc: An instance of a created descrambler.
/// @param[in] pstKeyInfo: A pointer to structure MI_DSC_KeyInfo_t for setting CW.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_DSC_SetKey(MI_HANDLE hDsc, MI_DSC_KeyInfo_t *pstKeyInfo);

//------------------------------------------------------------------------------
/// @brief Set initial vector to dscrambler handle.
/// @param[in] hDsc: An instance of a created descrambler.
/// @param[in] pstIv: A pointer to structure MI_DSC_Iv_t for setting IV.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_DSC_SetIv(MI_HANDLE hDsc, MI_DSC_Iv_t *pstIv);

//------------------------------------------------------------------------------
/// @brief set dsc attribute
/// @param[in] hDsc: An instance of a created descrambler.
/// @param[in] eAttrType parameter type
/// @param[in] pAttrParams User parameter
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_DSC_SetAttr(MI_HANDLE hDsc, MI_DSC_AttrType_e eAttrType, const void *pAttrParams);

//------------------------------------------------------------------------------
/// @brief Get dsc attribute
/// @param[in] hDsc: An instance of a created descrambler.
/// @param[in] eAttrType attributes type
/// @param[in] pInputParams input params
/// @param[out] pOutputParams A pointer to to get attribute corresponding to the eAttrType. The prototype of pOutputparams plz see the description of enum MI_DSC_AttrType_e
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_DSC_GetAttr(MI_HANDLE hDsc, MI_DSC_AttrType_e eAttrType, const void *pInputParams, void *pOutputParams);

//------------------------------------------------------------------------------
/// @brief enable scramble
/// @param[in] hDsc: An instance of a created descrambler.
/// @param[in] pstScrambleParams: scrambler parameter
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_DSC_EnableScramble(MI_HANDLE hDsc, MI_DSC_ScrambleParams_t *pstScrambleParams);


//------------------------------------------------------------------------------
/// @brief disable scramble
/// @param[in] hDsc: An instance of a created descrambler.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_DSC_DisableScramble(MI_HANDLE hDsc);


//------------------------------------------------------------------------------
/// @brief Dump DSC Info.
/// @param[in]  pstDumpInfoParams: struct for printing resources .
/// @return MI_OK: Dump information success.
//------------------------------------------------------------------------------
MI_RESULT MI_DSC_DumpInfo(const MI_DSC_DumpInfoParams_t *pstDumpInfoParams);

//------------------------------------------------------------------------------
/// @brief Set DSC debug level.
/// @param[in] u32DebugLevel.
/// @return MI_OK: Set debug level success.
//------------------------------------------------------------------------------
MI_RESULT MI_DSC_SetDebugLevel(MI_DBG_LEVEL u32DebugLevel);


//------------------------------------------------------------------------------
/// @brief get DSC handle.
/// @param[in]  pstQueryParams: Query parameters
/// @param[out] *phDsc: dsc handler
/// @return MI_OK: Get dsc handle success.
/// @return MI_CONTINUE: There is not any handle match this query name.
/// @return MI_ERR_FAILED: dsc control failed
/// @return MI_ERR_INVALID_PARAMETER: parameter null
//------------------------------------------------------------------------------
MI_RESULT MI_DSC_GetHandle(const MI_DSC_QueryHandleParams_t *pstQueryParams, MI_HANDLE *phDsc);



#ifdef __cplusplus
}
#endif

#endif///_MI_DSC_H_


