/*------------------------------------------------------------------------------
 * MediaTek Inc. (C) 2018. All rights reserved.
 *
 * Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 *----------------------------------------------------------------------------*/

#ifndef _MI_UART_H_
#define _MI_UART_H_

#ifdef __cplusplus
extern "C" {
#endif

//-------------------------------------------------------------------------------------------------
//  Defines
//-------------------------------------------------------------------------------------------------
#define MI_UART_RXMODE_BUFSIZE_MAX  (32*1024)//max 32KB

//-------------------------------------------------------------------------------------------------
//  Structures
//-------------------------------------------------------------------------------------------------
typedef enum
{
    E_MI_UART_BAUDRATE_INVALID= -1,
    E_MI_UART_BAUDRATE_19200=0,
    E_MI_UART_BAUDRATE_38400,
    E_MI_UART_BAUDRATE_57600,
    E_MI_UART_BAUDRATE_230400,
    E_MI_UART_BAUDRATE_115200,
    E_MI_UART_BAUDRATE_460800,
} MI_UART_Baudrate_e;

typedef enum
{
    E_MI_UART_PORT_INVALID = -1,
    E_MI_UART_PORT_0,
    E_MI_UART_PORT_1,
    E_MI_UART_PORT_2,
    E_MI_UART_PORT_3,
    E_MI_UART_PORT_4,
} MI_UART_PortType_e;

typedef enum
{
    E_MI_UART_INVALID = -1,
    E_MI_UART_PIU_UART0,
    E_MI_UART_PIU_UART1,
    E_MI_UART_PIU_UART2,
    E_MI_UART_PIU_FUART0,
    E_MI_UART_HK51_UART0,
    E_MI_UART_HK51_UART1,
    E_MI_UART_VD51_UART0,
    E_MI_UART_VD51_UART1,
    E_MI_UART_DMD51_UART0,
    E_MI_UART_DMD51_UART1,
    E_MI_UART_VDEC,
    E_MI_UART_TSP,
    E_MI_UART_AEON,
    E_MI_UART_AEON_R2,
    E_MI_UART_AEON_AUDIO_R2,
    E_MI_UART_SECURE_R2,
    E_MI_UART_USB_CONVERTER,
    E_MI_UART_OFF,
} MI_UART_DeviceType_e;

typedef enum
{
    E_MI_UART_EXP_LOG_TYPE_USB = 0,
    E_MI_UART_EXP_LOG_TYPE_NUM,
} MI_UART_ExportLogType_e;

typedef enum
{
    E_MI_UART_EVENT_TYPE_POLL_READ_DATA_READY = MI_BIT(0),   ///< notify uart poll read data ready, pEventParam is MI_U8*
    E_MI_UART_EVENT_TYPE_INTERRUPT_READ_DATA_READY = MI_BIT(1),   ///< notify interrupt read data ready, pEventParam is MI_U8*
}MI_UART_EventType_e;

typedef struct MI_UART_InitParams_s
{
    MI_U8 u8Reserved;        ///[IN]: reserved
} MI_UART_InitParams_t;

typedef struct MI_UART_OpenParams_s
{
    MI_UART_PortType_e ePort;
    MI_UART_DeviceType_e eDevType;
    MI_UART_Baudrate_e eBaudrate;
    MI_U8 *pu8RxBuffer;
    MI_U16 u16RxBuffLen;
} MI_UART_OpenParams_t;

typedef struct MI_UART_QueryHandleParams_s
{
    MI_UART_PortType_e ePort;
}MI_UART_QueryHandleParams_t;

typedef struct MI_UART_Access_s
{
    MI_U8 *pu8Buf;
    MI_U32 u32Len;
} MI_UART_Access_t;

typedef struct MI_UART_ReadParams_s
{
    MI_U32 u32Len;                ///[in]:data lenght need to uart read
}MI_UART_ReadParams_t;

typedef struct MI_UART_ReadOutputParams_s
{
    MI_UART_Access_t stReadData;   ///[out]:buffer & size to  recived read data
}MI_UART_ReadOutputParams_t;

typedef struct MI_UART_WriteParams_s
{
    MI_UART_Access_t stWriteData;  ///[in]:write data buffer & size
}MI_UART_WriteParams_t;

typedef struct MI_UART_WriteOutputParams_s
{
    MI_U8 u8Reserved;             ///[Out]: reserved
}MI_UART_WriteOutputParams_t;

typedef struct MI_UART_ExportLogParams_s
{
    MI_U8  u8ExpLogType;
    MI_U8 *pszLogFilePath;
    MI_U16 u16FilePathLength;
} MI_UART_ExportLogParams_t;

typedef MI_RESULT (*MI_UART_EventCallback)(MI_HANDLE hUart, MI_U32 u32Event, void* pEventParams, void* pUserParams);

typedef struct MI_UART_CallbackInputParams_s
{
    MI_U64 u64CallbackId;                   ///[IN]: for multi-callback, use 0 for first register or single callback.
    MI_UART_EventCallback pfEventCallback;  ///[IN]: callback function pointer.
    MI_U32 u32EventFlags;                   ///[IN]: registered events which are bitwise OR operation.
    void * pUserParams;                     ///[IN]: for passing user-defined parameters.
} MI_UART_CallbackInputParams_t;

typedef struct MI_UART_CallbackOutputParams_s
{
    MI_U64 u64CallbackId;                  ///[OUT]: the returned ID for update or unregister callback.
} MI_UART_CallbackOutputParams_t;

//-------------------------------------------------------------------------------------------------
//  Global Functions
//-------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------
/// @brief Init UART module.
/// @param[in] pstInitParam..
/// @return MI_OK: Process success.
/// @return MI_HAS_INITED: UART module had inited.
//------------------------------------------------------------------------------
MI_RESULT MI_UART_Init(const MI_UART_InitParams_t* pstInitParams);

//------------------------------------------------------------------------------
/// @brief Finalize UART module.
/// @return MI_OK: Process success.
//------------------------------------------------------------------------------
MI_RESULT MI_UART_DeInit(void);

//------------------------------------------------------------------------------
/// @brief Open a uart device.
/// @param[in] pstOpenParam. Parameter to open uart
/// @param[out] phUart. return uart handle after opening success
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not inted.
/// @return MI_ERR_INVALID_PARAMETER: parameter error.
/// @return MI_ERR_RESOURCES: No available resource.
/// @return MI_ERR_FAILED: Process failed
//------------------------------------------------------------------------------
MI_RESULT MI_UART_Open(const MI_UART_OpenParams_t* pstOpenParams, MI_HANDLE* phUart);

//------------------------------------------------------------------------------
/// @brief Close a uart device.
/// @param[in] phUart. uart handle to close
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not inted.
/// @return MI_ERR_INVALID_HANDLE: Invalid handle.
//------------------------------------------------------------------------------
MI_RESULT MI_UART_Close(MI_HANDLE hUart);

//------------------------------------------------------------------------------
/// @brief Get Handle of the UART module.
/// @param[in]  pstQueryParams: A pointer to structure MI_UART_QueryHandleParams_t.
/// @param[out] phUart: phUart for retrieve an instance of UART interface.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: UART module Get Handle failed.
/// @return MI_ERR_INVALID_PARAMETR: Parameters is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_UART_GetHandle(const MI_UART_QueryHandleParams_t* pstQueryParams, MI_HANDLE* phUart);

//------------------------------------------------------------------------------
/// @brief Register the callback function for receiving the events of UART related.
/// @param[in] hUart: A Handle of a created UART instance.
/// @param[in] pstInputParams: A pointer to structure MI_UART_CallbackInputParams_t for events registered.
/// @param[out] pstOutputParams: A pointer to structure MI_UART_CallbackOutputParams_t.
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE: hanlde is invalid.
/// @return MI_ERR_INVALID_PARAMETER: parameters is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_UART_RegisterCallback(MI_HANDLE hUart, const MI_UART_CallbackInputParams_t *pstInputParams, MI_UART_CallbackOutputParams_t *pstOutputParams);

//------------------------------------------------------------------------------
/// @brief UnRegister the callback function for receiving the events of UART related.
/// @param[in] hUart: A Handle of a created UART instance.
/// @param[in] pstInputParams: A pointer to structure MI_UART_CallbackInputParams_t for events registered.
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE: hanlde is invalid.
/// @return MI_ERR_INVALID_PARAMETER: parameters is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_UART_UnRegisterCallback(MI_HANDLE hUart, const MI_UART_CallbackInputParams_t *pstInputParams);

//------------------------------------------------------------------------------
/// @brief Set bandrate of the UART.
/// @param[in] hUart. Uart handle to Write
/// @param[in] eBaudrate.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not inted.
/// @return MI_ERR_INVALID_PARAMETER: parameter error.
/// @return MI_ERR_INVALID_HANDLE: Invalid handle.
/// @return MI_ERR_FAILED: Process failed
//------------------------------------------------------------------------------
MI_RESULT MI_UART_SetBaudrate(MI_HANDLE hUart, MI_UART_Baudrate_e eBaudrate);

//------------------------------------------------------------------------------
/// @brief Write data through UART.
/// @param[in] hUart. Uart handle to Write
/// @param[in] pu8Str. The data structure to be written
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not inted.
/// @return MI_ERR_INVALID_PARAMETER: parameter error.
/// @return MI_ERR_INVALID_HANDLE: Invalid handle.
//------------------------------------------------------------------------------
MI_RESULT MI_UART_Write(MI_HANDLE hUart, const MI_UART_WriteParams_t *pstWriteParams, MI_UART_WriteOutputParams_t *pstOutputParams);

//------------------------------------------------------------------------------
/// @brief Read data through UART.
/// @param[in] hUart. Uart handle to Read
/// @param[in] pstRead. The data to be written
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not inted.
/// @return MI_ERR_INVALID_PARAMETER: parameter error.
/// @return MI_ERR_INVALID_HANDLE: Invalid handle.
//------------------------------------------------------------------------------
MI_RESULT MI_UART_Read(MI_HANDLE hUart, const MI_UART_ReadParams_t *pstReadParams, MI_UART_ReadOutputParams_t *pstOutputParams);

//------------------------------------------------------------------------------
/// @brief Write a character through UART.
/// @param[in] hUart. Uart handle to put char
/// @param[in] u8Char. The character to be written
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not inted.
/// @return MI_ERR_INVALID_HANDLE: Invalid handle.
//------------------------------------------------------------------------------
MI_RESULT MI_UART_PutChar(MI_HANDLE hUart, MI_U8 u8Char);

//------------------------------------------------------------------------------
/// @brief Read a character through UART.
/// @param[in] hUart. Uart handle to get char
/// @param[in] pu8Char. The pointer to read data
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not inted.
/// @return MI_ERR_INVALID_PARAMETER: parameter error.
/// @return MI_ERR_INVALID_HANDLE: Invalid handle.
//------------------------------------------------------------------------------
MI_RESULT MI_UART_GetChar(MI_HANDLE hUart, MI_U8 *pu8Char);

//------------------------------------------------------------------------------
/// @brief export log to other device.  Ex:USB
/// @param[in] pstExpLog. enable configuration of Export log
/// @param[out] phExpLogHandle.  return Export handle after opening success
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not inted.
/// @return MI_ERR_INVALID_PARAMETER: parameter error.
/// @return MI_ERR_INVALID_HANDLE: Invalid handle.
//------------------------------------------------------------------------------
MI_RESULT MI_UART_EnableExpLog(MI_UART_ExportLogParams_t *pstExpLog, MI_U32 *pu32ExpLogCtrl);

//------------------------------------------------------------------------------
/// @brief Disbale Export log function
/// @param[in] pstUsbLog. disable configuration of USB log
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not inted.
/// @return MI_ERR_INVALID_PARAMETER: parameter error.
/// @return MI_ERR_INVALID_HANDLE: Invalid handle..
//------------------------------------------------------------------------------
MI_RESULT MI_UART_DisableExpLog(MI_U32 u32ExpLogCtrl);


//------------------------------------------------------------------------------
/// @brief Set UART debug level.
/// @param[in] eDbgLevel.
/// @return MI_OK: Set debug level success.
//------------------------------------------------------------------------------
MI_RESULT MI_UART_SetDebugLevel(MI_DBG_LEVEL u32DebugLevel);

#ifdef __cplusplus
}
#endif

#endif///_MI_UART_H_

