/*------------------------------------------------------------------------------
 * MediaTek Inc. (C) 2018. All rights reserved.
 *
 * Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 *----------------------------------------------------------------------------*/
//------------------------------------------------------------------------------
// Use GetXxx/SetXxx and GetAttr/SetAttr coexist
//------------------------------------------------------------------------------

///////////////////////////////////////////////////////////////////////////////////////////////////
/// @file   mi_mm.h
/// @brief  MM Function Implement.
/// @author MediaTek Inc.
///////////////////////////////////////////////////////////////////////////////////////////////////
#ifndef _MI_MM_H_
#define _MI_MM_H_

#ifdef __cplusplus
extern "C" {
#endif

/// Define X, Y coordinate for HDR10 info
#define MI_MM_HDR10_COORDINATE      (2)
/// Define R, G, B chromaticity for HDR10 info
#define MI_MM_HDR10_CHROMATICITY    (3)
/// Audio index table from 0 to 100.
#define MI_MM_VOLUME_TABLE_INDEX_NUM (101)
/// Define the Max Native Buffer number
#define MI_MM_DISP_FRAME_QUEUE_MAX_SIZE (16)
/// Define the invalid PID value, it should be align with MI_DMX_PID_NULL in mi_dmx.c
#define MI_MM_PID_NULL (0x1FFF)
/// Define the DMA buffer(native buffer) File Descriptors
#define MI_MM_MAX_FD_NUM    (6)
typedef enum
{
    // Photo decoder is in stop status.
    E_MI_MM_PHOTO_STOP,
    // Photo decoder is decoding.
    E_MI_MM_PHOTO_DECODING,
    // Photo decoder has completed decoding.
    E_MI_MM_PHOTO_DECODE_OK,
    // Photo decoder has encountered a decoding error.
    E_MI_MM_PHOTO_DECODE_ERR,
    // Photo decoder status is none.
    E_MI_MM_PHOTO_NULL,
} MI_MM_PhotoDecoderStatus_e;

/// Define media item (photo and movie) zoom factor.
typedef enum
{
    // The zoom factor is one eighth.
    E_MI_MM_VIEW_ZOOM_1_DIV_8 = 0 ,
    // The zoom factor is one forth.
    E_MI_MM_VIEW_ZOOM_1_DIV_4,
    // The zoom factor is half.
    E_MI_MM_VIEW_ZOOM_1_DIV_2,
    // The zoom factor is 1X.
    E_MI_MM_VIEW_ZOOM_1X,
    // The zoom factor is 2X.
    E_MI_MM_VIEW_ZOOM_2X,
    // The zoom factor is 4X.
    E_MI_MM_VIEW_ZOOM_4X,
    // The zoom factor is 8X.
    E_MI_MM_VIEW_ZOOM_8X,
    // The zoom factor is 10/12X.(real factor is 10/12)
    E_MI_MM_VIEW_ZOOM_10_DIV_12,
    // The zoom factor is 10/16X.(real factor is 10/16)
    E_MI_MM_VIEW_ZOOM_10_DIV_16,
    // The zoom factor is 10/18X.(real factor is 10/18)
    E_MI_MM_VIEW_ZOOM_10_DIV_18,
    // The zoom factor is 1.2X.(real factor is 12/10)
    E_MI_MM_VIEW_ZOOM_12_DIV_10,
    // The zoom factor is 1.6X.(real factor is 16/10)
    E_MI_MM_VIEW_ZOOM_16_DIV_10,
    // The zoom factor is 1.8X.(real factor is 18/10)
    E_MI_MM_VIEW_ZOOM_18_DIV_10,
    // The zoom factor is none.
    E_MI_MM_VIEW_ZOOM_NOT_SUPPORT
} MI_MM_ViewZoomFactor_e;

typedef enum
{
    // Slide show effect is normal.
    E_MI_MM_SLIDE_SHOW_EFFECT_NORMAL,
    // Slide show effect is block display (horizontal raster order scan, the first block in top and left corner).
    // @image html E_SLIDE_SHOW_EFFECT_HORIZONTAL_BLOCKS_TOP_LEFT.JPG "E_SLIDE_SHOW_EFFECT_HORIZONTAL_BLOCKS_TOP_LEFT effect"
    E_MI_MM_SLIDE_SHOW_EFFECT_HORIZONTAL_BLOCKS_TOP_LEFT,
    // Slide show effect is block display (horizontal raster order scan, the first block in top and right corner).
    E_MI_MM_SLIDE_SHOW_EFFECT_HORIZONTAL_BLOCKS_TOP_RIGHT,
    // Slide show effect is block display (horizontal raster order scan, the first block in bottom and left corner).
    E_MI_MM_SLIDE_SHOW_EFFECT_HORIZONTAL_BLOCKS_BOTTOM_LEFT,
    // Slide show effect is block display (horizontal raster order scan, the first block in bottom and right corner).
    E_MI_MM_SLIDE_SHOW_EFFECT_HORIZONTAL_BLOCKS_BOTTOM_RIGHT,
    // Slide show effect is block display (vertical raster order scan, the first block in top and left corner).
    E_MI_MM_SLIDE_SHOW_EFFECT_VERTICAL_BLOCKS_TOP_LEFT,
    // Slide show effect is block display (vertical raster order scan, the first block in top and right corner).
    E_MI_MM_SLIDE_SHOW_EFFECT_VERTICAL_BLOCKS_TOP_RIGHT,
    // Slide show effect is block display (vertical raster order scan, the first block in bottom and left corner).
    E_MI_MM_SLIDE_SHOW_EFFECT_VERTICAL_BLOCKS_BOTTOM_LEFT,
    // Slide show effect is block display (vertical raster order scan, the first block in bottom and right corner).
    E_MI_MM_SLIDE_SHOW_EFFECT_VERTICAL_BLOCKS_BOTTOM_RIGHT,
    // Slide show effect is block display (horizontal zigzag order scan, the first block in top and left corner).
    E_MI_MM_SLIDE_SHOW_EFFECT_HORIZONTAL_ZIGZAG_BLOCKS_TOP_LEFT,
    // Slide show effect is block display (horizontal zigzag order scan, the first block in top and right corner).
    E_MI_MM_SLIDE_SHOW_EFFECT_HORIZONTAL_ZIGZAG_BLOCKS_TOP_RIGHT,
    // Slide show effect is block display (horizontal zigzag order scan, the first block in bottom and left corner).
    E_MI_MM_SLIDE_SHOW_EFFECT_HORIZONTAL_ZIGZAG_BLOCKS_BOTTOM_LEFT,
    // Slide show effect is block display (horizontal zigzag order scan, the first block in bottom and right corner).
    E_MI_MM_SLIDE_SHOW_EFFECT_HORIZONTAL_ZIGZAG_BLOCKS_BOTTOM_RIGHT,
    // Slide show effect is block display (vertical zigzag order scan, the first block in top and left corner).
    // @image html E_SLIDE_SHOW_EFFECT_VERTICAL_ZIGZAG_BLOCKS_TOP_LEFT.JPG "E_SLIDE_SHOW_EFFECT_VERTICAL_ZIGZAG_BLOCKS_TOP_LEFT"
    E_MI_MM_SLIDE_SHOW_EFFECT_VERTICAL_ZIGZAG_BLOCKS_TOP_LEFT,
    // Slide show effect is block display (vertical zigzag order scan, the first block in top and right corner).
    E_MI_MM_SLIDE_SHOW_EFFECT_VERTICAL_ZIGZAG_BLOCKS_TOP_RIGHT,
    // Slide show effect is block display (vertical zigzag order scan, the first block in bottom and left corner).
    E_MI_MM_SLIDE_SHOW_EFFECT_VERTICAL_ZIGZAG_BLOCKS_BOTTOM_LEFT,
    // Slide show effect is block display (vertical zigzag order scan, the first block in bottom and right corner).
    E_MI_MM_SLIDE_SHOW_EFFECT_VERTICAL_ZIGZAG_BLOCKS_BOTTOM_RIGHT,
    // Slide show effect is random block display
    E_MI_MM_SLIDE_SHOW_EFFECT_BLOCKS_RANDOM,
    // Slide show effect is block display (diagonal scan, the first block in top and left corner).
    // @image html E_SLIDE_SHOW_EFFECT_DIAGONAL_BLOCKS_TOP_LEFT.JPG "E_SLIDE_SHOW_EFFECT_DIAGONAL_BLOCKS_TOP_LEFT effect"
    E_MI_MM_SLIDE_SHOW_EFFECT_DIAGONAL_BLOCKS_TOP_LEFT,
    // Slide show effect is block display (diagonal scan, the first block in top and right corner).
    E_MI_MM_SLIDE_SHOW_EFFECT_DIAGONAL_BLOCKS_TOP_RIGHT,
    // Slide show effect is block display (diagonal scan, the first block in bottom and left corner).
    E_MI_MM_SLIDE_SHOW_EFFECT_DIAGONAL_BLOCKS_BOTTOM_LEFT,
    // Slide show effect is block display (diagonal scan, the first block in bottom and right corner).
    E_MI_MM_SLIDE_SHOW_EFFECT_DIAGONAL_BLOCKS_BOTTOM_RIGHT,
    // Slide show effect is bar wipe display (bar scan order is left to right).
    E_MI_MM_SLIDE_SHOW_EFFECT_BAR_WIPE_LEFT_TO_RIGHT,
    // Slide show effect is bar wipe display (bar scan order is right to left).
    E_MI_MM_SLIDE_SHOW_EFFECT_BAR_WIPE_RIGHT_TO_LEFT,
    // Slide show effect is bar wipe display (bar scan order is top to bottom).
    E_MI_MM_SLIDE_SHOW_EFFECT_BAR_WIPE_TOP_TO_BOTTOM,
    // Slide show effect is bar wipe display (bar scan order is bottom to top).
    E_MI_MM_SLIDE_SHOW_EFFECT_BAR_WIPE_BOTTOM_TO_TOP,
    // Slide show effect is box wipe display (box start from top and left corner).
    E_MI_MM_SLIDE_SHOW_EFFECT_BOX_WIPE_TOP_LEFT,
    // Slide show effect is box wipe display (box start from top and right corner).
    E_MI_MM_SLIDE_SHOW_EFFECT_BOX_WIPE_TOP_RIGHT,
    // Slide show effect is box wipe display (box start from bottom and left corner).
    E_MI_MM_SLIDE_SHOW_EFFECT_BOX_WIPE_BOTTOM_LEFT,
    // Slide show effect is box wipe display (box start from bottom and right corner).
    E_MI_MM_SLIDE_SHOW_EFFECT_BOX_WIPE_BOTTOM_RIGHT,
    // Slide show effect is barn door wipe display (horizontal barn door open).
    E_MI_MM_SLIDE_SHOW_EFFECT_BARNDOOR_WIPE_HORIZONTAL_OPEN,
    // Slide show effect is barn door wipe display (horizontal barn door close).
    E_MI_MM_SLIDE_SHOW_EFFECT_BARNDOOR_WIPE_HORIZONTAL_CLOSE,
    // Slide show effect is barn door wipe display (vertical barn door open).
    E_MI_MM_SLIDE_SHOW_EFFECT_BARNDOOR_WIPE_VERTICAL_OPEN,
    // Slide show effect is barn door wipe display (vertical barn door close).
    E_MI_MM_SLIDE_SHOW_EFFECT_BARNDOOR_WIPE_VERTICAL_CLOSE,
    // Slide show effect is box wipe display (box start from top center).
    E_MI_MM_SLIDE_SHOW_EFFECT_BOX_WIPE_TOP_CENTER,
    // Slide show effect is box wipe display (box start from right center).
    E_MI_MM_SLIDE_SHOW_EFFECT_BOX_WIPE_RIGHT_CENTER,
    // Slide show effect is box wipe display (box start from bottom center).
    E_MI_MM_SLIDE_SHOW_EFFECT_BOX_WIPE_BOTTOM_CENTER,
    /// Slide show effect is box wipe display (box start from left center).
    E_MI_MM_SLIDE_SHOW_EFFECT_BOX_WIPE_LEFT_CENTER,
    // Slide show effect is iris wipe display (iris start from center).
    E_MI_MM_SLIDE_SHOW_EFFECT_IRIS_WIPE_CENTER,
    // Slide show effect is iris wipe display (iris start from outer).
    E_MI_MM_SLIDE_SHOW_EFFECT_IRIS_WIPE_OUTER,
    // Slide show effect is 4 horizontal bar wipe display (start for each bar top side).
    E_MI_MM_SLIDE_SHOW_EFFECT_4BAR_WIPE_HORIZONTAL_FROM_TOP,
    // Slide show effect is 4 horizontal bar wipe display (start for each bar bottom side).
    E_MI_MM_SLIDE_SHOW_EFFECT_4BAR_WIPE_HORIZONTAL_FROM_BOTTOM,
    // Slide show effect is 4 vertical bar wipe display (start for each bar left side).
    E_MI_MM_SLIDE_SHOW_EFFECT_4BAR_WIPE_VERTICAL_FROM_LEFT,
    // Slide show effect is 4 vertical bar wipe display (start for each bar right side).
    E_MI_MM_SLIDE_SHOW_EFFECT_4BAR_WIPE_VERTICAL_FROM_RIGHT,
    // Slide show effect is bar slide display (bar start from left to right).
    E_MI_MM_SLIDE_SHOW_EFFECT_BAR_SLIDE_LEFT_TO_RIGHT,
    // Slide show effect is bar slide display (bar start from right to left).
    E_MI_MM_SLIDE_SHOW_EFFECT_BAR_SLIDE_RIGHT_TO_LEFT,
    // Slide show effect is bar slide display (bar start from top to bottom).
    E_MI_MM_SLIDE_SHOW_EFFECT_BAR_SLIDE_TOP_TO_BOTTOM,
    // Slide show effect is bar slide display (bar start from bottom to top).
    E_MI_MM_SLIDE_SHOW_EFFECT_BAR_SLIDE_BOTTOM_TO_TOP,
    // Slide show effect is box slide display (box start from top and left corner).
    E_MI_MM_SLIDE_SHOW_EFFECT_BOX_SLIDE_TOP_LEFT,
    // Slide show effect is box slide display (box start from top and right corner).
    E_MI_MM_SLIDE_SHOW_EFFECT_BOX_SLIDE_TOP_RIGHT,
    // Slide show effect is box slide display (box start from bottom and left corner).
    // @image html E_SLIDE_SHOW_EFFECT_BOX_SLIDE_BOTTOM_LEFT.JPG "E_SLIDE_SHOW_EFFECT_BOX_SLIDE_BOTTOM_LEFT effect"
    E_MI_MM_SLIDE_SHOW_EFFECT_BOX_SLIDE_BOTTOM_LEFT,
    // Slide show effect is box slide display (box start from bottom and right corner).
    E_MI_MM_SLIDE_SHOW_EFFECT_BOX_SLIDE_BOTTOM_RIGHT,
    // Slide show effect is barn door slide display (horizontal barn door open).
    E_MI_MM_SLIDE_SHOW_EFFECT_BARNDOOR_SLIDE_HORIZONTAL_OPEN,
    // Slide show effect is barn door slide display (horizontal barn door close).
    E_MI_MM_SLIDE_SHOW_EFFECT_BARNDOOR_SLIDE_HORIZONTAL_CLOSE,
    // Slide show effect is barn door slide display (vertical barn door open).
    // @image html E_SLIDE_SHOW_EFFECT_BARNDOOR_SLIDE_VERTICAL_OPEN.JPG "E_SLIDE_SHOW_EFFECT_BARNDOOR_SLIDE_VERTICAL_OPEN effect"
    E_MI_MM_SLIDE_SHOW_EFFECT_BARNDOOR_SLIDE_VERTICAL_OPEN,
    // Slide show effect is barn door slide display (vertical barn door close).
    E_MI_MM_SLIDE_SHOW_EFFECT_BARNDOOR_SLIDE_VERTICAL_CLOSE,
    // Slide show effect is 4 horizontal bar slide display (start for each bar top side).
    // @image html E_SLIDE_SHOW_EFFECT_4BAR_SLIDE_HORIZONTAL_FROM_TOP.JPG "E_SLIDE_SHOW_EFFECT_4BAR_SLIDE_HORIZONTAL_FROM_TOP effect"
    E_MI_MM_SLIDE_SHOW_EFFECT_4BAR_SLIDE_HORIZONTAL_FROM_TOP,
    // Slide show effect is 4 horizontal bar wipe display (start for each bar bottom side).
    E_MI_MM_SLIDE_SHOW_EFFECT_4BAR_SLIDE_HORIZONTAL_FROM_BOTTOM,
    // Slide show effect is 4 vertical bar wipe display (start for each bar left side).
    E_MI_MM_SLIDE_SHOW_EFFECT_4BAR_SLIDE_VERTICAL_FROM_LEFT,
    // Slide show effect is 4 vertical bar wipe display (start for each bar right side).
    E_MI_MM_SLIDE_SHOW_EFFECT_4BAR_SLIDE_VERTICAL_FROM_RIGHT,
    // Slide show effect total number.
    E_MI_MM_SLIDE_SHOW_EFFECT_NUM,
    // Slide show effect is random.
    E_MI_MM_SLIDE_SHOW_EFFECT_RANDOM,
} MI_MM_PhotoSlideShowEffect_e;

/// Define media item preview mode.
typedef enum
{
    // Media item preview mode is normal. For photo and video media.
    E_MI_MM_PREVIEW_NORMAL_MODE,
    // Media item preview mode is pause mode. For video media only, the video will be paused on the time (u32VideoPauseTime).
    E_MI_MM_PREVIEW_VIDEO_PAUSE_MODE,
    // Media item thumbnail mode. For video media only. The video will do thumbnail on the time (u32VideoPauseTime).
    E_MI_MM_PREVIEW_THUMBNAIL_MODE,
    // Media item preview mode is none.
    E_MI_MM_PREVIEW_NUM
} MI_MM_PreviewMode_e;


typedef enum
{
    // Video Main path
    E_MI_MM_PATH_MAIN = 0,
    // Video Sub path
    E_MI_MM_PATH_SUB,
    // Audio Main path
    E_MI_MM_AUDIO_PATH_MAIN,
    // Audio Sub path
    E_MI_MM_AUDIO_PATH_SUB,
    // Photo path
    E_MI_MM_PHOTO_PATH,
    // multi-play path, need HW support
    E_MI_MM_PATH_N,
    // Max path
    E_MI_MM_PATH_NUM
} MI_MM_Path_e;

typedef enum
{
    // For local file
    E_MI_MM_FILE_MODE,
    // For rtsp stream
    E_MI_MM_RTSP_MODE,
    // For seekable stream
    E_MI_MM_SEEKABLE_STREAM_MODE,
    // For unseekable stream
    E_MI_MM_UNSEEKABLE_STREAM_MODE,
    // For direct memory input
    E_MI_MM_DIRECT_MEMORY_MODE,
    // For ts inject stream
    E_MI_MM_TS_INJECT_MODE,
    // For internet stream
    E_MI_MM_INTERNET_MODE,
    // For es stream
    E_MI_MM_ES_INJECT_MODE,
    // Invalid file mode
    E_MI_MM_MODE_INVALID,
} MI_MM_FileMode_e;

typedef enum
{
    // Trick action none
    E_MI_MM_TRICK_ACTION_NONE = 0,
    // Normal play
    E_MI_MM_TRICK_ACTION_NORMAL,
    // Pause
    E_MI_MM_TRICK_ACTION_PAUSE,
    // Forward
    E_MI_MM_TRICK_ACTION_FORWARD,
    // Backward
    E_MI_MM_TRICK_ACTION_BACKWARD,
    // Step by step
    E_MI_MM_TRICK_ACTION_STEP,
} MI_MM_TrickAction_e;

typedef enum
{
    // The trick mode speed is 0X.
    E_MI_MM_TRICK_SPEED_0X = 0,
    // The trick mode speed is 1X.
    E_MI_MM_TRICK_SPEED_1X = 1,
    // The trick mode speed is 2X.
    E_MI_MM_TRICK_SPEED_2X,
    // The trick mode speed is 4X.
    E_MI_MM_TRICK_SPEED_4X,
    // The trick mode speed is 8X.
    E_MI_MM_TRICK_SPEED_8X,
    // The trick mode speed is 16X.
    E_MI_MM_TRICK_SPEED_16X,
    // The trick mode speed is 32X.
    E_MI_MM_TRICK_SPEED_32X,
    // The trick mode speed is 1.25X.
    E_MI_MM_TRICK_SPEED_1_25X,
    // The trick mode speed is 1.5X.
    E_MI_MM_TRICK_SPEED_1_5X,
    // The trick mode speed is 1.75X.
    E_MI_MM_TRICK_SPEED_1_75X,
    // The trick mode speed is slow
    E_MI_MM_TRICK_SPEED_SLOW = 0x1000,
    // The trick mode speed is slow 2x.
    E_MI_MM_TRICK_SPEED_SLOW_2X = E_MI_MM_TRICK_SPEED_SLOW,
    // The trick mode speed is slow 4x.
    E_MI_MM_TRICK_SPEED_SLOW_4X,
    // The trick mode speed is slow 8x.
    E_MI_MM_TRICK_SPEED_SLOW_8X,
    // The trick mode speed is slow 16x.
    E_MI_MM_TRICK_SPEED_SLOW_16X,
    // The trick mode speed is slow 32x.
    E_MI_MM_TRICK_SPEED_SLOW_32X,
    // The trick mode speed is slow 1.33x.
    E_MI_MM_TRICK_SPEED_SLOW_1_33X,
    // The trick mode speed is slow scan 2x.
    E_MI_MM_TRICK_SPEED_SLOW_SCAN_2X = 0x2000,
    // The trick mode speed is slow scan 4x.
    E_MI_MM_TRICK_SPEED_SLOW_SCAN_4X,
    // The trick mode speed is slow scan 8x.
    E_MI_MM_TRICK_SPEED_SLOW_SCAN_8X,
    // The trick mode speed is slow scan 16x.
    E_MI_MM_TRICK_SPEED_SLOW_SCAN_16X,
    // The trick mode speed is slow scan 32x.
    E_MI_MM_TRICK_SPEED_SLOW_SCAN_32X,
    // The trick mode in step
    E_MI_MM_TRICK_SPEED_STEP = 0x4000,
    // The trick mode speed is none.
    E_MI_MM_TRICK_SPEED_NOT_SUPPORT
} MI_MM_TrickSpeed_e;

typedef enum
{
    /// Attr type get/set min
    E_MI_MM_ATTR_TYPE_MIN = 0x0,
    // Get/set resume play setting
    E_MI_MM_ATTR_TYPE_RESUME_PLAY = E_MI_MM_ATTR_TYPE_MIN,
    // Max enum of get/set attribute type setting
    E_MI_MM_ATTR_TYPE_MAX,

    /// Attr type get/set audio min
    E_MI_MM_ATTR_TYPE_AUDIO_MIN = 0x200,
    // Mm audio input volume, parameter type is MI_U32. (Maximum volume is 100).
    E_MI_MM_ATTR_TYPE_AUDIO_VOLUME = E_MI_MM_ATTR_TYPE_AUDIO_MIN,
    // Mm audio ease effect, parameter type is a pointer to MI_MM_AudioEaseParams_t
    E_MI_MM_ATTR_TYPE_AUDIO_EASE,

    /// Attr type set min
    E_MI_MM_ATTR_TYPE_SET_MIN = 0x1000,
    // Sets video track
    E_MI_MM_ATTR_TYPE_SET_CHANGE_PROGRAM = E_MI_MM_ATTR_TYPE_SET_MIN,
    // Sets audio track
    E_MI_MM_ATTR_TYPE_SET_CHANGE_AUDIO,
    // Vdplayer read stream time out in ms; default:500
    E_MI_MM_ATTR_TYPE_SET_READ_TIME_OUT,
    // KTV mode, moive(whitout audio) and music can play at same time
    E_MI_MM_ATTR_TYPE_SET_KTV_MODE,
    // Seamless mode, series of moive can player in seamless way
    E_MI_MM_ATTR_TYPE_SET_SEAMLESS_MODE,
    // Repeats play between A and B
    E_MI_MM_ATTR_TYPE_SET_REPEAT_AB,
    // Replays when fast backward to head of file
    E_MI_MM_ATTR_TYPE_SET_FB_REPLAY,
    // For ts stream, set specific total time, then codec needn't read file end
    E_MI_MM_ATTR_TYPE_SET_SPECIFIC_TOTAL_TIME,
    // Sets start time
    E_MI_MM_ATTR_TYPE_SET_STARTTIME,
    // Sets the new audio mode enable
    E_MI_MM_ATTR_TYPE_SET_ENABLE_NEW_AUDIO_MODE,
    // Connect time out, for HTTP connection used, after MM_Open & before MM_Play. (Unit: sec)
    E_MI_MM_ATTR_TYPE_SET_HTTP_CONNECT_TIME_OUT,
    // Read time out, for HTTP connection used, after MM_Open & before MM_Play. (Unit: sec)
    E_MI_MM_ATTR_TYPE_SET_HTTP_READ_TIME_OUT,
    // Set TRUE/FALSE to turn on/off subtitle display
    E_MI_MM_ATTR_TYPE_SET_SUBTITLE_DISPLAY,
    // Set subtitle track id
    E_MI_MM_ATTR_TYPE_SET_SUBTITLE_TRACK,
    // Set teletext track id
    E_MI_MM_ATTR_TYPE_SET_TTX_TRACK,
    // Set teletext display or not
    E_MI_MM_ATTR_TYPE_SET_TTX_DISPLAY,
    // Set closed caption display or not
    E_MI_MM_ATTR_TYPE_SET_CC_DISPLAY,
    // Set display handle, parameter type is MI_HANDLE
    E_MI_MM_ATTR_TYPE_SET_DISPLAY,
    // Set audio output handle, parameter type is MI_HANDLE
    E_MI_MM_ATTR_TYPE_SET_AUDIO_OUTPUT,
    // Set app type, parameter type is a pointer to MI_MM_ApTypeParams_t
    E_MI_MM_ATTR_TYPE_SET_AP_TYPE,
    // Set es video parameter, parameter type is a pointer to MI_MM_EsVideoParams_t
    E_MI_MM_ATTR_TYPE_SET_ES_VIDEO_PARAM,
    // Set or switch es audio parameter, parameter type is a pointer to MI_MM_EsAudioParams_t
    E_MI_MM_ATTR_TYPE_SET_ES_AUDIO_PARAM,
    // Set trick option, parameter type is MI_MM_TrickOption_e
    E_MI_MM_ATTR_TYPE_SET_TRICK_MODE_OPTION,
    // Disable IO  operation timeout, parameter type is MI_BOOL
    E_MI_MM_ATTR_TYPE_SET_DISABLE_IO_TIMEOUT,
    // Set total time for ES_INJECT_MODE, parameter type is MI_U32
    E_MI_MM_ATTR_TYPE_SET_TOTAL_TIME,
    // Trigger PLAYING_OK event
    E_MI_MM_ATTR_TYPE_SET_TRIGGER_PLAYING_OK,
    // Set seek time (ms), parameter type is MI_U32
    // Before MI_MM_Start(),  AP set seek time 38s(Absolute) then send es data about in 30s, MM show in 38s
    // After MI_MM_Start(),  AP send es data about in 30s then set seek time 8s(Offset), MM show in 38s
    E_MI_MM_ATTR_TYPE_SET_SEEK_WAIT_TIME,
    // Repeat, parameter type is MI_BOOL
    E_MI_MM_ATTR_TYPE_SET_REPEAT,
    // Set ts info, parameter type is MI_MM_TsInfo_t
    E_MI_MM_ATTR_TYPE_SET_TS_INFO,
    //Set Frame Buffer Property, parameter type is MI_MM_FrameBufferProperty_t
    E_MI_MM_ATTR_TYPE_SET_FRAME_BUFFER_PROPERTY,
    // Audio only mode, moive(whitout video) or music
    E_MI_MM_ATTR_TYPE_SET_AUDIO_ONLY_MODE,
    // Trigger decrypt action when send MI_MM_EVENT_DRM_SECURE_HANDLER
    E_MI_MM_ATTR_TYPE_SET_SECURE_HANDLER_READY,
    // Set/unset TEMI timeline config
    // [Input]: parameter type is MI_MM_SetTemiTimelineConfig_t
    E_MI_MM_ATTR_TYPE_SET_TEMI_TIMELINE_CONFIG,
    // Enable to freeze at the last frame after EOS
    E_MI_MM_ATTR_TYPE_SET_EOS_FREEZE_AT_LAST_FRAME,
    // av interleave mode
    E_MI_MM_ATTR_TYPE_SET_AV_INTERLEAVE,
    // Create media item with under flow check, 1 for detection, 2 for detection and auto pause
    E_MI_MM_ATTR_TYPE_SET_RENDER_UNDERFLOW,
    // Max enum of set attribute type
    E_MI_MM_ATTR_TYPE_SET_MAX,

    /// Attr type set audio min
    E_MI_MM_ATTR_TYPE_SET_AUDIO_MIN = 0x1200,
    // Set mm audio volume table, parameter type is a pointer to MI_U16 array. The number of array can reference MI_MM_VOLUME_TABLE_INDEX_NUM (0~100).
    E_MI_MM_ATTR_TYPE_SET_AUDIO_VOLUME_TABLE = E_MI_MM_ATTR_TYPE_SET_AUDIO_MIN,
    // Max enum of set audio attribute type
    E_MI_MM_ATTR_TYPE_SET_AUDIO_MAX,

    /// Attr type set media sync min
    E_MI_MM_ATTR_TYPE_SET_MEDIA_SYNC_MIN = 0x1300,
    // Set media sync enable
    // [Intput]: parameter type is MI_BOOL
    E_MI_MM_ATTR_TYPE_SET_ENABLE_MEDIA_SYNC = E_MI_MM_ATTR_TYPE_SET_MEDIA_SYNC_MIN,
    // Set sync offset
    // [Intput]: parameter type is MI_S32
    E_MI_MM_ATTR_TYPE_SET_MEDIA_SYNC_OFFSET,
    // Max enum of set media sync attribute type
    E_MI_MM_ATTR_TYPE_SET_MEDIA_SYNC_MAX,
    // Set First Presentation Time when 1. Start. 2. Flush. 3. Seek
    // [Intput]: parameter type is MI_MM_FirstPresentionTimeInfo_t
    E_MI_MM_ATTR_TYPE_SET_FIRST_PRESENTATION_TIME,

    ///Attr type get min
    E_MI_MM_ATTR_TYPE_GET_MIN = 0x2000,
    // Video data buffer info
    // [Input]: NULL
    // [Output]: parameter type is MI_MM_BufferInfo_t
    E_MI_MM_ATTR_TYPE_GET_VIDEO_BUFFER_INFO = E_MI_MM_ATTR_TYPE_GET_MIN,
    // Get VDEC codec capability
    // [Input]: parameter type is MI_MM_VideoCodecType_e
    // [Output]: parameter type is MI_MM_CodecCapsInfo_t
    E_MI_MM_ATTR_TYPE_GET_VIDEO_CODEC_CAPABILITY,
    // Audio track info
    // [Input] parameter type is MI_U32 u32TrackId.
    // [Output]: parameter type is MI_MM_AudioTrackInfo_t
    E_MI_MM_ATTR_TYPE_GET_AUDIO_TRACK_INFO,
    // Time info (PTS, Current Time)
    // [Input]: MI_MM_StreamType_e for presentation time of the latest rendered audio or video sample.
    // [Output]: parameter type is MI_MM_PlaybackTimeInfo_t
    E_MI_MM_ATTR_TYPE_GET_PLAYBACK_TIME_INFO,
    // Ttx info
    // [Input]: NULL
    // [Output]: parameter type is MI_MM_SubtitleTrackInfo_t
    E_MI_MM_ATTR_TYPE_GET_TTX_INFO,
    // Subtitle info
    // [Input]: NULL
    // [Output]: parameter type is MI_MM_SubtitleTrackInfo_t
    E_MI_MM_ATTR_TYPE_GET_SUBTITLE_INFO,
    // Current component id for ts file(with track id), track id for other container
    // [Input]: NULL
    // [Output]: parameter type is MI_MM_ComponentId_t
    E_MI_MM_ATTR_TYPE_GET_COMPONENT_ID,
    // Get Frame Buffer Capability
    // [Input]: NULL
    // [Output]: parameter type is MI_MM_FrameBufferCaps_t
    E_MI_MM_ATTR_TYPE_GET_FRAME_BUFFER_CAPABILITY,
    // Get Frame Buffer Layout
    // [Input]: NULL
    // [Output]: parameter type is MI_MM_FrameBufferLayout_t
    E_MI_MM_ATTR_TYPE_GET_FRAME_BUFFER_LAYOUT,
    // Get Timed External Media Information
    // [Input]: parameter type is MI_MM_TemiTimelineConfig_t
    // [Output]: parameter type is MI_MM_TemiTimelineInfo_t
    E_MI_MM_ATTR_TYPE_GET_TEMI_TIMELINE_INFO,
    // Video track info
    // [Input] parameter type is MI_U32 u32TrackId.
    // [Output]: parameter type is MI_MM_VideoTrackInfo_t
    E_MI_MM_ATTR_TYPE_GET_VIDEO_TRACK_INFO,
    // Subtitle track info
    // [Input] parameter type is MI_U32 u32TrackId.
    // [Output]: parameter type is MI_MM_SubtitleTrackInfo_t
    E_MI_MM_ATTR_TYPE_GET_SUBTITLE_TRACK_INFO,
    // Max enum of get attribute type
    E_MI_MM_ATTR_TYPE_GET_MAX,
} MI_MM_AttrType_e;

typedef enum
{
    // Invalid media type
    E_MI_MM_MEDIA_INVALID = -1,
    // Photo media type
    E_MI_MM_MEDIA_PHOTO = 0,
    // Music media type
    E_MI_MM_MEDIA_MUSIC,
    // Movie media type
    E_MI_MM_MEDIA_MOVIE,
    // Max enum of media type
    E_MI_MM_MEDIA_MAX,
} MI_MM_MediaType_e;  //for user selection

typedef enum
{
    // Create media item for normal.
    E_MI_MM_AP_TYPE_NORMAL = 0,
    // Create media item for netflix.
    E_MI_MM_AP_TYPE_NETFLIX,
    // Create media item for dlna.
    E_MI_MM_AP_TYPE_DLNA,
    // Create media item for hbbtv
    E_MI_MM_AP_TYPE_HBBTV,
    // Create media item for webbrowser
    E_MI_MM_AP_TYPE_WEBBROWSER,
    // Create media item for wmdrm10
    E_MI_MM_AP_TYPE_WMDRM10,
    // Create media item for android usb
    E_MI_MM_AP_TYPE_ANDROID_USB,
    // Create media item for android streaming
    E_MI_MM_AP_TYPE_ANDROID_STREAMING,
    // Create media item for RVU
    E_MI_MM_AP_TYPE_RVU,
    // Create media item for YOUTUBE (autoplay)
    E_MI_MM_AP_TYPE_YOUTUBE,
    // Create media item for MSS
    E_MI_MM_AP_TYPE_MSS,
    // Create media item for CSP
    E_MI_MM_AP_TYPE_CSP,
    // Create media item for ADVERT Player
    E_MI_MM_AP_TYPE_ADVERT,
    // Find ini setting by string
    E_MI_MM_AP_TYPE_STRING = 16,
} MI_MM_ApType_e;

/// Define Photo output color format.
typedef enum
{
    // Photo Format Type: Unknown.
    E_MI_MM_PHOTO_COLOR_FORMAT_UNKNOWN = -1,
    // Photo Color Format: ARGB888
    E_MI_MM_PHOTO_COLOR_FORMAT_ARGB8888,
    // Photo Color Format: ARG1555
    E_MI_MM_PHOTO_COLOR_FORMAT_ARGB1555,
    // Photo Color Format: ARG4444
    E_MI_MM_PHOTO_COLOR_FORMAT_ARGB4444,
    // Photo Color Format: YUYV
    E_MI_MM_PHOTO_COLOR_FORMAT_YUV422_YUYV,
    // Photo Color Format: YVYU
    E_MI_MM_PHOTO_COLOR_FORMAT_YUV422_YVYU,
} MI_MM_PhotoColorFormat_e;

typedef enum
{
    // Video Codec Type: Unknown.
    E_MI_MM_VIDEO_CODEC_TYPE_UNKNOWN = -1,
    // Video Codec Type: MPEG 4.(DIVX serial)
    E_MI_MM_VIDEO_CODEC_TYPE_MPEG4,
    // Video Codec Type: Motion JPG.
    E_MI_MM_VIDEO_CODEC_TYPE_MJPEG,
    // Video Codec Type: H264.
    E_MI_MM_VIDEO_CODEC_TYPE_H264,
    // Video Codec Type: RealVideo 8.
    E_MI_MM_VIDEO_CODEC_TYPE_RM,
    // Video Codec Type: MPEG 1/2.
    E_MI_MM_VIDEO_CODEC_TYPE_MPEG2 = 0x5,
    // Video Codec Type: VC1.(VC1 main profile)
    E_MI_MM_VIDEO_CODEC_TYPE_VC1,
    // Video Codec Type: Audio Video Standard.
    E_MI_MM_VIDEO_CODEC_TYPE_AVS,
    // Video Codec Type: FLV.
    E_MI_MM_VIDEO_CODEC_TYPE_FLV,
    // Video Codec Type: MVC.
    E_MI_MM_VIDEO_CODEC_TYPE_MVC,
    // Video Codec Type: VP6.
    E_MI_MM_VIDEO_CODEC_TYPE_VP6,
    // Video Codec Type: VP8.
    E_MI_MM_VIDEO_CODEC_TYPE_VP8,
    // Video Codec Type: HEVC.
    E_MI_MM_VIDEO_CODEC_TYPE_HEVC,
    // Video Codec Type: VP9.
    E_MI_MM_VIDEO_CODEC_TYPE_VP9,
    // Video Codec Type: H263.
    E_MI_MM_VIDEO_CODEC_TYPE_H263,
    // Video Codec Type: VC1 advanced profile (VC1)
    E_MI_MM_VIDEO_CODEC_TYPE_VC1_ADV,
    // Video Codec Type: Real Video version 9 and 10
    E_MI_MM_VIDEO_CODEC_TYPE_RM9,
    // Video Codec Type: AV1
    E_MI_MM_VIDEO_CODEC_TYPE_AV1,
}MI_MM_VideoCodecType_e;

typedef enum
{
    // Audio Codec Type: Unkown
    E_MI_MM_AUDIO_CODEC_TYPE_UNKNOWN = -1,
    // Audio Codec Type: AAC
    E_MI_MM_AUDIO_CODEC_TYPE_AAC = 0x100,
    // Audio Codec Type: AC3
    E_MI_MM_AUDIO_CODEC_TYPE_AC3 = 0x200,
    // Audio Codec Type: AC3 Plus
    E_MI_MM_AUDIO_CODEC_TYPE_AC3P,
    // Audio Codec Type: AMR NB
    E_MI_MM_AUDIO_CODEC_TYPE_AMR_NB = 0x300,
    // Audio Codec Type: AMR WB
    E_MI_MM_AUDIO_CODEC_TYPE_AMR_WB = 0x310,
    // Audio Codec Type: DTS
    E_MI_MM_AUDIO_CODEC_TYPE_DTS = 0x400,
    // Audio Codec Type: DTS Express (LBR)
    E_MI_MM_AUDIO_CODEC_TYPE_DTS_LBR,
    // Audio Codec Type: DTS HD (reserved.)
    E_MI_MM_AUDIO_CODEC_TYPE_DTS_HD,
    // Audio Codec Type: DTS HD Master Audio
    E_MI_MM_AUDIO_CODEC_TYPE_DTS_HD_MA,
    // Audio Codec Type: DTS HD High Resolution Audio (reserved.)
    E_MI_MM_AUDIO_CODEC_TYPE_DTS_HD_HRA,
    // Audio Codec Type: FLAC
    E_MI_MM_AUDIO_CODEC_TYPE_FLAC = 0x500,
    // Audio Codec Type: MP3
    E_MI_MM_AUDIO_CODEC_TYPE_MP3 = 0x600,
    // Audio Codec Type: MP2
    E_MI_MM_AUDIO_CODEC_TYPE_MPEG,
    // Audio Codec Type: COOK/RA8LBR
    E_MI_MM_AUDIO_CODEC_TYPE_COOK = 0x700,
    // Audio Codec Type: COOK RA8LBR
    E_MI_MM_AUDIO_CODEC_TYPE_RA8_LBR = E_MI_MM_AUDIO_CODEC_TYPE_COOK,
    // Audio Codec Type: Vorbis
    E_MI_MM_AUDIO_CODEC_TYPE_VORBIS = 0x800,
    // Audio Codec Type: DRA
    E_MI_MM_AUDIO_CODEC_TYPE_DRA = 0x900,
    // Audio Codec Type: WMA1/WMA2/WMAPro
    E_MI_MM_AUDIO_CODEC_TYPE_WMA = 0x1000,
    // Audio Codec Type: WMA1
    E_MI_MM_AUDIO_CODEC_TYPE_WMA1,
    // Audio Codec Type: WMA2
    E_MI_MM_AUDIO_CODEC_TYPE_WMA2,
    // Audio Codec Type: WMA3 (PRO)
    E_MI_MM_AUDIO_CODEC_TYPE_WMA3,
    // Audio Codec Type: WMA3 (PRO)
    E_MI_MM_AUDIO_CODEC_TYPE_WMA_PRO = E_MI_MM_AUDIO_CODEC_TYPE_WMA3,
    // Audio Codec Type: PCM
    E_MI_MM_AUDIO_CODEC_TYPE_PCM = 0x1101,
    // Audio Codec Type: ADCPM
    E_MI_MM_AUDIO_CODEC_TYPE_ADPCM = 0x1200,
    // Audio Codec Type: OPUS
    E_MI_MM_AUDIO_CODEC_TYPE_OPUS = 0x1300,
    // Audio Codec Type: AC4
    E_MI_MM_AUDIO_CODEC_TYPE_AC4 = 0x1400,
}MI_MM_AudioCodecType_e;

typedef enum
{
    // Invalid event type
    E_MI_MM_EVENT_INVALID = -1,
    // Min enum of event type
    E_MI_MM_EVENT_MIN = 0,
    // Playback ok, and exit to ap, parameter type is MI_MM Handle.
    E_MI_MM_EVENT_EXIT_OK = E_MI_MM_EVENT_MIN,
    // Custom stop playback, and exit to ap
    E_MI_MM_EVENT_EXIT_FORCE,
    // Playback  error, and exit to ap, parameter type is MI_MM Handle.
    E_MI_MM_EVENT_EXIT_ERROR_FILE,

    // When playing, data enough to continue play, and codec will resume
    E_MI_MM_EVENT_SUFFICIENT_DATA = 0x10,
    // When playing, run short of data, and codec will pause
    E_MI_MM_EVENT_INSUFFICIENT_DATA,
    // When set init only and MM create media done.
    E_MI_MM_EVENT_PLAYING_INIT_OK,
    // When the first frame decode done.
    E_MI_MM_EVENT_FRAME_READY,
    // Player init ok, and start playing
    E_MI_MM_EVENT_START_PLAY,
    // When playing OK
    E_MI_MM_EVENT_PLAYING_OK,

    // Program has been changed.
    E_MI_MM_EVENT_PROGRAM_CHANGED = 0x20,
    // Audio track has been changed.
    E_MI_MM_EVENT_AUDIO_TRACK_CHANGED,
    // When trick operation back to start
    E_MI_MM_EVENT_BACKWARD_TO_START,
    // Clear data ready
    E_MI_MM_EVENT_CLEAR_DATA_READY,
    // Movie audio not support
    E_MI_MM_EVENT_AUDIO_UNSUPPORTED,
    // Only audio
    E_MI_MM_EVENT_AUDIO_ONLY,
    // After seek operation, do success
    E_MI_MM_EVENT_SEEK_ACK,
    // Aftrer trick operation, do success
    E_MI_MM_EVENT_TRICK_ACK,
    // When the black screen off.
    E_MI_MM_EVENT_BLACK_SCREEN_OFF,
    // When decode thumbnail done
    E_MI_MM_EVENT_THUMBNAIL_DECODE_DONE,
    // When decode thumbnail failed
    E_MI_MM_EVENT_THUMBNAIL_DECODE_FAIL,
    // Video track has been changed. And ready to wait for new video data.
    E_MI_MM_EVENT_VIDEO_TRACK_CHANGED,
    // when render buffer is underflow
    E_MI_MM_EVENT_VIDEO_RENDER_BUFFER_UNDERFLOW,
    // Max enum of event type
    E_MI_MM_EVENT_MAX,

    /// Photo Event
    // Min enum of photo event type
    E_MI_MM_EVENT_PHOTO_MIN = 0x100,
    // Brief The photo decode process has finished successfully.
    E_MI_MM_EVENT_PHOTO_DECODE_DONE = E_MI_MM_EVENT_PHOTO_MIN,
    // The photo decode process is failed. Parameter type is MI_MM Handle.
    E_MI_MM_EVENT_PHOTO_DECODE_FAILED,
    // Brief next file is decoding and no decoded photo is ready for display. */
    E_MI_MM_EVENT_PHOTO_DECODING_NEXT,
    // Brief one decoded photo is now displayed.
    E_MI_MM_EVENT_PHOTO_DISPLAYED,
    // One frame has decoded done, wait for drawing. parameter type is a pointer to MI_MM_PhotoDrawingInfo_t.
    E_MI_MM_EVENT_PHOTO_DECODE_ONE_FRAME_DONE,
    // Max enum of photo event type
    E_MI_MM_EVENT_PHOTO_MAX,

    /// DRM Event
    // Min enum of DRM event type
    E_MI_MM_EVENT_DRM_MIN = 0x200,
    // When streaming need request decrypt license. parameter type is a pointer to MI_MM_DrmRequestLicenseParams_t.
    E_MI_MM_EVENT_DRM_REQUEST_LICENSE = E_MI_MM_EVENT_DRM_MIN,
    // When streaming need decrypt data. parameter type is a pointer to MI_MM_DrmDecryptParams_t.
    E_MI_MM_EVENT_DRM_DECRYPT_DATA,
    // When streaming collect secure handler  parameter type is a pointer to MI_MM_DrmSecureHandler_t.
    E_MI_MM_EVENT_DRM_SECURE_HANDLER,
    // Max enum of DRM event type
    E_MI_MM_EVENT_DRM_MAX,

    // All events supported
    E_MI_MM_EVENT_ALL = 0xf0000000,
} MI_MM_Event_e;

typedef enum
{

    /* Music info: For wma, Layer, COMMENT and GENRE info are not supported.*/
    E_MI_MM_MUSIC_STRING_INFO_LAYER,            // Reserved for future use
    E_MI_MM_MUSIC_STRING_INFO_BITRATE,          // Bitrate
    E_MI_MM_MUSIC_STRING_INFO_SAMPLE_RATE,      // Sampling rate
    E_MI_MM_MUSIC_STRING_INFO_ALBUM,            // Album
    E_MI_MM_MUSIC_STRING_INFO_TITLE,            // Title
    E_MI_MM_MUSIC_STRING_INFO_ARTIST,           // Artist
    E_MI_MM_MUSIC_STRING_INFO_YEAR,             // Year
    E_MI_MM_MUSIC_STRING_INFO_GENRE,            // Reserved for future use
    E_MI_MM_MUSIC_STRING_INFO_COMMENT,          // Comment
    E_MI_MM_MUSIC_STRING_INFO_CHECK_FF_FB,      // Reserved for future use
    E_MI_MM_MUSIC_STRING_INFO_ALBUM_FORMAT,     // Album format
    E_MI_MM_MUSIC_STRING_INFO_TITLE_FORMAT,     // Title format
    E_MI_MM_MUSIC_STRING_INFO_ARTIST_FORMAT,    // Artist format
    E_MI_MM_MUSIC_STRING_INFO_YEAR_FORMAT,      // Year format
    E_MI_MM_MUSIC_STRING_INFO_GENRE_FORMAT,     // Reserved for future use
    E_MI_MM_MUSIC_STRING_INFO_COMMENT_FORMAT,   // Comment format
} MI_MM_MusicStringInfo_e;

typedef enum
{
    E_MI_MM_TRICK_MODE_NORMAL,                  // Enter normal play mode
    E_MI_MM_TRICK_MODE_PAUSE,                   // Pause
    E_MI_MM_TRICK_MODE_FF_2X,                   // Fast forward 2x
    E_MI_MM_TRICK_MODE_FF_4X,                   // Fast forward 4x
    E_MI_MM_TRICK_MODE_FF_8X,                   // Fast forward 8x
    E_MI_MM_TRICK_MODE_FF_16X,                  // Fast forward 16x
    E_MI_MM_TRICK_MODE_FF_32X,                  // Fast forward 32x
    E_MI_MM_TRICK_MODE_FB_2X,                   // Fast backward 2x
    E_MI_MM_TRICK_MODE_FB_4X,                   // Fast backward 4x
    E_MI_MM_TRICK_MODE_FB_8X,                   // Fast backward 8x
    E_MI_MM_TRICK_MODE_FB_16X,                  // Fast backward 16x
    E_MI_MM_TRICK_MODE_FB_32X,                  // Fast backward 32x
    E_MI_MM_TRICK_MODE_SLOW,                    // Slow motion mode
    E_MI_MM_TRICK_MODE_NUM,                     // Specify the number of movie play mode
    E_MI_MM_TRICK_MODE_INVALID = E_MI_MM_TRICK_MODE_NUM,    // Invalid trick mode
} MI_MM_TrickMode_e;

typedef enum
{
    E_MI_MM_FILE_FORMAT_UNKNOWN,                // Unknown
    E_MI_MM_FILE_FORMAT_AVI,                    // AVI
    E_MI_MM_FILE_FORMAT_MP4,                    // MP4
    E_MI_MM_FILE_FORMAT_MKV,                    // MKV
    E_MI_MM_FILE_FORMAT_ASF,                    // ASF
    E_MI_MM_FILE_FORMAT_RM,                     // RM/RMVB
    E_MI_MM_FILE_FORMAT_TS,                     // TS
    E_MI_MM_FILE_FORMAT_MPG,                    // MPG
    E_MI_MM_FILE_FORMAT_FLV,                    // FLV
    E_MI_MM_FILE_FORMAT_SWF,                    // SWF
    E_MI_MM_FILE_FORMAT_OGM,                    // OGM
    E_MI_MM_FILE_FORMAT_ES,                     // ES Only. It includes A only or V only or A/V mixed ES.
} MI_MM_FileFormat_e;

typedef enum
{
    // unknow type
    E_MI_MM_INFO_SUB_TYPE_UNKNOWN = 0,
    // Movie type
    E_MI_MM_INFO_SUB_TYPE_MOVIE,

    // Photo type: JPEG
    E_MI_MM_INFO_SUB_TYPE_JPEG,
    // Photo type: PNG
    E_MI_MM_INFO_SUB_TYPE_PNG,
    // Photo type: GIF
    E_MI_MM_INFO_SUB_TYPE_GIF,
    // Photo type: TIFF
    E_MI_MM_INFO_SUB_TYPE_TIFF,
    // Photo type: BMP
    E_MI_MM_INFO_SUB_TYPE_BMP,

    // Music type: MP3
    E_MI_MM_INFO_SUB_TYPE_MP3,
    // Music type: AAC
    E_MI_MM_INFO_SUB_TYPE_AAC,
    // Music type: PCM
    E_MI_MM_INFO_SUB_TYPE_PCM,
    // Music type: WAV
    E_MI_MM_INFO_SUB_TYPE_WAV,
    // Music type: MWA
    E_MI_MM_INFO_SUB_TYPE_WMA,

    // Text type
    E_MI_MM_INFO_SUB_TYPE_TEXT,
} MI_MM_InfoSubType_e;

typedef enum
{
	// Output color format ARGB8888
    E_MI_MM_THUMBNAIL_COLOR_FMT_ARGB8888,
    // Output color format ARGB1555
    E_MI_MM_THUMBNAIL_COLOR_FMT_ARGB1555,
    // Output color format ARGB4444
    E_MI_MM_THUMBNAIL_COLOR_FMT_ARGB4444,
    // Output color format YUV422
    E_MI_MM_THUMBNAIL_COLOR_FMT_YUV422,
    // Output color format RGB565
    E_MI_MM_THUMBNAIL_COLOR_FMT_RGB565,
    // Max enum of output color format
    E_MI_MM_THUMBNAIL_COLOR_FMT_MAX,
} MI_MM_ThumbnailColorFmt_e;

typedef enum
{
    E_MI_MM_ES_NAL_SIZE_NULL = 0,   // ES NAL size is null
    E_MI_MM_ES_NAL_SIZE_ONE_BYTE,   // ES NAL size is one byte
    E_MI_MM_ES_NAL_SIZE_TWO_BYTE,   // ES NAL size is two byte
    E_MI_MM_ES_NAL_SIZE_THREE_BYTE, // ES NAL size is three byte
    E_MI_MM_ES_NAL_SIZE_FOUR_BYTE,  // ES NAL size is four byte
} MI_MM_EsNalSize_e;

typedef enum
{
    E_MI_MM_DOLBY_VISION_PROFILE_UNSUPPORTED= 0,     // Unsupported Dolby Vision Profile
    E_MI_MM_DOLBY_VISION_PROFILE_DVAV_PER   = 1<<0,  // Dolby Vision Profile 0
    E_MI_MM_DOLBY_VISION_PROFILE_DVAV_PEN   = 1<<2,  // Dolby Vision Profile 1
    E_MI_MM_DOLBY_VISION_PROFILE_DVHE_DER   = 1<<3,  // Dolby Vision Profile 2
    E_MI_MM_DOLBY_VISION_PROFILE_DVHE_DEN   = 1<<4,  // Dolby Vision Profile 3
    E_MI_MM_DOLBY_VISION_PROFILE_DVHE_DTR   = 1<<5,  // Dolby Vision Profile 4
    E_MI_MM_DOLBY_VISION_PROFILE_DVHE_STN   = 1<<6,  // Dolby Vision Profile 5
    E_MI_MM_DOLBY_VISION_PROFILE_DVHE_DTH   = 1<<7,  // Dolby Vision Profile 6
    E_MI_MM_DOLBY_VISION_PROFILE_DVHE_DTB   = 1<<8,  // Dolby Vision Profile 7
    E_MI_MM_DOLBY_VISION_PROFILE_DVHE_STX   = 1<<9,  // Dolby Vision Profile 8 , dvhe.st{h,r,l,g,s}
    E_MI_MM_DOLBY_VISION_PROFILE_DVAV_SER   = 1<<10, // Dolby Vision Profile 9

    E_MI_MM_DOLBY_VISION_PROFILE_DVHE_STH_BL_COMPATIBILITY_ID_1 = 1<<27, // Dolby Vision Profile 8, Compatibility Id 1, dvhe.sth
    E_MI_MM_DOLBY_VISION_PROFILE_DVHE_STR_BL_COMPATIBILITY_ID_2 = 1<<28, // Dolby Vision Profile 8, Compatibility Id 2, dvhe.str
    E_MI_MM_DOLBY_VISION_PROFILE_DVHE_STL_BL_COMPATIBILITY_ID_3 = 1<<29, // Dolby Vision Profile 8, Compatibility Id 3, dvhe.stl
    E_MI_MM_DOLBY_VISION_PROFILE_DVHE_STG_BL_COMPATIBILITY_ID_4 = 1<<30, // Dolby Vision Profile 8, Compatibility Id 4, dvhe.stg
    E_MI_MM_DOLBY_VISION_PROFILE_DVHE_STS_BL_COMPATIBILITY_ID_5 = 1<<31, // Dolby Vision Profile 8, Compatibility Id 5, dvhe.sts
} MI_MM_DolbyVisionProfile_e;

typedef enum
{
    E_MI_MM_DOLBY_VISION_LEVEL_UNSUPPORTED = 0, // Unsupported Dolby Vision Level
    E_MI_MM_DOLBY_VISION_LEVEL_HD24,            // Dolby Vision Level HD24,  ex. 1280  x  720   x  24
    E_MI_MM_DOLBY_VISION_LEVEL_HD30,            // Dolby Vision Level HD30,  ex. 1280  x  720   x  30
    E_MI_MM_DOLBY_VISION_LEVEL_FHD24,           // Dolby Vision Level FHD24, ex. 1920  x  1080  x  24
    E_MI_MM_DOLBY_VISION_LEVEL_FHD30,           // Dolby Vision Level FHD30, ex. 1920  x  1080  x  30(25)
    E_MI_MM_DOLBY_VISION_LEVEL_FHD60,           // Dolby Vision Level FHD60, ex. 1920  x  1080  x  60(50)
    E_MI_MM_DOLBY_VISION_LEVEL_UHD24,           // Dolby Vision Level UHD24, ex. 3840  x  2160  x  24
    E_MI_MM_DOLBY_VISION_LEVEL_UHD30,           // Dolby Vision Level UHD30, ex. 3840  x  2160  x  30(25)
    E_MI_MM_DOLBY_VISION_LEVEL_UHD48,           // Dolby Vision Level UHD48, ex. 3840  x  2160  x  48
    E_MI_MM_DOLBY_VISION_LEVEL_UHD60,           // Dolby Vision Level UHD60, ex. 3840  x  2160  x  60(50)
} MI_MM_DolbyVisionLevel_e;

typedef enum
{
    // Default value, metadata follow BL
    E_MI_MM_DOLBY_VISION_META_FOLLOW_DEFAULT = 0,
    // Single track (single pid is 1), metadata follow BL
    E_MI_MM_DOLBY_VISION_META_FOLLOW_BL,
    // Dual track (dual pid is 2), metadata follow EL
    E_MI_MM_DOLBY_VISION_META_FOLLOW_EL,
} MI_MM_DolbyVisionMetaFollow_e;

typedef enum
{
    // Subtitle type: None
    E_MI_MM_SUBTITLE_TYPE_NONE = 0,
    // Subtitle type: STR
    E_MI_MM_SUBTITLE_TYPE_TEXT_SRT,
    // Subtitle type: UTF-8
    E_MI_MM_SUBTITLE_TYPE_TEXT_UTF8,
    // Subtitle type: ASS
    E_MI_MM_SUBTITLE_TYPE_TEXT_ASS,
    // Subtitle type: SSA
    E_MI_MM_SUBTITLE_TYPE_TEXT_SSA,
    // Subtitle type: 3GPP
    E_MI_MM_SUBTITLE_TYPE_TEXT_3GPP,
    // Subtitle type: USF
    E_MI_MM_SUBTITLE_TYPE_TEXT_USF,
    // Subtitle type: TS_BMP (DVb)
    E_MI_MM_SUBTITLE_TYPE_IMAGE_TS = 0x1000,
    // Subtitle type: DIVX (Xsub, Xsub+)
    E_MI_MM_SUBTITLE_TYPE_IMAGE_DIVX,
    // Subtitle type: VOBSUB (Dvd, Vobsub)
    E_MI_MM_SUBTITLE_TYPE_IMAGE_VOBSUB,
    // Subtitle type: PGS
    E_MI_MM_SUBTITLE_TYPE_IMAGE_PGS,
    // Subtitle type: Teletext
    E_MI_MM_SUBTITLE_TYPE_TELETEXT = 0x2000,
} MI_MM_SubtitleType_e;

typedef enum
{
    // Normal.
    E_MI_MM_TRICK_OPTION_NORMAL = (0),
    // Multi frame scan.(Server only provides a sequence of I or IDR frame) (mss/rvu/dlna)
    E_MI_MM_TRICK_OPTION_DECODE_I_FRAME     = MI_BIT(0),
    // Time base seek mode. (Music)
    E_MI_MM_TRICK_OPTION_TIME_BASE_SEEK     = MI_BIT(1),
    // Display One Frame
    E_MI_MM_TRICK_OPTION_DISPLAY_ONE_FRAME  = MI_BIT(2),
} MI_MM_TrickOption_e;

typedef enum
{
    // Codec Version None
    E_MI_MM_VIDEO_CODEC_VERSION_NONE       = 0x0,
    // Codec Version DIVX FLV 1
    E_MI_MM_VIDEO_CODEC_VERSION_FLV_1      = 0x10,
    // Codec Version DIVX H263 1
    E_MI_MM_VIDEO_CODEC_VERSION_H263_1     = 0x20,
    // Codec Version DIVX 311
    E_MI_MM_VIDEO_CODEC_VERSION_DIVX_311   = 0x30,
    // Codec Version DIVX 4
    E_MI_MM_VIDEO_CODEC_VERSION_DIVX_4,
    // Codec Version DIVX 5
    E_MI_MM_VIDEO_CODEC_VERSION_DIVX_5,
    // Codec Version DIVX 6
    E_MI_MM_VIDEO_CODEC_VERSION_DIVX_6,
} MI_MM_VideoCodecVersion_e;

typedef enum
{
    E_MI_MM_VIDEO_CODEC_PROFILE_NONE                       = 0x0,
    // MPEG2 main profile
    E_MI_MM_VIDEO_CODEC_PROFILE_MPEG2_MAIN                 = 0x10,
    // MPEG4 ASP profile
    E_MI_MM_VIDEO_CODEC_PROFILE_MPEG4_ASP                  = 0x20,
    // RCV profile
    E_MI_MM_VIDEO_CODEC_PROFILE_VC1_MAIN                   = 0x30,
    // VC-1 profile
    E_MI_MM_VIDEO_CODEC_PROFILE_VC1_ADVANCE,
    // H263 baseline profile
    E_MI_MM_VIDEO_CODEC_PROFILE_H263_BASELINE              = 0x40,
    // VP9 profile 0
    E_MI_MM_VIDEO_CODEC_PROFILE_VP9_0                      = 0x50,
    // VP9 profile 2
    E_MI_MM_VIDEO_CODEC_PROFILE_VP9_2,
    // Constrained Baseline Profile
    E_MI_MM_VIDEO_CODEC_PROFILE_H264_CONSTRAINED_BASELINE  = 0x100,
    // Baseline Profile
    E_MI_MM_VIDEO_CODEC_PROFILE_H264_BASELINE,
    // Extended Profile
    E_MI_MM_VIDEO_CODEC_PROFILE_H264_EXTENDED,
    // Main Profile
    E_MI_MM_VIDEO_CODEC_PROFILE_H264_MAIN,
    // High Profile
    E_MI_MM_VIDEO_CODEC_PROFILE_H264_HIGH,
    // Progressive High Profile
    E_MI_MM_VIDEO_CODEC_PROFILE_H264_PROGRESSIVE_HIGH,
    // Constrained High Profile
    E_MI_MM_VIDEO_CODEC_PROFILE_H264_CONSTRAINED_HIGH,
    // High 10 Profile
    E_MI_MM_VIDEO_CODEC_PROFILE_H264_HIGH_10,
    // High 4:2:2 Profile
    E_MI_MM_VIDEO_CODEC_PROFILE_H264_HIGH_422,
    // High 4:4:4 Predictive Profile
    E_MI_MM_VIDEO_CODEC_PROFILE_H264_HIGH_444_PREDICTIVE,
    // Main profile
    E_MI_MM_VIDEO_CODEC_PROFILE_H265_MAIN                  = 0x200,
    // Main 10 profile
    E_MI_MM_VIDEO_CODEC_PROFILE_H265_MAIN_10,
    // Main 12 profile
    E_MI_MM_VIDEO_CODEC_PROFILE_H265_MAIN_12,
    // Main 4:2:2 10 profile
    E_MI_MM_VIDEO_CODEC_PROFILE_H265_MAIN_422_10,
    // Main 4:2:2 12 profile
    E_MI_MM_VIDEO_CODEC_PROFILE_H265_MAIN_422_12,
    // Main 4:4:4 profile
    E_MI_MM_VIDEO_CODEC_PROFILE_H265_MAIN_444,
    // Main 4:4:4 10 profile
    E_MI_MM_VIDEO_CODEC_PROFILE_H265_MAIN_444_10,
    // Main 4:4:4 12 profile
    E_MI_MM_VIDEO_CODEC_PROFILE_H265_MAIN_444_12,
} MI_MM_VideoCodecProfile_e;

typedef enum
{
    E_MI_MM_VIDEO_CODEC_LEVEL_NONE             = 0x0,
    // MPEG2 level high
    E_MI_MM_VIDEO_CODEC_LEVEL_MPEG2_HIGH       = 0x10,
    // MPEG4 level 5
    E_MI_MM_VIDEO_CODEC_LEVEL_MPEG4_L5         = 0x20,
    // RCV high level
    E_MI_MM_VIDEO_CODEC_LEVEL_VC1_HIGH         = 0x30,
    // VC-1 advance level 3
    E_MI_MM_VIDEO_CODEC_LEVEL_VC1_L3,
    // H264 level 1
    E_MI_MM_VIDEO_CODEC_LEVEL_H264_L1          = 0x100,
    // H264 level 1b
    E_MI_MM_VIDEO_CODEC_LEVEL_H264_L1B,
    // H264 level 1.1
    E_MI_MM_VIDEO_CODEC_LEVEL_H264_L1_1,
    // H264 level 1.2
    E_MI_MM_VIDEO_CODEC_LEVEL_H264_L1_2,
    // H264 level 1.3
    E_MI_MM_VIDEO_CODEC_LEVEL_H264_L1_3,
    // H264 level 2
    E_MI_MM_VIDEO_CODEC_LEVEL_H264_L2,
    // H264 level 2.1
    E_MI_MM_VIDEO_CODEC_LEVEL_H264_L2_1,
    // H264 level 2.2
    E_MI_MM_VIDEO_CODEC_LEVEL_H264_L2_2,
    // H264 level 3
    E_MI_MM_VIDEO_CODEC_LEVEL_H264_L3,
    // H264 level 3.1
    E_MI_MM_VIDEO_CODEC_LEVEL_H264_L3_1,
    // H264 level 3.2
    E_MI_MM_VIDEO_CODEC_LEVEL_H264_L3_2,
    // H264 level 4
    E_MI_MM_VIDEO_CODEC_LEVEL_H264_L4,
    // H264 level 4.1
    E_MI_MM_VIDEO_CODEC_LEVEL_H264_L4_1,
    // H264 level 4.2
    E_MI_MM_VIDEO_CODEC_LEVEL_H264_L4_2,
    // H264 level 5
    E_MI_MM_VIDEO_CODEC_LEVEL_H264_L5,
    // H264 level 5.1
    E_MI_MM_VIDEO_CODEC_LEVEL_H264_L5_1,
    // H264 level 5.2
    E_MI_MM_VIDEO_CODEC_LEVEL_H264_L5_2,
    // H265 level 1
    E_MI_MM_VIDEO_CODEC_LEVEL_H265_L1          = 0x200,
    // H265 level 2
    E_MI_MM_VIDEO_CODEC_LEVEL_H265_L2,
    // H265 level 2.1
    E_MI_MM_VIDEO_CODEC_LEVEL_H265_L2_1,
    // H265 level 3
    E_MI_MM_VIDEO_CODEC_LEVEL_H265_L3,
    // H265 level 3.1
    E_MI_MM_VIDEO_CODEC_LEVEL_H265_L3_1,
    // H265 level 4 main tier
    E_MI_MM_VIDEO_CODEC_LEVEL_H265_L4_MAIN_TIER,
    // H265 level 4 high tier
    E_MI_MM_VIDEO_CODEC_LEVEL_H265_L4_HIGH_TIER,
    // H265 level 4.1 main tier
    E_MI_MM_VIDEO_CODEC_LEVEL_H265_L4_1_MAIN_TIER,
    // H265 level 4.1 high tier
    E_MI_MM_VIDEO_CODEC_LEVEL_H265_L4_1_HIGH_TIER,
    // H265 level 5 main tier
    E_MI_MM_VIDEO_CODEC_LEVEL_H265_L5_MAIN_TIER,
    // H265 level 5 high tier
    E_MI_MM_VIDEO_CODEC_LEVEL_H265_L5_HIGH_TIER,
    // H265 level 5.1 main tier
    E_MI_MM_VIDEO_CODEC_LEVEL_H265_L5_1_MAIN_TIER,
    // H265 level 5.1 high tier
    E_MI_MM_VIDEO_CODEC_LEVEL_H265_L5_1_HIGH_TIER,
    // H265 level 5.2 main tier
    E_MI_MM_VIDEO_CODEC_LEVEL_H265_L5_2_MAIN_TIER,
    // H265 level 5.2 high tier
    E_MI_MM_VIDEO_CODEC_LEVEL_H265_L5_2_HIGH_TIER,
    // H265 level 6 main tier
    E_MI_MM_VIDEO_CODEC_LEVEL_H265_L6_MAIN_TIER,
    // H265 level 6 high tier
    E_MI_MM_VIDEO_CODEC_LEVEL_H265_L6_HIGH_TIER,
    // H265 level 6.1 main tier
    E_MI_MM_VIDEO_CODEC_LEVEL_H265_L6_1_MAIN_TIER,
    // H265 level 6.1 high tier
    E_MI_MM_VIDEO_CODEC_LEVEL_H265_L6_1_HIGH_TIER,
    // H265 level 6.2 main tier
    E_MI_MM_VIDEO_CODEC_LEVEL_H265_L6_2_MAIN_TIER,
    // H265 level 6.2 high tier
    E_MI_MM_VIDEO_CODEC_LEVEL_H265_L6_2_HIGH_TIER,
} MI_MM_VideoCodecLevel_e;

typedef enum
{
    // Data Type: Audio
    E_MI_MM_DATA_TYPE_AUDIO,
    // Data Type: Video
    E_MI_MM_DATA_TYPE_VIDEO,
    // Data Type: Vorbis Header Info
    E_MI_MM_DATA_TYPE_VORBIS_HEADER,
    // Data Type: Ts
    E_MI_MM_DATA_TYPE_TS,
} MI_MM_DataType_e;

typedef enum
{
    // Dolby vision dual layer: None
    E_MI_MM_DOLBY_VISION_NONE,
    // Dolby vision dual layer: Base
    E_MI_MM_DOLBY_VISION_BASE_LAYER,
    // Dolby vision dual layer: Enhance
    E_MI_MM_DOLBY_VISION_ENHANCE_LAYER,
} MI_MM_DolbyVisionDualLayer_e;

typedef enum
{
    // None
    E_MI_MM_CLEAR_DATA_NONE = 0,
    // Audio Data
    E_MI_MM_CLEAR_DATA_AUDIO = (1<<0),
    // Video Data
    E_MI_MM_CLEAR_DATA_VIDEO = (1<<1),
} MI_MM_ClearData_e;

typedef enum
{
    // Stream music or photo
    E_MI_MM_STREAM_TYPE_NONE = 0,
    // Video of the movie
    E_MI_MM_STREAM_TYPE_VIDEO,
    // Subtitle of the movie
    E_MI_MM_STREAM_TYPE_SUBTITLE,
    // Audio of the movie
    E_MI_MM_STREAM_TYPE_AUDIO,
} MI_MM_StreamType_e;

typedef enum
{
    // Io open event, parameter type is a pointer to MI_MM_IoOpen_t
    E_MI_MM_IO_EVENT_OPEN = 0,
    // Io close event, parameter type is a pointer to MI_MM_IoClose_t
    E_MI_MM_IO_EVENT_CLOSE,
    // Io get length event, parameter type is a pointer to MI_MM_IoLength_t
    E_MI_MM_IO_EVENT_LENGTH,
    // Io seek event, parameter type is a pointer to MI_MM_IoSeek_t
    E_MI_MM_IO_EVENT_SEEK,
    // Io read event, parameter type is a pointer to MI_MM_IoRead_t
    E_MI_MM_IO_EVENT_READ,
    // All event needed
    E_MI_MM_IO_EVENT_ALL = 0xffffffff,
} MI_MM_IoEvent_e;

typedef enum
{
    E_MI_MM_TS_PACKET_LENGTH_INVALID = -1,  // Invalid transport stream packet length
    E_MI_MM_TS_PACKET_LENGTH_188 = 0,       // Transport stream packet length is 188 bytes
    E_MI_MM_TS_PACKET_LENGTH_192,           // Transport stream packet length is 192 bytes
    E_MI_MM_TS_PACKET_LENGTH_204,           // Transport stream packet length is 204 bytes
} MI_MM_TsPacketLength_e;

typedef enum
{
    E_MI_MM_AUDIO_EASE_TYPE_LINEAR = 0x0,   // Ease linear type
    E_MI_MM_AUDIO_EASE_TYPE_IN_CUBIC,       // Ease in-cubic type
    E_MI_MM_AUDIO_EASE_TYPE_OUT_CUBIC,      // Ease out-cubic type
    E_MI_MM_AUDIO_EASE_TYPE_IN_OUT_CUBIC,   // Ease in/out-cubic type
} MI_MM_AudioEaseType_e;

typedef enum
{
    // MM already detile frame data to upper layer provided frame buffer
    E_MI_MM_FRAME_BUFFER_EVENT_RENDERED_BUFFER,
    E_MI_MM_FRAME_BUFFER_EVENT_ALL = 0xffffffff,
} MI_MM_FrameBufferEvent_e;

typedef enum
{
    // Color format UnSupport
    E_MI_MM_FRAME_BUFFER_COLOR_FORMAT_NONE              = 0,
    //Color format ARGB8888
    E_MI_MM_FRAME_BUFFER_COLOR_FORMAT_ARGB8888          = 1 << 0,
    //Color format ARGB1555
    E_MI_MM_FRAME_BUFFER_COLOR_FORMAT_ARGB1555          = 1 << 1,
    //Color format ARGB4444
    E_MI_MM_FRAME_BUFFER_COLOR_FORMAT_ARGB4444          = 1 << 2,
    //Color format YUV422
    E_MI_MM_FRAME_BUFFER_COLOR_FORMAT_YUV422            = 1 << 3,
    //Color format YVYU
    E_MI_MM_FRAME_BUFFER_COLOR_FORMAT_YVYU              = 1 << 4,
    //Color format ABGR
    E_MI_MM_FRAME_BUFFER_COLOR_FORMAT_ABGR8888          = 1 << 5,
    //Color format RGB565
    E_MI_MM_FRAME_BUFFER_COLOR_FORMAT_RGB565            = 1 << 6,
    //Color format YUV420 NV12
    E_MI_MM_FRAME_BUFFER_COLOR_FORMAT_YUV420_NV12       = 1 << 7,
    //Color format YUV422 UYVY
    E_MI_MM_FRAME_BUFFER_COLOR_FORMAT_YUV422_UYVY       = 1 << 8,
    //Color format YUV420
    E_MI_MM_FRAME_BUFFER_COLOR_FORMAT_YUV420            = 1 << 9,
    //Color format YC422
    E_MI_MM_FRAME_BUFFER_COLOR_FORMAT_YC422             = 1 << 10,
    //Color format MStar NV12
    E_MI_MM_FRAME_BUFFER_COLOR_FORMAT_MST_NV12          = 1 << 11,
} MI_MM_FrameBufferColorFormat_e;

typedef enum
{
    // Rotation angle is invalid.
    E_MI_MM_ROTATE_INVALID = -1,
    // Rotation angle is 0 degree.
    E_MI_MM_ROTATE_0 = 0,
    // Rotation angle is 90 degree.
    E_MI_MM_ROTATE_90,
    // Rotation angle is 180 degree.
    E_MI_MM_ROTATE_180,
    // Rotation angle is 270 degree.
    E_MI_MM_ROTATE_270,
} MI_MM_RotateAngle_e;

typedef enum
{
    E_MI_MM_DRM_CRYPTO_SCHEME_CLEAR = 0,    // Clear data
    E_MI_MM_DRM_CRYPTO_SCHEME_AES_CTR,      // AES CTR mode
    E_MI_MM_DRM_CRYPTO_SCHEME_AES_CBC,      // AES CBC mode
    E_MI_MM_DRM_CRYPTO_SCHEME_MAX,          // max enum of DRM crypto scheme
} MI_MM_DrmCryptoScheme_e;

typedef enum
{
    E_MI_MM_DRM_TYPE_NONE = 0,              // DRM type none
    E_MI_MM_DRM_TYPE_PLAYREADY,             // DRM type playready
    E_MI_MM_DRM_TYPE_WIDEVINE_CENC,         // DRM type widevine
    E_MI_MM_DRM_TYPE_HDCP,                  // DRM type hdcp
    E_MI_MM_DRM_TYPE_MAX,                   // Max enum of DRM type
} MI_MM_DrmType_e;

typedef enum
{
    E_MI_MM_RENDER_UNDERFLOW_NONE = 0,
    E_MI_MM_RENDER_UNDERFLOW_DETECTION,
    E_MI_MM_RENDER_UNDERFLOW_AUTOPAUSE,
    E_MI_MM_RENDER_UNDERFLOW_MAX
} MI_MM_RenderUnderflow_e;

typedef struct MI_MM_TrickInfo_s
{
    MI_MM_TrickAction_e eAction;            /// [OUT] Trick Action
    MI_MM_TrickSpeed_e eSpeed;              /// [OUT] Trick Speed
} MI_MM_TrickInfo_t;

/// Define the information for preview process.
typedef struct MI_MM_PreviewSetting_s
{
    /// [IN] Preview mode.
    MI_MM_PreviewMode_e eMode;
    /// [IN] The time stamp for preview pause time (ms unit). Valid for preview mode is E_PREVIEW_VIDEO_PAUSE_MODE.
    /// The time stamp for do thumbnail time (ms unit). Valid for preview mode is E_PREVIEW_THUMBNAIL_MODE.
    MI_U32 u32VideoPauseTime;
} MI_MM_PreviewSetting_t;

typedef struct MI_MM_OpenParams_s
{
    MI_U8 *pszName;                         /// [IN] String name
    MI_MM_MediaType_e eMediaType;           /// [IN] Media type
} MI_MM_OpenParams_t;

typedef struct MI_MM_QueryHandleParams_s
{
    MI_U8 *pszName;                         /// [IN] String name
    MI_MM_MediaType_e eMediaType;           /// [IN] Media type
} MI_MM_QueryHandleParams_t;

typedef struct MI_MM_StartParams_s
{
    MI_BOOL bInitOnly;                      /// [IN] Init only or not
    MI_BOOL bPreviewEnable;                 /// [IN] Preview enable
    MI_U8 *pu8DirMemInputBuf;               /// [IN] Photo Direct Memory Input Buffer
    MI_U32 u32DirMemInputBufLen;            /// [IN] Direct Memory Input Buffer Length
    MI_MM_PreviewSetting_t stPreviewSetting;/// [IN] Preview settings
    MI_MM_FileMode_e eFileOption;           /// [IN] File option
    MI_U8* pszFileName;                     /// [IN] File name
    MI_BOOL bMuteAudio;                     /// [IN] Mute audio when playing. The audio of previous non-mute movie will be muted if setting non-mute to this movie
    MI_BOOL bSecureModeEnable;              /// [IN] Enable secure mode
    MI_HANDLE hDisplay;                     /// [IN] Display handle
    MI_HANDLE hAout;                        /// [IN] Aout handle
    MI_MM_DrmType_e eDrmType;               /// [IN] DRM type
    MI_BOOL bIsLowLatencyMode;              /// [IN] Enable low latency mode
} MI_MM_StartParams_t;

typedef struct MI_MM_MusicStringInfo_s
{
    MI_U32 u32StringLen;                    /// [OUT] String length
    MI_VIRT virtStringAddr;                 /// [OUT] String data addr
} MI_MM_MusicStringInfo_t;

typedef struct MI_MM_MusicInfo_s
{
    MI_U32 u32TotalTime;                    /// [OUT] Total time
    MI_U32 u32CurentTime;                   /// [OUT] Current time
    MI_U32 u32MusicErrCode;                 /// [OUT] Error code
    MI_MM_TrickMode_e eTrickMode;           /// [OUT] Trick mode
    MI_MM_AudioCodecType_e eCodec;          /// [OUT] Music codec
    MI_BOOL bVariableBitRate;               /// [OUT] Variable bit rate or not
    MI_BOOL bPictureExist;                  /// [OUT] Has picture or not
    MI_U32 u32PictureOffset;                /// [OUT] If has picture, picture offset
    MI_U32 u32PictureSize;                  /// [OUT] If has picture, picture size
    MI_MM_TrickInfo_t stTrickInfo;          /// [OUT] Music playing status
    MI_U64 u64CurrentTime;                  /// [OUT] Current playing time in 64bit base
} MI_MM_MusicInfo_t;

typedef struct MI_MM_DateTime_s
{
    MI_U32 u32Year;                         /// [OUT] Time unit (Year)
    MI_U32 u32Month;                        /// [OUT] Time unit (Month)
    MI_U32 u32Day;                          /// [OUT] Time unit (Day)
    MI_U32 u32Hour;                         /// [OUT] Time unit (Hour)
    MI_U32 u32Minute;                       /// [OUT] Time unit (Minute)
    MI_U32 u32Second;                       /// [OUT] Time unit (Second)
} MI_MM_DateTime_t;

typedef struct MI_MM_PhotoInfo_s
{
    MI_U32 u32PhotoOutputWidth;                     /// [OUT] Width (decoded result, may be reduced)
    MI_U32 u32PhotoOutputHeight;                    /// [OUT] Height (decoded result, may be reduced)
    MI_U32 u32PhotoOutputPitch;                     /// [OUT] Pitch (decoded result, may be reduced) (Unit: byte)
    MI_U32 u32PhotoDecodeProgress;                  /// [OUT] Decode progress in percentage
    MI_U32 u32PhotoErrCode;                         /// [OUT] Error code
    MI_MM_InfoSubType_e ePhotoType;                 /// [OUT] Photo type
    MI_U32 u32PhotoSourceWidth;                     /// [OUT] Source width
    MI_U32 u32PhotoSourceHeight;                    /// [OUT] Source height
    MI_MM_PhotoDecoderStatus_e ePhotoDecoderStatus; /// [OUT] Decoder status
    MI_MM_PhotoColorFormat_e ePhotoColorFormat;     /// [OUT] Color format
    MI_BOOL bThumbnailExist;                        /// [OUT] Has thumbnail or not
    MI_BOOL bDateExist;                             /// [OUT] Has created time or not
    MI_MM_DateTime_t stDateTime;                    /// [OUT] Photo date time info
} MI_MM_PhotoInfo_t;

typedef struct MI_MM_MovieInfo_s
{
    MI_U32 u32TotalTime;                /// [OUT] Total time
    MI_BOOL bTotalTimeValid;            /// [OUT] Total time is valid or not
    MI_U32 u32CurentTime;               /// [OUT] Current time
    MI_U32 u32FramePerSec;              /// [OUT] Frame update rate per second
    MI_U32 u32MovieWidth;               /// [OUT] Movie width
    MI_U32 u32MovieHeight;              /// [OUT] Movie height
    MI_U32 u32TotalAudioTrack;          /// [OUT] Total audio track
    MI_U32 u32AudioTrack;               /// [OUT] Audio track

    MI_U32 u32TotalSubtitleTrack;       /// [OUT] Total subtitle track
    MI_U32 u32SubtitleTrack;            /// [OUT] Subtitle track
    MI_U32 u32TotalProgram;             /// [OUT] Total program
    MI_U32 u32Program;                  /// [OUT] Program
    MI_MM_VideoCodecType_e eVideoCodec; /// [OUT] Video codec
    MI_MM_AudioCodecType_e eAudioCodec; /// [OUT] Audio codec
    MI_U32 u32DurationPercent;          /// [OUT] Current play time in percentage
    MI_U32 u32MovieErrCode;             /// [OUT] Error code
    MI_BOOL bIndexTableExist;           /// [OUT] Whether or not the movie contains an Index table (supports seek function or not)
    MI_U32 u32BufferPercent;            /// [OUT] Buffering percentage

    MI_MM_TrickMode_e eTrickMode;       /// [OUT] Trick mode

    MI_U32 u32MovieDarWidth;            /// [OUT] Movie display aspect ratio (width)
    MI_U32 u32MovieDarHeight;           /// [OUT] Movie display aspect ratio (height)
    MI_U32 u32AudioChannelCount;        /// [OUT] Audio channel count of current playing audio
    MI_MM_TrickInfo_t stTrickInfo;      /// [OUT] Trick play action and speed info
    MI_U32 u32TrickModeOption;          /// [OUT] Related with MI_MM_TrickOption_e (Bitwise)
    MI_U32 u32DecodedFrameCount;        /// [OUT] Decode frame count
    MI_U32 u32ErrorFrameCount;          /// [OUT] Error frame count
    MI_U32 u32SkipFrameCount;           /// [OUT] Skip frame count
    MI_U32 u32DropFrameCount;           /// [OUT] Drop frame count

    MI_MM_FileFormat_e eFileFormat;     /// [OUT] File Format.
} MI_MM_MovieInfo_t;

typedef struct MI_MM_PhotoAddr_s
{
    MI_VIRT virtInputBufAddr;           /// [OUT] Input buffer address, the decoder will read from this buffer to decode photo
    MI_VIRT virtOutputBufAddr;          /// [OUT] Output buffer address, the buffer has decoded result.
    MI_VIRT virtInterBufAddr;           /// [OUT] Interim buffer address, the decoder will use this buffer to decode the photo.
    MI_VIRT virtDisplayBufAddr;         /// [OUT] Display buffer address.
} MI_MM_PhotoAddr_t;

typedef struct MI_MM_InitParams_s
{
    MI_U8 u8Reserved;                   //// Reserverd
} MI_MM_InitParams_t;

typedef struct MI_MM_PhotoDrawingInfo_s
{
    MI_HANDLE hMm;                      /// [IN] MM handle
    MI_MM_PhotoAddr_t stPhotoAddr;      /// [IN] Structure of photo addresses, such as MM output address
    MI_MM_PhotoInfo_t stPhotoInfo;      /// [IN] Structure of photo information, such as photo pitch, width, …
} MI_MM_PhotoDrawingInfo_t;

typedef struct MI_MM_ThumbnailParams_s
{
    MI_U8* pu8Addr;                     /// [IN] Thumbnail Address (Virtual)
    MI_U32 u32AddrSize;                 /// [IN] Thumbnail Size
    MI_U32 u32Width;                    /// [IN] Thumbnail Width
    MI_U32 u32Height;                   /// [IN] Thumbnail Height
    MI_MM_ThumbnailColorFmt_e eColorFmt;/// [IN] Thumbnail color format
} MI_MM_ThumbnailParams_t;

typedef struct MI_MM_ResumeInfo_s
{
    /// File position.
    /// [IN] For MI_MM_SetAttr
    /// [OUT] For MI_MM_GetAttr
    MI_U64 u64FilePos;
    /// Media present time stamp. (ms)
    /// [IN] For MI_MM_SetAttr
    /// [OUT] For MI_MM_GetAttr
    MI_U64 u64Pts;
    /// audio index
    /// [IN] For MI_MM_SetAttr
    /// [OUT] For MI_MM_GetAttr
    MI_U8 u8AudioTrackId;
} MI_MM_ResumeInfo_t;

typedef struct MI_MM_EsVideoInfo_s
{
    /// [IN] Video width
    MI_U32 u32Width;
    /// [IN] Video Height
    MI_U32 u32Height;
    /// [IN] Video frame rate. Denominator is 1000. ex: 23976 = 23.796 fps
    MI_U32 u32FrameRate;
    /// [IN] Decide video freerun or not
    MI_BOOL bAvsyncDisable;
    /// [IN] Enable video drop error frame or not
    MI_BOOL bDropErrorFrame;
    /// [IN] Send PTS or DTS
    MI_BOOL bPtsMode;
    /// [IN] MM would calculate PTS by self
    MI_BOOL bLivePlayback;
    /// [IN] Enable Seamless or not
    MI_BOOL bEnableSeamless;
    /// [IN] Data send NAL size or general header(00000001).
    MI_MM_EsNalSize_e eNalSizeUnit;
} MI_MM_EsVideoInfo_t;

typedef struct MI_MM_Hdr10Info_s
{
    /// [IN] Maximum luminance. Shall be represented in candelas per square meter (cd/m2).
    MI_U32  u32MaxLuminance;
    /// [IN] Minimum luminance. Shall be represented in candelas per square meter (cd/m2).
    MI_U32  u32MinLuminance;
    /// [IN] (Red, Green, Blue) (X, Y) chromaticity coordinate as defined by CIE 1931.
    MI_U16  au16Primaries[MI_MM_HDR10_CHROMATICITY][MI_MM_HDR10_COORDINATE];  /// [R,G,B][X,Y]
    /// [IN] White X, Y chromaticity coordinate as defined by CIE 1931.
    MI_U16  au16WhitePoint[MI_MM_HDR10_COORDINATE];     /// [X,Y]
    /// [IN] Maximum brightness of a single pixel (Maximum Content Light Level) in candelas per square meter (cd/m2).
    MI_U16  u16MaxContentLightLevel;
    /// [IN] Maximum brightness of a single full frame (Maximum FrameAverage Light Level) in candelas per square meter (cd/m2).
    MI_U16  u16MaxFrameAvgLightLevel;
    /// [IN] The Matrix Coefficients of the video used to derive luma and chroma values from reg, green, and blue color primaries.
    /// For clarity, the value and meanings for MatrixCoefficients are adopted from Table 4 of ISO/IEC 230018:2013/DCOR1.
    /// (0:GBR, 1: BT709, 2: Unspecified, 3: Reserved, 4: FCC, 5: BT470BG, 6: SMPTE 170M, 7: SMPTE 240M, 8: YCOCG, 9: BT2020 Nonconstant Luminance, 10: BT2020 Constant Luminance)
    MI_U8   u8MatrixCoefficients;
    /// [IN] Number of decoded bits per channel. A value of 0 indicates that the BitsPerChannel is unspecified .
    MI_U8   u8BitsPerChannel;
    /// [IN] The amount of pixels to remove in the Cr and Cb channels for every pixel not removed horizontally.
    /// Example: For video with 4:2:0 chroma subsampling, the ChromaSubsamplingHorz should be set to 1.
    MI_U8   u8ChromaSubsamplingHorz;
    /// [IN] The amount of pixels to remove in the Cr and Cb channels for every pixel not removed vertically.
    /// Example: For video with 4:2:0 chroma subsampling, the ChromaSubsamplingVert should be set to 1.
    MI_U8   u8ChromaSubsamplingVert;
    /// [IN] The amount of pixels to remove in the Cb channel for every pixel not removed horizontally. This is additive with ChromaSubsamplingHorz.
    /// Example: For video with 4:2:1 chroma subsampling, the ChromaSubsamplingHorz should be set to 1 and CbSubsamplingHorz should be set to 1.
    MI_U8   u8CbSubsamplingHorz;
    /// [IN] The amount of pixels to remove in the Cb channel for every pixel not removed vertically. This is additive with ChromaSubsamplingVert.
    MI_U8   u8CbSubsamplingVert;
    /// [IN] How chroma is subsampled horizontally. (0:Unspecified, 1: Left Collocated, 2: Half)
    MI_U8   u8ChromaSitingHorz;
    /// [IN] How chroma is subsampled vertically. (0:Unspecified, 1: Top Collocated, 2: Half)
    MI_U8   u8ChromaSitingVert;
    /// [IN] Clipping of the color ranges. (0: Unspecified, 1:Broadcast Range, 2: Full range (no clipping), 3:Defined by MatrixCoefficients/ TransferCharacteristics )
    MI_U8   u8ColorRange;
    /// [IN] The transfer characteristics of the video. For clarity, the value and meanings for TransferCharacteristics 115 are adopted from Table 3 of ISO/IEC 230018:2013/DCOR1. TransferCharacteristics 1618 are proposed values.
    /// (0: Reserved, 1: ITUR BT.709, 2:Unspecified, 3: Reserved, 4: Gamma 2.2 curve, 5: Gamma 2.8 curve, 6: SMPTE 170M, 7:SMPTE 240M, 8: Linear, 9: Log, 10: Log Sqrt, 11: IEC 6196624,
    /// 12: ITUR BT.1361 Extended Colour Gamut, 13: IEC 6196621, 14: ITUR BT.2020 10 bit, 15: ITUR BT.2020 12 bit, 16: SMPTE ST 2084, 17: SMPTE ST 4281 18:ARIB STDB67 (HLG))
    MI_U8   u8TransferCharacteristics;
    /// [IN] The color primaries of the video. For clarity, the value and meanings for Primaries are adopted from Table 2 of ISO/IEC 230018:2013/DCOR1.
    /// (0: Reserved, 1: ITUR BT.709, 2: Unspecified, 3: Reserved, 4: ITUR BT.470M, 5: ITUR BT.470BG, 6: SMPTE 170M, 7: SMPTE 240M, 8: FILM, 9: ITUR BT.2020, 10: SMPTE ST 4281, 22: JEDEC P22 phosphors)
    MI_U8   u8ColourPrimaries;
} MI_MM_Hdr10Info_t;

typedef struct MI_MM_DolbyVisionInfo_s
{
    /// [IN] Video's Dolby Vision Profile
    MI_MM_DolbyVisionProfile_e eProfile;
    /// [IN] Video's Dolby Vision Level
    MI_MM_DolbyVisionLevel_e eLevel;
    /// [IN] Meta data follow BL/EL.
    MI_MM_DolbyVisionMetaFollow_e eMetaFollow;
} MI_MM_DolbyVisionInfo_t;

typedef struct MI_MM_EsVideoParams_s
{
    /// [IN] Video codec
    MI_MM_VideoCodecType_e eCodec;
    /// [IN] Video Info
    MI_MM_EsVideoInfo_t stVideoInfo;
    /// [IN] Video hdr 10 info
    MI_MM_Hdr10Info_t stHdr10Info;
    /// [IN] Video dolby vision info
    MI_MM_DolbyVisionInfo_t stDolbyVisionInfo;
} MI_MM_EsVideoParams_t;

typedef struct MI_MM_EsAudioAacInfo_s
{
    /// [IN] Sampling rate, 48000(48KHz), 44100(44.1KHz), 32000(32KHz),....
    MI_U32 u32SampleRate;
    /// [IN] AAC object type for ADTS component. Reference ISO/IEC 14496-3:2009
    MI_U32 u32ObjectTypeId;
    /// [IN] AAC channel
    MI_U32 u32Channel;
} MI_MM_EsAudioAacInfo_t;

typedef struct MI_MM_EsAudioPcmInfo_s
{
    /// [IN] Sampling rate, 48000(48KHz), 44100(44.1KHz), 32000(32KHz),....
    MI_U32 u32SampleRate;
    /// [IN] Bits per sample, 8(bits), 16(bits), 24(bits),...
    MI_U32 u32BitsPerSample;
    /// [IN] Channels, 1(mono), 2(stereo),...
    MI_U32 u32Channel;
} MI_MM_EsAudioPcmInfo_t;

typedef struct MI_MM_EsAudioAdpcmInfo_s
{
    /// [IN] Sampling rate, 48000(48KHz), 44100(44.1KHz), 32000(32KHz),....
    MI_U32 u32SampleRate;
    /// [IN] Bits per sample, 8(bits), 16(bits), 24(bits),...
    MI_U32 u32BitsPerSample;
    /// [IN] Channels, 1(mono), 2(stereo),...
    MI_U32 u32Channel;
    /// [IN] Block Alignment
    MI_U32 u32BlockAlign;
    /// [IN] Samplers per Block, 2(samples), 3(samples),...
    MI_U32 u32SamplesPerBlock;
} MI_MM_EsAudioAdpcmInfo_t;

typedef struct MI_MM_EsAudioRmInfo_s
{
    /// [IN] Sampling rate, 48000(48KHz), 44100(44.1KHz), 32000(32KHz),....
    MI_U32 u32SampleRate;
} MI_MM_EsAudioRmInfo_t;

typedef struct MI_MM_EsAudioWmaInfo_s
{
    /// [IN] Version
    MI_U8 u8Version;
    /// [IN] Wma encode option
    MI_U16 u16EncodeOpt;
    /// [IN] Wma encode option
    MI_U16 u16AdvanceEncodeOpt;
    /// [IN] Sampling rate, 48000(48KHz), 44100(44.1KHz), 32000(32KHz),....
    MI_U32 u32SampleRate;
    /// [IN] Bits per sample, 8(bits), 16(bits), 24(bits),...
    MI_U32 u32BitsPerSample;
    /// [IN] Channels, 1(mono), 2(stereo),...
    MI_U32 u32Channel;
    /// [IN] Bit rate
    MI_U32 u32BitRate;
    /// [IN] Block Alignment
    MI_U32 u32BlockAlign;
    /// [IN] Channel mask define channel in different place
    MI_U32 u32ChannelMask;
} MI_MM_EsAudioWmaInfo_t;

typedef struct MI_MM_EsAudioAmrInfo_s
{
    /// [IN] Sampling rate, 48000(48KHz), 44100(44.1KHz), 32000(32KHz),....
    MI_U32 u32SampleRate;
    /// [IN] Bits per sample, 8(bits), 16(bits), 24(bits),...
    MI_U32 u32BitsPerSample;
    /// [IN] Channels, 1(mono), 2(stereo),...
    MI_U32 u32Channel;
} MI_MM_EsAudioAmrInfo_t;

typedef struct MI_MM_EsAudioParams_s
{
    /// [IN] Audio codec type
    MI_MM_AudioCodecType_e eCodec;
    union{
        /// [IN] AAC info
        MI_MM_EsAudioAacInfo_t   stEsAacInfo;
        /// [IN] PCM info
        MI_MM_EsAudioPcmInfo_t   stEsPcmInfo;
        /// [IN] Adpcm info
        MI_MM_EsAudioAdpcmInfo_t stEsAdpcmInfo;
        /// [IN] Rm info
        MI_MM_EsAudioRmInfo_t    stEsRmInfo;
        /// [IN] Wma info
        MI_MM_EsAudioWmaInfo_t   stEsWmaInfo;
        /// [IN] Amr info
        MI_MM_EsAudioAmrInfo_t   stEsAmrInfo;
    } attr;
} MI_MM_EsAudioParams_t;

typedef struct MI_MM_SubtitleTrackInfo_s
{
    /// [OUT] Current subtitle track id.
    MI_U8 u8TrackId;
    /// [OUT] Total ttx track.
    MI_U8 u8TrackCount;
    /// [OUT] Subtitle type.
    MI_MM_SubtitleType_e eSubtitleType;
    /// [OUT] Subtitle Language (ISO-639)
    MI_U8  au8Language[4];
    /// [OUT] TS file: component_tag field in the stream_identifier_descriptor in PMT which defined at 8.4.2 AVComponent of OIPF-DAE spec.
    MI_U32 u32ComponentTag;
    /// [OUT] TS file: subtitling_type field in the subtitling_descriptor which defined at 8.4.2 AVComponent of OIPF-DAE spec & spec ETSI EN 300 468: 6.2.41 Subtitling descriptor
    MI_U32 u32SubtitlingType;
} MI_MM_SubtitleTrackInfo_t;

typedef struct MI_MM_CodecCapsInfo_s
{
    // [OUT] Video capability width
    MI_U32 u32MaxWidth;
    // [OUT] Video capability height
    MI_U32 u32MaxHeight;
    // [OUT] Video capability framerate
    MI_U32 u32MaxFrameRate;
    // [OUT] Codec level capability
    MI_MM_VideoCodecLevel_e eLevel;
    // [OUT] Codec profile capability
    MI_MM_VideoCodecProfile_e eProfile;
    // [OUT] MPEG4 version capability
    MI_MM_VideoCodecVersion_e eVersion;
} MI_MM_CodecCapsInfo_t;

typedef struct MI_MM_StreamData_s
{
    /// [IN] The 64bit base time stamp (ms)
    MI_U64 u64Pts;
    /// [IN] Data start address (virtual)
    MI_U8* pu8BufAddr;
    /// [IN] Data u32Size u32Size
    MI_U32 u32BufSize;
    /// [IN] Input Data Type
    MI_MM_DataType_e eDataType;
    /// [IN] End of Segment for seamless player
    MI_BOOL bEndOfSegment;
    /// [IN] Dolby Vision : track 1 base layer, track 2 enhance layer
    MI_MM_DolbyVisionDualLayer_e eDolbyVisionDualLayer;
} MI_MM_StreamData_t;

//the callback of MI_MM_RegisterCallback, u32Event is releated MI_MM_EventType_e
typedef MI_RESULT (*MI_MM_EventCallback)(MI_HANDLE hMm, MI_U32 u32Event, void *pEventParams, void *pUserParams);

typedef struct MI_MM_CallbackInputParams_s
{
    /// [IN] For multi-callback, use 0 for first register or single callback.
    MI_U64 u64CallbackId;
    /// [IN] Callback function pointer
    MI_MM_EventCallback pfEventCallback;
    /// [IN] registered events.
    MI_U32 u32EventFlags;
    /// [IN] User parameter
    void *pUserParams;
} MI_MM_CallbackInputParams_t;

typedef struct MI_MM_CallbackOutputParams_s
{
    /// [OUT] the returned ID for update or unregister callback.
    MI_U64 u64CallbackId;
} MI_MM_CallbackOutputParams_t;

typedef struct MI_MM_IoOpen_s
{
    // [IN] Filename to be opened
    MI_U8 *pszFileName;
    // [IN] File open flag, e.q. "rb"
    MI_U8 *pu8Mode;
    // [IN] Specify the stream format of the file
    MI_MM_StreamType_e eType;
    // [OUT] File descriptor of the opened file
    void *pRetStream;
} MI_MM_IoOpen_t;

typedef struct MI_MM_IoClose_s
{
    // [IN] File descriptor of the opened file
    void *pStream;
} MI_MM_IoClose_t;

typedef struct MI_MM_IoLength_s
{
    // [IN] File descriptor of the opened file
    void *pStream;
    // [OUT] File length
    MI_U64 u64RetLength;
} MI_MM_IoLength_t;

typedef struct MI_MM_IoSeek_s
{
    // [IN] File descriptor of the opened file
    void *pStream;
    // [IN] Seek offset of the file
    MI_U64 u64Offset;
} MI_MM_IoSeek_t;

typedef struct MI_MM_IoRead_s
{
    // [IN] File descriptor of the opened file
    void *pStream;
    // [IN] Read buffer address
    void *pBufAddr;
    // [IN] Read size of the file
    MI_S32 s32Size;
    // [OUT] Size of readed data
    MI_S32 s32RetReadSize;
} MI_MM_IoRead_t;

typedef MI_RESULT (*MI_MM_IoEventCallback)(MI_HANDLE hMm, MI_U32 u32Event, void *pIoEventParams, void *pUserParams);
typedef struct MI_MM_IoCallbackInputParams_s
{
    /// [IN] For multi-callback, use 0 for first register or single callback.
    MI_U64 u64CallbackId;
    /// [IN] Callback function pointer
    MI_MM_IoEventCallback pfEventCallback;
    /// [IN] Registered events.
    MI_U32 u32EventFlags;
    /// [IN] User parameter
    void *pUserParams;
} MI_MM_IoCallbackInputParams_t;

typedef struct MI_MM_IoCallbackOutputParams_s
{
    /// [OUT] The returned ID for update or unregister callback.
    MI_U64 u64CallbackId;
} MI_MM_IoCallbackOutputParams_t;

typedef struct MI_MM_AudioTrackInfo_s
{
    /// [OUT] Audio Codec
    MI_MM_AudioCodecType_e eCodec;
    /// [OUT] Audio Language
    MI_U8 au8Language[4];
    /// [OUT] MP4 file trackID or TS file PID which defined at 8.4.2 AVComponent of OIPF-DAE spec.
    MI_U32 u32TrackPid;
    /// [OUT] TS file: component_tag field in the stream_identifier_descriptor in PMT which defined at 8.4.2 AVComponent of OIPF-DAE spec.
    MI_U32 u32ComponentTag;
    /// [OUT] Audio Channels
    MI_U32 u32ChannelCount;
    /// [OUT] TS file: True if is component is an audio description
    MI_BOOL bIsAudioDescription;
} MI_MM_AudioTrackInfo_t;

typedef struct MI_MM_VideoTrackInfo_s
{
    /// [OUT] MP4 file trackID or TS file PID which defined at 8.4.2 AVComponent of OIPF-DAE spec.
    MI_U32 u32TrackPid;
    /// [OUT] TS file: component_tag field in the stream_identifier_descriptor in PMT which defined at 8.4.2 AVComponent of OIPF-DAE spec.
    MI_U32 u32ComponentTag;
} MI_MM_VideoTrackInfo_t;

typedef struct MI_MM_BufferInfo_s
{
    /// [OUT] Video data buffer data size which is waiting for display
    MI_U32 u32Size;
    /// [OUT] Video data buffer the residual play time of demuxed data(ms).
    MI_U32 u32Duration;
    /// [OUT] Video data buffer fill percetage.
    MI_U32 u32Percentage;
    /// [OUT] Video average bit-rate (Input process total size/last PTS)
    MI_U32 u32BitRate;
} MI_MM_BufferInfo_t;

typedef struct MI_MM_PlaybackTimeInfo_s
{
    /// [OUT] Audio's pts (ms)
    MI_U64 u64AudioPts;
    /// [OUT] Video's pts (ms)
    MI_U64 u64VideoPts;
    /// [OUT] Current time (ms)
    MI_U64 u64CurrentTime;
    /// [OUT] Total Time (ms)
    MI_U64 u64TotalTime;

    /// Linux STC Time Spec: (sec), (nsec)
    /// [OUT] System Time Seconds (sec)
    MI_U64 u64StcSeconds;
    /// [OUT] System Time Nano Seconds (nsec)
    MI_U32 u32StcNanoSeconds;
} MI_MM_PlaybackTimeInfo_t;

typedef struct MI_MM_FirstPresentionTimeInfo_s
{
    /// get the current presentation clock(ms)
    MI_U64 u64PresentionTime;

    /// Linux STC Time Spec: (sec), (nsec)
    /// [OUT] System Time Seconds (sec)
    MI_U64 u64StcSeconds;
    /// [OUT] System Time Nano Seconds (nsec)
    MI_U32 u32StcNanoSeconds;
} MI_MM_FirstPresentionTimeInfo_t;

typedef struct MI_MM_ComponentId_s
{
    /// [OUT]
    MI_U32 u32VideoId;
    /// [OUT]
    MI_U32 u32AudioId;
} MI_MM_ComponentId_t;

typedef struct MI_MM_ApTypeParams_s
{
    /// [IN] Ap type
    MI_MM_ApType_e eApType;
    /// [IN] Need set in ap type: string
    MI_U8 *pszApName;
} MI_MM_ApTypeParams_t;

typedef struct MI_MM_TsInfo_s
{
    // [IN] Transport stream's video codec
    MI_MM_VideoCodecType_e eVideoCodec;
    // [IN] Transport stream's audio codec
    MI_MM_AudioCodecType_e eAudioCodec;
    // [IN] Transport stream's video pid
    MI_U16 u16VideoPid;
    // [IN] Transport stream's audio pid
    MI_U16 u16AudioPid;
    // [IN] Transport stream's packet length
    MI_MM_TsPacketLength_e eTsPktLen;
    // [IN] Transport stream's subtitle pid
    MI_U16 u16SubtitlePid;
} MI_MM_TsInfo_t;

//the callback of MI_MM_RegisterCallback, u32Event is releated MI_MM_FrameBufferEventType_e
typedef MI_RESULT (*MI_MM_FrameBufferEventCallback)(MI_HANDLE hMm, MI_U32 u32Event, void *pEventParams, void *pUserParams);

typedef struct MI_MM_FrameBufferCallbackInputParams_s
{
    /// [IN] For multi-callback, use 0 for first register or single callback.
    MI_U64 u64CallbackId;
    /// [IN] Callback function pointer
    MI_MM_FrameBufferEventCallback pfEventCallback;
    /// [IN] registered events.
    MI_U32 u32EventFlags;
    /// [IN] User parameter
    void *pUserParams;
} MI_MM_FrameBufferCallbackInputParams_t;

typedef struct MI_MM_FrameBufferCallbackOutputParams_s
{
    /// [OUT] the returned ID for update or unregister callback.
    MI_U64 u64CallbackId;
} MI_MM_FrameBufferCallbackOutputParams_t;

typedef struct MI_MM_FrameBuffer_s
{
    /// [OUT] Resolution Width
    MI_U32 u32Width;
    /// [OUT] Resolution Height
    MI_U32 u32Height;
    /// [OUT] Color Format
    MI_MM_FrameBufferColorFormat_e eColorFormat;
    /// [OUT] Frame Pitch
    MI_U32 u32Pitch;
    /// [OUT] Buffer Address
    MI_PHY phyFrameBufferAddr;
    /// [OUT] Buffer Size
    MI_U32 u32Size;
} MI_MM_FrameBuffer_t;

typedef struct MI_MM_RenderedFrameBuffer_s
{
    // [IN] Frame buffer info
    MI_MM_FrameBuffer_t stFrameBufferInfo;
    // [IN] Video left crop size (pixel unit)
    MI_U16 u16CropLeft;
    // [IN] Video right crop size (pixel unit)
    MI_U16 u16CropRight;
    // [IN] Video top crop size (pixel unit)
    MI_U16 u16CropTop;
    // [IN] Video bottom crop size (pixel unit)
    MI_U16 u16CropBottom;
    /// DMA buffer(native buffer) File Descriptors
    MI_S32 as32NativeBufferFd[MI_MM_MAX_FD_NUM];
    /// Native buffer MST_BUFFER flag(refer to mstar_natives.h)
    MI_U32 u32NativeBufferFlags;
    /// The valid number of the file descriptors, it depends on the format
    MI_U8 u8FdNum;
} MI_MM_RenderedFrameBuffer_t;

typedef struct MI_MM_FrameBufferCaps_s
{
    // [OUT] Support Color Format (bitwise operation, Ref: MI_MM_FrameBufferColorFormat_e)
    MI_U32 u32SupportColorFormat;
    // [OUT] Support Rotation Feature.
    MI_BOOL bSupportRotation;
} MI_MM_FrameBufferCaps_t;

typedef struct MI_MM_FrameBufferLayout_s
{
    // [OUT] The number of frame buffers
    MI_U8 u8Number;
    // [OUT] The Frame buffer mode frame buffers
    MI_MM_FrameBuffer_t astFrameBuffer[MI_MM_DISP_FRAME_QUEUE_MAX_SIZE];
} MI_MM_FrameBufferLayout_t;

typedef struct MI_MM_FrameBufferProperty_s
{
    // [IN] Color Format
    MI_MM_FrameBufferColorFormat_e eColorFormat;
    // [IN] Rotation Angle
    MI_MM_RotateAngle_e eRotationAngle;
} MI_MM_FrameBufferProperty_t;

typedef struct MI_MM_AudioEaseParams_s
{
    MI_MM_AudioEaseType_e eType;    /// [IN] A type of curve, eg linear, in-cubic, out-cubic,in-out-cubic
    MI_U16 u16Duration;             /// [IN] Duration time of fade-in or fade-out. unit: mini second
    MI_U16 u16Scale;                /// [IN] Scale value, range from 0 to 100
} MI_MM_AudioEaseParams_t;

typedef struct MI_MM_DrmSubsampleEntry_s
{
    MI_U32 u32ClearBytes;           /// [IN] Number of clear bytes.
    MI_U32 u32CipherBytes;          /// [IN] Number of cipher bytes.
} MI_MM_DrmSubsampleEntry_t;

typedef struct MI_MM_DrmWidevineCencDecryptMetadata_s
{
    MI_U8 *pu8KeyId;                /// [IN] Widevine key id.
    MI_U32 u32KeyIdSize;            /// [IN] Widevine key id size.
} MI_MM_DrmWidevineCencDecryptMetadata_t;

typedef struct MI_MM_DrmPlayReadyDecryptMetadata_s
{
    MI_U32 u32HandleIndex;          /// [IN] Index of PlayReady handle.
    MI_U64 u64BlockOffset;          /// [IN] Block offset.
    MI_U8 u8ByteOffset;             /// [IN] Byte offset.
} MI_MM_DrmPlayReadyDecryptMetadata_t;

typedef struct MI_MM_DrmDecryptMetadata_s
{
    union
    {
        MI_MM_DrmWidevineCencDecryptMetadata_t stWvCenc;   /// [IN] Widevine metadata
        MI_MM_DrmPlayReadyDecryptMetadata_t stPlayReady;   /// [IN] Playready metadata
    };
} MI_MM_DrmDecryptMetadata_t;

typedef struct MI_MM_DrmDecryptParams_s
{
    MI_MM_DrmType_e eDrmType;                       /// [IN] Drm type
    MI_U64 u64Identifier;                           /// [IN] Drm Identifier
    const MI_U8 *pu8EncryptedData;                  /// [IN] Buffer of encrypted data.
    MI_U32 u32DataSize;                             /// [IN] Data size.
    MI_U8 *pu8Iv;                                   /// [IN] IV.
    MI_U32 u32IvLen;                                /// [IN] IV length.
    MI_MM_DrmSubsampleEntry_t *pstSubsamples;       /// [IN] Subsamples.
    MI_U32 u32SubsamplesNum;                        /// [IN] Number of subsamples.
    MI_MM_DrmCryptoScheme_e eCryptoSchemeType;      /// [IN] Crypto scheme type.
    MI_BOOL bIsVideo;                               /// [IN] Determine whether it is video or not.
    void *pSecureHandle;                            /// [IN] Opaque pointer for SVP secure handle.
    MI_U32 u32SecureHandleLength;                   /// [IN] Secure handle length.
    MI_MM_DrmDecryptMetadata_t stDecryptMetadata;   /// [IN] Decrypt meta data.
    MI_U8 *pu8DecryptedData;                        /// [OUT] Buffer of decrypted data.
} MI_MM_DrmDecryptParams_t;

typedef struct MI_MM_DrmRequestLicenseParams_s
{
    MI_MM_DrmType_e eDrmType;                   /// [IN] Type of DRM
    MI_U8 *pu8DrmData;                          /// [IN] Pointer to buffer of DRM header.
    MI_U32 u32DrmDataSize;                      /// [IN] Size of DRM header.
    MI_MM_DrmType_e eRetDrmType;                /// [OUT] If request license drm type is none, need return drm type to inform drm type.
    MI_U64 u64RetIdentifier;                    /// [OUT] Corresponding with multi decryptor to identify DRM decrypt.
} MI_MM_DrmRequestLicenseParams_t;

typedef struct MI_MM_DrmSecureHandler_s
{
    void *pSecureHandler;                       /// [IN] Secure handler
    MI_U32 u32SecureHandlerSize;                /// [IN] Secure handler size
} MI_MM_DrmSecureHandler_t;

typedef struct MI_MM_TemiTimelineConfig_s
{
    /// [IN] The indicated prensentation time stamp in ms
    MI_U64 u64Pts;
    /// [IN] Specified component tag in programme map table(PMT) of the TEMI
    MI_U8 u8ComponentTag;
    /// [IN] Specified timeline ID in the timeline descriptor
    MI_U8 u8TimelineId;
} MI_MM_TemiTimelineConfig_t;

typedef struct MI_MM_TemiTimelineDescriptorInfo_s
{
    /// [OUT] Ticks of PTS(unit: ticks, formula: 1 ms = 90 ticks)
    MI_U64 u64PtsTick;
    /// [OUT] Indicates the media time in timescale units corresponding to the PES PTS value of this packet for the timeline identified
    MI_U64 u64MediaTimestamp;
    /// [OUT] Indicates the timescale of the u64MediaTimestamp field
    MI_U32 u32Timescale;
    /// [OUT] Indicates the active timeline
    MI_U8 u8TimelineID;
    /// [OUT] Indicates a media timestamp will be carried in this descriptor
    /// Value 0: no media timestamp is presented
    /// Value 1: present a 32 bit media timestamp
    /// Value 2: present a 64 bit media timestamp
    /// Value 3: reserved.
    MI_U8 u8HasTimestamp;
    /// [OUT] Indicates that the add-on description shall be reloaded before attempting to map media times or locate media components.
    MI_U8 u8ForceReload;
    /// [OUT] Indicates that the timeline ID is currently paused;
    MI_U8 u8Paused;
    /// [OUT] When set to 1, indicates that a discontinuity has happened in the timeline.
    /// If set to 0, no discontinuity happened since the last received TEMI timeline descriptor with the same value of the timeline ID
    MI_U8 u8Discontinuity;
} MI_MM_TemiTimelineDescriptorInfo_t;

typedef struct MI_MM_TemiTimelineInfo_s
{
    /// [OUT] The last received timeline descriptor information
    MI_MM_TemiTimelineDescriptorInfo_t stTimelineDescInfo;
} MI_MM_TemiTimelineInfo_t;

typedef struct MI_MM_SetTemiTimelineConfig_s
{
    /// [IN] The TEMI timeline config information
    MI_MM_TemiTimelineConfig_t stTemiTimelineConfig;
    /// [IN] Set/unset TEMI timeline config
    MI_BOOL bSet;
} MI_MM_SetTemiTimelineConfig_t;

//-------------------------------------------------------------------------------------------------
//  Global Functions
//-------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------
/// @brief Initialize multi-media function
/// @param [in] pstInitParams: init parameter, include callback function and reserved.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_INVALID_HANDLE: MM handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @sa
/// @note
//------------------------------------------------------------------------------
MI_RESULT MI_MM_Init(const MI_MM_InitParams_t *pstInitParams);
//------------------------------------------------------------------------------
/// @brief De-Initialize multi-media function
/// @param None
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_INVALID_HANDLE: MM handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @sa
/// @note
//------------------------------------------------------------------------------
MI_RESULT MI_MM_DeInit(void);
//------------------------------------------------------------------------------
/// @brief Get MM handle
/// @param [in] pstQueryHandleParams: photo, video, and music
/// @param [output] phMm: handle for MM path.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_INVALID_HANDLE: MM handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @sa
/// @note
//------------------------------------------------------------------------------
MI_RESULT MI_MM_GetHandle(const MI_MM_QueryHandleParams_t *pstQueryParams, MI_HANDLE *phMm);

//------------------------------------------------------------------------------
/// @brief Open for MM path
/// @param [in] pstOpenParams: video, audio, xc path info
/// @param [output] phMm: handle for MM path.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_INVALID_HANDLE: MM handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @sa
/// @note
//------------------------------------------------------------------------------
MI_RESULT MI_MM_Open(const MI_MM_OpenParams_t *pstOpenParams, MI_HANDLE *phMm);
//------------------------------------------------------------------------------
/// @brief Close for MM path
/// @param [in] hMm: handle for MM path.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_INVALID_HANDLE: MM handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @sa
/// @note
//------------------------------------------------------------------------------
MI_RESULT MI_MM_Close(MI_HANDLE hMm);
//------------------------------------------------------------------------------
/// @brief Play multi-media file
/// @param [in] hMm: handle for MM path.
/// @param [in] pstMMPlayParams: Play parameter
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_INVALID_HANDLE: MM handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @sa
/// @note
//------------------------------------------------------------------------------
MI_RESULT MI_MM_Start(MI_HANDLE hMm, const MI_MM_StartParams_t *pstStartParams);
//------------------------------------------------------------------------------
/// @brief Stop play multi-media file
/// @param [in] hMm: handle for MM path.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_INVALID_HANDLE: MM handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @sa
/// @note
//------------------------------------------------------------------------------
MI_RESULT MI_MM_Stop(MI_HANDLE hMm);
//------------------------------------------------------------------------------
/// @brief Pause MM file playback
/// @param [in] hMm: handle for MM path.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_INVALID_HANDLE: MM handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @sa
/// @note
//------------------------------------------------------------------------------
MI_RESULT MI_MM_Pause(MI_HANDLE hMm);
//------------------------------------------------------------------------------
/// @brief Resume MM play from pause status or FF/RW status.
/// @param [in] hMm: handle for MM path.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_INVALID_HANDLE: MM handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @sa
/// @note
//------------------------------------------------------------------------------
MI_RESULT MI_MM_Resume(MI_HANDLE hMm);
//------------------------------------------------------------------------------
/// @brief Fast forward for MM file
/// @param [in] hMm: handle for MM path.
/// @param [in] ePlaySpeed: 1X. 2X. 4X. 8X. 16X. 32X; 0X means to step to next FF play speed
///                        and loop back to 1X if current speed is 32X.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_INVALID_HANDLE: MM handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @sa
/// @note
//------------------------------------------------------------------------------
MI_RESULT MI_MM_FastForward(MI_HANDLE hMm, MI_MM_TrickSpeed_e ePlaySpeed);
//------------------------------------------------------------------------------
/// @brief Fast backward for MM file
/// @param [in] hMm: handle for MM path.
/// @param [in] ePlaySpeed: 1X. 2X. 4X. 8X. 16X. 32X. 0X means to step to next RW play speed
///                        and loop back to 1X if current speed is 32X.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_INVALID_HANDLE: MM handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @sa
/// @note
//------------------------------------------------------------------------------
MI_RESULT MI_MM_FastBackward(MI_HANDLE hMm, MI_MM_TrickSpeed_e ePlaySpeed);
//------------------------------------------------------------------------------
/// @brief Seek to user specific time in millisecond
/// @param [in] hMm: handle for MM path.
/// @param [in] u32GotoTimeMs (MS)
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_INVALID_HANDLE: MM handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @sa
/// @note
//------------------------------------------------------------------------------
MI_RESULT MI_MM_Seek(MI_HANDLE hMm, MI_U32 u32GotoTimeMs);
//------------------------------------------------------------------------------
/// @brief Set information of multi-media file
/// @param [in] hMm: handle for MM path.
/// @param [in] eAttrType: enumeration of MI_MM_AttrType_e
/// @param [in] pAttrParams: value
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_INVALID_HANDLE: MM handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @sa
/// @note
//------------------------------------------------------------------------------
MI_RESULT MI_MM_SetAttr(MI_HANDLE hMm, MI_MM_AttrType_e eAttrType, const void *pAttrParams);
//------------------------------------------------------------------------------
/// @brief Change subtitle track
/// @param [in] hMm: handle for MM path.
/// @param [in] u32TrackId: Subtitle track id
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_INVALID_HANDLE: MM handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @sa
/// @note
//------------------------------------------------------------------------------
MI_RESULT MI_MM_SetSubtitleTrack(MI_HANDLE hMm, MI_U32 u32TrackId);
//------------------------------------------------------------------------------
/// @brief Change audio track
/// @param [in] hMm: handle for MM path.
/// @param [in] u32TrackId: Audio track id
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_INVALID_HANDLE: MM handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @sa
/// @note
//------------------------------------------------------------------------------
MI_RESULT MI_MM_SetAudioTrack(MI_HANDLE hMm, MI_U32 u32TrackId);
//------------------------------------------------------------------------------
/// @brief Get Duration information of multi-media file
/// @param [in] hMm: handle for MM path.
/// @param [out] pu32MsTime: Duration information of multi-media file
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_INVALID_HANDLE: MM handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @sa
/// @note
//------------------------------------------------------------------------------
MI_RESULT MI_MM_GetDuration(MI_HANDLE hMm, MI_U32 *pu32MsTime);
//------------------------------------------------------------------------------
/// @brief Get Current Time information of multi-media file
/// @param [in] hMm: handle for MM path.
/// @param [out] pu32MsTime: Duration information of multi-media file
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_INVALID_HANDLE: MM handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @sa
/// @note
//------------------------------------------------------------------------------
MI_RESULT MI_MM_GetCurrentTime(MI_HANDLE hMm, MI_U32 *pu32MsTime);
//------------------------------------------------------------------------------
/// @brief Get Photo information of multi-media file
/// @param [in] hMm: handle for MM path.
/// @param [out] pstPhotoInfo: photo information of multi-media file
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_INVALID_HANDLE: MM handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @sa
/// @note
//------------------------------------------------------------------------------
MI_RESULT MI_MM_GetPhotoInfo(MI_HANDLE hMm, MI_MM_PhotoInfo_t *pstPhotoInfo);
//------------------------------------------------------------------------------
/// @brief Get Music information of multi-media file
/// @param [in] hMm: handle for MM path.
/// @param [out] pstMusicInfo: Music information of multi-media file
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_INVALID_HANDLE: MM handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @sa
/// @note
//------------------------------------------------------------------------------
MI_RESULT MI_MM_GetMusicInfo(MI_HANDLE hMm, MI_MM_MusicInfo_t *pstMusicInfo);
//------------------------------------------------------------------------------
/// @brief Get Music information (string of album, artist, title, etc.) of multi-media file
/// @param [in] hMm: handle for MM path.
/// @param [in] eInfo: selete album,artist, title...ect that user want to get.
/// @param [out] pstMusicInfo: Music information of multi-media file (string of album,artist, title...ect)
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_INVALID_HANDLE: MM handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @sa
/// @note
//------------------------------------------------------------------------------
MI_RESULT MI_MM_GetMusicInfoString(MI_HANDLE hMm, MI_MM_MusicStringInfo_e eInfo, MI_MM_MusicStringInfo_t *pstMusicStringInfo);
//------------------------------------------------------------------------------
/// @brief Get Movie information of multi-media file
/// @param [in] hMm: handle for MM path.
/// @param [out] pstMovieInfo: Movie information of multi-media file
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_INVALID_HANDLE: MM handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @sa
/// @note
//------------------------------------------------------------------------------
MI_RESULT MI_MM_GetMovieInfo(MI_HANDLE hMm, MI_MM_MovieInfo_t *pstMovieInfo);
//------------------------------------------------------------------------------
/// @brief Get Photo Decoder Status
/// @param [in] hMm: handle for MM path.
/// @param [out] pePhotoDecoderStatus: Photo Decoder Status, such as stop, decoding, decode ok, and err.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_INVALID_HANDLE: MM handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @sa
/// @note
//------------------------------------------------------------------------------
MI_RESULT MI_MM_GetPhotoDecoderStatus(MI_HANDLE hMm, MI_MM_PhotoDecoderStatus_e *pePhotoDecoderStatus);
//------------------------------------------------------------------------------
/// @brief Get MM Photo buffer address struct
/// @param [in] hMm: handle for MM path.
/// @param [out] pstPhotoAddr: Photo buffer address struct, such as input buffer, out buffer, display buffer, and inter buffer.
/// for slide show, zoom, rotate ap use.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_INVALID_HANDLE: MM handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @sa
/// @note
//------------------------------------------------------------------------------
MI_RESULT MI_MM_GetPhotoAddr(MI_HANDLE hMm, MI_MM_PhotoAddr_t *pstPhotoAddr);

//------------------------------------------------------------------------------
/// @brief Get Movie thumbnail bitmap
/// @param [in] hMm: handle for MM path.
/// @param [in] pstThumbnailParam: Thumbnail width, height, color format size, address
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @sa
/// @note
//------------------------------------------------------------------------------
MI_RESULT MI_MM_GetThumbnail(MI_HANDLE hMm, MI_MM_ThumbnailParams_t *pstThumbnailParam);

//------------------------------------------------------------------------------
/// @brief MI_MM_RotatePhoto is Set rotate for mm photo
/// @param [in] hMm: handle for MM path.
/// @param [in] eAngle: Rotate, now we have 0/90/180/270 degree
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_INVALID_HANDLE: MM handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @sa
/// @note
//------------------------------------------------------------------------------
MI_RESULT MI_MM_RotatePhoto(MI_HANDLE hMm, MI_MM_RotateAngle_e eAngle);
//------------------------------------------------------------------------------
/// @brief MI_MM_ZoomPhoto is Set zoom for mm photo
/// @param [in] hMm: handle for MM path.
/// @param [in] eZoom: ZOOM, now we have 1/8 to 8x
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_INVALID_HANDLE: MM handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @sa
/// @note
//------------------------------------------------------------------------------
MI_RESULT MI_MM_ZoomPhoto(MI_HANDLE hMm, MI_MM_ViewZoomFactor_e eZoom);
//------------------------------------------------------------------------------
/// @brief MI_MM_DrawPhoto is Set and play MM photo slide show on XC.
/// @param [in] hMm: handle for MM path.
/// @param [in] eEffect: eEffect Slide show effect
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_INVALID_HANDLE: MM handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @sa
/// @note
//------------------------------------------------------------------------------
MI_RESULT MI_MM_DrawPhoto(MI_HANDLE hMm, MI_MM_PhotoSlideShowEffect_e eEffect);
//------------------------------------------------------------------------------
/// @brief call MI_MM_SetupPhotoDisplay first and call MI_MM_DrawPhotoXC to show photo on XC
/// @param [in] hMm: handle for MM path.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_INVALID_HANDLE: MM handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @sa
/// @note
//------------------------------------------------------------------------------
MI_RESULT MI_MM_SetupPhotoDisplay(MI_HANDLE hMm);
//------------------------------------------------------------------------------
/// @brief MI_MM_MovePhoto is Set photo move
/// @param [in] hMm: handle for MM path.
/// @param [in] s32OffsetX: move photo if zoom in, out of range will be protected.
/// @param [in] s32OffsetY: move photo if zoom in, out of range will be protected.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_INVALID_HANDLE: MM handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @sa
/// @note
//------------------------------------------------------------------------------
MI_RESULT MI_MM_MovePhoto(MI_HANDLE hMm, MI_S32 s32OffsetX, MI_S32 s32OffsetY);
//------------------------------------------------------------------------------
/// @brief MI_MM_ClearPhoto is clear for mm photo
/// @param [in] hMm: handle for MM path.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_INVALID_HANDLE: MM handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @sa
/// @note
//------------------------------------------------------------------------------
MI_RESULT MI_MM_ClearPhoto(MI_HANDLE hMm);

//------------------------------------------------------------------------------
/// @brief Set MM debug level.
/// @param [in] u32DebugLevel: Debug level defined in enum type MI_DBG_LEVEL
/// @return MI_OK: Set debug level success.
//------------------------------------------------------------------------------
MI_RESULT MI_MM_SetDebugLevel(MI_DBG_LEVEL u32DebugLevel);

//------------------------------------------------------------------------------
/// @brief Register callback.
/// @param [in] hMm: handle for MM path.
/// @param [in] pstInputParams: input callback parameter
/// @param [out] pstOutputParams: output callback parameter
/// @return MI_OK: Register function success
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_INVALID_HANDLE: MM handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameter is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_MM_RegisterCallback(MI_HANDLE hMm, const MI_MM_CallbackInputParams_t *pstInputParams, MI_MM_CallbackOutputParams_t *pstOutputParams);

//------------------------------------------------------------------------------
/// @brief UnRegister callback.
/// @param [in] hMm: handle for MM path.
/// @param [in] pstInputParams: input callback parameter
/// @return MI_OK: UnRegister function success
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_INVALID_HANDLE: MM handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameter is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_MM_UnRegisterCallback(MI_HANDLE hMm, const MI_MM_CallbackInputParams_t *pstInputParams);

//------------------------------------------------------------------------------
/// @brief Register IO callback.
/// @param [in] hMm: handle for MM path.
/// @param [in] pstInputParams: Io input callback parameter
/// @param [out] pstOutputParams: Io output callback parameter
/// @return MI_OK: Register IO function success
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_INVALID_HANDLE: MM handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameter is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_MM_RegisterIoCallback(MI_HANDLE hMm, const MI_MM_IoCallbackInputParams_t *pstInputParams, MI_MM_IoCallbackOutputParams_t *pstOutputParams);

//------------------------------------------------------------------------------
/// @brief UnRegister IO callback.
/// @param [in] hMm: handle for MM path.
/// @param [in] pstInputParams: Io input callback parameter
/// @return MI_OK: UnRegister IO function success
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_INVALID_HANDLE: MM handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameter is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_MM_UnRegisterIoCallback(MI_HANDLE hMm, const MI_MM_IoCallbackInputParams_t *pstInputParams);

//------------------------------------------------------------------------------
/// @brief Get option.
/// @param [in] hMm: handle for MM path.
/// @param [in] eAttrType: get attr type enum
/// @param [in] pInputParams: Input Parameter
/// @param[out] pOutputParams: Output Parameter
/// @return MI_OK: Get Option success
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_INVALID_HANDLE: MM handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameter is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_MM_GetAttr(MI_HANDLE hMm, MI_MM_AttrType_e eAttrType, const void *pInputParams, void *pOutputParams);

//------------------------------------------------------------------------------
/// @brief Push Stream
/// @param [in] hMm: handle for MM path.
/// @param [in] pstData: data param
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_INVALID_HANDLE: MM handle is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_MM_PushStream(MI_HANDLE hMm, MI_MM_StreamData_t *pstData);

//------------------------------------------------------------------------------
/// @brief Clear Data
/// @param [in] hMm: handle for MM path.
/// @param [in] u32ClearData: the bitwise flag of MI_MM_ClearData_e to clear audio or video or both
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_INVALID_HANDLE: MM handle is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_MM_Clear(MI_HANDLE hMm, MI_U32 u32ClearData);

//------------------------------------------------------------------------------
/// @brief Set End of Stream
/// @param [in] hMm: handle for MM path.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_INVALID_HANDLE: MM handle is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_MM_SetEndOfStream(MI_HANDLE hMm);

//------------------------------------------------------------------------------
/// @brief Get Secure Handler
/// @param [in] hMm: handle for MM path.
/// @param [in] u32DataLen: Data length.
/// @param [out] ppSecureHandler: Secure handler.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_INVALID_HANDLE: MM handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameter is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_MM_GetSecureHandler(MI_HANDLE hMm, MI_U32 u32DataLen, void **ppSecureHandler);

//------------------------------------------------------------------------------
/// @brief Release Secure Handler
/// @param [in] hMm: handle for MM path.
/// @param [in] pSecureHandler: Secure Handle.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_INVALID_HANDLE: MM handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameter is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_MM_ReleaseSecureHandler(MI_HANDLE hMm, void *pSecureHandler);

//------------------------------------------------------------------------------
/// @brief Free Frame Buffer for Frame Buffer Mode
/// @param [in] hMm: handle for MM path.
/// @param [in] phyFrameBufferAddr: the Frame Buffer address. (PA)
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_INVALID_HANDLE: MM handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameter is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_MM_FreeFrameBuffer(MI_HANDLE hMm, MI_PHY phyFrameBufferAddr);

//------------------------------------------------------------------------------
/// @brief Register frame buffer callback.
/// @param [in] hMm: handle for MM path.
/// @param [in] pstInputParams: Frame buffer input callback parameter
/// @param [out] pstOutputParams: Frame buffer output callback parameter
/// @return MI_OK: Register frame buffer function success
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_INVALID_HANDLE: MM handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameter is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_MM_RegisterFrameBufferCallback(MI_HANDLE hMm, const MI_MM_FrameBufferCallbackInputParams_t *pstInputParams, MI_MM_FrameBufferCallbackOutputParams_t *pstOutputParams);

//------------------------------------------------------------------------------
/// @brief Unregister frame buffer callback.
/// @param [in] hMm: handle for MM path.
/// @param [in] pstInputParams: Frame buffer input callback parameter
/// @return MI_OK: Unregister frame buffer function success
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_INVALID_HANDLE: MM handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameter is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_MM_UnRegisterFrameBufferCallback(MI_HANDLE hMm, const MI_MM_FrameBufferCallbackInputParams_t *pstInputParams);

#ifdef __cplusplus
}
#endif

#endif //_MI_MM_H_

