/*------------------------------------------------------------------------------
 * MediaTek Inc. (C) 2018. All rights reserved.
 *
 * Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 *----------------------------------------------------------------------------*/

#ifndef _MI_DISP_H_
#define _MI_DISP_H_

#ifdef __cplusplus
extern "C" {
#endif

//-------------------------------------------------------------------------------------------------
//  Defines
//-------------------------------------------------------------------------------------------------

typedef MI_RESULT (* MI_DISP_EventCallback)(MI_HANDLE hDisp, MI_U32 u32Event, void *pEventParams, void *pUserParams);
//-------------------------------------------------------------------------------------------------
//  Enum
//-------------------------------------------------------------------------------------------------
/// Aspect ratio type of TV screen
typedef enum
{
    E_MI_DISP_TV_AR_16_9 = 0,
    E_MI_DISP_TV_AR_4_3 = 1,
} MI_DISP_TvAr_e;

/// Aspect ratio type of video window
typedef enum
{
    E_MI_DISP_VIDWIN_AR_4_3 = 0,
    E_MI_DISP_VIDWIN_AR_16_9,
    E_MI_DISP_VIDWIN_AR_FULL,
    E_MI_DISP_VIDWIN_AR_LETTERBOX,
    E_MI_DISP_VIDWIN_AR_PANSCAN,
    E_MI_DISP_VIDWIN_AR_COMBINED,
    E_MI_DISP_VIDWIN_AR_SOURCE_DISPLAY_ASPECT_RATIO,
} MI_DISP_VidWinAr_e;

/// Output timing type
typedef enum
{
    E_MI_DISP_TIMING_720X480_60I     = 0,
    E_MI_DISP_TIMING_720X480_60P     = 1,
    E_MI_DISP_TIMING_720X576_50I     = 2,
    E_MI_DISP_TIMING_720X576_50P     = 3,
    E_MI_DISP_TIMING_1280X720_50P    = 4,
    E_MI_DISP_TIMING_1280X720_60P    = 5,
    E_MI_DISP_TIMING_1920X1080_50I   = 6,
    E_MI_DISP_TIMING_1920X1080_60I   = 7,
    E_MI_DISP_TIMING_1920X1080_24P   = 8,
    E_MI_DISP_TIMING_1920X1080_25P   = 9,
    E_MI_DISP_TIMING_1920X1080_30P   = 10,
    E_MI_DISP_TIMING_1920X1080_50P   = 11,
    E_MI_DISP_TIMING_1920X1080_60P   = 12,
    E_MI_DISP_TIMING_3840X2160_24P   = 13,
    E_MI_DISP_TIMING_3840X2160_25P   = 14,
    E_MI_DISP_TIMING_3840X2160_30P   = 15,
    E_MI_DISP_TIMING_3840X2160_50P   = 16,
    E_MI_DISP_TIMING_3840X2160_60P   = 17,
    E_MI_DISP_TIMING_4096X2160_24P   = 18,
    E_MI_DISP_TIMING_4096X2160_25P   = 19,
    E_MI_DISP_TIMING_4096X2160_30P   = 20,
    E_MI_DISP_TIMING_4096X2160_50P   = 21,
    E_MI_DISP_TIMING_4096X2160_60P   = 22,
    E_MI_DISP_TIMING_1366X768_50I    = 23,
    E_MI_DISP_TIMING_1366X768_50P    = 24,
    E_MI_DISP_TIMING_1366X768_60I    = 25,
    E_MI_DISP_TIMING_1366X768_60P    = 26,
    E_MI_DISP_TIMING_MAX
} MI_DISP_Timing_e;

/// TV system type
typedef enum
{
    E_MI_DISP_TV_SYSTEM_NTSC,
    E_MI_DISP_TV_SYSTEM_NTSC_443,
    E_MI_DISP_TV_SYSTEM_NTSC_J,
    E_MI_DISP_TV_SYSTEM_PAL_M,
    E_MI_DISP_TV_SYSTEM_PAL_N,
    E_MI_DISP_TV_SYSTEM_PAL_NC,
    E_MI_DISP_TV_SYSTEM_PAL,
    E_MI_DISP_TV_SYSTEM_SECAM,
    E_MI_DISP_TV_SYSTEM_MAX
} MI_DISP_TvSystem_e;

/// Deflicker level
typedef enum
{
    E_MI_DISP_DE_FLICKER_DEFAULT,
    E_MI_DISP_DE_FLICKER_LOW,
    E_MI_DISP_DE_FLICKER_MID,
    E_MI_DISP_DE_FLICKER_HIGH,
    E_MI_DISP_DE_FLICKER_MAX = E_MI_DISP_DE_FLICKER_DEFAULT,
} MI_DISP_DeFlicker_e;

typedef enum
{
    E_MI_DISP_VIDWIN_Z_ORDER_MOVE_FRONTMOST,
    E_MI_DISP_VIDWIN_Z_ORDER_MOVE_BACKMOST,
    E_MI_DISP_VIDWIN_Z_ORDER_MOVE_FORWARD,
    E_MI_DISP_VIDWIN_Z_ORDER_MOVE_BACKWARD,
} MI_DISP_VidWinZOrder_e;

//Bit[20~30] For Internal Used
typedef enum
{
    /// MI_DISP mute flag for user select
    E_MI_DISP_MUTE_FLAG_USER            = MI_BIT(0),
    /// MI_DISP mute flag for video
    E_MI_DISP_MUTE_FLAG_VIDEO           = MI_BIT(1),
    /// MI_DISP mute flag for setting window
    E_MI_DISP_MUTE_FLAG_SET_WINDOW       = MI_BIT(2),
    /// MI_DISP mute flag for bad video
    E_MI_DISP_MUTE_FLAG_BAD_VIDEO       = MI_BIT(3),
    /// MI_DISP mute flag for rating
    E_MI_DISP_MUTE_FLAG_RATING          = MI_BIT(4),
    /// MI_DISP mute flag for block program
    E_MI_DISP_MUTE_FLAG_BLOCK           = MI_BIT(5),
    /// MI_DISP mute flag for scrambled program
    E_MI_DISP_MUTE_FLAG_CA_SCRAMBLED    = MI_BIT(6),
    /// MI_DISP mute flag for PVR
    E_MI_DISP_MUTE_FLAG_PVR             = MI_BIT(7),
    /// MI_DISP mute flag for Unsupport format
    E_MI_DISP_MUTE_FLAG_UNSUPPORT       = MI_BIT(8),
    /// MI_DISP mute flag for still image
    E_MI_DISP_MUTE_FLAG_STILL_IMAGE      = MI_BIT(9),
    /// MI_DISP mute flag for set timing
    E_MI_DISP_MUTE_FLAG_SET_TIMING      = MI_BIT(10),
    /// MI_DISP mute flag for Force un/mute
    E_MI_DISP_MUTE_FLAG_FORCE           = MI_BIT(31)
} MI_DISP_MuteFlag_e;

/// Video window type
typedef enum
{
    E_MI_DISP_VIDWIN_HD,    //HD Window
    E_MI_DISP_VIDWIN_SD,    //SD Window
    E_MI_DISP_VIDWIN_MAX,
} MI_DISP_VidWinType_e;

//Attr Parameter Type
typedef enum
{
    E_MI_DISP_ATTR_TYPE_MIN = 0,
    ///<Set and Get>. pParam is a pointer to MI_BOOL
    E_MI_DISP_ATTR_TYPE_MISC_MIN = E_MI_DISP_ATTR_TYPE_MIN,
    E_MI_DISP_ATTR_TYPE_AFD_ENABLE = E_MI_DISP_ATTR_TYPE_MISC_MIN,
    ///Set . pParam is a pointer to MI_DISP_RgbColor_t
    E_MI_DISP_ATTR_TYPE_MUTE_COLOR,
    //Get. Get frame latency(ms) for AV Sync adjustment. pParam is a pointer to MI_U16.
    E_MI_DISP_ATTR_TYPE_FRAME_LATENCY,
    //Set.  pixel report pParam is a pointer to MI_DISP_PixelReportWindow_t.
    E_MI_DISP_ATTR_TYPE_PIXEL_REPORT_WINDOW,
    //Get. pixel info . pParam is a pointer to MI_DISP_PixelReport_t.
    E_MI_DISP_ATTR_TYPE_PIXEL_REPORT,
    //<Set and Get>. pParam is pointer to MI_DISP_SourceOffset_t
    E_MI_DISP_ATTR_TYPE_SOURCE_OFFSET,
    /// Get the display output latency. pParam is pointer to MI_DISP_OutputLatencyParams_t.
    E_MI_DISP_ATTR_TYPE_OUTPUT_PATH_LATENCY,
    /// Get the vsync info. pParam is pointer to MI_DISP_VsyncParams_t.
    E_MI_DISP_ATTR_TYPE_VSYNC_INFO,
    /// Set the rolling mode enable/disable. pParam is pointer to MI_BOOL.
    E_MI_DISP_ATTR_TYPE_ENABLE_ROLLING_MODE,
    ///Get. Get current input source color space. pParam is a pointer to MI_DISP_ColoSpace_e.
    E_MI_DISP_ATTR_TYPE_COLORSPACE,
    /// Set, Get mirror mode.
    E_MI_DISP_ATTR_TYPE_MIRROR_MODE,
    E_MI_DISP_ATTR_TYPE_MISC_MAX,

    E_MI_DISP_ATTR_TYPE_3D_MIN = 0x200,         // reserved 0x100 to 0x200
    ///<Set and Get>. pParam is a pointer to MI_DISP_3DInputFormat_e
    E_MI_DISP_ATTR_TYPE_3D_INPUT_FORMAT = E_MI_DISP_ATTR_TYPE_3D_MIN,
    ///<Set and Get>. pParam is a pointer to MI_DISP_3DOutputFormat_e
    E_MI_DISP_ATTR_TYPE_3D_OUTPUT_FORMAT,
    ///<Set and Get>. pParam is a pointer to MI_BOOL
    E_MI_DISP_ATTR_TYPE_3D_ENABLE,
    ///<Get>. pParam is a pointer to MI_DISP_3DInputFormat_e
    E_MI_DISP_ATTR_TYPE_3D_DETECT_INPUT_FORMAT,
    ///<Set>. pParam is a pointer to MI_BOOL
    E_MI_DISP_ATTR_TYPE_3D_DUAL_VIEW_ENABLE,
    ///<Set>. pParam is a pointer to MI_BOOL
    E_MI_DISP_ATTR_TYPE_3D_TO_2D_ENABLE,
    ///<Set>. pParam is a pointer to MI_BOOL
    E_MI_DISP_ATTR_TYPE_2D_TO_3D_ENABLE,
    ///<Set and Get>. pParam is a pointer to MI_BOOL
    E_MI_DISP_ATTR_TYPE_3D_SWITCH_LR,
    ///<Set and Get>. pParam is a pointer to MI_U16
    E_MI_DISP_ATTR_TYPE_3D_GAIN,
    ///<Set and Get>. pParam is a pointer to MI_U16, 0~31 range, default: 16
    E_MI_DISP_ATTR_TYPE_3D_OFFSET,
    ///<Set and Get>. pParam is a pointer to MI_DISP_2DTo3DCapability_t
    E_MI_DISP_ATTR_TYPE_3D_2D_TO_3D_CAPBILITY,
    E_MI_DISP_ATTR_TYPE_3D_MAX,

    E_MI_DISP_ATTR_TYPE_HDR_MIN = 0x300,
    ///<Set and Get>. pParam is a pointer to MI_BOOL, this control all hdr type
    E_MI_DISP_ATTR_TYPE_HDR_ENABLE = E_MI_DISP_ATTR_TYPE_HDR_MIN,
    ///Set . pParam is a pointer to MI_DISP_HdrLevel_t
    E_MI_DISP_ATTR_TYPE_HDR_LEVEL,
    ///Set . pParam is a pointer to MI_BOOL
    E_MI_DISP_ATTR_TYPE_HDR_OPENHDR_STANDARD_MODE_ENABLE,
    ///Get . pParam is a pointer to MI_DISP_HdrType_e
    E_MI_DISP_ATTR_TYPE_HDR_TYPE,
    ///<Set and Get>. pParam is a pointer to MI_DISP_HdrOnOff_t, this is controled by type
    E_MI_DISP_ATTR_TYPE_HDR_ENABLE_BY_TYPE,
    ///<Set and Get>. pParam is a pointer to MI_DISP_HdrEnableStaticMetadata_e.
    E_MI_DISP_ATTR_TYPE_HDR_ENABLE_STATIC_METADATA,
    ///<Set and Get>. pParam is a pointer to MI_DISP_HdrMetaData_t.
    E_MI_DISP_ATTR_TYPE_HDR_STATIC_METADATA,
    ///Set. pParam is a pointer to MI_DISP_Tmo1DLUT_s.
    E_MI_DISP_ATTR_TYPE_TMO_1D_LUT,
    //Set. pParam is a pointer to MI_DISP_HdrAttr_t
    E_MI_DISP_ATTR_TYPE_HDR_ATTR,
    E_MI_DISP_ATTR_TYPE_HDR_MAX,

    E_MI_DISP_ATTR_TYPE_TEST_PATTERN_MIN = 0x400,
    ///Set. pParam is a pointer to MI_DISP_RgbTestPattern_t
    E_MI_DISP_ATTR_TYPE_TEST_PATTERN_RGB = E_MI_DISP_ATTR_TYPE_TEST_PATTERN_MIN,
    ///Set. pParam is a pointer to MI_DISP_StageTestPattern_t
    E_MI_DISP_ATTR_TYPE_TEST_PATTERN_STAGE,
    E_MI_DISP_ATTR_TYPE_TEST_PATTERN_MAX,
     ///<Set>. pParam is a pointer to MI_BOOL
    E_MI_DISP_ATTR_TYPE_ALLM_ENABLE,
    ///<Get>. pParam is a pointer to MI_BOOL
    E_MI_DISP_ATTR_TYPE_SOURCE_IS_STILLIMAGE,
    E_MI_DISP_ATTR_TYPE_MAX
} MI_DISP_AttrType_e;

//Define 3D Output format
typedef enum
{
    /// 3D format is None
    E_MI_DISP_3D_OUTPUT_MODE_NONE,
    /// 3D format is Frame Packing
    E_MI_DISP_3D_OUTPUT_FRAME_PACKING,
    /// 3D format is Frame Alternate
    E_MI_DISP_3D_OUTPUT_FRAME_ALTERNATE,
    /// 3D format is Line Alternativ
    E_MI_DISP_3D_OUTPUT_LINE_ALTERNATIVE,
    /// 3D format is Side by Side Half
    E_MI_DISP_3D_OUTPUT_SIDE_BY_SIDE_HALF,
    /// 3D format is Side by Side Full
    E_MI_DISP_3D_OUTPUT_SIDE_BY_SIDE_FULL,
    /// 3D format is Top and Bottom
    E_MI_DISP_3D_OUTPUT_TOP_BOTTOM,
    /// 3D format max
    E_MI_DISP_3D_OUTPUT_MAX,
}MI_DISP_3DOutputFormat_e;

//Define 3D Input format
typedef enum
{
    /// 3D format is None
    E_MI_DISP_3D_INPUT_MODE_NONE,
    /// 3D format is Frame Packing
    E_MI_DISP_3D_INPUT_FRAME_PACKING,
    /// 3D format  is Frame Alternative
    E_MI_DISP_3D_INPUT_FRAME_ALTERNATIVE,
    /// 3D format is Field Alternative
    E_MI_DISP_3D_INPUT_FIELD_ALTERNATIVE,
    /// 3D format is Line Alternativ
    E_MI_DISP_3D_INPUT_LINE_ALTERNATIVE,
    /// 3D format is Side by Side Half
    E_MI_DISP_3D_INPUT_SIDE_BY_SIDE_HALF,
    /// 3D format is Side by Side Full
    E_MI_DISP_3D_INPUT_SIDE_BY_SIDE_FULL,
    /// 3D format is Top and Bottom
    E_MI_DISP_3D_INPUT_TOP_BOTTOM,
    /// 3D format is Check board
    E_MI_DISP_3D_INPUT_CHECK_BORAD,
    /// 3D format is Pixel Alternative
    E_MI_DISP_3D_INPUT_PIXEL_ALTERNATIVE,
    /// 3D format max
    E_MI_DISP_3D_INPUT_MAX,
}MI_DISP_3DInputFormat_e;

typedef enum
{
    ///<Set and Get>. pParam is a pointer to MI_DISP_DetectOsdParam_t
    E_MI_DISP_CONTROL_ATTR_TYPE_DETECT_OSD,
    ///<Set>. pParam is a pointer to MI_DISP_FreerunConfig_e
    E_MI_DISP_CONTROL_ATTR_TYPE_FREERUN,
    ///<Set and Get>. pParam is a pointer to MI_BOOL
    E_MI_DISP_CONTROL_ATTR_TYPE_PIXEL_SHIFT_ENABLE,
} MI_DISP_ControlAttrType_e;

typedef enum
{
     E_MI_DISP_FREERUN_DISABLE,
     E_MI_DISP_FREERUN_FRAMERATE_50,
     E_MI_DISP_FREERUN_FRAMERATE_60,
     E_MI_DISP_FREERUN_FRAMERATE_AUTO,
}MI_DISP_FreeRunConfig_e;

typedef enum
{
    // auto hdr level
    E_MI_DISP_HDR_LEVEL_AUTO,
    // open hdr low level
    E_MI_DISP_HDR_LEVEL_LOW,
    // open hdr middle level
    E_MI_DISP_HDR_LEVEL_MID,
    // open hdr high level
    E_MI_DISP_HDR_LEVEL_HIGH,
    E_MI_DISP_HDR_LEVEL_MAX,
}MI_DISP_HdrLevel_e;

typedef enum
{
    // non HDR
    E_MI_DISP_HDR_TYPE_NONE,
    // Open HDR
    E_MI_DISP_HDR_TYPE_OPEN,
    // Dolby HDR
    E_MI_DISP_HDR_TYPE_DOLBY,
    // tch HDR
    E_MI_DISP_HDR_TYPE_TCH,
    // HLG HDR
    E_MI_DISP_HDR_TYPE_HLG,
    // HDR10 PLUS
    E_MI_DISP_HDR_TYPE_HDR10_PLUS,
    E_MI_DISP_HDR_TYPE_MAX,
}MI_DISP_HdrType_e;

typedef enum
{
    //dolby hdr bright level
    E_MI_DISP_HDR_DOLBY_LEVEL_BRIGHT,
    //dolby hdr dark level
    E_MI_DISP_HDR_DOLBY_LEVEL_DARK,
    //dolby hdr vivi level
    E_MI_DISP_HDR_DOLBY_LEVEL_VIVID,
    E_MI_DISP_HDR_DOLBY_LEVEL_MAX,
}MI_DISP_HdrDolbyLevel_e;

typedef enum
{
    //HDR auto
    E_MI_DISP_HDR_AUTO = 0,
    //HDR on
    E_MI_DISP_HDR_ON,
    //HDR off
    E_MI_DISP_HDR_OFF,
}MI_DISP_HdrOnOff_e;

//Super wide dynamic range
typedef enum
{
    //SWDR level off
    E_MI_DISP_SWDR_LEVEL_OFF,
    //SWDR level low
    E_MI_DISP_SWDR_LEVEL_LOW,
    //SWDR level middle
    E_MI_DISP_SWDR_LEVEL_MID,
    //SWDR level high
    E_MI_DISP_SWDR_LEVEL_HIGH,
    E_MI_DISP_SWDR_LEVEL_MAX,
} MI_DISP_SwdrLevel_e;

typedef enum
{
    E_MI_DISP_HSB_HUE,//Hue
    E_MI_DISP_HSB_SATURATION,//Saturation
    E_MI_DISP_HSB_BRIGHTNESS,//Brightness
    E_MI_DISP_HSB_MAX
}MI_DISP_HsbType_e;

//HSY picture mode
typedef enum
{
    E_MI_DISP_HSY_PICTUREMODE_AUTO,
    E_MI_DISP_HSY_PICTUREMODE_GAME,
    E_MI_DISP_HSY_PICTUREMODE_LIGHTNESS,
    E_MI_DISP_HSY_PICTUREMODE_NATURAL,
    E_MI_DISP_HSY_PICTUREMODE_SOFT,
    E_MI_DISP_HSY_PICTUREMODE_SPORTS,
    E_MI_DISP_HSY_PICTUREMODE_STANDARD,
    E_MI_DISP_HSY_PICTUREMODE_USER,
    E_MI_DISP_HSY_PICTUREMODE_VIVID,
    E_MI_DISP_HSY_PICTUREMODE_PC,
    E_MI_DISP_HSY_PICTUREMODE_MAX,
} MI_DISP_HsyPictureMode_e;

//Picture mode type
typedef enum
{
    //Average luma,  param is a point of MI_DISP_AvgLumaParams_t
    E_MI_DISP_PICTURE_PARAM_TYPE_AVG_LUMA,
    //Enable/Display pq bypass, param is a point of MI_BOOL
    E_MI_DISP_PICTURE_PARAM_TYPE_BYPASS_PQ_ENABLE,
    //Color temperature, param is a point of MI_DISP_ColorTemperature_t
    E_MI_DISP_PICTURE_PARAM_TYPE_COLOR_TEMPERATURE,
    //Enable/Dispable demo mode,param is a point of MI_DISP_DemoMode_t
    E_MI_DISP_PICTURE_PARAM_TYPE_DEMO_MODE,
    //Enable/Display DLC, param is a point of MI_BOOL
    E_MI_DISP_PICTURE_PARAM_TYPE_DLC_ENABLE,
    //DLC index, parma is a point of MI_U8
    E_MI_DISP_PICTURE_PARAM_TYPE_DLC_INDEX,
    //Dynamic contrast curve, param is a point of MI_DISP_DynamicContrastCurve_t
    E_MI_DISP_PICTURE_PARAM_TYPE_DYNAMIC_CONTRAST_CURVE,
    //Dynamic contrast level, param is a point of MI_BOOL
    E_MI_DISP_PICTURE_PARAM_TYPE_DYNAMIC_CONTRAST_ENABLE,
    //Enable/Disable Film mode, parm is a point of MI_BOOL
    E_MI_DISP_PICTURE_PARAM_TYPE_FILM_MODE_ENABLE,
    //Enable/Disable Game mode, param is a point of MI_BOOL
    E_MI_DISP_PICTURE_PARAM_TYPE_GAME_MODE_ENABLE,
    //Enable/Disable HSB bypass, param is a point of MI_DISP_HsbBypassParams_t
    E_MI_DISP_PICTURE_PARAM_TYPE_HSB_BYPASS,
    //Color range, param is a point of MI_DISP_InputColorRange_t
    E_MI_DISP_PICTURE_PARAM_TYPE_INPUT_COLOR_RANGE,
    //Memc level, param is a point of MI_DISP_MemcLevel_e
    E_MI_DISP_PICTURE_PARAM_TYPE_MEMC_LEVEL,
    //Enable/Disable Mpeg NR, param is a point of MI_DISP_MpegNr_t
    E_MI_DISP_PICTURE_PARAM_TYPE_MPEG_NR,
    //Enable/Disable NR, param is a point of MI_DISP_Nr_t
    E_MI_DISP_PICTURE_PARAM_TYPE_NR ,
    //Set PQ Grule, param is a point of MI_DISP_PqGrule_t
    E_MI_DISP_PICTURE_PARAM_TYPE_PQ_GRULE,
    //Sharpness, param is a point of MI_U32
    E_MI_DISP_PICTURE_PARAM_TYPE_SHARPNESS,
    //Set XVYCC mode, param is a point of MI_DISP_XvyccMode_e
    E_MI_DISP_PICTURE_PARAM_TYPE_XVYCC_MODE,
    //Brightness, param is a point of MI_U32
    E_MI_DISP_PICTURE_PARAM_TYPE_BRIGHTNESS,
    //Hue, param is a point of MI_U32
    E_MI_DISP_PICTURE_PARAM_TYPE_HUE,
    //Saturation, param is a point of MI_U32
    E_MI_DISP_PICTURE_PARAM_TYPE_SATURATION,
    //Contrast, param is a point of MI_U32
    E_MI_DISP_PICTURE_PARAM_TYPE_CONTRAST,
    //<Get>Get HSY Color default setting. pInputParams is a pointer to MI_DISP_HsyModelType_e. pOutputParams is a pointer to MI_DISP_HsyColorInfo_t.
    E_MI_DISP_PICTURE_PARAM_TYPE_HSY_DEFAULT_COLOR_MODEL,
    //<Set>HSY Color adjustment. pParams is a pointer to MI_DISP_HsyColorInfo_t.
    //<Get>HSY Color adjustment. pInputParams is a pointer to MI_DISP_HsyModelType_e. pOutputParams is a pointer to MI_DISP_HsyColorInfo_t.
    E_MI_DISP_PICTURE_PARAM_TYPE_HSY_COLOR_MODEL,
    //<Get only> Get HSY color model range. pOutputParams is a pointer to MI_DISP_HsyModelRange_t.
    E_MI_DISP_PICTURE_PARAM_TYPE_HSY_COLOR_MODEL_RANGE,
    //<Set and Get>Set Blue stretch strength. param is a pointer to MI_U8
    E_MI_DISP_PICTURE_PARAM_TYPE_BLUE_STRETCH_STRENGTH,
    //<Set and Get> Set/Get Pre Gamma Gain Offset. pParam is a pointer to MI_DISP_GammaGainOffset_t.
    E_MI_DISP_PICTURE_PARAM_TYPE_PRE_GAMMA_GAIN_OFFSET,
    //<Set>Set Gamma Enable. pParams is a pointer to MI_DISP_GammaStatus_t.
    //<Get>Get Gamma Enable Status.pInputParams is a pointer to MI_DISP_GammaType_e. pOutputParams is a pointer to MI_DISP_GammaStatus_t.
    E_MI_DISP_PICTURE_PARAM_TYPE_GAMMA_ENABLE,
    //<Set>Set Gamma Curve. pParams is a pointer to MI_DISP_GammaSetting_t.
    //<Get>Get Gamma Curve. pInputParams is a pointer to MI_DISP_GammaType_e. pOutputParams is a pointer to MI_DISP_GammaSetting_t.
    E_MI_DISP_PICTURE_PARAM_TYPE_GAMMA_CURVE,
    //<Get> Get 3D NR control info.pOutputParams is a pointer to MI_DISP_3DNrControlInfo_t.
    E_MI_DISP_PICTURE_PARAM_TYPE_3D_NR_CONTROL_INFO,
    //<Set>Set 3D NR control parameter. pParams is a pointer to MI_DISP_3DNrControlSetting_t.
    E_MI_DISP_PICTURE_PARAM_TYPE_3D_NR_CONTROL_SETTING,
    //<Set>Set advanced XVYCC control setting. pParams is a pointer to MI_DISP_XvyccControlSetting_t.
    E_MI_DISP_PICTURE_PARAM_TYPE_XVYCC_CONTROL_SETTING,
    //<Set and Get> Enable/Disable customer luma curve. pParams is a pointer to MI_BOOL.
    E_MI_DISP_PICTURE_PARAM_TYPE_CUS_LUMA_CURVE_ENABLE,
    //<Set> Set customer luma curve data. pParams is a pointer to MI_DISP_CusLumaCurve_t.
    E_MI_DISP_PICTURE_PARAM_TYPE_CUS_LUMA_CURVE,
    //<Set/Get> Set and Get Black Stretch. pParams is a pointer to MI_DISP_BlackStretch_t.
    E_MI_DISP_PICTURE_PARAM_TYPE_BLACK_STRETCH_SETTING,
    //<Set/Get> Set and Get White Stretch. pParams is a pointer to MI_DISP_WhiteStretch_t.
    E_MI_DISP_PICTURE_PARAM_TYPE_WHITE_STRETCH_SETTING,
    //<Set> Set non linear Scaling Setting. pParam is a pointer to MI_DISP_NonLinearScaling_t.
    //<Get> Get non linear Scaling Setting. pInputParams is a pointer to MI_DISP_NonLinearScalingType_e. pOutputParams is a pointer to MI_DISP_NonLinearScaling_t.
    E_MI_DISP_PICTURE_PARAM_TYPE_NON_LINEAR_SCALING,
    //<Set/Get> Set and get Super Wide Dynamic Range(SWDR) Level. pParam is a pointer to MI_DISP_SwdrLevel_e.
    E_MI_DISP_PICTURE_PARAM_TYPE_SWDR_LEVEL,
    //<Set> Set HSY picture mode parameter. pParams is a pointer to MI_DISP_HsyPictureMode_e.
    E_MI_DISP_PICTURE_PARAM_TYPE_HSY_PICTURE_MODE,
    //<Set> Set PQ mode enable or disable. pParam is a pointer to MI_DISP_PqOnOffParams_t.
    E_MI_DISP_PICTURE_PARAM_TYPE_PQ_ON_OFF,
    //<Set/Get> Set and get PQ Module status. pParam is a pointer to MI_DISP_PqModuleStatusParams_t.
    E_MI_DISP_PICTURE_PARAM_TYPE_PQ_MODULE_STATUS,
    //<Set> Set non linear Scaling Setting. pParam is a pointer to MI_DISP_NonLinearScalingByRatio_t.
    //<Get> Get non linear Scaling Setting. pInputParams is a pointer to MI_DISP_NonLinearScalingType_e. pOutputParams is a pointer to MI_DISP_NonLinearScalingByRatio_t.
    E_MI_DISP_PICTURE_PARAM_TYPE_NON_LINEAR_SCALING_BY_RATIO_OF_SOURCE_AND_PANEL,
    //<Set>Set panel gamma from bin. pParams is a pointer to MI_DISP_PanelGammaSetting_t.
    E_MI_DISP_PICTURE_PARAM_TYPE_PANEL_GAMMA,
    //<Set/Get> Set and get skin weight. pParams is a pointer to MI_U16.
    E_MI_DISP_PICTURE_PARAM_TYPE_SKIN_WEIGHT,

    E_MI_DISP_PICTURE_PARAM_TYPE_STATS_MIN = 0x200,
    //<Set/Get> Set and Get Histogram statistics control setting. pParams is a pointer to MI_DISP_HistogramCtrl_t.
    E_MI_DISP_PICTURE_PARAM_TYPE_STATS_HISTOGRAM_CONTROL = E_MI_DISP_PICTURE_PARAM_TYPE_STATS_MIN,
    //<Get> Get Histogram support Info. pParams is a pointer to MI_DISP_HistogramInfo_t.
    E_MI_DISP_PICTURE_PARAM_TYPE_STATS_HISTOGRAM_INFO,
    //<Get> Get Histogram data. pInputParams is a pointer to MI_DISP_HistogramParams_t.
    //pOutputParams is a pointer to MI_DISP_HistogramData_t. User need to pre-allocate buffer for the parameter MI_DISP_HistogramData_t->pu32Histogram.
    E_MI_DISP_PICTURE_PARAM_TYPE_STATS_HISTOGRAM_DATA,
    //<Get> Get Luma Statistics Info. pParams is a pointer to MI_DISP_LumaStatistics_t.
    E_MI_DISP_PICTURE_PARAM_TYPE_STATS_LUMA_STATISTICS,
    //<Set> Set Saturation by Hue window Range. For getting the saturation histogram by the specified hue range.pParams is a pointer to MI_DISP_SatByHueWinRangeData_t.
    //<Get> Get Saturation by Hue window Range. pInputParams is a pointer to MI_DISP_SatByHueWinRangeParams_t. pOutputParams is a pointer to MI_DISP_SatByHueWinRangeData_t.
    //User need to pre-allocate buffer for the parameter MI_DISP_SatByHueWinRangeData_t->pu16HueWinStart/pu16HueWinEnd.
    E_MI_DISP_PICTURE_PARAM_TYPE_STATS_SAT_BY_HUE_WINDOW_RANGE,
    //<Get> Get Saturation Histograms of the specified Hue Ranges.
    //pInputParams is a pointer to MI_DISP_SatByHueHistogramParams_t. pOutputParams is a pointer to MI_DISP_SatByHueHistogramData_t.
    //User need to pre-allocate buffer for the parameter MI_DISP_SatByHueHistogramData_t->ppu32SatByHueHistogram.
    E_MI_DISP_PICTURE_PARAM_TYPE_STATS_SAT_BY_HUE_HISTOGRAM,
    E_MI_DISP_PICTURE_PARAM_TYPE_STATS_MAX,

    E_MI_DISP_PICTURE_PARAM_TYPE_MISC_MIN = 0xf00,
    // <Get> Get PQ binary version
    E_MI_DISP_PICTURE_PARAM_TYPE_MISC_PQ_VERSION = E_MI_DISP_PICTURE_PARAM_TYPE_MISC_MIN,
    E_MI_DISP_PICTURE_PARAM_TYPE_MISC_MAX,

}MI_DISP_PictureParamsType_e;

typedef enum
{
    E_MI_DISP_FIELD_TYPE_NONE,
    E_MI_DISP_FIELD_TYPE_TOP,
    E_MI_DISP_FIELD_TYPE_BOTTOM,
    E_MI_DISP_FIELD_TYPE_BOTH,
    E_MI_DISP_FIELD_TYPE_MAX,
} MI_DISP_FieldType_e;

typedef enum
{
    E_MI_DISP_VIEW_TYPE_CENTER,
    E_MI_DISP_VIEW_TYPE_LEFT,
    E_MI_DISP_VIEW_TYPE_RIGHT,
    E_MI_DISP_VIEW_TYPE_TOP,
    E_MI_DISP_VIEW_TYPE_BOTTOM,
    E_MI_DISP_VIEW_TYPE_MAX,
} MI_DISP_ViewType_e;

typedef enum
{
    E_MI_DISP_COLOR_RANGE_YUV_16_235,    //16~235
    E_MI_DISP_COLOR_RANGE_YUV_0_255,     //0~255
    E_MI_DISP_COLOR_RANGE_RGB_16_235,     // 16~235
    E_MI_DISP_COLOR_RANGE_RGB_0_255,      // 0~255
    E_MI_DISP_COLOR_RANGE_AUTO,            // auto
    E_MI_DISP_COLOR_RANGE_CUS,
} MI_DISP_ColorRange_e;

typedef enum
{
    ///  MEMC level off
    E_MI_DISP_MEMC_LEVEL_OFF,
    ///  MEMC level low
    E_MI_DISP_MEMC_LEVEL_LOW,
    ///  MEMC level middle
    E_MI_DISP_MEMC_LEVEL_MID,
    ///  MEMC level high
    E_MI_DISP_MEMC_LEVEL_HIGH,
    ///  MEMC level bypass
    E_MI_DISP_MEMC_LEVEL_BYPASS,
}MI_DISP_MemcLevel_e;

typedef enum
{
    ///  MpegNR level off
    E_MI_DISP_MPEG_NR_LEVEL_OFF,
    ///  MpegNR level low
    E_MI_DISP_MPEG_NR_LEVEL_LOW,
    ///  MpegNR level middle
    E_MI_DISP_MPEG_NR_LEVEL_MID,
    ///  MpegNR level high
    E_MI_DISP_MPEG_NR_LEVEL_HIGH,
    ///  MpegNR level default
    E_MI_DISP_MPEG_NR_LEVEL_DEFAULT,
}MI_DISP_MpegNrLevel_e;

typedef enum
{
    ///  NR level off
    E_MI_DISP_NR_LEVEL_OFF,
    ///  NR level low
    E_MI_DISP_NR_LEVEL_LOW,
    ///  NR level middle
    E_MI_DISP_NR_LEVEL_MID,
    ///  NR level high
    E_MI_DISP_NR_LEVEL_HIGH,
    ///  NR level auto
    E_MI_DISP_NR_LEVEL_AUTO,
    ///  NR level default
    E_MI_DISP_NR_LEVEL_DEFAULT,
}MI_DISP_NrLevel_e;

typedef enum
{
    E_MI_DISP_XVYCC_DISABLE,
    E_MI_DISP_XVYCC_XVYCC601,    ///< xvycc 601
    E_MI_DISP_XVYCC_XVYCC709,    ///< xvycc 709
    E_MI_DISP_XVYCC_SYCC601,     ///< sYCC 601
    E_MI_DISP_XVYCC_ADOBE_YCC601, ///< Adobe YCC 601
    E_MI_DISP_XVYCC_ADOBE_RGB,    ///< Adobe RGB
    E_MI_DISP_XVYCC_DEFAULT = E_MI_DISP_XVYCC_XVYCC601,    ///< Default setting
    E_MI_DISP_XVYCC_UNKNOWN = 0xFF,    ///< Unknow
} MI_DISP_XvyccMode_e;

typedef enum
{
    ///  MEMC demo Left
    E_MI_DISP_MEMC_DEMO_TYPE_LEFT,
    ///  MEMC demo Right
    E_MI_DISP_MEMC_DEMO_TYPE_RIGHT,
    ///  MEMC demo Top
    E_MI_DISP_MEMC_DEMO_TYPE_TOP,
    ///  MEMC demo Bottom
    E_MI_DISP_MEMC_DEMO_TYPE_BOTTOM,
} MI_DISP_MemcDemoType_e;

typedef enum
{
    E_MI_DISP_QUALITY_DEMO_MODE_DEFAULT,
    E_MI_DISP_QUALITY_DEMO_MODE_CUS,
} MI_DISP_QualityDemoMode_e;

typedef enum
{
    E_MI_DISP_QUALITY_DEMO,
    E_MI_DISP_MEMC_DEMO,
}MI_DISP_Demo_e;

typedef enum
{
    ///event of flip frame done, refer to MI_DISP_FrameInfo_t.
    E_MI_DISP_CALLBACK_EVENT_FLIP_FRAME_DONE    = MI_BIT(0),
    ///event of video latnecy, refer to MI_DISP_FrameInfo_t.
    E_MI_DISP_CALLBACK_EVENT_GET_VIDEO_LATENCY    = MI_BIT(1),
    ///event of video frame flip to mvop and callback to user. Refer to MI_DISP_OutputLatencyParams_t.
    E_MI_DISP_CALLBACK_EVENT_FLIP_FRAME_TO_MVOP    = MI_BIT(2),
    ///event of video frame show more than once, Refer to MI_U32(u32RepeatCnt).
    E_MI_DISP_CALLBACK_EVENT_FLIP_FRAME_REPEAT    = MI_BIT(3),
    //All event.
    E_MI_DISP_CALLBACK_EVENT_ALL            = 0xFFFFFFFF,
}MI_DISP_CallbackEvent_e;

typedef enum
{
    E_MI_DISP_CONNECTION_SHOW_TYPE_DEFAULT,
    E_MI_DISP_CONNECTION_SHOW_TYPE_ONSCREEN,
    E_MI_DISP_CONNECTION_SHOW_TYPE_OFFSCREEN,
}MI_DISP_ConnectionShowType_e;

typedef enum    // For MI_DISP_FrameFormat_t
{
    E_MI_DISP_FRAME_TYPE_I,   //Indicate this frame type is I.
    E_MI_DISP_FRAME_TYPE_P,  //Indicate this frame type is P.
    E_MI_DISP_FRAME_TYPE_B,  //Indicate this frame type is B.
    E_MI_DISP_FRAME_TYPE_OTHER,  //Not used yet.
    E_MI_DISP_FRAME_TYPE_MAX,
}MI_DISP_FrameType_e;

typedef enum    // For MI_DISP_FrameFormat_t
{
    E_MI_DISP_FRAME_FIELD_TYPE_NONE,   //Not used yet.
    E_MI_DISP_FRAME_FIELD_TYPE_TOP,   //Indicate this frame field type is top field.
    E_MI_DISP_FRAME_FIELD_TYPE_BOTTOM,   //Indicate this frame field type is bottom field.
    E_MI_DISP_FRAME_FIELD_TYPE_BOTH,   //Indicate this frame field type contain both field.
    E_MI_DISP_FRAME_FIELD_TYPE_MAX,
}MI_DISP_FrameFieldType_e;

typedef enum    // For MI_DISP_FrameInfo_t
{
    E_MI_DISP_SCAN_TYPE_PROGRESSIVE = 0,  //Indicate this frame info contain a progressive frame.
    E_MI_DISP_SCAN_TYPE_INTERLACE_FRAME, //Indicate this frame info contain a interlace frame
    E_MI_DISP_SCAN_TYPE_INTERLACE_FIELD,  //Indicate this frame info contain a interlace field
    E_MI_DISP_SCAN_TYPE_MAX,
}MI_DISP_ScanType_e;

typedef enum // For MI_DISP_FrameInfo_t
{
    E_MI_DISP_FRAME_CONTROL_NORMAL = 0, //Default flip scenario. Used in normal flip case.
    E_MI_DISP_FRAME_CONTROL_SEEK,       //Seek flip scenario. Handling non continues source flip which can avoid de-interlace error of interlace clips. Ex: FF/FB case.
    E_MI_DISP_FRAME_CONTROL_MAX,
}MI_DISP_FrameControl_e;

typedef enum
{
    E_MI_DISP_HSY_MODEL_HUE,
    E_MI_DISP_HSY_MODEL_SATURATION,
    E_MI_DISP_HSY_MODEL_LUMINANCE,
    E_MI_DISP_HSY_MODEL_MAX
}MI_DISP_HsyModelType_e;

typedef enum
{
    E_MI_DISP_HSY_COLOR_RED,
    E_MI_DISP_HSY_COLOR_GREEN,
    E_MI_DISP_HSY_COLOR_BLUE,
    E_MI_DISP_HSY_COLOR_CYAN,
    E_MI_DISP_HSY_COLOR_MAGENTA,
    E_MI_DISP_HSY_COLOR_YELLOW,
    E_MI_DISP_HSY_COLOR_FLESH,
    E_MI_DISP_HSY_COLOR_MAX,
}MI_DISP_HsyColorType_e;

typedef enum
{
    E_MI_DISP_GAMMA_TYPE_PQ,
    E_MI_DISP_GAMMA_TYPE_MAX,
}MI_DISP_GammaType_e;

typedef enum
{
    E_MI_DISP_GAMMA_ENTRY_TYPE_256,
    E_MI_DISP_GAMMA_ENTRY_TYPE_1024,
    E_MI_DISP_GAMMA_ENTRY_TYPE_MAX,
}MI_DISP_GammaEntryType_e;

typedef enum
{
    E_MI_DISP_GAMMA_BIT_TYPE_10_BIT,
    E_MI_DISP_GAMMA_BIT_TYPE_12_BIT,
}MI_DISP_GammaBitType_e;

typedef enum
{
    E_MI_DISP_PANEL_GAMMA_TABLE_FROM_BIN,
    E_MI_DISP_PANEL_GAMMA_TABLE_FROM_REG,
    E_MI_DISP_PANEL_GAMMA_TABLE_TYPE_MAX,
}MI_DISP_PanelGammaTableType_e;

typedef enum // For MI_DISP_FrameInfo_t
{
    E_MI_DISP_FRAME_COLOR_FORMAT_YUV420 = 0, /// YUV420.
    E_MI_DISP_FRAME_COLOR_FORMAT_YUV422,     /// YUV422. (YUYV)
    E_MI_DISP_FRAME_COLOR_FORMAT_ARGB8888,     /// ARGB8888
    E_MI_DISP_FRAME_COLOR_FORMAT_MAX,
}MI_DISP_FrameColorFmt_e;

typedef enum
{
    E_MI_DISP_FRAME_TILE_BLOCK_NONE  = 0x0,
    E_MI_DISP_FRAME_TILE_BLOCK_16X16 = 0x1,
    E_MI_DISP_FRAME_TILE_BLOCK_16X32 = 0x2,
    E_MI_DISP_FRAME_TILE_BLOCK_32X16 = 0x3,
    E_MI_DISP_FRAME_TILE_BLOCK_32X32 = 0x4,
    E_MI_DISP_FRAME_TILE_BLOCK_4X2_COMPRESSION_MODE = 0x5,
    E_MI_DISP_FRAME_TILE_BLOCK_8X1_COMPRESSION_MODE = 0x6,
    E_MI_DISP_FRAME_TILE_BLOCK_32X16_82PACK = 0x7,
    E_MI_DISP_FRAME_TILE_BLOCK_MAX,
} MI_DISP_FrameTileBlock_e;

typedef enum
{
    E_MI_DISP_CONNECTION_SOURCE_TYPE_MODULES,         // For connect MI module as the source
    E_MI_DISP_CONNECTION_SOURCE_TYPE_DRAM             // For connect DRAM as the source
} MI_DISP_ConnectionSourceType_e;

typedef enum
{
    E_MI_DISP_DATA_RANGE_8_BIT,
    E_MI_DISP_DATA_RANGE_10_BIT,
    E_MI_DISP_DATA_RANGE_12_BIT,
    E_MI_DISP_DATA_RANGE_MAX,
}MI_DISP_DataRange_e;

typedef enum
{
    E_MI_DISP_HISTOGRAM_SOURCE_DEFAULT, //Histogram source is default.
    E_MI_DISP_HISTOGRAM_SOURCE_MAX,
}MI_DISP_HistogramSource_e;

typedef enum
{
    E_MI_DISP_HISTOGRAM_TYPE_LUMA,
    E_MI_DISP_HISTOGRAM_TYPE_SATURATION,
    E_MI_DISP_HISTOGRAM_TYPE_HUE,
}MI_DISP_HistogramType_e;

typedef enum
{
    E_MI_DISP_NON_LINEAR_SCALING_TYPE_HORIZONTAL,
    E_MI_DISP_NON_LINEAR_SCALING_TYPE_MAX,
}MI_DISP_NonLinearScalingType_e;

typedef enum
{
    E_MI_DISP_XVYCC_DEGAMMA_MODE_AUTO, //driver control
    E_MI_DISP_XVYCC_DEGAMMA_MODE_ENABLE, //customer enable
    E_MI_DISP_XVYCC_DEGAMMA_MODE_DISABLE, //customer disable
}MI_DISP_XvyccDeGammaMode_e;

typedef enum
{
    E_MI_DISP_XVYCC_GAMMA_MODE_AUTO, //driver control
    E_MI_DISP_XVYCC_GAMMA_MODE_ENABLE, //customer enable
    E_MI_DISP_XVYCC_GAMMA_MODE_DISABLE, //customer disable
}MI_DISP_XvyccGammaMode_e;

typedef enum
{
    E_MI_DISP_XVYCC_GAMUT_MODE_AUTO, //driver control
    E_MI_DISP_XVYCC_GAMUT_MODE_ENABLE, //customer enable
    E_MI_DISP_XVYCC_GAMUT_MODE_DISABLE, //customer disable
}MI_DISP_XvyccGamutMode_e;

typedef enum
{
    E_MI_DISP_HDR_STATIC_METADATA_DISABLE = 0,
    E_MI_DISP_HDR_STATIC_METADATA_ENABLE = 1,
} MI_DISP_HdrEnableStaticMetadata_e;

typedef enum
{
    E_MI_DISP_PIXEL_REPORT_STAGE_AFTER_DLC = 0x01,  ///< Stage after dynamic contrast
    E_MI_DISP_PIXEL_REPORT_STAGE_PRE_GAMMA = 0x02,  ///< Stage before Gamma
    E_MI_DISP_PIXEL_REPORT_STAGE_AFTER_OSD = 0x03,  ///< Stage after OSD / Video blending
}MI_DISP_PixelReportStage_e;

typedef enum
{
    E_MI_DISP_DBG_INFO_NONE = 0,
    E_MI_DISP_DBG_INFO_SETUP = MI_BIT(0),
    E_MI_DISP_DBG_INFO_WINDOW = MI_BIT(1),
    E_MI_DISP_DBG_INFO_SETTING = MI_BIT(2),
    E_MI_DISP_DBG_INFO_MUTE = MI_BIT(3),
    E_MI_DISP_DBG_INFO_INTERNAL = MI_BIT(30),
    E_MI_DISP_DBG_INFO_DUMPSTACK = MI_BIT(31),
}MI_DISP_DbgInfoType_e;

typedef enum
{
    E_MI_DISP_COLOR_SPACE_BT709 = 0,
    E_MI_DISP_COLOR_SPACE_SRGB,
    E_MI_DISP_COLOR_SPACE_DOLBY,
    E_MI_DISP_COLOR_SPACE_XVYCC,
    E_MI_DISP_COLOR_SPACE_UNSPECIFIED,
    E_MI_DISP_COLOR_SPACE_BT470_6,
    E_MI_DISP_COLOR_SPACE_BT601_625,
    E_MI_DISP_COLOR_SPACE_PAL,
    E_MI_DISP_COLOR_SPACE_SECAM,
    E_MI_DISP_COLOR_SPACE_BT601_525,
    E_MI_DISP_COLOR_SPACE_NTSC,
    E_MI_DISP_COLOR_SPACE_SMPTE_170M,
    E_MI_DISP_COLOR_SPACE_SMPTE_240M,
    E_MI_DISP_COLOR_SPACE_GENERIC_FILM,
    E_MI_DISP_COLOR_SPACE_BT2020_CL,
    E_MI_DISP_COLOR_SPACE_BT2020_NCL,
    E_MI_DISP_COLOR_SPACE_CIEXYZ,
    E_MI_DISP_COLOR_SPACE_P3,
    E_MI_DISP_COLOR_SPACE_ADOBERGB,
    E_MI_DISP_COLOR_SPACE_MAX,
}MI_DISP_ColoSpace_e;

typedef enum
{
    E_MI_DISP_MIRROR_MODE_NORMAL = 0,
    E_MI_DISP_MIRROR_MODE_HORIZONTAL,
    E_MI_DISP_MIRROR_MODE_VERTICAL,
    E_MI_DISP_MIRROR_MODE_HORIZONTAL_VERTICAL,

    E_MI_DISP_MIRROR_MODE_MAX,
} MI_DISP_MirrorMode_e;

typedef enum
{
    E_MI_DISP_MODULE_HDR = 0,
    E_MI_DISP_MODULE_TNR,
    E_MI_DISP_MODULE_DI_FILM,
    E_MI_DISP_MODULE_MPEGNR,
    E_MI_DISP_MODULE_VIDEO_ENHANCE,
    E_MI_DISP_MODULE_RESOLUTION_ENHANCE,
    E_MI_DISP_MODULE_CONSTRAST_ENHANCE,
    E_MI_DISP_MODULE_COLOR_ENHANCE,
    E_MI_DISP_MODULE_GAMUT_MAPPING,
    E_MI_DISP_MODULE_PQ_GAMMA,
    E_MI_DISP_MODULE_LOCALDIMING,
    E_MI_DISP_MODULE_PANEL,

    E_MI_DISP_MODULE_MAX,
} MI_DISP_ModuleList_e;

typedef enum
{
    E_MI_DISP_MODULE_SET_NONE = 0,
    E_MI_DISP_MODULE_SET_BYPASS,
    E_MI_DISP_MODULE_SET_RESUME,
    E_MI_DISP_MODULE_SET_RESERVED,

    E_MI_DISP_MODULE_SET_MAX
} MI_DISP_ModuleSetting_e;

typedef enum
{
    E_MI_DISP_MODULE_STATUS_NONE = 0,
    E_MI_DISP_MODULE_STATUS_BYPASS,
    E_MI_DISP_MODULE_STATUS_AVAIL,

    E_MI_DISP_MODULE_STATUS_MAX
}  MI_DISP_ModuleStatus_e;

//-------------------------------------------------------------------------------------------------
//  Structures
//-------------------------------------------------------------------------------------------------
typedef struct MI_DISP_HdrCaps_s
{
MI_BOOL bSupport;
} MI_DISP_HdrCaps_t;

/// Display module capability
typedef struct MI_DISP_Caps_s
{
    MI_BOOL bSupport4k2k;
    MI_DISP_HdrCaps_t astSupportHdrCaps[E_MI_DISP_HDR_TYPE_MAX];
    MI_BOOL bSupportXvycc;
    MI_BOOL bSupportHsy;
} MI_DISP_Caps_t;

/// Display init parameters
typedef struct MI_DISP_InitParams_s
{
    MI_DISP_Timing_e eDispTiming;
    MI_DISP_TvSystem_e eTvSystem;
    MI_DISP_DeFlicker_e eDeFlicker;
} MI_DISP_InitParams_t;

/// Open parameters of video window
typedef struct MI_DISP_OpenParams_s
{
    MI_DISP_VidWinType_e eVidWinType;
    MI_U8* pszName;     //String name of handle

} MI_DISP_OpenParams_t;

/// Get Disp handle
typedef struct MI_DISP_QueryHandleParams_s
{
    MI_U8* pszName;     //Query string name for disp handle
} MI_DISP_QueryHandleParams_t;

/// Background color of video window
typedef struct MI_DISP_VidWinBgColor_s
{
    MI_U16 u16Red;
    MI_U16 u16Green;
    MI_U16 u16Blue;
} MI_DISP_VidWinBgColor_t;

/// Retangular information of videwo window
typedef struct MI_DISP_VidWinRect_s
{
    MI_U16 u16X;
    MI_U16 u16Y;
    MI_U16 u16Width;
    MI_U16 u16Height;
} MI_DISP_VidWinRect_t;

typedef struct MI_DISP_RgbColor_s
{
    MI_U32 u32Red;
    MI_U32 u32Green;
    MI_U32 u32Blue;
} MI_DISP_RgbColor_t;

typedef struct MI_DISP_2DTo3DCapability_s
{
    MI_BOOL bSupportGain;
    MI_BOOL bSupportOffset;
} MI_DISP_2DTo3DCapability_t;

typedef struct MI_DISP_OpenControllerParams_s
{
    ///Reserved
    MI_U8 u8Reserved;
} MI_DISP_OpenControllerParams_t;

typedef struct MI_DISP_DetectOsdParams_s
{
    MI_BOOL bEnable;
    MI_U32 u32Threshold;
    MI_BOOL bOsdExisted;
} MI_DISP_DetectOsdParams_t;

typedef struct MI_DISP_GetControllerParams_s
{
    ///Reserved
    MI_U8 u8Reserved;
} MI_DISP_GetControllerParams_t;

typedef struct MI_DISP_HdrOnOff_s
{
    MI_DISP_HdrType_e eHdrType;
    MI_DISP_HdrOnOff_e eHdrOnOff;
}MI_DISP_HdrOnOff_t;


typedef struct
{
    /// Structure version
    MI_U32 u32Version;
    /// Structure length
    MI_U16 u16Length;
    /// HDR type, reference MI_DISP_IMPL_XC_HdrType_e
    MI_DISP_HdrType_e eHdrType;
    ///output max Lumimance
    MI_BOOL bOutputMaxLuminance;
    ///output TR parameter
    MI_U16 u16OutputMaxLuminance;
} MI_DISP_HdrAttr_t;

typedef struct MI_DISP_HdrLevel_s
{
    MI_DISP_HdrType_e eHdrType;
    //Open HDR level:MI_DISP_HdrLevel_e
    //Dolby HDR level:MI_DISP_HdrDolbyLevel_e
    MI_U32 u32HdrLevel;
}MI_DISP_HdrLevel_t;

typedef struct MI_DISP_AvgLumaParams_s
{
    MI_DISP_VidWinRect_t stReportRect;
    MI_U32 u32AvgLuma;
}MI_DISP_AvgLumaParams_t;

typedef struct MI_DISP_InputRect_s
{
    MI_U16 u16X;          //Input rect(crop) x axis
    MI_U16 u16Y;          //Input rect(crop) y axis
    MI_U16 u16Width;      //Input rect(crop) width
    MI_U16 u16Height;     //Input rect(crop) height
    MI_U16 u16WidthBase;  //Input rect(crop) width base. If set, MI will re-calculate input rect base on real video source and the ratio of (u16Width/u16WidthBase). Prevent mixed-up user input rect in DS stream case.
    MI_U16 u16HeightBase; //Input rect(crop) height base. If set, MI will re-calculate input rect base on real video source and the ratio of (u16Height/u16HeightBase). Prevent mixed-up user input rect in DS stream case.
} MI_DISP_InputRect_t;


typedef struct MI_DISP_ColorTemperature_s
{
    MI_U32 u32RGain;
    MI_U32 u32GGain;
    MI_U32 u32BGain;
    MI_U32 u32ROffset;
    MI_U32 u32GOffset;
    MI_U32 u32BOffset;
} MI_DISP_ColorTemperature_t;

typedef struct MI_DISP_HsbBypassParams_s
{
    ///HSB type, input param.
    MI_DISP_HsbType_e eHsbType;
    ///Bypass or/not.
    MI_BOOL bEnable;
} MI_DISP_HsbBypassParams_t;

typedef struct MI_DISP_InputColorRange_s
{
    MI_DISP_ColorRange_e eInputColorRange;
    MI_U8 u8CusBlackLevel;
    MI_U8 u8CusWhiteLevel;
} MI_DISP_InputColorRange_t;

typedef struct MI_DISP_PqGrule_s
{
    MI_U16 u16GruleType;
    MI_U16 u16GruleStatus;
} MI_DISP_PqGrule_t;

typedef struct MI_DISP_QualityDemoParams_s
{
    MI_DISP_VidWinRect_t stDemoModeArea;        /// Demo mode area. This area must in Window.
    MI_DISP_QualityDemoMode_e eQualityDemoMode;    /// Predefined quality mode.
    MI_U16 u16CusDemoIndex; //Load cus demo index when eQualityDemoMode = E_MI_DISP_QUALITY_DEMO_MODE_CUS
}MI_DISP_QualityDemoParams_t;

typedef struct MI_DISP_MemcDemoParams_s
{
    MI_DISP_MemcDemoType_e eMemcDemoType;
}MI_DISP_MemcDemoParams_t;

typedef struct MI_DISP_DemoMode_s
{
    MI_BOOL bEnable;
    MI_DISP_Demo_e eDemoType;
    void *pDemoParams;
}MI_DISP_DemoMode_t;

/// Disp connect input HW IP parameters
typedef struct MI_DISP_ConnectInputParams_s
{
    MI_DISP_ConnectionShowType_e eConnectionShowType;
    MI_DISP_ConnectionSourceType_e eConnectionSourceType;
}MI_DISP_ConnectInputParams_t;

typedef struct MI_DISP_ConnectedConds_s
{
    MI_BOOL bIsInput;
    MI_U32 u32Module;
    //if need other conditions add here
    MI_DISP_ConnectionShowType_e eConnectionShowType;
} MI_DISP_ConnectedConds_t;

typedef struct MI_DISP_CallbackInputParams_s
{
    ///[IN]: for multi-callback, use 0 for first register or single callback.
    MI_U64 u64CallbackId;
    /// Callback function pointer.
    MI_DISP_EventCallback pfEventCallback;
    /// Event flags defined by MI_DISP_CallbackEvent_e
    MI_U32 u32EventFlags;
    /// User parameter
    void *pUserParams;
} MI_DISP_CallbackInputParams_t;

typedef struct MI_DISP_CallbackOutputParams_s
{
    ///[OUT]: the returned ID for update or unregister callback.
    MI_U64 u64CallbackId;
} MI_DISP_CallbackOutputParams_t;

typedef struct MI_DISP_FramesFormat_s   // For MI_DISP_FrameInfo_t
{
    MI_PHY phyLumaAddr;                    // Luma Address for YUV color spece.
    MI_PHY phyChromaAddr;                  // Chroma Address for YUV color space.
    MI_DISP_FrameType_e eFrameType;       // Indicate frame type. (I/B/P Frame)
    MI_DISP_FrameFieldType_e eFieldType;  // Indicate frame filed type. (Bottom/Top/Both)
    MI_U8 u8LumaBitDepth;                  // Luma color bit depth.
    MI_U8 u8ChromaBitDepth;                // Chroma color bit depth.
    MI_U16 u16LumaPitch;                     // Luma Pitch. Unit: Pixel.
    MI_U16 u16ChromaPitch;                   // Chroma Pitch. Unit: Pixel.
}MI_DISP_FramesFormat_t;

typedef struct MI_DISP_ForcePModeParams_s
{
    MI_BOOL bForcePMode;    /// Force P mode for special case usage.(e.g. BBC cert)
    MI_U32 u32ForceFrameRate;    /// Force frame rate.
} MI_DISP_ForcePModeParams_t;

typedef struct MI_DISP_FrameInfo_s
{
    MI_VIRT virtMetadata; // private metadata of frame.

    MI_DISP_FramesFormat_t astFramesFormat[2];  // If bBottomFieldFirst = TRUE, bottom(0) top(1). If bBottomFieldFirst = FALSE, bottom(1), top(0).
    MI_U64 u64Pts;                              // unit: 90k hz, for invalid PTS please assign MI_INVALID_PTS.
    MI_DISP_ScanType_e eScanType;             // Indicate this frame is progressive/interlace frame/interlace field.
    MI_U32 u32FrameRate;                        // unit: 1000
    MI_U32 u32AspectWidth;                      // Display width.
    MI_U32 u32AspectHeight;                     // Display height.
    MI_U32 u32Width;                            // original video width.
    MI_U32 u32Height;                           // original video height.
    MI_U32 u32CropLeft;                         // Left cropping.
    MI_U32 u32CropRight;                        // Right cropping.
    MI_U32 u32CropTop;                          // Top cropping.
    MI_U32 u32CropBottom;                       // Bottom cropping.
    MI_BOOL bBottomFieldFirst;                  // Indiacte the bottom/top position for MI_VIDEO_FramesFormat_t.
    MI_U32 u32FrameFieldNum;                    // Frame field num.
    MI_DISP_FrameControl_e eFrameControl;       // Flip control for handling different flip scenario.
    MI_DISP_FrameColorFmt_e eFrameColorFmt;     // Frame color fmt
    MI_DISP_FrameTileBlock_e eFrameTileMode;    // Frame Tile mode
    MI_U32 u32ExternalDelay;                    // External delay for avsync usage(e.g tunnel/non-tunnel mode delay.), unit: ms.
    MI_DISP_ForcePModeParams_t stForcePModeParams;  /// Force Progressive mode. (For BBC cert usage)
    MI_BOOL bFrameStamp;                        // Stamp the frame.
    MI_U32 u32MaxWidth;                         // Set the maximum resolution (width/hegiht) in this stream for better PQ quaility.
    MI_U32 u32MaxHeight;                        // Set the maximum resolution (width/hegiht) in this stream for better PQ quaility.
} MI_DISP_FrameInfo_t;

typedef struct MI_DISP_HsyModelRange_s
{
    MI_S32 as32MinModelRange[E_MI_DISP_HSY_MODEL_MAX]; //base 256
    MI_S32 as32MaxModelRange[E_MI_DISP_HSY_MODEL_MAX]; //base 256
}MI_DISP_HsyModelRange_t;

typedef struct MI_DISP_HsyColorInfo_s
{
    MI_DISP_HsyModelType_e eHsyModelType;
    MI_S32 as32AdjustColorValue[E_MI_DISP_HSY_COLOR_MAX]; //All HSY color adjust is base on 256. Ex: if Hue model need to shift 10 degree. the adjustvalue for hue is 10*256.
}MI_DISP_HsyColorInfo_t;

typedef struct MI_DISP_GammaGainOffset_s
{
    MI_U32 u32RGain; //Base 1024
    MI_U32 u32GGain; //Base 1024
    MI_U32 u32BGain; //Base 1024
    MI_U32 u32ROffset; //Bias 1024
    MI_U32 u32GOffset; //Bias 1024
    MI_U32 u32BOffset; //Bias 1024
} MI_DISP_GammaGainOffset_t;

typedef struct MI_DISP_GammaStatus_s
{
    MI_DISP_GammaType_e eGammaType;
    MI_BOOL bEnable;
}MI_DISP_GammaStatus_t;

typedef struct MI_DISP_GammaSetting_s
{
    MI_DISP_GammaType_e eGammaType;
    MI_DISP_GammaEntryType_e eGammaEntryType;
    MI_DISP_GammaBitType_e eGammaEntryBit;
    MI_U16 *pu16GammaR;
    MI_U16 *pu16GammaG;
    MI_U16 *pu16GammaB;
    MI_U16 u16GammaRMax;
    MI_U16 u16GammaGMax;
    MI_U16 u16GammaBMax;
}MI_DISP_GammaSetting_t;

typedef struct MI_DISP_PanelGammaSetting_s
{
    MI_U8 u8GammaTableIndex;
    MI_DISP_PanelGammaTableType_e eGammaTableType;
}MI_DISP_PanelGammaSetting_t;

typedef struct MI_DISP_3DNrControlInfo_s
{
    MI_U8 u8GlobalNrStrengthMin;
    MI_U8 u8GlobalNrStrengthMax;
    MI_U8 u8NrControlStepNum;
}MI_DISP_3DNrControlInfo_t;

typedef struct MI_DISP_3DNrControlSetting_s
{
    MI_BOOL bEnable; //Enable: use user 3D NR setting. Disable: use default driver setting.
    MI_U8 u8GlobalNrStrength; //Control global 3D NR strength.
    MI_U8 u8NrControlStepNum; //Numbers of motion control steps.
    MI_U8* pu8NrControlStepValue; //Set 3D NR weighting value by motion steps.
}MI_DISP_3DNrControlSetting_t;

typedef struct MI_DISP_RgbTestPattern_s
{
    MI_BOOL bEnable;
    MI_DISP_DataRange_e eDataRange;
    MI_U32 u32R;
    MI_U32 u32G;
    MI_U32 u32B;
} MI_DISP_RgbTestPattern_t;

typedef struct MI_DISP_Tmo1DLUT_s
{
    MI_U16 u16ControlPoints; //TMO 1D LUT control points set by user
    MI_U16 au16InputPoint[256]; // TMO 1D Lut input poit
    MI_U16 au16OutputPoint[256]; // TMO 1D Lut output value
} MI_DISP_Tmo1DLut_t;

typedef struct MI_DISP_StageTestPattern_s
{
    MI_U8 u8PatternStage;//test pattern stage
    MI_DISP_RgbTestPattern_t  stPatternInfo;     // test pattern info.
} MI_DISP_StageTestPattern_t;

typedef struct MI_DISP_XvyccControlSetting_s
{
    MI_DISP_XvyccDeGammaMode_e eXvyccDeGammaMode;
    MI_DISP_XvyccGammaMode_e eXvyccGammaMode;
    MI_DISP_XvyccGamutMode_e eXvyccGamutMode;
    MI_S32 as32ColorMatrix[9]; //User control gamut matrix when MI_DISP_XvyccGamutMode_e is enable. 65536 base.
}MI_DISP_XvyccControlSetting_t;

typedef struct MI_DISP_CusLumaCurve_s
{
    MI_DISP_DataRange_e eDataRange; //data range for the customer luma curve.
    MI_U16 u16AnchorPointNum; //Numbers of anchor points.
    MI_U32 *pu32AnchorPointIndex; //pointer to the anchor point index array.
    MI_U32 *pu32AnchorPointValue; //pointer to the anchor point value array.
}MI_DISP_CusLumaCurve_t;

typedef struct MI_DISP_BlackStretch_s
{
    MI_U16 u16StretchGain; //base 1024
}MI_DISP_BlackStretch_t;

typedef struct MI_DISP_WhiteStretch_s
{
    MI_U16 u16StretchGain; //base 1024
}MI_DISP_WhiteStretch_t;

typedef struct MI_DISP_HistogramCtrl_s
{
    MI_DISP_HistogramSource_e eHistogramSource;
}MI_DISP_HistogramCtrl_t;

typedef struct MI_DISP_HistogramInfo_s
{
    MI_U16 u16LumaHistBinNum; //Get numbers of support Luma histogram bin.
    MI_U16 u16SatHistBinNum; //Get numbers of support Saturation histogram bin.
    MI_U16 u16HueHistBinNum; //Get numbers of support hue histogram bin.
    MI_U16 u16SatByHueWinNum; //Get numbers of support hue windows. For get the saturation histogram in the specified hue range(window).
    MI_U16 u16SatByHueHistBinNum; //Get numbers of support Saturation of Hue histogram bin.
    MI_U16 u16SatByHueWinSliceNum; //Get slice numbers(N) of hue window. Divide hue 360 degree into N slices.
}MI_DISP_HistogramInfo_t;

typedef struct MI_DISP_HistogramParams_s
{
    MI_DISP_HistogramType_e eHistogramType;
    MI_U16 u16HistBinNum;  //Numbers of bin element buffer which is allocated in MI_DISP_HistogramData_t->pu32Histogram. Bin number should be got first by using E_MI_DISP_PICTURE_PARAM_TYPE_STATISTICS_HISTOGRAM_INFO attr.
}MI_DISP_HistogramParams_t;

typedef struct MI_DISP_HistogramData_s
{
    MI_U16 u16HistBinNum;  //Numbers of supported histogram bin.
    MI_U32 *pu32Histogram; //pointer to Histogram data.
}MI_DISP_HistogramData_t;

typedef struct MI_DISP_LumaStatistics_s
{
    MI_DISP_DataRange_e eDataRange;//Normalized the luma statistics data to the eDataRange.
    MI_U32 u32MinPixelLuma; //Minimal luma pixel
    MI_U32 u32MaxPixelLuma; //Maximal luma pixel
    MI_U32 u32AvgPixelLuma; //Average luma of total pixels
}MI_DISP_LumaStatistics_t;

typedef struct MI_DISP_SatByHueWinRangeParams_s
{
    MI_U16 u16SatByHueWinNum; //Numbers of Saturation by Hue window.
}MI_DISP_SatByHueWinRangeParams_t;

typedef struct MI_DISP_SatByHueWinRangeData_s
{
    MI_U16 u16SatByHueWinNum; //Numbers of Saturation by Hue window.
    MI_U16 *pu16HueWinStart; //The start slice number of the saturation by hue window. The element number of the pointer is specified in u16SatByHueWinNum.
    MI_U16 *pu16HueWinEnd;  //The end slice number of the saturation by hue window. The element number of the pointer is specified in u16SatByHueWinNum.
}MI_DISP_SatByHueWinRangeData_t;

typedef struct MI_DISP_SatByHueHistogramParams_s
{
    MI_U16 u16SatByHueWinNum; //Numbers of Saturation by hue window.
    MI_U16 u16HistBinNum;  //Numbers of Saturation by hue histogram bin.
}MI_DISP_SatByHueHistogramParams_t;

typedef struct MI_DISP_SatByHueHistogramData_s
{
    MI_U16 u16SatByHueWinNum; //Numbers of Saturation by hue window.
    MI_U16 u16HistBinNum;    //Numbers of Saturation by hue histogram bin.
    MI_U32 **ppu32SatByHueHistogram; //Saturation by hue histogram data. 2D array => array[u16SatByHueWinNum][u16HistBinNum].
}MI_DISP_SatByHueHistogramData_t;

typedef struct MI_DISP_HoriNonLinear_s
{
    MI_BOOL bEnable; //enable or disable horizontal non linear scaling.
    MI_U32 u32GainOfStartRatio; //scaling ratio start from u32GainOfStartRatio*(original linear scaling ratio). base is 1024
    MI_U32 u32GainOfEndRatio; //scaling ratio end at u32GainOfEndRatio*(original linear scaling ratio). base is 1024
    MI_U16 u161stScalingCtrlPoint; //first non linear scaling control point. Normalized the half of display window width in 0~65535.
    MI_U16 u162ndScalingCtrlPoint; //second non linear scaling control point. Normalized the half of display window width in 0~65535.
}MI_DISP_HoriNonLinear_t;

typedef struct MI_DISP_HoriNonLinearByRatioOfSourceAndPanel_s
{
    MI_BOOL bEnable; //enable or disable horizontal non linear scaling.
    MI_U16 u16SourceRatio; //Source Ratio
    MI_U16 u16PanelRatio; //Panel Ratio
}MI_DISP_HoriNonLinearByRatioOfSourceAndPanel_t;

typedef struct MI_DISP_NonLinearScaling_s
{
    MI_DISP_NonLinearScalingType_e eNonLinearScalingType;
    union{
        MI_DISP_HoriNonLinear_t stHoriNonLinear;
        MI_DISP_HoriNonLinearByRatioOfSourceAndPanel_t stHoriNonLinearByRatioOfSourceAndPanel;
    };
}MI_DISP_NonLinearScaling_t;

/// < HDR metadata
typedef struct MI_DISP_HdrMetaDataCllInfo_s
{
    /// Content Light level valid info
    MI_BOOL bContentLightLevelValid;
    /// Max Content Light Level in source.
    MI_U32  u32MaxContentLightLevel;
    /// Max average Picture Content Light Level in source.
    MI_U32  u32MaxPicAverageLightLevel;
}MI_DISP_HdrMetaDataCllInfo_t;

typedef struct MI_DISP_HdrMetaDataSeiInfo_s
{
    /// SEI info valid info
    MI_BOOL bSeiValid;
    /// SEI Info, DisplayPrimariesX in R/G/B, real range is 0-1, multiply 50000
    MI_U32 au32DisplayPrimariesX[3];
    /// SEI Info, DisplayPrimariesY in R/G/B, real range is 0-1, multiply 50000
    MI_U32 au32DisplayPrimariesY[3];
    /// SEI Info, White point X, real range is 0-1, multiply 50000
    MI_U32 u32WhitePointX;
    /// SEI Info, White point Y, real range is 0-1, multiply 50000
    MI_U32 u32WhitePointY;
    /// SEI Info, MaxPanelLuminance, real range is 0-1, multiply 1000
    MI_U32 u32MaxPanelLuminance;
    /// SEI Info, MinPanelLuminance, real range is 0-1, multiply 1000
    MI_U32 u32MinPanelLuminance;
} MI_DISP_HdrMetaDataSeiInfo_t;

typedef struct MI_DISP_HdrMetaData_s
{
    ///HDR SEI info
    MI_DISP_HdrMetaDataSeiInfo_t stSeiInfo;
    ///HDR CLL Info
    MI_DISP_HdrMetaDataCllInfo_t stCllInfo;
} MI_DISP_HdrMetaData_t;

typedef struct MI_DISP_PqInfo_s
{
    MI_U8 szPqVersion[32];
} MI_DISP_PqInfo_t;
/// < HDR metadata
typedef struct MI_DISP_ReportWindowColor_s
{
    MI_U16 u16Red;
    MI_U16 u16Green;
    MI_U16 u16Blue;
} MI_DISP_ReportWindowColor_t;

typedef struct MI_DISP_PixelReportWindow_s
{
    MI_DISP_VidWinRect_t stReportWindowArea;           /// The area on a Window. User can retrieve pixel information from this area by using
    MI_DISP_PixelReportStage_e eStage;                /// The stage for retrieving pixel information
    MI_BOOL bShowReportWindow;                        /// Show a window on the screen
    MI_DISP_ReportWindowColor_t stReportWindowColor; /// RGB color normalized in 0X00~0XFFFF,will clamp by hw support bit
} MI_DISP_PixelReportWindow_t;

typedef struct MI_DISP_PixelReport_s
{
    MI_U32 u32RCrMin;                    ///<Output:R or Cr min value
    MI_U32 u32RCrMax;                    ///<Output:R or Cr max value
    MI_U32 u32GYMin;                     ///<Output:G or Y min value
    MI_U32 u32GYMax;                     ///<Output:G or Y max value
    MI_U32 u32BCbMin;                    ///<Output:B or Cb min value
    MI_U32 u32BCbMax;                    ///<Output:B or Cb max value
    MI_U64 u64RCrSum;                    ///<Output:R or Cr sum value
    MI_U64 u64GYSum;                     ///<Output:G or Y sum value
    MI_U64 u64BCbSum;                    ///<Output:B or Cb sum value
} MI_DISP_PixelReport_t;

typedef struct MI_DISP_SourceOffset_s
{
    MI_S32 s32XOffset;
    MI_S32 s32YOffset;
} MI_DISP_SourceOffset_t;

typedef struct MI_DISP_VarLatencyParams_s
{
    MI_U64 u64Pts;          /// Current display frame pts.
    MI_S64 s64SystemTime;   /// Current display frmae system time.
    MI_U32 u32LatencyTime;  /// buffer-in-queue output time.
    MI_BOOL bFrameSync;     /// Is Frame sync or not.
    MI_U32 u32FrameSyncDelay;   /// Frame sync delay.
} MI_DISP_VarLatencyParams_t;

typedef struct MI_DISP_RegularLatencyParams_s
{
    MI_U32 u32VideoLatancyTime;
} MI_DISP_RegularLatencyParams_t;


typedef struct MI_DISP_OutputLatencyParams_s
{
    MI_DISP_VarLatencyParams_t stVarLatencyParams;
    MI_DISP_RegularLatencyParams_t stRegularLatencyParams;
} MI_DISP_OutputLatencyParams_t;

typedef struct MI_DISP_PqOnOffParams_s
{
    MI_BOOL bEnable;
}MI_DISP_PqOnOffParams_t;

typedef struct MI_DISP_PqModuleStatusParams_s
{
    MI_U32 u32ControlMode;
    MI_U64 u64PqModuleBitMap;
}MI_DISP_PqModuleStatusParams_t;

typedef struct MI_DISP_VsyncParams_s
{
    MI_S64 s64InputVsyncSystemTime;    /// Vsync time. unit: ns.
    MI_U32 u32InputFrameRate;    /// Frame rate. unit: 1000 base.
} MI_DISP_VsyncParams_t;

//-------------------------------------------------------------------------------------------------
//  Global Functions
//-------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------
/// @brief Display module capability.
/// @param[in] pstCaps: Display module capability.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_DISP_GetCaps(MI_DISP_Caps_t *pstCaps);

//------------------------------------------------------------------------------
/// @brief disable bootlogo, it should be called once when app start to run
/// @param[in] hDispController: Display global controller handle
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_HAS_INITED: Display module has been initialized.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_DISP_DisableBootLogo(MI_HANDLE hDispController);

//------------------------------------------------------------------------------
/// @brief Display module initialize.
/// @param[in] pstInitParams: Display initialize paramaters
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_HAS_INITED: Display module has been initialized.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_DISP_Init(const MI_DISP_InitParams_t *pstInitParams);

//------------------------------------------------------------------------------
/// @brief Finalize display module.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_NOT_INITED: Display module not initialized.
//------------------------------------------------------------------------------
MI_RESULT MI_DISP_DeInit(void);

//------------------------------------------------------------------------------
/// @brief Open Controller for global setting.
/// @param[in] pstOpenParams: open parameters of controller.
/// @param[out] phDispController: Disp controller handle.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_NOT_INITED: Display module not initialized.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_NOT_SUPPORT: Video window type is not support.
//------------------------------------------------------------------------------
MI_RESULT MI_DISP_OpenController(const MI_DISP_OpenControllerParams_t *pstOpenParams, MI_HANDLE *phDispController);

//------------------------------------------------------------------------------
/// @brief Close disp controller.
/// @param[in] hDispController: Disp controller handle.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_INVALID_HANDLE: Video window handle is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_DISP_CloseController(MI_HANDLE hDispController);

//------------------------------------------------------------------------------
/// @brief Get disp controller handle.
/// @param[in] pstParams: reserved.
/// @param[out] phDispController: Disp controller handle.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_DISP_GetController(const MI_DISP_GetControllerParams_t *pstParams, MI_HANDLE *phDispController);

//------------------------------------------------------------------------------
/// @brief Open video window.
/// @param[in] pstOpenParams: Initialize parameters of video window.
/// @param[out] phDisp: Video window handle.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_NOT_INITED: Display module not initialized.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_NOT_SUPPORT: Video window type is not support.
//------------------------------------------------------------------------------
MI_RESULT MI_DISP_Open(const MI_DISP_OpenParams_t *pstOpenParams, MI_HANDLE *phDisp);

//------------------------------------------------------------------------------
/// @brief Close video window.
/// @param[in] hDisp: Video window handle.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_INVALID_HANDLE: Video window handle is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_DISP_Close(MI_HANDLE hDisp);

//------------------------------------------------------------------------------
/// @brief Get video window handle.
/// @param[in] pstQueryParams: The video window type that used for getting corresponding video window handle.
/// @param[out] phDisp: Video window handle.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_DISP_GetHandle(const MI_DISP_QueryHandleParams_t  *pstQueryParams, MI_HANDLE *phDisp);

//------------------------------------------------------------------------------
/// @brief Connect Disp input module.
/// @param[in]  hDisp: display window handle
/// @param[in]  hInput: input module handle
/// @param[in]  pstParams: Connect parameters.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_IMPLEMENT: Not implement functions.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_DISP_ConnectInput(MI_HANDLE hDisp, MI_HANDLE hInput, const MI_DISP_ConnectInputParams_t *pstParams);

//------------------------------------------------------------------------------
/// @brief DisConnect Disp input module.
/// @param[in]  hDisp: display window handle
/// @param[in]  hInput: input module handle
/// @return MI_OK: Process success.
//------------------------------------------------------------------------------
MI_RESULT MI_DISP_DisconnectInput(MI_HANDLE hDisp, MI_HANDLE hInput);

//------------------------------------------------------------------------------
/// @brief Get the element which is connected to the specified element.
/// @param[in] hDisp: display window handle
/// @param[in] pstDispConds: bIsinput-The direction for finding the connected module.
///                          u32ModuleType-The module type of connected with DISP. it defined in mi_common.h with prefix MI_MODULE_TYPE_XXX.
///                                        If it is MI_MODULE_TYPE_NONE it find all type of connected modules.
///                                        e.g. MI_DISP_GetConnectedNum(hDisp, TRUE, MI_MODULE_TYPE_VIDEO, pu32ConnectedNum)
/// @param[out] pu32ConnectedNum: The number of connected handle
/// @return MI_OK: Process success.
//------------------------------------------------------------------------------
MI_RESULT MI_DISP_GetConnectedNum(const MI_HANDLE hDisp, const MI_DISP_ConnectedConds_t *pstDispConds, MI_U32 *pu32ConnectedNum);

//------------------------------------------------------------------------------
/// @brief Get the element which is connected to the specified element.
/// @param[in] hDisp: display window handle
/// @param[in] pstDispConds: bIsinput-The direction for finding the connected module.
///                                       u32ModuleType-The module type of connected with DISP. it defined in mi_common.h with prefix MI_MODULE_TYPE_XXX.
///                                       If it is MI_MODULE_TYPE_NONE it find all type of connected modules.
///                                       e.g. MI_DISP_GetConnected(hDisp, TRUE, MI_MODULE_TYPE_VIDEO, u32ConnectedNum, phConnectedArray)
/// @param[in] u32ConnectedNum: The number of get handle
/// @param[out] phConnectedArray: Pointer to handle buffer to retrieve the handle of MI module which is connected to the specified element with the specified direction.
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_FAILED: Process fail, no connection is available.
//------------------------------------------------------------------------------
MI_RESULT MI_DISP_GetConnected(const MI_HANDLE hDisp, const MI_DISP_ConnectedConds_t *pstDispConds, const MI_U32 u32ConnectedNum, MI_HANDLE *phConnectedArray);

//------------------------------------------------------------------------------
/// @brief Set aspect ratio of video window.
/// @param[in] hDisp: Video window handle.
/// @param[in] eAr: Aspect ratio.
/// @param[in] eTvAr: TV aspect ratio.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_INVALID_HANDLE: Video window handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_DISP_SetAspectRatio(MI_HANDLE hDisp,MI_DISP_VidWinAr_e eAr, MI_DISP_TvAr_e eTvAr);

//------------------------------------------------------------------------------
/// @brief Get aspect ratio of video window.
/// @param[in] hDisp: The video window handle that used for getting corresponding aspect ratio.
/// @param[out] peAr: Aspect ratio.
/// @param[out] peTvAr: TV aspect ratio.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_INVALID_HANDLE: Video window handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_DISP_GetAspectRatio(MI_HANDLE hDisp, MI_DISP_VidWinAr_e *peAr, MI_DISP_TvAr_e *peTvAr);

//------------------------------------------------------------------------------
/// @brief Set input rectangle of video window.
/// @param[in] hDisp: Video window handle.
/// @param[in] pstInRect: Input rectangle of video window.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_INVALID_HANDLE: Video window handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_DISP_SetInputRect(MI_HANDLE hDisp, MI_DISP_InputRect_t *pstInRect);

//------------------------------------------------------------------------------
/// @brief Get input rectangle of video window.
/// @param[in] hDisp: The video window handle that used for getting corresponding input rectangle.
/// @param[out] pstInRect: Input rectangle of video window.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_INVALID_HANDLE: Video window handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_DISP_GetInputRect(MI_HANDLE hDisp, MI_DISP_InputRect_t *pstInRect);

//------------------------------------------------------------------------------
/// @brief Set output rectangle of video window.
/// @param[in] hDisp: Video window handle.
/// @param[in] pstOutRect: Output rectangle of video window.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_INVALID_HANDLE: Video window handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_DISP_SetOutputRect(MI_HANDLE hDisp, MI_DISP_VidWinRect_t *pstOutRect);

//------------------------------------------------------------------------------
/// @brief Get output rectangle of video window.
/// @param[in] hDisp: The video window handle that used for getting corresponding input rectangle.
/// @param[out] pstOutRect: Output rectangle of video window.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_INVALID_HANDLE: Video window handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_DISP_GetOutputRect(MI_HANDLE hDisp, MI_DISP_VidWinRect_t *pstOutRect);

//------------------------------------------------------------------------------
/// @brief Get display rectangle of video window.
/// @param[in] hDisp: Video window handle that used for getting corresponding display rectangle.
/// @param[out] pstDispRect: Display rectangle of video window.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_INVALID_HANDLE: Video window handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_DISP_GetDispRect(MI_HANDLE hDisp, MI_DISP_VidWinRect_t *pstDispRect);

//------------------------------------------------------------------------------
/// @brief Apply setting for specified video window after set the input rectangle, output rectangular and aspect ratio.
/// @param[in] hDisp: The video window handle that used for applying corresponding setting.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_INVALID_HANDLE: Video window handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_DISP_ApplySetting(MI_HANDLE hDisp);

//------------------------------------------------------------------------------
/// @brief Set alpha value of video window.
/// @param[in] hDisp: Video window handle.
/// @param[in] u32Alpha: Alpha value of video window.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_INVALID_HANDLE: Video window handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_DISP_SetAlpha(MI_HANDLE hDisp, MI_U32 u32Alpha);

//------------------------------------------------------------------------------
/// @brief Get alpha value of video window.
/// @param[in] hDisp: The video window handle that used for getting corresponding alpha value.
/// @param[out] pu32Alpha: Alpha value of video window.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_INVALID_HANDLE: Video window handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_DISP_GetAlpha(MI_HANDLE hDisp, MI_U32 *pu32Alpha);

//------------------------------------------------------------------------------
/// @brief Set zorder of video window.
/// @param[in] hDisp: Video window handle.
/// @param[in] eZOrder: ZOrder of video window.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_INVALID_HANDLE: Video window handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
//------------------------------------------------------------------------------

MI_RESULT MI_DISP_SetZOrder(MI_HANDLE hDisp, MI_DISP_VidWinZOrder_e eZOrder);

//------------------------------------------------------------------------------
/// @brief Get layer index of video zorder (between video & OSD).
/// @param[in] hDisp: The video window handle that used for getting corresponding zorder.
/// @param[out] pu32ZOrder: ZOrder of video window.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_INVALID_HANDLE: Video window handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_DISP_GetZOrder(MI_HANDLE hDisp, MI_U32 *pu32ZOrder);

//------------------------------------------------------------------------------
/// @brief Set background color of video window.
/// @param[in] hDisp: Video window handle.
/// @param[in] pstBgColor: Background color of video window.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_INVALID_HANDLE: Video window handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_DISP_SetBgColor(MI_HANDLE hDisp, MI_DISP_VidWinBgColor_t *pstBgColor);

//------------------------------------------------------------------------------
/// @brief Get background color of video window.
/// @param[in] hDisp: The video window handle that used for getting corresponding background color.
/// @param[out] pstBgColor: Background color of video window.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_INVALID_HANDLE: Video window handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_DISP_GetBgColor(MI_HANDLE hDisp, MI_DISP_VidWinBgColor_t *pstBgColor);

//------------------------------------------------------------------------------
/// @brief Set mute of video window.
/// @param[in] hDisp: Video window handle.
/// @param[in] u32MuteFlag: Mute flag of video window.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_INVALID_HANDLE: Video window handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_DISP_SetMute(MI_HANDLE hDisp,  MI_U32 u32MuteFlag);

//------------------------------------------------------------------------------
/// @brief Set unmute of video window.
/// @param[in] hDisp: Video window handle.
/// @param[in] u32UnMuteFlag: Unmute flag of video window.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_INVALID_HANDLE: Video window handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_DISP_SetUnMute(MI_HANDLE hDisp,  MI_U32 u32UnMuteFlag);

//------------------------------------------------------------------------------
/// @brief Get mute status of specified video window.
/// @param[in] hDisp: Video window handle that used for getting corresponding mute status.
/// @param[in] eMuteMode: Mute mode of specified video window.
/// @param[out] pbMute: Mute status of specified video window.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_INVALID_HANDLE: Video window handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_DISP_GetMuteStatus(MI_HANDLE hDisp, MI_U32 u32MuteFlag, MI_BOOL *pbMute);

//------------------------------------------------------------------------------
/// @brief Set TV system.
/// @param[in] hDispController: Display global controller handle
/// @param[out] eTvSystem: The enum of TV system.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_DISP_SetTvSystem(MI_HANDLE hDispController, MI_DISP_TvSystem_e eTvSystem);

//------------------------------------------------------------------------------
/// @brief Get TV sytem.
/// @param[in] hDispController: Display global controller handle
/// @param[out] peTvSystem: The enum of TV system.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_DISP_GetTvSystem(MI_HANDLE hDispController, MI_DISP_TvSystem_e *peTvSystem);

//------------------------------------------------------------------------------
/// @brief Set output timing.
/// @param[in] hDispController: Display global controller handle
/// @param[in] eDispTiming: The enum of output timing.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_DISP_SetOutputTiming(MI_HANDLE hDispController, MI_DISP_Timing_e eDispTiming);

//------------------------------------------------------------------------------
/// @brief Get output timing.
/// @param[in] hDispController: Display global controller handle
/// @param[out] peDispTiming: The enum of output timing.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_DISP_GetOutputTiming(MI_HANDLE hDispController, MI_DISP_Timing_e *peDispTiming);

//------------------------------------------------------------------------------
/// @brief Set DISP debug level.
/// @param[in] u32DebugLevel: Debug level.
/// @return MI_OK: Set debug level success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_DISP_SetDebugLevel(MI_DBG_LEVEL u32DebugLevel);

//------------------------------------------------------------------------------
/// @brief Set DISP debug info.
/// @param[in] eDebugInfo: Debug info.
/// @return MI_OK: Set debug info success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
//------------------------------------------------------------------------------

MI_RESULT MI_DISP_SetDebugInfo(MI_DISP_DbgInfoType_e eDebugInfo);

//------------------------------------------------------------------------------
/// @brief Get DISP debug Info.
/// @param[in] eDebugInfo: Debug Info.
/// @return MI_OK: Get debug info success.
//------------------------------------------------------------------------------
MI_RESULT MI_DISP_GetDebugInfo(MI_DISP_DbgInfoType_e *peDebugInfo);

//------------------------------------------------------------------------------
/// @brief Set DISP information of the specified attribute.
/// @param[in]  hDisp:  set attr of the specified window.
///                       Set hVidWin to MI_HANDLE_NULL if not necessary for the specified attr command
/// @param[in]  eAttrType: the attribute described in enum type MI_DISP_ParamType_e.
/// @param[in]  pAttrParams: Pointer to struct to set the information accroding to eAttrType
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_DISP_SetAttr(MI_HANDLE hDisp, MI_DISP_AttrType_e eAttrType, const void *pAttrParams);

//------------------------------------------------------------------------------
/// @brief Get DISP information of the specified attribute.
/// @param[in]  hDisp:  get attr of the specified window.
///                       Set hVidWin to MI_HANDLE_NULL if not necessary for the specified attr command
/// @param[in]  eAttrType: the attribute described in enum type MI_DISP_ParamType_e.
/// @param[in]  pInputParams: input params,set NULL if not necessary.
/// @param[in]  pOutputParams: Pointer to struct to retrieve the information accroding to eAttrType
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_DISP_GetAttr(MI_HANDLE hDisp, MI_DISP_AttrType_e eAttrType,const void *pInputParams,void * pOutputParams);

//------------------------------------------------------------------------------
/// @brief Enable window.
/// @param[in]  hDisp video window
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_DISP_EnableWindow(MI_HANDLE hDisp);

//------------------------------------------------------------------------------
/// @brief Disable window.
/// @param[in]  hDisp video window
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_DISP_DisableWindow(MI_HANDLE hDisp);

//------------------------------------------------------------------------------
/// @brief Get window Enable/Disable status
/// @param[in]  hDisp video window
/// @param[out] pbEnable: window is enable or disable.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_DISP_GetWindowEnable(MI_HANDLE hDisp, MI_BOOL *pbEnable);

//------------------------------------------------------------------------------
/// @brief Set DISP information of the specified attribute.
/// @param[in]  hDispController: Disp controller handle.
/// @param[in]  eControlAttrType: the attribute described in enum type MI_DISP_ControlAttrType_e.
/// @param[in]  pAttrParams : Pointer to struct to set the information accroding to eControlParamType
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_DISP_SetControlAttr(MI_HANDLE hDispController, MI_DISP_ControlAttrType_e eControlAttrType ,const void *pAttrParams );

//------------------------------------------------------------------------------
/// @brief Get DISP information of the specified attribute.
/// @param[in]  hDispController: Disp controller handle.
/// @param[in]  eControlAttrType: the attribute described in enum type MI_DISP_ControlAttrType_e.
/// @param[in]  pInputParams: input params,set NULL if not necessary.
/// @param[in]  pOutputParams: Pointer to struct to get the information accroding to eControlParamType
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_DISP_GetControlAttr(MI_HANDLE hDispController, MI_DISP_ControlAttrType_e eControlAttrType, const void *pInputParams,void *pOutputParams);

//------------------------------------------------------------------------------
/// @brief Set Picture releated status.
/// @param[in]  hDisp: video window
/// @param[in]  eParamsType: picture mode
/// @param[in]  pParams: params releated of picture mode
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_DISP_SetPictureParam(MI_HANDLE hDisp, MI_DISP_PictureParamsType_e eParamsType,  const void *pParams);

//------------------------------------------------------------------------------
/// @brief Get Picture releated status.
/// @param[in]  hDisp: video window
/// @param[in]  eParamsType: picture mode
/// @param[in]  pInputParams: input params,set NULL if not necessary.
/// @param[out]  pOutputParams: params releated of picture mode
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_DISP_GetPictureParam(MI_HANDLE hDisp, MI_DISP_PictureParamsType_e eParamsType,const void *pInputParams, void *pOutputParams);

//------------------------------------------------------------------------------
/// @brief Flip Frame info
/// @param[in]  hDisp: video window
/// @param[in]  pstFrameInfo: Frame Info
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_DISP_Flip(MI_HANDLE hVidWin, MI_DISP_FrameInfo_t *pstFrameInfo);

//------------------------------------------------------------------------------
/// @brief Register callback
/// @param[in]  hDisp: video window
/// @param[in]  pstInputParams: Callback input parameters.
/// @param[out]  pstOutputParams: Callback output parameters.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_DISP_RegisterCallback( MI_HANDLE hDisp, const MI_DISP_CallbackInputParams_t *pstInputParams, MI_DISP_CallbackOutputParams_t *pstOutputParams);

//------------------------------------------------------------------------------
/// @brief Unregister callback
/// @param[in]  hDisp: video window
/// @param[in]  pstInputParams: Callback input parameters.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_DISP_UnRegisterCallback( MI_HANDLE hDisp, const MI_DISP_CallbackInputParams_t *pstInputParams);

//------------------------------------------------------------------------------
/// @brief disp output window will be translated by UI dimension information.(optional)
///        default is output timing.
/// @param[in]  hDispController: disp controller handle.
/// @param[in]  bEnable: enable or disable this feature.
/// @param[in]  pstDimensionInfo:UI dimension information.
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_DISP_SetUiDimension( MI_HANDLE hDispController,const MI_BOOL bEnable, const MI_DISP_VidWinRect_t *pstDimensionInfo );

#ifdef __cplusplus
}
#endif

#endif///_MI_DMX_H_
