/*------------------------------------------------------------------------------
 * MediaTek Inc. (C) 2018. All rights reserved.
 *
 * Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 *----------------------------------------------------------------------------*/
//-------------------------------------------------------------------------------------------------
//  GetXxx/SetXxx only
//-------------------------------------------------------------------------------------------------

#ifndef _MI_SMC_H_
#define _MI_SMC_H_

#ifdef __cplusplus
extern "C" {
#endif

//-------------------------------------------------------------------------------------------------
//  Defines
//-------------------------------------------------------------------------------------------------
#define MI_SMC_ATR_LEN_MAX                                 (33)/// < Maximum ATR length stored in MI_SMC_Atr_t

//-------------------------------------------------------------------------------------------------
//  Structures
//-------------------------------------------------------------------------------------------------
typedef enum
{
    E_MI_SMC_VCC_ACTIVE_LOW = 0,                           /// < VCC acitve low
    E_MI_SMC_VCC_ACTIVE_HIGH,                              /// < VCC acitve higt
    E_MI_SMC_VCC_8024_CTRL,                                /// < VCC contryled by 8024
    E_MI_SMC_VCC_ONCHIP_8024_CTRL,                         /// < VCC contryled by On chip 8024
    E_MI_SMC_VCC_MAX
} MI_SMC_VccMode_e;

typedef enum
{
    E_MI_SMC_STANDARD_ISO = 0,                             /// < ISO 7816 standard
    E_MI_SMC_STANDARD_IRDETO,                              /// < Irdeto CA
    E_MI_SMC_STANDARD_TF,                                  /// < TF CA
    E_MI_SMC_STANDARD_VMX,                                 /// < VMX CA
    E_MI_SMC_STANDARD_DVN,                                 /// < DVN CA
    E_MI_SMC_STANDARD_OVT,                                 /// < OVT CA

    E_MI_SMC_STANDARD_MAX
} MI_SMC_Standard_e;

typedef enum
{
    E_MI_SMC_PROTOCOL_T0 = 0,                              /// < T=0 protocol
    E_MI_SMC_PROTOCOL_T1 = 1,                              /// < T=1 protocol
    E_MI_SMC_PROTOCOL_T14 = 14,                            /// < T=14 protocol

    E_MI_SMC_PROTOCOL_MAX
} MI_SMC_Protocol_e;

typedef enum
{
    E_MI_SMC_CLOCK_3M = 0,                                 /// < Smartcard clock: 3 MHz
    E_MI_SMC_CLOCK_4P5M,                                   /// < Smartcard clock: 4.5 MHz
    E_MI_SMC_CLOCK_6M,                                     /// < Smartcard clock: 6 MHz

    E_MI_SMC_CLOCK_MAX
} MI_SMC_Clock_e;

typedef enum
{
    E_MI_SMC_EVENT_IN   = MI_BIT(0),                       /// < Callback event: Card in
    E_MI_SMC_EVENT_OUT  = MI_BIT(1),                       /// < Callback event: Card out

    E_MI_SMC_EVENT_MAX
} MI_SMC_Event_e;

typedef enum
{
    E_MI_SMC_CLASS_NONE,
    E_MI_SMC_CLASS_A_5V,                                   ///< 5V
    E_MI_SMC_CLASS_B_3P3V,                                 ///<3.3V
    E_MI_SMC_CLASS_MAX
} MI_SMC_Class_e;

typedef enum
{
    E_MI_SMC_DETECT_HIGH_ACTIVE = 0,                      /// < HIGH ACTIVE
    E_MI_SMC_DETECT_LOW_ACTIVE,                           /// < Low ACTIVE
    E_MI_SMC_DETECT_MAX,
} MI_SMC_CardDetectType_e;

typedef enum
{
    E_MI_SMC_UART_CHAR_INVALID,
    E_MI_SMC_UART_CHAR_8,                                 /// < 8 bit character
    E_MI_SMC_UART_CHAR_7,                                 /// < 7 bit character
} MI_SMC_UartChar_e;

typedef enum
{
    E_MI_SMC_UART_STOP_INVALID,
    E_MI_SMC_UART_STOP_1,                                /// < 1 stop bit
    E_MI_SMC_UART_STOP_2,                                /// < 2 stop bits
    E_MI_SMC_UART_STOP_MAX
} MI_SMC_UartStop_e;

typedef enum
{
    E_MI_SMC_UART_PARITY_NO,                     /// < No parity
    E_MI_SMC_UART_PARITY_ODD,                    /// < Parity odd
    E_MI_SMC_UART_PARITY_EVEN                    /// < Parity even
} MI_SMC_UartParity_e;


typedef MI_RESULT (*MI_SMC_EventCallback)(MI_HANDLE hSmc, MI_U32 u32Event ,void * pEventParams, void * pUserParams);

typedef struct MI_SMC_CallbackInputParams_s
{
    MI_U64 u64CallbackId;                   ///[IN]: for multi-callback, use 0 for first register or single callback.
    MI_SMC_EventCallback pfEventCallback;   ///[IN]: callback function pointer.
    MI_U32 u32EventFlags;                   ///[IN]: registered events which are bitwise by MI_SMC_Event_e.
    void * pUserParams;                    ///[IN]: for passing user-defined parameters.
} MI_SMC_CallbackInputParams_t;

typedef struct MI_SMC_Caps_s
{
    MI_U8 u8DeviceNum;                                    /// < [OUT]: Device Num
} MI_SMC_Caps_t;

typedef struct MI_SMC_InitParams_s
{
    MI_U8 u8Reserved;
} MI_SMC_InitParams_t;

typedef struct MI_SMC_ClockParams_s
{
    MI_SMC_Clock_e eClock;                                 /// < [IN]: Clock provid to smartcard
    MI_U16 u16ClockDiv;                                    /// < [IN]: Clock division
} MI_SMC_ClockParams_t;

typedef struct MI_SMC_OpenParams_s
{
    MI_U32 u32SmcId;                                      /// < [IN]: Smartcard interface ID
    MI_SMC_ClockParams_t stClk;                           /// < [IN]: Configuration for open a smartcard interface
    MI_SMC_CallbackInputParams_t stCallbackInputParams;   /// < [IN]: register callback to receive command
    MI_SMC_CardDetectType_e eCardDetectType;              /// < [IN]: TRUE: detect PIN is inverted
    MI_SMC_VccMode_e eVccMode;                            /// < [IN]: enum MI_SMC_VccMode_e to indicate a specified VCC mode in MI_SMC_OpenParams_t
    MI_SMC_Class_e  eVoltageClass;                        /// < [IN]: Indicate smart card voltage class (ClassA: 3.3V, ClassB: 5V).
} MI_SMC_OpenParams_t;

typedef struct MI_SMC_UartMode_s
{
    MI_SMC_UartChar_e eUartChar;                        /// < [IN]: Indicate uart char (CHAR_7, CHAR_8).
    MI_SMC_UartStop_e eUartStop;                        /// < [IN]: Indicate uart stop (uart stop 1, uart stop 2).
    MI_SMC_UartParity_e eUartParity;                    /// < [IN]: Indicate uart parity (parity none, parity odd, parity even).
} MI_SMC_UartMode_t;

typedef struct MI_SMC_ResetParams_s
{
    MI_BOOL bColdReset;                                    /// < [IN]: A flag to indicate: TRUE for code reset, FALSE for warm reset
    MI_U32 u32Timeout;                                     /// < [IN]: Timeout value: the unit is millisecond(ms)
    MI_SMC_UartMode_t stUartMode;                          /// < [IN]: Uart mode: UART_CHAR | UART_STOP | UART_PARITY
} MI_SMC_ResetParams_t;

typedef struct MI_SMC_Atr_s
{
    MI_U8 u8Length;                                        /// < [OUT]: The data length of answer to reset
    MI_U8 au8Data[MI_SMC_ATR_LEN_MAX];                     /// < [OUT]: An array to store ATR
} MI_SMC_Atr_t;

typedef struct MI_SMC_Pps_s
{
    MI_SMC_Protocol_e eProtocol;                           /// < [IN]: PPS parameter: to change protocol
    MI_U8 u8Di;                                            /// < [IN]: PPS parameter: to change Di
    MI_U8 u8Fi;                                            /// < [IN]: PPS parameter: to change Fi
} MI_SMC_Pps_t;


typedef struct MI_SMC_SendParams_s
{
    MI_U8 *pu8SendBuffer;                                /// < [IN]: The send data buffer
    MI_U32 u32SendLen;                                   /// < [IN]: indicate the size of pu8SendBuffer
    MI_U32 u32Timeout;                                   /// < [IN]: Timeout value: the unit is millisecond(ms)
} MI_SMC_SendParams_t;

typedef struct MI_SMC_SendOutputParams_s
{
    MI_U8 u8Reserved;                                    /// <[Out]   Reserved
} MI_SMC_SendOutputParams_t;

typedef struct MI_SMC_ReceiveParams_s
{
    MI_U8 *pu8ReceiveBuffer;                               /// < [Out]: The receive data buffer
    MI_U32 u32BufferLen;                                   /// < [IN]: The Buffer size
    MI_U32 u32Timeout;                                     /// < [IN]: Timeout value: the unit is millisecond(ms)
} MI_SMC_ReceiveParams_t;

typedef struct MI_SMC_ReceiveOutputParams_s
{
    MI_U32 u32ActualReceiveLen;                            /// < [OUT]: indicate the actual length after receive
} MI_SMC_ReceiveOutputParams_t;

typedef struct MI_SMC_TransferParams_s
{
    MI_U32 u32SendLen;                                     /// < [IN]: indicate the size of pu8SendBuffer
    MI_U8 *pu8SendBuffer;                                  /// < [IN]: The send data buffer
    MI_U8 *pu8ReceiveBuffer;                               /// < [OUT]: The receive data buffer
    MI_U32 u32ActualReceiveLen;                            /// < [OUT]: indicate the size of pu8ReceiveBuffer
} MI_SMC_TransferParams_t;

typedef struct MI_SMC_Status_s
{
    MI_U32 u32SmcId;                                       /// < [OUT]:Smartcard interface ID
    MI_SMC_Protocol_e eProtocol;                           /// < [OUT]:Protocol used currently
    MI_SMC_Standard_e eStandard;                           /// < [OUT]:Standard
    MI_BOOL bIsCardIn;                                     /// < [OUT]:A flag indicating card is in or out
    MI_BOOL bValidAtr;                                     /// < [OUT]:A flag indicating whether reset has be done correctly
} MI_SMC_Status_t;

typedef struct MI_SMC_QueryHandleParams_s
{
    MI_U32 u32SmcId;                                       /// < [IN]: Smartcard interface ID
}MI_SMC_QueryHandleParams_t;

typedef struct MI_SMC_DumpInfoParams_s
{
    MI_BOOL bAllInfo;                                     /// < [IN]: TRUE :dump all debug info
}MI_SMC_DumpInfoParams_t;


//-------------------------------------------------------------------------------------------------
//  Global Functions
//-------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------
/// @brief Get SMC module capibilities.
/// @param[out] pstSmcCap: A pointer to structure MI_SMC_Caps_t to retrieve the information of SMC capabilities
/// @return MI_OK: Process success.
//------------------------------------------------------------------------------
MI_RESULT MI_SMC_GetCaps(MI_SMC_Caps_t *pstCaps);

//------------------------------------------------------------------------------
/// @brief Init Smartcard module.
/// @param[in] pstInitParams: A pointer to structure MI_SMC_InitParams_t for initialization.
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_RESOURCES: No available resource.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_SMC_Init(const MI_SMC_InitParams_t *pstInitParams);

//------------------------------------------------------------------------------
/// @brief Finalize Smartcard module.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_SMC_DeInit(void);

//------------------------------------------------------------------------------
/// @brief Open a Smartcard handle.
/// @param[in] pstOpenParams: A pointer to structure MI_SMC_OpenParams_t for open smartcard interface.
/// @param[out] phSmc: A handle pointer to retrieve an instance of a created smartcard interface.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_RESOURCES: No available resource.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_SMC_Open(const MI_SMC_OpenParams_t *pstOpenParams, MI_HANDLE *phSmc);

//------------------------------------------------------------------------------
/// @brief Close a Smartcard handle.
/// @param[in] hSmc: An instance of a created smartcard interface.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_SMC_Close(MI_HANDLE hSmc);

//------------------------------------------------------------------------------
/// @brief Config clock paramters for smartcard.
/// @param[in] hSmc: An instance of a created smartcard interface.
/// @param[in] pstClkParams: A pointer to structure MI_SMC_ClockParams_t for following reset.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_SMC_SetClock(MI_HANDLE hSmc, const MI_SMC_ClockParams_t *pstClkParams);

//------------------------------------------------------------------------------
/// @brief Reset smartcard.
/// @param[in] hSmc: An instance of a created smartcard interface.
/// @param[in] pstResetParams: A pointer to structure MI_SMC_ResetParams_t for reset.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_SMC_Reset(MI_HANDLE hSmc, const MI_SMC_ResetParams_t *pstResetParams);

//------------------------------------------------------------------------------
/// @brief Activate smartcard.
/// @param[in] hSmc: An instance of a created smartcard interface.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_SMC_Activate(MI_HANDLE hSmc);

//------------------------------------------------------------------------------
/// @brief Deactivate smartcard.
/// @param[in] hSmc: An instance of a created smartcard interface.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_SMC_Deactivate(MI_HANDLE hSmc);

//------------------------------------------------------------------------------
/// @brief Get answer to reset.
/// @param[in] hSmc: An instance of a created smartcard interface.
/// @param[out] pstAtr: A pointer to structure MI_SMC_ATR_t for getting ATR data.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_SMC_GetAtr(MI_HANDLE hSmc, MI_SMC_Atr_t *pstAtr);

//------------------------------------------------------------------------------
/// @brief Set standard.
/// @param[in] hSmc: An instance of a created smartcard interface.
/// @param[in] eStandard: The value of smartcard standard, default is E_MI_SMC_STANDARD_ISO.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_SMC_SetStandard(MI_HANDLE hSmc, MI_SMC_Standard_e eStandard);

//------------------------------------------------------------------------------
/// @brief Do Protocol and Paramseters Selection exchange.
/// @param[in] hSmc: An instance of a created smartcard interface.
/// @param[in] pstPps: A pointer to structure MI_SMC_PPS_t for doing PPS exchange.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_SMC_SetPps(MI_HANDLE hSmc, const MI_SMC_Pps_t *pstPps);

//------------------------------------------------------------------------------
/// @brief Setting Extra Guard Time, unit is etu.
/// @param[in] hSmc: An instance of a created smartcard interface.
/// @param[in] u8GuardTime: The value of extra guard time, default is 0 etu.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_SMC_SetEgt(MI_HANDLE hSmc, MI_U8 u8GuardTime);

//------------------------------------------------------------------------------
/// @brief Do Protocol and Paramseters Selection exchange.
/// @param[in] hSmc: An instance of a created smartcard interface.
/// @param[in] u16WaitingTime: The value of waiting time, default is 9600 etu for T=0 protocol.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_SMC_SetWt(MI_HANDLE hSmc, MI_U16 u16WaitingTime);

//------------------------------------------------------------------------------
/// @brief Setting Block Guard Time for T=1 protocol, unit is etu.
/// @param[in] hSmc: An instance of a created smartcard interface.
/// @param[in] u8GuardTime: The value of block guard time, default is 22 etu.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_SMC_SetBgt(MI_HANDLE hSmc, MI_U8 u8GuardTime);

//------------------------------------------------------------------------------
/// @brief Setting Block Waiting Time for T=1 protocol, unit is etu.
/// @param[in] hSmc: An instance of a created smartcard interface.
/// @param[in] u32WaitingTime: The value of block waiting time.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_SMC_SetBwt(MI_HANDLE hSmc, MI_U32 u32WaitingTime);

//------------------------------------------------------------------------------
/// @brief Config voltage paramters for smartcard.
/// @param[in] hSmc: An instance of a created smartcard interface.
/// @param[in] eClass: The value of smartcard class, default is E_MI_SMC_CLASS_B_3P3V.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_SMC_SetClass(MI_HANDLE hSmc, MI_SMC_Class_e eClass);

//------------------------------------------------------------------------------
/// @brief Send command.
/// @param[in] hSmc: An instance of a created smartcard interface.
/// @param[in/out] pstSendParams: A pointer to structure MI_SMC_SendParams_t for sending data to card.
/// @param[out] pstOutputParams: Pointer to the send data output
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_SMC_Send(MI_HANDLE hSmc,const MI_SMC_SendParams_t *pstSendParams, MI_SMC_SendOutputParams_t *pstOutputParams);

//------------------------------------------------------------------------------
/// @brief Receive data.
/// @param[in] hSmc: An instance of a created smartcard interface.
/// @param[in/out] pstReceiveParams: A pointer to structure MI_SMC_ReceiveParams_t for receiving data from card.
/// @param[out] pstOutputParams: Pointer to the Receive data output
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_SMC_Receive(MI_HANDLE hSmc,const MI_SMC_ReceiveParams_t *pstReceiveParams, MI_SMC_ReceiveOutputParams_t *pstOutputParams);

//------------------------------------------------------------------------------
/// @brief Transfer data.
/// @param[in] hSmc: An instance of a created smartcard interface.
/// @param[in/out] pstTransferParams: A pointer to structure MI_SMC_TransferParams_t for data exchange.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_SMC_Transfer(MI_HANDLE hSmc, MI_SMC_TransferParams_t *pstTransferParams);

//------------------------------------------------------------------------------
/// @brief Get smartcard status.
/// @param[in] hSmc: An instance of a created smartcard interface.
/// @param[out] pstStatus: A pointer to structure MI_SMC_Status_t for get card status.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_SMC_GetStatus(MI_HANDLE hSmc, MI_SMC_Status_t *pstStatus);

//------------------------------------------------------------------------------
/// @brief Get a Smartcard handle by slot ID.
/// @param[in] u8SlotId: The value of smartcard slot ID, e.g. u8SlotId = 0.
/// @param[out] phSmc: A handle pointer to retrieve an instance of a created smartcard interface.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_SMC_GetHandle(const MI_SMC_QueryHandleParams_t * pstQueryParams, MI_HANDLE * phSmc);


//------------------------------------------------------------------------------
/// @brief Do Stress test(for debuging and testing).
/// @param[in] hSmc: An instance of a created smartcard interface.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_SMC_StressTest(MI_HANDLE hSmc);

//------------------------------------------------------------------------------
/// @brief Dump Smartcard Info.
/// @param[in] bAll: TRUE for print all resources, FALSE for print opned resources only.
/// @return MI_OK: Dump information success.
//------------------------------------------------------------------------------
MI_RESULT MI_SMC_DumpInfo(const MI_SMC_DumpInfoParams_t * pstDumpInfoParams);

//------------------------------------------------------------------------------
/// @brief Set Smartcard debug level.
/// @param[in] u32DebugLevel.
/// @return MI_OK: Set debug level success.
//------------------------------------------------------------------------------
MI_RESULT MI_SMC_SetDebugLevel(MI_DBG_LEVEL u32DebugLevel);


#ifdef __cplusplus
}
#endif

#endif///_MI_SMC_H_


