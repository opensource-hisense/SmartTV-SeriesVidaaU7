/*------------------------------------------------------------------------------
 * MediaTek Inc. (C) 2018. All rights reserved.
 *
 * Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 *----------------------------------------------------------------------------*/
//-------------------------------------------------------------------------------------------------
//    Use GetAttr/SetAttr only
//-------------------------------------------------------------------------------------------------

#ifndef _MI_AENC_H_
#define _MI_AENC_H_

#ifdef __cplusplus
extern "C" {
#endif

//-------------------------------------------------------------------------------------------------
//  Defines
//-------------------------------------
//-------------------------------------------------------------------------------------------------
#define MI_AENC_AAC_ENCODE_BATCH_DELAY    (15)

//------------------------------------------------------------
//
//-------------------------------------------------------------------------------------------------
//  Structures
//-------------------------------------------------------------------------------------------------

typedef enum
{
    E_MI_AENC_CALLBACK_EVENT_DATA_READY = MI_BIT(0),    ///< Batch of encoded data is ready: parameter type is a pointer to MI_AENC_DataInfo_t
    E_MI_AENC_CALLBACK_EVENT_MAX,
} MI_AENC_CallbackEvent_e;

typedef enum
{
    E_MI_AENC_CODEC_TYPE_AAC = 0,                       ///< encoder type is AAC
    E_MI_AENC_CODEC_TYPE_MP3,                           ///< encoder type is MP3
    E_MI_AENC_CODEC_TYPE_MAX,
} MI_AENC_CodecType_e;

typedef enum
{
    E_MI_AENC_SAMPLE_RATE_4000 = 0,                     ///< Sample rate 4000 HZ
    E_MI_AENC_SAMPLE_RATE_8000,                         ///< Sample rate 8000 HZ
    E_MI_AENC_SAMPLE_RATE_16000,                        ///< Sample rate 16000 HZ
    E_MI_AENC_SAMPLE_RATE_24000,                        ///< Sample rate 24000 HZ
    E_MI_AENC_SAMPLE_RATE_32000,                        ///< Sample rate 32000 HZ
    E_MI_AENC_SAMPLE_RATE_44100,                        ///< Sample rate 44000 HZ
    E_MI_AENC_SAMPLE_RATE_48000,                        ///< Sample rate 48000 HZ
    E_MI_AENC_SAMPLE_RATE_96000,                        ///< Sample rate 96000 HZ
    E_MI_AENC_SAMPLE_RATE_MAX,
} MI_AENC_SampleRate_e;

typedef enum
{
    E_MI_AENC_CHANNEL_MODE_MONO,                        ///< Encoder ouput channel mode is mono
    E_MI_AENC_CHANNEL_MODE_JOINT_STEREO,                ///< Encoder ouput channel mode is joint stereo
    E_MI_AENC_CHANNEL_MODE_MAX,
} MI_AENC_ChannelMode_e;

typedef enum
{
    E_MI_AENC_AAC_FORMAT_RAW,                           ///< AAC RAW DATA
    E_MI_AENC_AAC_FORMAT_ADTS,                          ///< AAC with ADTS Header
    E_MI_AENC_AAC_FORMAT_MAX,
} MI_AENC_AacFormat_e;

typedef enum
{
    E_MI_AENC_AAC_MPEG_2,                               ///< MPEG-2 AAC
    E_MI_AENC_AAC_MPEG_4,                               ///< MPEG-4 AAC
    E_MI_AENC_AAC_MPEG_VERSION_MAX,
} MI_AENC_AacMpegVersion_e;

typedef enum
{
    E_MI_AENC_ATTR_TYPE_ENCODE_BUF_FREE_SIZE = 0,       ///< Encode buffer free size, parameter type is a pointer to MI_U32.
    E_MI_AENC_ATTR_TYPE_MAX,
} MI_AENC_AttrType_e;

typedef struct MI_AENC_AacEncodeParams_s
{
    MI_AENC_AacMpegVersion_e eMpegVersion;              ///< MPEG-2 AAC or MPEG-4 AAC output
    MI_AENC_AacFormat_e eOutputFormat;                  ///< Header format of output data (RAW, ADTS, ...)
    MI_U32 u32OutputBitRate;                            ///< Bit rate of output data
    MI_AENC_ChannelMode_e eChannelMode;                 ///< Channel mode of output data (Mono, Joint Stereo, ...)
} MI_AENC_AacEncodeParams_t;

typedef struct MI_AENC_InitParams_s
{
    MI_U8 u8Reserved;
} MI_AENC_InitParams_t;

typedef struct MI_AENC_DataInfo_s
{
    MI_VIRT virtAddr;                                   ///< [IN] Address of data buffer.
    MI_U32  u32Bytes;                                   ///< [IN] Data buffer size.
    MI_U32  u32FrameCount;                              ///< [IN] Frame count in data buffer.
    MI_U64  u64Pts;                                     ///< [IN] u64PTS (unit: 90k Hz), MI_INVALID_PTS represent no pts info.
} MI_AENC_DataInfo_t;

typedef struct MI_AENC_PcmFormat_s
{
    MI_U8   u8Channels;                                 ///< [IN] Channels, 1(mono), 2(stereo)
    MI_U8   u8BitsPerSample;                            ///< [IN] Bits per sample, 8(bits), 16(bits)
    MI_BOOL bBigEndian;                                 ///< [IN] For LPCM, FALSE: little endian, TRUE: big endian
    MI_AENC_SampleRate_e  eSampleRate;                  ///< [IN] Sampling rate, 48000(48KHz), 44100(44.1KHz), 32000(32KHz),....
} MI_AENC_PcmFormat_t;

typedef MI_RESULT (*MI_AENC_EventCallback)(MI_HANDLE hAenc, MI_U32 u32Event, void *pEventParams, void *pUserParams);
typedef struct MI_AENC_CallbackParams_s
{
    MI_AENC_EventCallback pfEventCallback;              ///< [IN] A function pointer for event notifcation, used to notify encode data is ready
    MI_U32 u32EventFlags;                               ///< [IN] Bit-wise events defined by MI_AENC_CallbackEvent_e
    void *pUserParams;                                  ///< [IN] User parameter for the event callback function
} MI_AENC_CallbackParams_t;

typedef struct MI_AENC_OpenParams_s
{
    MI_U8 *pszName;                                    ///< [IN] Audio encoder name.
    MI_AENC_CodecType_e eEncodeType;                    ///< [IN] Encoder Codec type.
    MI_AENC_PcmFormat_t stInputPcmParam;                ///< [IN] Input Pcm format.
    MI_AENC_CallbackParams_t stCallbackParams;          ///< [IN] Parameter of callback control.
    union
    {
        MI_AENC_AacEncodeParams_t stAacEncodeParams;    ///< [IN] Extra parameter for AAC encoder.
    } attr;
} MI_AENC_OpenParams_t;

typedef struct MI_AENC_StartParams_s
{
    MI_U8 u8Reserved;
} MI_AENC_StartParams_t;

typedef struct MI_AENC_QueryHandleParams_s
{
    MI_U8 *pszName;                                    ///< [IN] Audio encoder handle with string name.
} MI_AENC_QueryHandleParams_t;

typedef struct MI_AENC_Caps_s
{
    MI_U32 u32MaxAacEncoderNum;                         ///< [OUT] Chip capability can support the number of AAC encoder.
    MI_U32 u32MaxEncoderNum;                            ///< [OUT] Chip capability can support the number of audio encoder.
    MI_U32 u32MaxMp3EncoderNum;                         ///< [OUT] Chip capability can support the number of MP3 encoder.
} MI_AENC_Caps_t;

typedef struct MI_AENC_WriteParams_s
{
    MI_AENC_DataInfo_t stDataInfo;                      ///< [IN] Data buffer information.
} MI_AENC_WriteParams_t;

typedef struct MI_AENC_WriteOutputParams_s
{
    MI_U32 u32ReturnSize;                               ///< [OUT] Successfully written size.
} MI_AENC_WriteOutputParams_t;

//-------------------------------------------------------------------------------------------------
//  Global Functions
//-------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------
/// @brief Init audio encoder module.
/// @param[in] *pstInitParams: Init parameters.
/// @return MI_OK: Init success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_AENC_Init(const MI_AENC_InitParams_t *pstInitParams);

//------------------------------------------------------------------------------
/// @brief Deinit audio encoder module.
/// @return MI_OK: Deinit success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_AENC_DeInit(void);

//------------------------------------------------------------------------------
/// @brief Open an audio encoder and obtain the handle of the audio encoder.
/// @param[in] *pstOpenParams: Open parameters of an audio encoder.
/// @param[out] *phAenc: A handle pointer to retrieve an instance of a created audio encoder interface.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_AENC_Open(const MI_AENC_OpenParams_t *pstOpenParams, MI_HANDLE *phAenc);

//------------------------------------------------------------------------------
/// @brief Close an audio encoder and release the handle of the audio encoder.
/// @param[in] hAenc: A handle of an audio encoder.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_AENC_Close(MI_HANDLE hAenc);

//------------------------------------------------------------------------------
/// @brief Start an audio encoder
/// @param[in] hAenc: A handle of an audio encoder.
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE: Invalid aenc handle.
/// @return MI_ERR_INVALID_PARAMETER: Invalid parameter.
/// @return MI_ERR_FAILED: Process failed.
//------------------------------------------------------------------------------
MI_RESULT MI_AENC_Start(MI_HANDLE hAenc, const MI_AENC_StartParams_t *pstStartParams);

//------------------------------------------------------------------------------
/// @brief Stop an audio encoder
/// @param[in] hAenc: A handle of an audio encoder.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process failed
//------------------------------------------------------------------------------
MI_RESULT MI_AENC_Stop(MI_HANDLE hAenc);

//------------------------------------------------------------------------------
/// @brief Get audio encoder capability.
/// @param[out] *pstCaps. The capabilty of audio encoder
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_AENC_GetCaps(MI_AENC_Caps_t *pstCaps);

//------------------------------------------------------------------------------
/// @brief Get the attribute of an audio encoder.
/// @param[in] hAenc: A handle of an audio encoder.
/// @param[in] eAttrType
/// @param[in] pInputParams
/// @param[out] pParam
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_AENC_GetAttr(MI_HANDLE hAenc, MI_AENC_AttrType_e eAttrType, const void *pInputParams, void *pOutputParams);

//------------------------------------------------------------------------------
/// @brief Write PCM data to an audio encoder.
/// @param[in] hAenc: A handle of an audio encoder.
/// @param[out] pstWriteParams: Write parameters of an audio encoder.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_AENC_Write(MI_HANDLE hAenc, const MI_AENC_WriteParams_t *pstWriteParams, MI_AENC_WriteOutputParams_t *pstOutputParams);

//------------------------------------------------------------------------------
/// @brief Get an audio encoder handle
/// @param[in] *pstQueryParams: pstQueryParams. The parameters of getting handle.
/// @param[out] *phAenc: Audio encoder handle which will be acquired by users.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_AENC_GetHandle(const MI_AENC_QueryHandleParams_t *pstQueryParams, MI_HANDLE *phAenc);

//------------------------------------------------------------------------------
/// @brief Set the debug level for mi_aenc module.
/// @param[in] u32DebugLevel.
/// @return MI_OK: Process success.
//------------------------------------------------------------------------------
MI_RESULT MI_AENC_SetDebugLevel(MI_DBG_LEVEL u32DebugLevel);

#ifdef __cplusplus
}
#endif

#endif ///_MI_AENC_H_
