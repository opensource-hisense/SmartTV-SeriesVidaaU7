/*------------------------------------------------------------------------------
 * MediaTek Inc. (C) 2018. All rights reserved.
 *
 * Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 *----------------------------------------------------------------------------*/
//------------------------------------------------------------------------------
// Use GetAttr/SetAttr only
//------------------------------------------------------------------------------

#ifndef _MI_CC_H_
#define _MI_CC_H_

#ifdef __cplusplus
extern "C" {
#endif


///CC attribute type
typedef enum
{
    /// cc608 attr min
    E_MI_CC_ATTR_TYPE_CC608_MIN = 0x00,
    /// Reserve for future use.Get station ID,parameter type is a pointer to MI_U8
    E_MI_CC_ATTR_TYPE_CC608_STATION_ID = E_MI_CC_ATTR_TYPE_CC608_MIN,
    /// Reserve for future use.Get program title,parameter type is a pointer to MI_U8
    E_MI_CC_ATTR_TYPE_CC608_PROGRAM_TITLE,
    /// Reserve for future use.Get network name,parameter type is a pointer to MI_U8
    E_MI_CC_ATTR_TYPE_CC608_NETWORK_NAME,
    /// Reserve for future use.Get XDS data,parameter type is a pointer to MI_U8
    E_MI_CC_ATTR_TYPE_CC608_VCHIP_DATA,
    /// Set text row number, parameter type is MI_U8, customer adjust lines that text will show through this.
    E_MI_CC_ATTR_TYPE_CC608_SELECTOR_TEXT_ROW_NUMBER,
    /// Set text x position, parameter type is MI_U8, customer adjust  text start x position through this.
    E_MI_CC_ATTR_TYPE_CC608_SELECTOR_TEXT_X_POSITION,
    /// Set text y position, parameter type is MI_U8, customer adjust  text start y position through this.
    E_MI_CC_ATTR_TYPE_CC608_SELECTOR_TEXT_Y_POSITION,
    /// cc608 attr max
    E_MI_CC_ATTR_TYPE_CC608_MAX,

    ///cc708 attr min
    E_MI_CC_ATTR_TYPE_CC708_MIN = 0x100,
    ///cc708 attr max
    E_MI_CC_ATTR_TYPE_CC708_MAX,

    ///isdb attr min
    E_MI_CC_ATTR_TYPE_ISDB_MIN = 0x200,
    ///Enable/disable gap between two lines, parameter type is MI_BOOL, It is only for ISDB CC.
    E_MI_CC_ATTR_TYPE_ISDB_SELECTOR_ENABLE_VERTICAL_SPACING = E_MI_CC_ATTR_TYPE_ISDB_MIN,
    ///isdb attr max
    E_MI_CC_ATTR_TYPE_ISDB_MAX,

    /// cc608/cc708/isdb common attr min
    E_MI_CC_ATTR_TYPE_COMMON_MIN = 0x300,
    /// Get  CC exist or not, parameter type is a pointer to MI_BOOL, customer decide to start cc or not through this.
    E_MI_CC_ATTR_TYPE_COMMON_CC_DATA_READY = E_MI_CC_ATTR_TYPE_COMMON_MIN,
    /// Set CC status, parameter type is MI_CC_Language_e
    E_MI_CC_ATTR_TYPE_COMMON_CC_LANGUAGE,
    ///cc608/cc708/isdb common attr max
    E_MI_CC_ATTR_TYPE_COMMON_MAX,
} MI_CC_AttrType_e;


///CC Source mode
typedef enum
{
    /// Disable source in
    E_MI_CC_SOURCE_MODE_NONE = 0x00,
    /// Analog CC(VBI)
    E_MI_CC_SOURCE_MODE_ANALOG,
    /// Digital video decoder
    E_MI_CC_SOURCE_MODE_DIGITAL_VIDEO,
    /// Digital isdb decoder
    E_MI_CC_SOURCE_MODE_DIGITAL_TS,
    /// source path use raw data(for MM)
    E_MI_CC_SOURCE_MODE_RAW_DATA,
    /// source mode max
    E_MI_CC_SOURCE_MODE_MAX,
} MI_CC_SourceMode_e;


/// CC selection, sync with UI
typedef enum
{
    ///Basic for ATSC/NTSC/KOREAN CC
    ///Basic CC min
    E_MI_CC_SELECT_TYPE_BASIC_MIN = 0x00,
    ///Basic CC OFF
    E_MI_CC_SELECT_TYPE_BASIC_OFF = E_MI_CC_SELECT_TYPE_BASIC_MIN,
    ///SERVICE1
    E_MI_CC_SELECT_TYPE_BASIC_SERVICE1,
    ///SERVICE2
    E_MI_CC_SELECT_TYPE_BASIC_SERVICE2,
    ///SERVICE3
    E_MI_CC_SELECT_TYPE_BASIC_SERVICE3,
    ///SERVICE4
    E_MI_CC_SELECT_TYPE_BASIC_SERVICE4,
    ///SERVICE5
    E_MI_CC_SELECT_TYPE_BASIC_SERVICE5,
    ///SERVICE6
    E_MI_CC_SELECT_TYPE_BASIC_SERVICE6,
    ///CC1
    E_MI_CC_SELECT_TYPE_BASIC_CC1,
    ///CC2
    E_MI_CC_SELECT_TYPE_BASIC_CC2,
    ///CC3
    E_MI_CC_SELECT_TYPE_BASIC_CC3,
    ///CC4
    E_MI_CC_SELECT_TYPE_BASIC_CC4,
    ///TEXT1
    E_MI_CC_SELECT_TYPE_BASIC_TEXT1,
    ///TEXT2
    E_MI_CC_SELECT_TYPE_BASIC_TEXT2,
    ///TEXT3
    E_MI_CC_SELECT_TYPE_BASIC_TEXT3,
    ///TEXT4
    E_MI_CC_SELECT_TYPE_BASIC_TEXT4,
    ///Basic cc max
    E_MI_CC_SELECT_TYPE_BASIC_MAX,

    ///ISDB for ISDBT CC
    ///ISDBTCC min
    E_MI_CC_SELECT_TYPE_ISDB_MIN = 0x100,
    ///ISDB CC OFF
    E_MI_CC_SELECT_TYPE_ISDB_OFF = E_MI_CC_SELECT_TYPE_ISDB_MIN,
    ///ISDB CC ON
    E_MI_CC_SELECT_TYPE_ISDB_ON,
    ///ISDB CC max
    E_MI_CC_SELECT_TYPE_ISDB_MAX
}MI_CC_SelectType_e;



///Language type
typedef enum
{
    E_MI_CC_LANGUAGE_NONE = 0x00,
    ///customer
    E_MI_CC_LANGUAGE_CUSTOMER,
    ///english
    E_MI_CC_LANGUAGE_ENGLISH,
    ///korea
    E_MI_CC_LANGUAGE_KOREA,
    ///max
    E_MI_CC_LANGUAGE_MAX,
} MI_CC_Language_e;

/// CC from Analog input, e.q. VBI
typedef struct MI_CC_AnalogCcParams_s
{
    MI_HANDLE hVbi;
}MI_CC_AnalogCcParams_t;

/// CC from video private data, e.q. ATSC CC
typedef struct MI_CC_DigitalVideoCcParams_s
{
    MI_HANDLE hVideo;
}MI_CC_DigitalVideoCcParams_t;

/// CC from 13818-1 TS packets, e.q. ISDB CC
typedef struct MI_CC_DigitalTsCcParams_s
{
    MI_DMX_PathParams_t stDmxPathParams;
    MI_U16 u16Pid;
} MI_CC_DigitalTsCcParams_t;

///Open function parameters
typedef struct MI_CC_OpenParams_s
{
    /// Source type
    MI_CC_SourceMode_e eSourceMode;
    union
    {
        MI_CC_AnalogCcParams_t stAnalogCcParams;
        MI_CC_DigitalVideoCcParams_t stDigitalVideoCcParams;
        MI_CC_DigitalTsCcParams_t stDigitalTsCcParams;
    };
    /// Open Analog Output or not
    MI_BOOL bEnableAnalogOutput;
}MI_CC_OpenParams_t;

/// CC init parameter
typedef struct MI_CC_InitParams_s
{
    ///Reserved
    MI_U8 u8Reserved;
} MI_CC_InitParams_t;

///CC start function params
typedef struct MI_CC_StartParams_s
{
    MI_CC_SelectType_e eSelectType;
}MI_CC_StartParams_t;

/// CC push raw data params for MM
typedef struct MI_CC_PushDataParams_s
{
    ///< [IN]: Data buffer for CC
    MI_U8   *pu8DataBuf;
    ///< [IN]: Size of data for buffer, unit: byte
    MI_U32  u32BufSize;
} MI_CC_PushDataParams_t;

/// CC push raw data output params
typedef struct MI_CC_PushDataOutputParams_s
{
    ///< [OUT]Return Size of data.Valid written data size.
    MI_U32  u32ReturnSize;
} MI_CC_PushDataOutputParams_t;

//-------------------------------------------------------------------------------------------------
//  Global Functions
//-------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------
/// @brief CC init.
/// @param[in] pstInitParams.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_CC_Init(const MI_CC_InitParams_t *pstInitParams);
//------------------------------------------------------------------------------
/// @brief CC Deinit.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_CC_DeInit(void);

//------------------------------------------------------------------------------
/// @brief CC open.
/// @param[in] pstOpenParams
/// @param[out] phCc. The handler of CC
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_CC_Open(const MI_CC_OpenParams_t *pstOpenParams, MI_HANDLE *phCc);


//------------------------------------------------------------------------------
/// @brief CC close.
/// @param[in] hCc. The handler of CC.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_CC_Close(MI_HANDLE hCc);

//------------------------------------------------------------------------------
/// @brief CC start.
/// @param[in] hCc. The handler of CC
/// @param[in] pstStartParams
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_CC_Start(MI_HANDLE hCc, const MI_CC_StartParams_t *pstStartParams);


//------------------------------------------------------------------------------
/// @brief CC start.
/// @param[in] hCc. The handler of CC..
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_CC_Stop(MI_HANDLE hCc);

//------------------------------------------------------------------------------
/// @brief Get Attribute.
/// @param[in] hCc. The handler of CC
/// @param[in] eAttrType
/// @param[in] pInputParams
/// @param[out] pOutputParams,
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process failed
//------------------------------------------------------------------------------
MI_RESULT MI_CC_GetAttr(MI_HANDLE hCc, MI_CC_AttrType_e eAttrType, const void *pInputParams, void *pOutputParams);


//------------------------------------------------------------------------------
/// @brief Set Attribute.
/// @param[in] hCc. The handler of CC
/// @param[in] eAttrType
/// @param[in] pAttrParams,
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process failed
//------------------------------------------------------------------------------
MI_RESULT MI_CC_SetAttr(MI_HANDLE hCc, MI_CC_AttrType_e eAttrType, const void *pAttrParams);

//------------------------------------------------------------------------------
/// @brief push raw data to cc for mm
/// @param[in] hCc cc handle.
/// @param[in] pstWriteParams: raw data params
/// @param[out] pstOutputParams: output params
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process failed
//------------------------------------------------------------------------------
MI_RESULT MI_CC_PushSourceData(MI_HANDLE hCc, const MI_CC_PushDataParams_t *pstPushDataParams, MI_CC_PushDataOutputParams_t *pstOutputParams);

//------------------------------------------------------------------------------
/// @brief set debug level.
/// @param[in] u32DebugLevel.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_CC_SetDebugLevel(MI_DBG_LEVEL u32DebugLevel);

#ifdef __cplusplus
}
#endif

#endif
