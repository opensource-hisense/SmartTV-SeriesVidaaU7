/*------------------------------------------------------------------------------
 * MediaTek Inc. (C) 2018. All rights reserved.
 *
 * Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 *----------------------------------------------------------------------------*/
//------------------------------------------------------------------------------
// Use GetAttr/SetAttr only
//------------------------------------------------------------------------------

#ifndef _MI_TSMUX_H_
#define _MI_TSMUX_H_

#ifdef __cplusplus
extern "C" {
#endif

//-------------------------------------------------------------------------------------------------
//  Defines
//-------------------------------------------------------------------------------------------------

//-------------------------------------------------------------------------------------------------
//  Structures
//-------------------------------------------------------------------------------------------------
typedef enum
{
    E_MI_TSMUX_EVENT_OUTPUT_STREAM_READY = MI_BIT(0),  ///< notify output stream is available, pEventParam is NULL
    E_MI_TSMUX_EVENT_OUTPUT_BUFFER_FULL = MI_BIT(1),   ///< notify output buffer is full, pEventParam is NULL

}MI_TSMUX_Event_e;

typedef enum
{
    ///< Get
    E_MI_TSMUX_ATTR_TYPE_GET_MIN = 0,
    E_MI_TSMUX_ATTR_TYPE_OUTPUT_STREAM_SIZE = E_MI_TSMUX_ATTR_TYPE_GET_MIN, ///< Size of current valid output transport stream . Parameter is a pointer to MI_U32.
                                                                            ///  no input when MI_TSMUX_GetAttr
    E_MI_TSMUX_ATTR_TYPE_GET_MAX,


    ///< Set
    E_MI_TSMUX_ATTR_TYPE_SET_MIN = 0x100,
    E_MI_TSMUX_ATTR_TYPE_INSERT_DIT = E_MI_TSMUX_ATTR_TYPE_SET_MIN,         ///< Immediately insert a DIT(Discontinuity Information Table).
                                                                            ///  Parameter is a pointer to MI_U32 to indicator the value of transition_flag.
    E_MI_TSMUX_ATTR_TYPE_SET_MAX,


    ///< Get/Set
    E_MI_TSMUX_ATTR_TYPE_GET_AND_SET_MIN = 0x200,
    E_MI_TSMUX_ATTR_TYPE_AV_INTERLEAVING_CONTROL = E_MI_TSMUX_ATTR_TYPE_GET_AND_SET_MIN,    ///< The AV interleaving control. Parameter is a pointer to struct MI_TSMUX_AvInterleavingCtrl_t.
                                                                                            ///  no input when MI_TSMUX_GetAttr
    E_MI_TSMUX_ATTR_TYPE_CBR_CONTROL,                                       ///< The constant bit rate(CBR) control. Parameter is a pointer to struct MI_TSMUX_CbrCtrl_t.
                                                                            ///  no input when MI_TSMUX_GetAttr
    E_MI_TSMUX_ATTR_TYPE_IGNORE_REMAIN_MEDIA_DATA_WHEN_STOP,                ///< TRUE for ignoring remaing data, FALSE for waiting until all data are multiplexed into TS when calling MI_TSMUX_Stop(),
                                                                            ///  no input when MI_TSMUX_GetAttr
                                                                            ///  default is FALSE. Parameter is a pointer to MI_BOOL.
    E_MI_TSMUX_ATTR_TYPE_PTS_CONTINUITY_CONTROL,    ///< Enable/Disable concatenate timer of PTS when PTS discontinuity is occured. Parameter is a pointer to struct MI_TSMUX_PtsContinuityCtrl_t
                                                    ///  no input when MI_TSMUX_GetAttr
                                                    ///  default is TRUE with threshold = 270000(3 sec)
    E_MI_TSMUX_ATTR_TYPE_DELTA_OF_FIRST_PCR,        ///< The dalta value(90KHz) to calculate the first PCR value, i.e. PCR(first) = PTS(first) - delta. Parameter is a pointer to MI_U64.
                                                    ///  no input when MI_TSMUX_GetAttr
    E_MI_TSMUX_ATTR_TYPE_GET_AND_SET_MAX,
}MI_TSMUX_AttrType_e;

typedef enum
{
    E_MI_TSMUX_PACKET_MODE_188 = 188,               ///< Multiplex packet is 188 bytes
    E_MI_TSMUX_PACKET_MODE_192 = 192,               ///< Multiplex packet is 192 bytes including 4 bytes TS timestamp
    E_MI_TSMUX_PACKET_MODE_MAX,
} MI_TSMUX_PacketMode_e;

typedef enum
{
    E_MI_TSMUX_STREAM_TYPE_NONE = 0,

    ///< video
    E_MI_TSMUX_STREAM_TYPE_VIDEO_MIN,
    E_MI_TSMUX_STREAM_TYPE_VIDEO_MPEG1 = E_MI_TSMUX_STREAM_TYPE_VIDEO_MIN,      ///< stream_type 0x01, 11172-2
    E_MI_TSMUX_STREAM_TYPE_VIDEO_MPEG2,             ///< stream_type 0x02, 13818-2
    E_MI_TSMUX_STREAM_TYPE_VIDEO_MPEG4,             ///< stream_type 0x10, 14496-2
    E_MI_TSMUX_STREAM_TYPE_VIDEO_H264,              ///< stream_type 0x1B, AVC, 14496-10
    E_MI_TSMUX_STREAM_TYPE_VIDEO_H265,              ///< stream_type 0x24, HEVC, 23008-2
    E_MI_TSMUX_STREAM_TYPE_VIDEO_AVS,               ///< stream_type 0x42, AVS, AVS+
    E_MI_TSMUX_STREAM_TYPE_VIDEO_MAX,

    ///< audio
    E_MI_TSMUX_STREAM_TYPE_AUDIO_MIN = 0x100,
    E_MI_TSMUX_STREAM_TYPE_AUDIO_MPEG1 = E_MI_TSMUX_STREAM_TYPE_AUDIO_MIN,      ///< stream_type 0x03, 11172-3
    E_MI_TSMUX_STREAM_TYPE_AUDIO_MPEG2,             ///< stream_type 0x04, 13818-3
    E_MI_TSMUX_STREAM_TYPE_AUDIO_AC3,               ///< stream_type 0x81, AC3, Dolby Digital
    E_MI_TSMUX_STREAM_TYPE_AUDIO_EAC3,              ///< stream_type 0x87, Enhanced AC3, Dolby Digital Pluse
    E_MI_TSMUX_STREAM_TYPE_AUDIO_AAC,               ///< stream_type 0x0F, 13818-7
    E_MI_TSMUX_STREAM_TYPE_AUDIO_HEAAC,             ///< stream_type 0x11, 14496-3
    E_MI_TSMUX_STREAM_TYPE_AUDIO_MAX,

    ///< private stream
    E_MI_TSMUX_STREAM_TYPE_PRIVATE_STREAM_MIN = 0x200,
    E_MI_TSMUX_STREAM_TYPE_PRIVATE_STREAM_SUBTITLE = E_MI_TSMUX_STREAM_TYPE_PRIVATE_STREAM_MIN,     ///< stream_type 0x06 DVB-subtitle
    E_MI_TSMUX_STREAM_TYPE_PRIVATE_STREAM_TELETEXT, ///< stream_type 0x06, Teletext
    E_MI_TSMUX_STREAM_TYPE_PRIVATE_STREAM_MAX,
}MI_TSMUX_StreamType_e;

typedef enum
{
    E_MI_TSMUX_MEDIA_ES = 0,                        ///< ES(Elementary Stream)
    E_MI_TSMUX_MEDIA_PES,                           ///< PES(Packetized Elementary Stream) packet
    E_MI_TSMUX_MEDIA_PSI,                           ///< TS section data, SI/PSI
    E_MI_TSMUX_MEDIA_TS_188,                        ///< TS packets with size 188
    E_MI_TSMUX_MEDIA_TS_192,                        ///< TS packets with size 192

    E_MI_TSMUX_MEDIA_MAX,
}MI_TSMUX_MediaType_e;

typedef struct MI_TSMUX_MediaSource_s
{
    MI_TSMUX_MediaType_e eMediaType;                ///< [IN]: media type, ES, PES or PSI
    MI_TSMUX_StreamType_e eStreamType;              ///< [IN]: stream_type, video, audio, subtitle,....
    MI_U16 u16Pid;                                  ///< [IN]: PID of stream in TS. Ignored if media type is E_MI_TSMUX_MEDIA_TS
    MI_U8 u8StreamId;                               ///< [IN]: stream_id of PES. Only valid if media type is E_MI_TSMUX_MEDIA_ES

}MI_TSMUX_MediaSource_t;

typedef struct MI_TSMUX_MediaData_s
{
    MI_U64 u64MediaSourceId;                        ///< [IN]: media source id, obtained from MI_TSMUX_AttachMediaSource()
    MI_U8 *pu8DataBuf;                              ///< [IN]: media data
    MI_U32 u32DataLen;                              ///< [IN]: length of media data
    MI_U64 u64Pts;                                  ///< [IN]: PTS of elementary stream, used for ES media type only. MI_INVALID_PTS for invalid PTS.

}MI_TSMUX_MediaData_t;

typedef struct MI_TSMUX_InitParams_s
{
    MI_U8 u8Reserved;                               ///< [IN]: reserved for future
} MI_TSMUX_InitParams_t;

typedef struct MI_TSMUX_OpenParams_s
{
    MI_U8 *pszName;                                 ///< [IN]: Custom defined module instance name which is a string with zero terminated.
    MI_TSMUX_PacketMode_e ePacketMode;              ///< [IN]: size of output ts packets, 188, 192,...
    MI_BOOL bPsiControl;                            ///< [IN]: boolean value to enable auto generating PAT/PMT per 100ms
    MI_BOOL bCbrControl;                            ///< [IN]: boolean value to enable CBR bit rate control, false for VBR
    MI_U8 u8Reserved[10];                           ///< [IN]: reserved for future

    MI_U16 u16TsId;                                 ///< [IN]: transport stream id. Valid only if bPsiControl is TRUE.
    MI_U16 u16ProgNum;                              ///< [IN]: program number for service. Valid only if bPsiControl is TRUE.
    MI_U16 u16PmtPid;                               ///< [IN]: PID of PMT. Valid only if bPsiControl is TRUE.
    MI_U16 u16PcrPid;                               ///< [IN]: PID of PCR. Valid only if bPsiControl is TRUE.

    MI_U32 u32CbrBitRate;                           ///< [IN]: bitrate for constant bit rate control. Valid only if bCbrControl is TRUE.
    MI_U8 *pu8OutputBuf;                            ///< [IN]: virtual address of TSMUX's output buffer
    MI_U32 u32OutputBufSize;                        ///< [IN]: size of TSMUX's output buffer

} MI_TSMUX_OpenParams_t;

typedef struct MI_TSMUX_CbrCtrl_s
{
    MI_BOOL bEnable;                                ///< [IN]: boolean value to enable/disable CBR control when MI_TSMUX_SetAttr, [OUT] when MI_TSMUX_GetAttr
    MI_U32 u32BitRate;                              ///< [IN]: bits per second, the bitrate for constant bit rate control when MI_TSMUX_SetAttr, [OUT] when MI_TSMUX_GetAttr
}MI_TSMUX_CbrCtrl_t;

typedef struct MI_TSMUX_AvInterleavingCtrl_s
{
    MI_BOOL bEnable;                                ///< [IN]: boolean value to enable/disable AV interleaving control when MI_TSMUX_SetAttr, [OUT] when MI_TSMUX_GetAttr
    MI_U32 u32LeavingTimeInMs;                      ///< [IN]: the maximum interleaving time in ms unit when MI_TSMUX_SetAttr, [OUT] when MI_TSMUX_GetAttr
}MI_TSMUX_AvInterleavingCtrl_t;

typedef MI_RESULT (*MI_TSMUX_EventCallback)(MI_HANDLE hTsmux, MI_U32 u32Event, void *pEventParams, void *pUserParams);
typedef struct MI_TSMUX_CallbackInputParams_s
{
    MI_U64 u64CallbackId;                           ///[IN]: Use 0 for first register, other valid value(returned by MI_TSMUX_CallbackOutputParams_t) for update callback event.
    MI_TSMUX_EventCallback pfEventCallback;         ///[IN]: Event callback function pointer.
    MI_U32 u32EventFlags;                           ///[IN]: Registered events MI_TSMUX_Event_e which are bitwise OR operation.
    void *pUserParams;                              ///[IN]: For passing user-defined parameters.
} MI_TSMUX_CallbackInputParams_t;

typedef struct MI_TSMUX_CallbackOutputParams_s
{
    MI_U64 u64CallbackId;                           ///[OUT]: the returned ID for update or unregister callback.
} MI_TSMUX_CallbackOutputParams_t;

typedef struct MI_TSMUX_PtsContinuityCtrl_s
{
    MI_BOOL bEnable;                                ///< [IN]: Boolean value to enable/disable concatenate discontinuity control for PCR/PTS when MI_TSMUX_SetAttr, [OUT] when MI_TSMUX_GetAttr
    MI_U64 u64VideoPtsThreshold;                    ///< [IN]: 90KHz PTS threshold for determining video continuity, set 0 to use default, set MI_INVALID_PTS for not checking when MI_TSMUX_SetAttr, [OUT] when MI_TSMUX_GetAttr
    MI_U64 u64AudioPtsThreshold;                    ///< [IN]: 90KHz PTS threshold for determining audio continuity, set 0 to use default, set MI_INVALID_PTS for not checking when MI_TSMUX_SetAttr, [OUT] when MI_TSMUX_GetAttr

}MI_TSMUX_PtsContinuityCtrl_t;

typedef struct MI_TSMUX_StartParams_s
{
    MI_U8 u8Reserved;                               ///< [IN]: reserved
} MI_TSMUX_StartParams_t;

typedef struct MI_TSMUX_DumpInfoParams_s
{
    MI_HANDLE hTsmux;                               ///< [IN]: MI_HANDLE_NULL to all info, other valid hTsmux to dump specific instance.
}MI_TSMUX_DumpInfoParams_t;

typedef struct MI_TSMUX_QueryHandleParams_s
{
    MI_U8 *pszName;                                 ///[IN]: tsmux handle with string name.
}MI_TSMUX_QueryHandleParams_t;

//-------------------------------------------------------------------------------------------------
//  Global Functions
//-------------------------------------------------------------------------------------------------

//------------------------------------------------------------------------------
/// @brief Initialize the MUX module.
/// @param[in] pstInitParams: A pointer to structure MI_TSMUX_InitParams_t for initialize MI_TSMUX module.
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_FAILED: Process fail.
/// @note Please call this API before operating any other MI_TSMUX interfaces
//------------------------------------------------------------------------------
MI_RESULT MI_TSMUX_Init(const MI_TSMUX_InitParams_t *pstInitParams);

//------------------------------------------------------------------------------
/// @brief Uninitialize the MUX module, release internal resource.
/// @param[in] None
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_FAILED: Process fail.
/// @note Please call this API if the application doesn't need to use MI_TSMUX module anymore.
//------------------------------------------------------------------------------
MI_RESULT MI_TSMUX_DeInit(void);

//------------------------------------------------------------------------------
/// @brief Open a MUX controller
/// @param[in] pstOpencParams: A pointer to structure MI_TSMUX_OpenParams_t for opening a MUX controller
/// @param[out] phTsmux: A pointer to retrieve a handle of a MUX control
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_TSMUX_Open(const MI_TSMUX_OpenParams_t *pstOpenParams, MI_HANDLE *phTsmux);

//------------------------------------------------------------------------------
/// @brief Close a MUX controller.
/// @param[in] hTsmux: A handle of a created MUX controller
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_TSMUX_Close(MI_HANDLE hTsmux);

//------------------------------------------------------------------------------
/// @brief Start to run a MUX controller
/// @param[in] hTsmux: A handle of a created MUX controller
/// @param[in] pstStartParams: Pointer to structure MI_TSMUX_StartParams_t.
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_TSMUX_Start(MI_HANDLE hTsmux, const MI_TSMUX_StartParams_t * pstStartParams);

//------------------------------------------------------------------------------
/// @brief Stop the MUX controller
/// @param[in] hTsmux: A handle of a created MUX controller
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_TSMUX_Stop(MI_HANDLE hTsmux);

//------------------------------------------------------------------------------
/// @brief Attach a media source for  the MUX controller
/// @param[in] hTsmux: A handle of a created MUX controller
/// @param[in] pstMediaSource: Pointer to struct MI_TSMUX_MediaSource_t to describe the format of a media source to be added-in.
/// @param[out] pu64MediaSourceId: Pointer to MI_U64 to retrieve the source id of the specified media source
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_TSMUX_AttachMediaSource(MI_HANDLE hTsmux, MI_TSMUX_MediaSource_t *pstMediaSource, MI_U64 *pu64MediaSourceId);

//------------------------------------------------------------------------------
/// @brief Detach a media source for  the MUX controller
/// @param[in] hTsmux: A handle of a created MUX controller
/// @param[in] u64MediaSourceId: source id of a specified media source to be removed out.
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_TSMUX_DetachMediaSource(MI_HANDLE hTsmux, MI_U64 u64MediaSourceId);

//------------------------------------------------------------------------------
/// @brief Push media data to the MUX controller
/// @param[in] hTsmux: A handle of a created MUX controller
/// @param[in] pstMediaData: pointer to struct MI_TSMUX_MediaData_t to push into MUX
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_BUSY: Process is busy to multiplex this media data.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_TSMUX_PushMediaData(MI_HANDLE hTsmux, MI_TSMUX_MediaData_t *pstMediaData);

//------------------------------------------------------------------------------
/// @brief Copy output TS stream from a MUX controller
/// @param[in] hTsmux: A handle of a created MUX controller
/// @param[in] pu8Buf: Buffer address for copying output TS stream
/// @param[in] u32BufSize: Size of buffer for copying output TS stream
/// @param[out] *pu32CopiedBufSize: Actual copied size of multiplexed TS stream
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_BUSY: Process is busy to multiplex this media data.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_TSMUX_CopyOutputStream(MI_HANDLE hTsmux, MI_U8 *pu8Buf, MI_U32 u32BufSize, MI_U32 *pu32CopiedBufSize);

//------------------------------------------------------------------------------
/// @brief Set the attribute/information of a created MUX instance.
/// @param[in] hTsmux: A Handle of a created MUX instance.
/// @param[in] eAttrType: The parameter type for setting attribute.
/// @param[in] pAttrParams: A pointer to to set attribute corresponding to the eAttrType. The prototype of pAttrParams plz see the description of enum MI_TSMUX_AttrType_e
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_SUPPORT: eParamType is not supported.
/// @return MI_ERR_INVALID_HANDLE: hanlde is invalid.
/// @return MI_ERR_INVALID_PARAMETER: parameters is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_TSMUX_SetAttr(MI_HANDLE hTsmux, MI_TSMUX_AttrType_e eAttrType, const void * pAttrParams);

//------------------------------------------------------------------------------
/// @brief Get the attribute/information of a created MUX instance.
/// @param[in] hTsmux: A Handle of a created MUX instance.
/// @param[in] eAttrType: The parameter type for setting attribute.
/// @param[in] pInputParams: A pointer to to pass input parameters corresponding to the eAttrType. The prototype of pInputParams plz see the description of enum MI_TSMUX_AttrType_e
/// @param[out] pOutputParams: A pointer to to get attribute corresponding to the eAttrType. The prototype of pOutputParams plz see the description of enum MI_TSMUX_AttrType_e
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_SUPPORT: eParamType is not supported.
/// @return MI_ERR_INVALID_HANDLE: hanlde is invalid.
/// @return MI_ERR_INVALID_PARAMETER: parameters is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_TSMUX_GetAttr(MI_HANDLE hTsmux, MI_TSMUX_AttrType_e eAttrType, const void * pInputParams, void * pOutputParams);

//------------------------------------------------------------------------------
/// @brief Register the callback function for receiving the events of TSMUX related.
/// @param[in] hTsmux: A Handle of a created TSMUX instance.
/// @param[in] pstInputParams: A pointer to structure MI_TSMUX_CallbackInputParams_t for events registered.
/// @param[out] pstOutputParams: A pointer to structure MI_TSMUX_CallbackOutputParams_t.
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE: hanlde is invalid.
/// @return MI_ERR_INVALID_PARAMETER: parameters is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_TSMUX_RegisterCallback(MI_HANDLE hTsmux, const MI_TSMUX_CallbackInputParams_t *pstInputParams, MI_TSMUX_CallbackOutputParams_t *pstOutputParams);

//------------------------------------------------------------------------------
/// @brief UnRegister the callback function for receiving the events of TSMUX related.
/// @param[in] hTsmux: A Handle of a created TSMUX instance.
/// @param[in] pstInputParams: A pointer to structure MI_TSMUX_CallbackInputParams_t for events registered.
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE: hanlde is invalid.
/// @return MI_ERR_INVALID_PARAMETER: parameters is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_TSMUX_UnRegisterCallback(MI_HANDLE hTsmux, const MI_TSMUX_CallbackInputParams_t *pstInputParams);

//------------------------------------------------------------------------------
/// @brief Set MUX debug level.
/// @param[in] u32DebugLevel: Debug level.
/// @return MI_OK: Set debug level success.
//------------------------------------------------------------------------------
MI_RESULT MI_TSMUX_SetDebugLevel(MI_DBG_LEVEL  u32DebugLevel);

//------------------------------------------------------------------------------
/// @brief Dump TSMUX Info.
/// @param[in] pstDumpInfoParams: A pointer to structure MI_TSMUX_DumpInfoParams_t.
/// @return MI_OK: Dump information success.
//------------------------------------------------------------------------------
MI_RESULT MI_TSMUX_DumpInfo(const MI_TSMUX_DumpInfoParams_t *pstDumpInfoParams);

//------------------------------------------------------------------------------
/// @brief get Tsmux handle.
/// @param[in]  pstQueryParams: Query parameters
/// @param[out] *phTsmux: tsmux handler
/// @return MI_OK: Get tsmux handle success.
/// @return MI_ERR_FAILED: Process fail
/// @return MI_ERR_INVALID_PARAMETER: parameter null
//------------------------------------------------------------------------------
MI_RESULT MI_TSMUX_GetHandle(const MI_TSMUX_QueryHandleParams_t *pstQueryParams, MI_HANDLE *phTsmux);

#ifdef __cplusplus
}
#endif

#endif///_MI_TSMUX_H_

