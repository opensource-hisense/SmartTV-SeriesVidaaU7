/*------------------------------------------------------------------------------
 * MediaTek Inc. (C) 2018. All rights reserved.
 *
 * Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 *----------------------------------------------------------------------------*/

#ifndef _MI_PM_H_
#define _MI_PM_H_

#ifdef __cplusplus
extern "C" {
#endif

//-------------------------------------------------------------------------------------------------
//  Defines
//-------------------------------------------------------------------------------------------------
#define MI_PM_SOURCE_DISABLE              (0xFF)

#define MI_PM_MAX_IR_SUP                  (5)
#define MI_PM_MAX_BUF_WAKE_IR_KEY         (6)

#define MI_PM_MAX_BUF_WAKE_IR             (32) //Both IR and Keypad share this pool
#define MI_PM_MAX_BUF_WAKE_IR2            (16) //Only 2nd IR share this pool
#define MI_PM_MAX_BUF_WAKE_MAC_ADDRESS    (6)  //For Mac address
#define MI_PM_MAX_PATH_LENGTH             (64) //Max path length for pm bin file
#define MI_PM_MAX_LED_STATE_CNT           (2)  //LED State cnt

// wake on cast
#define MI_PM_MAX_BUF_WAKE_WOC_MAC_ADDRESS (6)
#define MI_PM_MAX_BUF_WAKE_WOC_IP_ADDRESS  (4)
#define MI_PM_MAX_BUF_WAKE_WOC_PORT        (2)

//-------------------------------------------------------------------------------------------------
//  Structures
//-------------------------------------------------------------------------------------------------
typedef enum
{
    E_MI_PM_RTC_MODE_STANDBY = 0,           //rtc wakeup powerdown with standby mode
    E_MI_PM_RTC_MODE_FAST_STANDBY,          //rtc wakeup powerdown with faststandby mode
} MI_PM_RtcMode_e;

typedef enum
{
    E_MI_PM_RUNNING_MODE_SRAM,             //PM51 run on sram
    E_MI_PM_RUNNING_MODE_SERIAL_FLASH,      //PM51 run spi flash
    E_MI_PM_RUNNING_MODE_MAX,
}MI_PM_RunningMode_e;

typedef enum
{
    E_MI_PM_WAKEUP_SOURCE_NONE        = 0x00,
    E_MI_PM_WAKEUP_SOURCE_USB         = 0x10,
    E_MI_PM_WAKEUP_SOURCE_IR          = 0x01,
    E_MI_PM_WAKEUP_SOURCE_DVI         = 0x02,
    E_MI_PM_WAKEUP_SOURCE_DVI2        = 0x03,
    E_MI_PM_WAKEUP_SOURCE_CEC         = 0x04,
    E_MI_PM_WAKEUP_SOURCE_CEC_PORT1   = 0x14,
    E_MI_PM_WAKEUP_SOURCE_CEC_PORT2   = 0x24,
    E_MI_PM_WAKEUP_SOURCE_CEC_PORT3   = 0x34,
    E_MI_PM_WAKEUP_SOURCE_SAR         = 0x05,
    E_MI_PM_WAKEUP_SOURCE_ESYNC       = 0x06,
    E_MI_PM_WAKEUP_SOURCE_SYNC        = 0x07,
    E_MI_PM_WAKEUP_SOURCE_RTC         = 0x08,
    E_MI_PM_WAKEUP_SOURCE_RTC2        = 0x09,
    E_MI_PM_WAKEUP_SOURCE_AVLINK      = 0x0A,
    E_MI_PM_WAKEUP_SOURCE_VOICE       = 0x1A,
    E_MI_PM_WAKEUP_SOURCE_UART        = 0x0B,
    E_MI_PM_WAKEUP_SOURCE_GPIO        = 0x0C,
    E_MI_PM_WAKEUP_SOURCE_GPIO_WOWLAN = 0x1C, //wake on wifi
    E_MI_PM_WAKEUP_SOURCE_GPIO_WOBT   = 0x2C, //wake on bluetooth
    E_MI_PM_WAKEUP_SOURCE_GPIO_EWBS   = 0x3C, //wake on ewbs
    E_MI_PM_WAKEUP_SOURCE_MHL         = 0x0D,
    E_MI_PM_WAKEUP_SOURCE_WOL         = 0x0E, // WOL: wake on lan
    E_MI_PM_WAKEUP_SOURCE_WOC         = 0x0F, // WOC: wake on cast
}MI_PM_WakeupSource_e;

///Define PM return to HK PowerOn Mode
typedef enum
{
    E_MI_PM_POWER_ON_MODE_INVALID = 0,
    E_MI_PM_POWER_ON_MODE_STANDBY,
    E_MI_PM_POWER_ON_MODE_SLEEP,
    E_MI_PM_POWER_ON_MODE_AC_ON = 0xFF,
}MI_PM_PowerOnMode_e;

/// Parameter type
typedef enum
{
    E_MI_PM_ATTR_TYPE_GET_MIN = 0,
    //Get wakeup source from standby, parameter type is a pointer to MI_PM_WakeupSource_e
    E_MI_PM_ATTR_TYPE_GET_WAKEUP_SOURCE = E_MI_PM_ATTR_TYPE_GET_MIN,
    //Get wakeup key from standby, parameter type is a pointer to MI_U8
    E_MI_PM_ATTR_TYPE_GET_WAKEUP_KEY,
    //Get power on mode from standby,parameter type is a pointer to MI_PM_PowerOnMode_e
    E_MI_PM_ATTR_TYPE_GET_POWER_ON_MODE,
    //Get pm WakeConfig,parameter type is a pointer to MI_PM_WakeConfig_t
    E_MI_PM_ATTR_TYPE_GET_WAKEUP_CONFIG,
    E_MI_PM_ATTR_TYPE_GET_MAX,

    E_MI_PM_ATTR_TYPE_SET_MIN = 0x100,
    //Set LED mode for pm/rtpm, parameter type is a pointer to MI_PM_LedModeConfig_t
    E_MI_PM_ATTR_TYPE_SET_LED_MODE = E_MI_PM_ATTR_TYPE_SET_MIN,
    //Set pm WakeConfig,parameter type is a pointer to MI_PM_WakeConfig_t
    E_MI_PM_ATTR_TYPE_SET_WAKEUP_CONFIG,
    //Set a designated wakeup source or reset register
    E_MI_PM_ATTR_TYPE_SET_WAKEUP_SOURCE,
    E_MI_PM_ATTR_TYPE_SET_MAX,
} MI_PM_AttrType_e;

typedef enum
{
    E_MI_PM_STR_STAGE_SUSPEND = 0, // Enable kernel apm notify for google  an7.0 reference design,  suspend
    E_MI_PM_STR_STAGE_RESUME,      // Enable kernel apm notify for google an7.0 reference design, resume.
} MI_PM_StrStage_e;

typedef enum
{
    //send to PM
    E_MI_PM_TYPE_PM= 0,
    //send to RTPM
    E_MI_PM_TYPE_RTPM,
} MI_PM_PmType_e;

typedef enum
{
    //Set led on
    E_MI_PM_LED_MODE_ON = 0,
    //set led dark
    E_MI_PM_LED_MODE_OFF,
    //set led breath
    E_MI_PM_LED_MODE_BREATH,
    //set led flicker,after flicker return the previous mode
    //(E_MI_PM_LED_ON, E_MI_PM_LED_OFF, E_MI_PM_LED_BREATH)
    E_MI_PM_LED_MODE_FLICKER_ONCE,
    //set led flicker
    E_MI_PM_LED_MODE_FLICKER,
} MI_PM_LedMode_e;

typedef enum
{
    E_MI_PM_CALLBACK_EVENT_SHUTDOWN = MI_BIT(0),   ///< notify PM before shutdown event, pEventParam is NULL
    E_MI_PM_CALLBACK_EVENT_SUSPEND = MI_BIT(1),    ///< notify PM str suspend event, pEventParam is NULL
    E_MI_PM_CALLBACK_EVENT_RESUME = MI_BIT(2),     ///< notify PM str resume event, pEventParam is NULL
}MI_PM_CallbackEventType_e;

typedef enum
{
    E_MI_PM_WOC_PROTOCOL_TCP = 0x06,
    E_MI_PM_WOC_PROTOCOL_UDP = 0x11,
    E_MI_PM_WOC_PROTOCOL_RESERVED = 0xFF,
}MI_PM_WocProtocol_e;

typedef struct MI_PM_WakeWocConfigInfo_s
{
    MI_U8 u8PmWakeEnableWocDesMacFilter1    : 1;        ///[IN]:packet mac address filter1 enable
    MI_U8 u8PmWakeEnableWocIpFilter1        : 1;        ///[IN]:packet  ip address filter1 enable
    MI_U8 u8PmWakeEnableWocProtocolFilter1  : 1;        ///[IN]:packet protocol number filter1 enable
    MI_U8 u8PmWakeEnableWocPortFilter1      : 1;        ///[IN]:packet port number filter1 enable

    MI_U8 u8PmWakeEnableWocDesMacFilter2    : 1;        ///[IN]:packet mac address filter2 enable
    MI_U8 u8PmWakeEnableWocIpFilter2        : 1;        ///[IN]:packet  ip address filter2 enable
    MI_U8 u8PmWakeEnableWocProtocolFilter2  : 1;        ///[IN]:packet protocol number filter2 enable
    MI_U8 u8PmWakeEnableWocPortFilter2      : 1;        ///[IN]:packet port number filter2 enable

    MI_U8 au8PmWakeWocMacAddressFilter1[MI_PM_MAX_BUF_WAKE_WOC_MAC_ADDRESS]; ///[IN]:packet mac address filter1
    MI_U8 au8PmWakeWocMacAddressFilter2[MI_PM_MAX_BUF_WAKE_WOC_MAC_ADDRESS]; ///[IN]:packet mac address filter2
    MI_U8 au8PmWakeWocIpFilter1[MI_PM_MAX_BUF_WAKE_WOC_IP_ADDRESS];          ///[IN]:packet ip address filter1
    MI_U8 au8PmWakeWocIpFilter2[MI_PM_MAX_BUF_WAKE_WOC_IP_ADDRESS];          ///[IN]:packet ip address filter2
    MI_PM_WocProtocol_e ePmWakeWocProtocolFilter1;                           ///[IN]:packet protocol number filter1
    MI_PM_WocProtocol_e ePmWakeWocProtocolFilter2;                           ///[IN]:packet protocol number filter2
    MI_U8 au8PmWakeWocPortFilter1[MI_PM_MAX_BUF_WAKE_WOC_PORT];              ///[IN]:packet port number filter1
    MI_U8 au8PmWakeWocPortFilter2[MI_PM_MAX_BUF_WAKE_WOC_PORT];              ///[IN]:packet port number filter2
} MI_PM_WakeWocConfigInfo_t;

typedef struct MI_PM_WakeWowLanConfigInfo_s
{
    MI_U8 u8PmWakeWowLanGpioNumber;   // wifi gpio wakeup index, u8PmWakeWowLanNum = 0xFF  disable wifi wakeup
    MI_U8 u8PmWakeWOwLanGpioPolarity; // gpio edge trigger interrupts ,1 == FALLING ,0 == RISING
} MI_PM_WakeWowLanConfigInfo_t;

typedef struct MI_PM_WakeBtConfigInfo_s
{
    MI_U8 u8PmWakeBtGpioNumber;       // wifi gpio wakeup index, u8PmWakeWowLanNum = 0xFF  disable BT wakeup
    MI_U8 u8PmWakeBtGpioPolarity;     // gpio edge trigger interrupts ,1 == FALLING ,0 == RISING
} MI_PM_WakeBtConfigInfo_t;

typedef struct MI_PM_WakeEwbsConfigInfo_s
{
    MI_U8 u8PmWakeEwbsGpioNumber;       // ewbs gpio wakeup index, u8PmWakeWowLanNum = 0xFF  disable ewbs wakeup
    MI_U8 u8PmWakeEwbsGpioPolarity;     // gpio edge trigger interrupts ,1 == FALLING ,0 == RISING
} MI_PM_WakeEwbsConfigInfo_t;

typedef struct MI_PM_WakeConfig_s
{
    MI_U8 bPmWakeEnableIr         : 1;     /// For PM IR Wake-up
    MI_U8 bPmWakeEnableSar        : 1;     /// For PM SAR Wake-up
    MI_U8 bPmWakeEnableGpio0      : 1;     /// For PM GPIO First Wake-up : First GPIO wake up pin
    MI_U8 bPmWakeEnableGpio1      : 1;     /// For PM GPIO Second Wake-up : Second GPIO wake up pin
    MI_U8 bPmWakeEnableUart1      : 1;     /// For PM UART1 Wake-up
    MI_U8 bPmWakeEnableSync       : 1;     /// For PM SYNC Wake-up
    MI_U8 bPmWakeEnableEasySync   : 1;     /// For PM EasySYNC Wake-up
    MI_U8 bPmWakeEnableRtc0       : 1;     /// For PM RTC0 Wake-up

    MI_U8 bPmWakeEnableRtc1       : 1;     /// For PM RTC1 Wake-up
    MI_U8 bPmWakeEnableDvi0       : 1;     /// For PM DVI0 Wake-up
    MI_U8 bPmWakeEnableDvi2       : 1;     /// For PM DVI1 Wake-up
    MI_U8 bPmWakeEnableCec        : 1;     /// For PM CEC Wake-up
    MI_U8 bPmWakeEnableAvLink     : 1;     /// For PM AVLINK Wake-up
    MI_U8 bPmWakeEnableMhl        : 1;     /// For PM MHL Wake-up
    MI_U8 bPmWakeEnableWol        : 1;     /// For PM WOL Wake-up
    MI_U8 bPmWakeEnableCm4        : 1;     /// For PM Voice Wake-up

    MI_U8 bPmWakeEnableWoc        : 1;     /// For PM WOC Wake-up : wakeup on cast

    MI_U8 au8PmWakeIr[MI_PM_MAX_BUF_WAKE_IR];   ///For PM IR Wake-up key define
    MI_U8 au8PmWakeIr2[MI_PM_MAX_BUF_WAKE_IR2]; ///For PM IR Wake-up key define
    MI_U8 au8PmWakeMacAddress[MI_PM_MAX_BUF_WAKE_MAC_ADDRESS];///For PM WOL Wake-up Mac define

    MI_U8 u8PmWakeGpio0Num;     /// For PM GPIO First Wake-up GPIO number define
    MI_PM_WakeWocConfigInfo_t stWakeWocConfig;
    MI_PM_WakeWowLanConfigInfo_t stWakeWowLanConfig;  /// For PM wifi GPIO Wake-up
    MI_PM_WakeBtConfigInfo_t stWakeBtConfig;          /// For PM bluetooth GPIO Wake-up
    MI_PM_WakeEwbsConfigInfo_t stWakeEwbsConfig;      /// For PM ewbs GPIO Wake-up
    MI_U8 u8PmWakeUsb;
} MI_PM_WakeConfig_t;

typedef struct MI_PM_IrConfig_s
{
    MI_U8 u8IrNum;                     //supported ir number, should be less than MI_PM_MAX_IR_SUP
    MI_U8 au8IrMode[MI_PM_MAX_IR_SUP]; //0: 32bit ir, 1:48bit ir
    MI_U8 u8Reserved;
    MI_U32 au32CustomerCode[MI_PM_MAX_IR_SUP];
    MI_U16 au16WakeKeyCode[MI_PM_MAX_IR_SUP][MI_PM_MAX_BUF_WAKE_IR_KEY];
} MI_PM_IrConfig_t;

typedef struct MI_PM_BinOnRamInfo_s
{
    MI_PM_RunningMode_e ePmRunningMode;
    MI_U32 u32PmLiteSize;
    MI_U32 u32PmLoaderSize;
    MI_U8 *pu8PmLite;
    MI_U8 *pu8PmLoader;
} MI_PM_BinOnRamInfo_t;

typedef struct MI_PM_InitParams_s
{
    MI_PM_WakeConfig_t stWakeConfig;
    MI_U8 szPmBinPath[MI_PM_MAX_PATH_LENGTH];
    MI_PM_BinOnRamInfo_t stBinOnRamInfo;
    MI_PM_IrConfig_t stIrConfig;
} MI_PM_InitParams_t;

typedef struct MI_PM_OpenParams_s
{
    MI_U8 u8Reserved;           ///[IN]: reserved
} MI_PM_OpenParams_t;

typedef MI_PM_OpenParams_t MI_PM_QueryHandleParams_t;

typedef struct MI_PM_LedDarkParams_s
{
    MI_U8 u8Reserved;           ///[IN]: reserved
}MI_PM_LedDarkParams_t;

typedef struct MI_PM_LedLightParams_s
{
    MI_U8 u8LightRate; //range:0~100, light rate(0~100%) eg. 60 -> 60% light rate
}MI_PM_LedLightParams_t;

typedef struct MI_PM_LedFlinkerParams_s
{
    MI_U8 u8LightRate; //range:0~100, light rate(0~100%) eg. 60 -> 60% light rate
    MI_U8 u8Period;  //one flinker period total time (dark+light) per 100ms
    MI_U8 u8Duty; //one flinker period light time  per 100ms eg.10 -> 10*100ms = 1s
} MI_PM_LedFlinkerParams_t;

typedef struct MI_PM_LedBreathParams_s
{
    MI_U8 u8LightRate; //range:0~100, light rate(0~100%) eg. 60 -> 60% light rate
    MI_U8 u8DarkTime; //one breath period dark time per 100ms eg.10 -> 10*100ms = 1s
    MI_U8 u8DarkToLightTime; //one breath period dark->light time per 100ms
    MI_U8 u8LightTime; //one breath period light time per 100ms
    MI_U8 u8LightToDarkTime; //one breath period light->dark time per 100ms
} MI_PM_LedBreathParams_t;

typedef struct MI_PM_LedStateInfo_s
{
    MI_PM_LedMode_e eStageMode;
    union
    {
        MI_PM_LedDarkParams_t stLedDarkParams;
        MI_PM_LedLightParams_t stLedLightParams;
        MI_PM_LedFlinkerParams_t stLedFlinkerParams;
        MI_PM_LedBreathParams_t stLedBreathParams;
    };
}MI_PM_LedStateInfo_t;

typedef struct MI_PM_LedModeConfig_s
{
    MI_PM_PmType_e ePmType;
    MI_U8 u8StageSpaceTime; /// space time between two stage
    MI_PM_LedStateInfo_t astStateInfo[MI_PM_MAX_LED_STATE_CNT];
} MI_PM_LedModeConfig_t;

typedef struct MI_PM_RtcTime_s
{
    MI_U32 u32RtcSysTime;      //[in]: system time ,Secs
}MI_PM_RtcTime_t;

typedef struct MI_PM_RtcMatchTime_s
{
    MI_U32 u32RtcMatchTime;      //[in]: RTC match time ,Secs
}MI_PM_RtcMatchTime_t;

typedef MI_RESULT (*MI_PM_EventCallback)(MI_HANDLE hPm, MI_U32 u32Event, void* pEventParams, void* pUserParams);

typedef struct MI_PM_CallbackInputParams_s
{
    MI_U64 u64CallbackId;                   ///[IN]: for multi-callback, use 0 for first register or single callback.
    MI_PM_EventCallback pfEventCallback;    ///[IN]: callback function pointer.
    MI_U32 u32EventFlags;                   ///[IN]: registered events which are bitwise OR operation.
    void * pUserParams;                     ///[IN]: for passing user-defined parameters.
} MI_PM_CallbackInputParams_t;

typedef struct MI_PM_CallbackOutputParams_s
{
    MI_U64 u64CallbackId;                   ///[OUT]: the returned ID for update or unregister callback.
} MI_PM_CallbackOutputParams_t;

//-------------------------------------------------------------------------------------------------
//  Global Functions
//-------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------
/// @brief Init PM module
/// @param[in] pstInitParam: Init Param.
/// @return MI_OK: Process success
/// @return MI_ERR_INVALID_PARAMETER: parameter error.
/// @return MI_HAS_INITED: Module has inited
/// @return MI_ERR_FAILED: Process failure
//------------------------------------------------------------------------------
MI_RESULT MI_PM_Init(const MI_PM_InitParams_t* pstInitParams);

//----------------------------------------------------------------------
/// @brief Finalize PM module.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_FAILED: Process fail.
//-----------------------------------------------------------------------
MI_RESULT MI_PM_DeInit(void);

//------------------------------------------------------------------------------
/// @brief open PM handle
/// @param[in] pstOpenParams.
/// @param[out] phPm.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_PM_Open(const MI_PM_OpenParams_t* pstOpenParams, MI_HANDLE* phPm);

//------------------------------------------------------------------------------
/// @brief close pm handle
/// @param[in] hPm: pm handle
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_PM_Close(MI_HANDLE hPm);

//------------------------------------------------------------------------------
/// @brief Get Handle of the PM module.
/// @param[in]  pstQueryParams: A pointer to structure MI_PM_QueryHandleParams_t.
/// @param[out] phPm: phPm for retrieve an instance of PM interface.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: PM module Get Handle failed.
/// @return MI_ERR_INVALID_PARAMETR: Parameters is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_PM_GetHandle(const MI_PM_QueryHandleParams_t* pstQueryParams, MI_HANDLE* phPm);

//------------------------------------------------------------------------------
/// @brief Execute Normal Standby
/// @return MI_OK: Process success
/// @return MI_NOT_INITED: Module not initial
/// @return MI_ERR_FAILED: Process failure
//------------------------------------------------------------------------------
MI_RESULT MI_PM_Standby(MI_HANDLE hPm);

//------------------------------------------------------------------------------
/// @brief Execute Fast Standby
/// @return MI_OK: Process success
/// @return MI_NOT_INITED: Module not initial
/// @return MI_ERR_FAILED: Process failure
//------------------------------------------------------------------------------
MI_RESULT MI_PM_FastStandby(MI_HANDLE hPm);

//------------------------------------------------------------------------------
/// @brief Execute STR stage for an7.0
/// @param[in] hPm: PM module handle
/// @param[in] eEnterStrStage: PM str stage
/// @return MI_OK: Process success
/// @return MI_NOT_INITED: Module not initial
/// @return MI_ERR_FAILED: Process failure
//------------------------------------------------------------------------------
MI_RESULT MI_PM_SetStrStage(MI_HANDLE hPm, MI_PM_StrStage_e eEnterStrStage);

//------------------------------------------------------------------------------
/// @brief Go to standby immediately by mode selection and waked up by time
/// @param[in] hPm: PM module handle
/// @param[in] u32SleepTime: Time to sleep(in second)
/// @param[in] eMode: RTC Standby Mode
/// @return MI_OK: Process success
/// @return MI_ERR_FAILED: Process failure
/// @return MI_NOT_INITED: Module not initial
//------------------------------------------------------------------------------
MI_RESULT MI_PM_RtcWakeUp(MI_HANDLE hPm, MI_U32 u32SleepTime, MI_PM_RtcMode_e eMode);

//------------------------------------------------------------------------------
/// @brief Get system time by RTC
/// @param[in] hPm: PM module handle
/// @param[in] pu32SysTime in second
/// @return MI_OK - Process success
//------------------------------------------------------------------------------
MI_RESULT MI_PM_GetRtcTime(MI_HANDLE hPm, MI_PM_RtcTime_t *pstRtcTimeParams);

//------------------------------------------------------------------------------
/// @brief Set system time by RTC
/// @param[in] hPm: PM module handle
/// @param[in] u32secs Time in second. (365*10)+2)*24*60*60 from 1970/1/1 to 1980/1/1
/// @return MI_OK - Process success
//------------------------------------------------------------------------------
MI_RESULT MI_PM_SetRtcTime(MI_HANDLE hPm, MI_PM_RtcTime_t *pstRtcTimeParams);

//------------------------------------------------------------------------------
/// @brief Get match time by RTC
/// @param[in] pu32SysTime
/// @return MI_OK - Process success
//------------------------------------------------------------------------------
MI_RESULT MI_PM_GetRtcMatchTime(MI_HANDLE hPm, MI_PM_RtcMatchTime_t *pstRtcMatchTimeParams);

//------------------------------------------------------------------------------
/// @brief Set match time by RTC
/// @param[in] u32secs Time in second.
/// @return MI_OK - Process success
//------------------------------------------------------------------------------
MI_RESULT MI_PM_SetRtcMatchTime(MI_HANDLE hPm, MI_PM_RtcMatchTime_t *pstRtcMatchTimeParams);

//------------------------------------------------------------------------------
/// @brief Get information for PM module
/// @param[in] hPm: PM module handle
/// @param[in] eParamType: information enum type params
/// @param[in] pInputParams: input data params
/// @param[out] pOutputParams: information for user(AP) to get
/// @return MI_OK - Process success
/// @return MI_ERR_FAILED: Process failure
//------------------------------------------------------------------------------
MI_RESULT MI_PM_GetAttr(MI_HANDLE hPm, MI_PM_AttrType_e eAttrType, const void *pInputParams, void *pOutputParams);

//------------------------------------------------------------------------------
/// @brief Set information for PM module
/// @param[in] hPm: PM module handle
/// @param[in] eParamType: information enum type params
/// @param[in] pAttrParams: information for user(AP) to set
/// @return MI_OK - Process success
/// @return MI_ERR_FAILED: Process failure
//------------------------------------------------------------------------------
MI_RESULT MI_PM_SetAttr(MI_HANDLE hPm, MI_PM_AttrType_e eAttrType, const void *pAttrParams);

//------------------------------------------------------------------------------
/// @brief Register the callback function for receiving the events of PM related.
/// @param[in] hPm: A Handle of a created PM instance.
/// @param[in] pstInputParams: A pointer to structure MI_PM_CallbackInputParams_t for events registered.
/// @param[out] pstOutputParams: A pointer to structure MI_PM_CallbackOutputParams_t.
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE: hanlde is invalid.
/// @return MI_ERR_INVALID_PARAMETER: parameters is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_PM_RegisterCallback(MI_HANDLE hPm, const MI_PM_CallbackInputParams_t *pstInputParams, MI_PM_CallbackOutputParams_t *pstOutputParams);

//------------------------------------------------------------------------------
/// @brief UnRegister the callback function for receiving the events of PM related.
/// @param[in] hPm: A Handle of a created PM instance.
/// @param[in] pstInputParams: A pointer to structure MI_PM_CallbackInputParams_t for events registered.
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE: hanlde is invalid.
/// @return MI_ERR_INVALID_PARAMETER: parameters is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_PM_UnRegisterCallback(MI_HANDLE hPm, const MI_PM_CallbackInputParams_t *pstInputParams);

//------------------------------------------------------------------------------
/// @brief Set PM module debug level.
/// @param[in] eDgbLevel.
/// @return MI_OK: Set debug level success.
//------------------------------------------------------------------------------
MI_RESULT MI_PM_SetDebugLevel(MI_DBG_LEVEL u32DebugLevel);

#ifdef __cplusplus
}
#endif

#endif///_MI_PM_H_

