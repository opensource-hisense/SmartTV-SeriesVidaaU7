/*------------------------------------------------------------------------------
 * MediaTek Inc. (C) 2018. All rights reserved.
 *
 * Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 *----------------------------------------------------------------------------*/

///////////////////////////////////////////////////////////////////////////////////////////////////
/// @file   MI_Subtitle.h
/// @author MediaTek Inc.
///////////////////////////////////////////////////////////////////////////////////////////////////

#ifndef _MI_SUBTITLE_H_
#define _MI_SUBTITLE_H_

#ifdef __cplusplus
extern "C" {
#endif

/// Subtitle status
typedef enum
{
    /// SUBTITLE empty status
    E_MI_SUBTITLE_STATUS_EMPTY      = 0,
    /// SUBTITLE inited status
    E_MI_SUBTITLE_STATUS_INITED     = 1,
    /// SUBTITLE opened status
    E_MI_SUBTITLE_STATUS_OPENED     = 2,
    /// SUBTITLE running status
    E_MI_SUBTITLE_STATUS_DECODING   = 3,
    /// SBTITLE showing status
    E_MI_SUBTITLE_STATUS_SHOWING    = 4,
    /// SUBTITLE max status
    E_MI_SUBTITLE_STATUS_MAX        = 0xff,
} MI_SUBTITLE_Status_e;

/// Subtitle decoder capability.
typedef enum
{
    /// Subtitle support FHD
    E_MI_SUBTITLE_DECODE_CAPS_HD,
    /// Subtitle support SD only
    E_MI_SUBTITLE_DECODE_CAPS_SD,
} MI_SUBTITLE_DecodeCaps_e;

/// Subtitle init parameter
typedef struct MI_SUBTITLE_InitParams_s
{
    ///Reserved
    MI_U8 u8Reserved;
} MI_SUBTITLE_InitParams_t;

/// Subtitle open parameter
typedef struct MI_SUBTITLE_OpenParams_s
{
    /// Subtitle cache pool id
    MI_S32 s32CachedPoolId;
    /// Subtitle noncache pool id
    MI_S32 s32NonCachedPoolId;
    /// Subtitle decoder capability.
    MI_SUBTITLE_DecodeCaps_e eDecodeCaps;
    /// Subtitle dmx source parameters
    MI_DMX_PathParams_t stDmxPathParams;
} MI_SUBTITLE_OpenParams_t;

/// Subtitle Start parameter
typedef struct MI_SUBTITLE_StartParams_s
{
    /// show or not
    MI_BOOL bShow;
    /// Subtitle pid
    MI_U16 u16Pid;
    /// Subtitle composition page id
    MI_U16 u16CompositionPageId;
    /// Subtitle ancillary page id
    MI_U16 u16AncillaryPageId;
} MI_SUBTITLE_StartParams_t;

/// Subtitle status output parameter
typedef struct MI_SUBTITLE_Status_s
{
    /// Subtitle status
    MI_SUBTITLE_Status_e eStatus;
} MI_SUBTITLE_Status_t;
//-------------------------------------------------------------------------------------------------
//  Global Functions
//-------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------
/// @brief do subtitle init , and change subtitle status to E_MI_SUBTITLE_STATUS_INITED
/// @param[in] *pstInitParams reserved
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: init fail.
/// @return MI_HAS_INITED: already inited.
//------------------------------------------------------------------------------
MI_RESULT MI_SUBTITLE_Init(const MI_SUBTITLE_InitParams_t *pstInitParams);

//------------------------------------------------------------------------------
/// @brief do subtitle deinit , and change subtitle status to E_MI_SUBTITLE_STATUS_EMPTY
/// @param[in] none
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: deinit fail.
//------------------------------------------------------------------------------
MI_RESULT MI_SUBTITLE_DeInit(void);

//------------------------------------------------------------------------------
/// @brief Open subtitle handler, and change subtitle status to E_MI_SUBTITLE_STATUS_OPENED
/// @param[in] *pstOpenParam memory pool id (cache & noncached)
/// @param[out] *phSubtitle subtitle handler
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process failed
/// @return MI_ERR_INVALID_HANDLE: Null handle
/// @return MI_ERR_INVALID_PARAMETER: Null parameter
//------------------------------------------------------------------------------
MI_RESULT MI_SUBTITLE_Open(const MI_SUBTITLE_OpenParams_t *pstOpenParams, MI_HANDLE *phSubtitle);

//------------------------------------------------------------------------------
/// @brief Open subtitle handler, and change subtitle status to E_MI_SUBTITLE_STATUS_OPENED
/// @param[in] hSubtitle subtitle handler
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process failed
/// @return MI_ERR_INVALID_HANDLE: Null handle
/// @return MI_ERR_INVALID_PARAMETER: Null parameter
//------------------------------------------------------------------------------
MI_RESULT MI_SUBTITLE_Close(MI_HANDLE hSubtitle);

//------------------------------------------------------------------------------
/// @brief start decoding subtitle, and change subtitle status to E_MI_SUBTITLE_STATUS_DECODING
/// @param[in] hSubtitle subtitle handle.
/// @param[in] *pstStartParams pid, composition page id, ancillary page id.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process failed
//------------------------------------------------------------------------------
MI_RESULT MI_SUBTITLE_Start(MI_HANDLE hSubtitle, const MI_SUBTITLE_StartParams_t *pstStartParams);

//------------------------------------------------------------------------------
/// @brief stop & hide subtitle, and change subtitle status to E_MI_SUBTITLE_STATUS_OPENED
/// @param[in] hSubtitle subtitle handle.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process failed
//------------------------------------------------------------------------------
MI_RESULT MI_SUBTITLE_Stop(MI_HANDLE hSubtitle);

//------------------------------------------------------------------------------
/// @brief start showing subtitle, and change subtitle status to E_MI_SUBTITLE_STATUS_SHOWING
/// @param[in] hSubtitle subtitle handle.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process failed
//------------------------------------------------------------------------------
MI_RESULT MI_SUBTITLE_Show(MI_HANDLE hSubtitle);

//------------------------------------------------------------------------------
/// @brief stop showing subtitle, and change subtitle status to E_MI_SUBTITLE_STATUS_DECODING
/// @param[in] hSubtitle subtitle handle.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process failed
//------------------------------------------------------------------------------
MI_RESULT MI_SUBTITLE_Hide(MI_HANDLE hSubtitle);

//------------------------------------------------------------------------------
/// @brief get subtitle status
/// @param[in] hSubtitle subtitle handle.
/// @param[out] *pstStatusParams subtitle status.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process failed
//------------------------------------------------------------------------------
MI_RESULT MI_SUBTITLE_GetStatus(MI_HANDLE hSubtitle, MI_SUBTITLE_Status_t *pstStatusParams);

//------------------------------------------------------------------------------
/// @brief set subtitle debug level
/// @param[in] eDgbLevel debug level.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process failed
//------------------------------------------------------------------------------
MI_RESULT MI_SUBTITLE_SetDebugLevel(MI_DBG_LEVEL u32DebugLevel);
#ifdef __cplusplus
}
#endif

#endif
