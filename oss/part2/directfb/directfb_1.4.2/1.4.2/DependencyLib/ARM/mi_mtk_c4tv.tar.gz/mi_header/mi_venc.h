/*------------------------------------------------------------------------------
 * MediaTek Inc. (C) 2018. All rights reserved.
 *
 * Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 *----------------------------------------------------------------------------*/
//-------------------------------------------------------------------------------------------------
//  Use GetAttr/SetAttr only
//-------------------------------------------------------------------------------------------------
#ifndef _MI_VENC_H_
#define _MI_VENC_H_

#ifdef __cplusplus
extern "C" {
#endif

//-------------------------------------------------------------------------------------------------
//  Defines
//-------------------------------------------------------------------------------------------------

//-------------------------------------------------------------------------------------------------
//  Structures
//-------------------------------------------------------------------------------------------------
typedef enum
{
    E_MI_VENC_COLOR_FORMAT_YUYV = 0,
    E_MI_VENC_COLOR_FORMAT_YVYU,
    E_MI_VENC_COLOR_FORMAT_UYVY,
    E_MI_VENC_COLOR_FORMAT_VYUY,
    E_MI_VENC_COLOR_FORMAT_MSTTILE,                         /// < MST TILE YUV420 format
    E_MI_VENC_COLOR_FORMAT_EVDTILE,                         /// < EVD TILE YUV420 format 32x16 tiled
    E_MI_VENC_COLOR_FORMAT_MAX
} MI_VENC_ColorFormat_e;

typedef enum
{
    E_MI_VENC_CODEC_H264=MI_BIT(0),                         /// < Encode to H.264 codec

    E_MI_VENC_CODEC_MAX
} MI_VENC_CodecType_e;

typedef enum
{
    E_MI_VENC_FRAME_TYPE_I = 0,                             /// < I frame
    E_MI_VENC_FRAME_TYPE_P,                                 /// < P frame
    E_MI_VENC_FRAME_TYPE_B,                                 /// < B frame

    E_MI_VENC_FRAME_TYPE_SPS = 0xFF,                        /// < Sequence Parameter Set

} MI_VENC_FrameType_e;

typedef enum
{
    E_MI_VENC_ATTR_TYPE_AUTO_INSERT_HEADER=0,               /// < [Set] Auto insert SPS Header or not, default is enable, parameter is pointer to MI_BOOL
    E_MI_VENC_ATTR_TYPE_BITRATE,                            /// < [Set] Set output bitrate, parameter is pointer to MI_U32, unit is Kbps, 2*1024 is 2Mbps
    E_MI_VENC_ATTR_TYPE_OUTPUT_FRAME_RATE,                  /// < [Set] Set output frame rate, parameter is pointer to MI_U32, unit is value X100, 2997 is 29.97fps
    E_MI_VENC_ATTR_TYPE_INPUT_FRAME_RATE,                   /// < [Set] Set output frame rate, parameter is pointer to MI_U32, unit is value X100, 2997 is 29.97fps
    E_MI_VENC_ATTR_TYPE_COLOR_FORMAT,                       /// < [Set] Set output color format, parameter is one of MI_VENC_ColorFormat_e
    E_MI_VENC_ATTR_TYPE_REAL_TIME_ENCODE,                   ///< [Set] Avoid encoder too slow, too many frames couldn't encode immediately. if frame number in queue is large then this value it will be drop.
    E_MI_VENC_ATTR_TYPE_MAX
} MI_VENC_AttrType_e;

typedef enum
{
    E_MI_VENC_CALLBACK_EVENT_FRAME_READY = MI_BIT(0),
    E_MI_VENC_CALLBACK_EVENT_MAX
} MI_VENC_CallbackEvent_e;

// Encode profile
typedef enum
{
    E_MI_VENC_PROFILE_DEFAULT = 0,                       //default set by driver
    E_MI_VENC_PROFILE_H264_BASELINE  = 66,
    E_MI_VENC_PROFILE_H264_MAIN = 77,
    E_MI_VENC_PROFILE_MAX,
} MI_VENC_Profile_e;

// Encode level
typedef enum
{
    E_MI_VENC_LEVEL_DEFAULT = 0,                       //default set by driver
    E_MI_VENC_LEVEL_H264_1_0 = 100,
    E_MI_VENC_LEVEL_H264_1_B = 101,
    E_MI_VENC_LEVEL_H264_1_1 = 110,
    E_MI_VENC_LEVEL_H264_1_2 = 120,
    E_MI_VENC_LEVEL_H264_1_3 = 130,
    E_MI_VENC_LEVEL_H264_2_0 = 200,
    E_MI_VENC_LEVEL_H264_2_1 = 210,
    E_MI_VENC_LEVEL_H264_2_2 = 220,
    E_MI_VENC_LEVEL_H264_3_0 = 300,
    E_MI_VENC_LEVEL_H264_3_1 = 310,
    E_MI_VENC_LEVEL_H264_3_2 = 320,
    E_MI_VENC_LEVEL_H264_4_0 = 400,
    E_MI_VENC_LEVEL_H264_4_1 = 410,
    E_MI_VENC_LEVEL_MAX,
} MI_VENC_Level_e;

typedef MI_RESULT (* MI_VENC_EventCallback)(MI_HANDLE hVenc, MI_VENC_CallbackEvent_e eEvent, void *pEventParams, void *pUserParams);

typedef struct MI_VENC_CallbackParams_s
{
    MI_VENC_EventCallback pfEventCallback;                  ///[IN]: Callback function pointer to notify applicaiton event
    MI_U32 u32EventFlag;                                    ///[IN]: Event flags defined by MI_VENC_CallbackEvent_e
    void *pUserParams;                                      ///[IN]: User parameter
} MI_VENC_CallbackParams_t;

typedef struct MI_VENC_FrameInfo_s
{
    MI_U8 *pu8Data;                                         ///[OUT]: Pointer to an encoded frame data
    MI_U32 u32DataSize;                                     ///[OUT]: Encoded frame data size
    MI_U8 u8FrameType;                                      ///[OUT]: Frame type: 0: I-Frame, 1: P-Frame, 0xFF: SPS. (mapping to enum of MI_VENC_FrameType_e)
    MI_U64 u64Pts;                                          ///[OUT]: PTS of this frame, use MI_INVALID_PTS for invalid PTS
    MI_U32 u32FrameStamp;                                   ///[OUT]: Frame number stamp to Encoded frame
} MI_VENC_FrameInfo_t;

typedef struct MI_VENC_Caps_s
{
    MI_U32 u32MaxEncodeWidth;                               ///[OUT]: Max supporting encode width
    MI_U32 u32MaxEncodeHeight;                              ///[OUT]: Max supporting encode height
    MI_U32 u32MaxEncodeFrameRate;                           ///[OUT]: Max supporting encode frame rate
    MI_U32 u32SupportEncodeCodec;                           ///[OUT]: Support encode codec
    MI_U32 u32FrameAddrAlign;                               ///[OUT]: Address alignment of source frame buffer when calling MI_VENC_WriteBufferComplete()
    MI_BOOL bSupportMultiEncode;                            ///[OUT]: Support multiencode
    MI_U8 u8MaxEncodeNum;                                   ///[OUT]: The maximal number of slot which venc driver supported.
} MI_VENC_Caps_t;

typedef struct MI_VENC_InitParams_s
{
    MI_U8 u8Reserved;                                       ///[IN]: Reserved
} MI_VENC_InitParams_t;

typedef struct MI_VENC_FrameParams_s
{
    MI_U32 u32Width;                                        ///[IN]: Width of output frame
    MI_U32 u32Height;                                       ///[IN]: Height of output frame
    MI_U32 u32FrameRate;                                    ///[IN]: Output file frame rate, 30 for 30fps, 25 for 25fps,...
} MI_VENC_FrameParams_t;

typedef struct MI_VENC_GopCfg_s
{
    MI_U32 u32NumberOfPBetweenI;                            ///[IN]: Number of P frames between 2 I frames. Set 0 for using default(2 times of output frame rate). For infinite P frames plz set 0xFFFFFFFF.
} MI_VENC_GopCfg_t;

typedef struct MI_VENC_ConfigParams_s
{
    MI_VENC_ColorFormat_e eColorFormat;                     ///[IN]: Color format for DRAM input source
    MI_VENC_FrameParams_t stOutputFrame;                    ///[IN]: Frame info of output file
    MI_U32 u32OutputBitrate;                                ///[IN]: Bit rate with kbps
    MI_BOOL bEnableCabac;                                   ///[IN]: For main profile requires CABAC, disable for baseline
    MI_VENC_GopCfg_t stGopCfg;                              ///[IN]: GOP configuration
    MI_VENC_Profile_e eProfile;                             ///[IN]: Profile configuration
    MI_VENC_Level_e eLevel;                                 ///[IN]: Level configuration
} MI_VENC_ConfigParams_t;

typedef struct MI_VENC_OpenParams_s
{
    MI_U8 * pszName;                                        ///[IN]: Custom defined module instance name which is a string with zero terminated.
    MI_VENC_ConfigParams_t stConfigParams;                  ///[IN]: Config Params
    MI_VENC_CodecType_e eEncType;                           ///[IN]: Encode type
    MI_VENC_CallbackParams_t stCallbackParams;              ///[IN]: Callback parameters
    void *pUsrParams;                                       ///[IN]: User data is the parameter of callback function
} MI_VENC_OpenParams_t;

typedef struct MI_VENC_StartParams_s
{
    MI_U8 u8Reserved;                                       ///[IN]: reserved
} MI_VENC_StartParams_t;

typedef struct MI_VENC_BufInfo_s
{
    MI_U8 *pu8DataBuf;                                      ///[IN]: Data Buffer address. [OUT] in MI_VENC_QueryBuffer and MI_VENC_QueryEntireInjectBuffer
    MI_U32 u32BufSize;                                      ///[IN]: Size of data. [OUT] in MI_VENC_QueryBuffer and MI_VENC_QueryEntireInjectBuffer
    MI_BOOL bUseExtBuf;                                     ///[IN]: TRUE: using external buffer, FALSE: using internal buffer by calling MI_VENC_QueryBuffer()
    MI_BOOL bForceIFrame;                                   ///[IN]: Boolean value to set encoder to force encode this frame as I frame
    MI_U64 u64Pts;                                          ///[IN]: PTS of this frame, use MI_INVALID_PTS for invalid PTS
    MI_U32 u32FrameStamp;                                   ///[IN]: The frame number for encode
} MI_VENC_BufInfo_t;

typedef struct MI_VENC_SeqHeader_s
{
    MI_VENC_CodecType_e eEncType;                           ///[OUT]: Encode type  h264 or mpeg4
    MI_U8* pu8HeaderSps;                                    ///[OUT]: Pointer to H264 Sequence Parameter Set
    MI_U32 u32SpsLen;                                       ///[OUT]: H264 SPS size
    MI_U8* pu8HeaderPps;                                    ///[OUT]: Pointer to H264 Picture Parameter Set
    MI_U32 u32PpsLen;                                       ///[OUT]: H264 PPS size
} MI_VENC_SeqHeader_t;

typedef struct MI_VENC_DumpInfoParams_s
{
    MI_U8 u8Reserved;                                       ///[OUT]: Reserved
}MI_VENC_DumpInfoParams_t;

typedef struct MI_VENC_RealTimeEncode_s
{
    MI_BOOL bRealTimeEncode;                                /// < Open Real time encode
    MI_U32 u32FrameMax;                                     /// < The number of waiting frames
} MI_VENC_RealTimeEncode_t;

///Video Encoder Query Handle Parameters
typedef struct MI_VENC_QueryHandleParams_s
{
    MI_U8 * pszName;                                    ///[IN]: Venc handle with string name.
}MI_VENC_QueryHandleParams_t;

//-------------------------------------------------------------------------------------------------
//  Global Functions
//-------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------
/// @brief Get VENC module capibilities.
/// @param[out] pstVencCap: A pointer to structure MI_VENC_Caps_t to retrieve the information of VENC capabilities
/// @return MI_OK: Process success.
//------------------------------------------------------------------------------
MI_RESULT MI_VENC_GetCaps(MI_VENC_Caps_t *pstCaps);

//------------------------------------------------------------------------------
/// @brief Init VENC module.
/// @param[in] pstInitParam: A pointer to structure MI_VENC_InitParams_t for initialization.
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Invalid parameter.
/// @return MI_ERR_RESOURCES: Lack of resource or fail to configure VENC.
/// @return MI_ERR_NOT_SUPPORT: Chip not support VENC function.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_VENC_Init(const MI_VENC_InitParams_t *pstInitParams);

//------------------------------------------------------------------------------
/// @brief Finalize VENC module.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_VENC_DeInit(void);

//------------------------------------------------------------------------------
/// @brief Open a VENC handle.
/// @param[in] pstOpenParam: A pointer to structure MI_VENC_OpenParams_t for open VENC interface.
/// @param[out] phVenc: A handle pointer to retrieve an instance of a created VENC interface.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_RESOURCES: No available resource.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_VENC_Open(const MI_VENC_OpenParams_t *pstOpenParams, MI_HANDLE *phVenc);

//------------------------------------------------------------------------------
/// @brief Close a VENC handle.
/// @param[in] hVenc: An instance of a created VENC interface.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_VENC_Close(MI_HANDLE hVenc);

//------------------------------------------------------------------------------
/// @brief Get VENC handle.
/// @param[in] pstQueryParams Query parameters
/// @param[out] *phVenc handle
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_INVALID_PARAMETER: parameter null.
//------------------------------------------------------------------------------
MI_RESULT MI_VENC_GetHandle(const MI_VENC_QueryHandleParams_t *pstQueryParams, MI_HANDLE *phVenc);

//------------------------------------------------------------------------------
/// @brief Start video encoder.
/// @param[in] hVenc: An instance of a created VENC interface.
/// @param[in] pstStartParams: A pointer to structure MI_VENC_StartParams_t for the start VENC.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_VENC_Start(MI_HANDLE hVenc,const MI_VENC_StartParams_t *pstStartParams);

//------------------------------------------------------------------------------
/// @brief Stop video encoder.
/// @param[in] hVenc: An instance of a created VENC interface.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_VENC_Stop(MI_HANDLE hVenc);

//------------------------------------------------------------------------------
/// @brief Qurey buffer for put frame data.Using after MI_VENC_Start and get one frame size buffer.
/// @param[in] hVenc: An instance of a created VENC interface.
/// @param[out] pstBufInfo: Buffer information.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Invalid parameter.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_VENC_QueryBuffer(MI_HANDLE hVenc, MI_VENC_BufInfo_t *pstBufInfo);

//------------------------------------------------------------------------------
/// @brief Info VENC data complete.
/// @param[in] hVenc: An instance of a created VENC interface.
/// @param[in] pstBufInfo: A pointer to structure MI_VENC_BufInfo_t for buffer written.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Invalid parameter.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_VENC_WriteBufferComplete(MI_HANDLE hVenc,const MI_VENC_BufInfo_t *pstBufInfo);

//------------------------------------------------------------------------------
/// @brief Set attributes of video encoder.
/// @param[in] hVenc: An instance of a created VENC interface.
/// @param[in] eAttrType: A enum to set VENC attributes.
/// @param[in] pAttrParams  A pointer to to set attribute corresponding to the eParamType. The prototype of pParam plz see the description of enum MI_VENC_ParamType_e
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Invalid parameter.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_VENC_SetAttr(MI_HANDLE hVenc, MI_VENC_AttrType_e eAttrType, const void *pAttrParams);

//------------------------------------------------------------------------------
/// @brief Get Seqence Header Info.
/// @param[in] hVenc: An instance of a created VENC interface.
/// @param[in] pstHeader: A pointer to structure MI_VENC_SeqHeader_t for getting Seqence Header.
/// @return MI_OK: Get Seqence Header success.
/// @return MI_ERR_INVALID_PARAMETER: Invalid parameter.
//------------------------------------------------------------------------------
MI_RESULT MI_VENC_GetSeqHeader(MI_HANDLE hVenc, MI_VENC_SeqHeader_t *pstHeader);

//------------------------------------------------------------------------------
/// @brief Dump VENC Info.
/// @param[in] pstDumpInfoParams: A pointer to structure MI_VENC_DumpInfoParams_t for info dump.
/// @return MI_OK: Dump information success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_PARAMETER: Invalid parameter.
//------------------------------------------------------------------------------
MI_RESULT MI_VENC_DumpInfo(const MI_VENC_DumpInfoParams_t *pstDumpInfoParams);

//------------------------------------------------------------------------------
/// @brief Set VENC debug level.
/// @param[in] eDbgLevel.
/// @return MI_OK: Set debug level success.
//------------------------------------------------------------------------------
MI_RESULT MI_VENC_SetDebugLevel(MI_DBG_LEVEL u32DebugLevel);

//------------------------------------------------------------------------------
/// @brief Qurey buffer for input data. Using before MI_VENC_Start and get entire inject buffer.
/// @param[in] hVenc: An instance of a created VENC interface.
/// @param[out] pstBufInfo: Buffer information.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Invalid parameter.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_VENC_QueryEntireInjectBuffer(MI_HANDLE hVenc, MI_VENC_BufInfo_t *pstBufInfo);

#ifdef __cplusplus
}
#endif

#endif///_MI_VENC_H_


