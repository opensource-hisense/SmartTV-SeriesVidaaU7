/*------------------------------------------------------------------------------
 * MediaTek Inc. (C) 2018. All rights reserved.
 *
 * Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 *----------------------------------------------------------------------------*/

///////////////////////////////////////////////////////////////////////////////////////////////////
/// @file   MI_WLAN.h
/// @author MediaTek Inc.
///////////////////////////////////////////////////////////////////////////////////////////////////

#ifndef _MI_WLAN_H_
#define _MI_WLAN_H_
#ifdef __cplusplus
extern "C" {
#endif

//-------------------------------------------------------------------------------------------------
//  Defines - Constant
//-------------------------------------------------------------------------------------------------

/// WLAN max MAC len
#define MI_WLAN_MAX_MAC_LEN 32
/// WLAN max SSID len
#define MI_WLAN_MAX_SSID_LEN 32
/// WLAN max password len
#define MI_WLAN_MAX_PASSWD_LEN 40
/// WLAN max AP number
#define MI_WLAN_MAX_AP_INFO_NUM 64
/// WLAN max path len
#define MI_WLAN_MAX_FOLDER_PATH_LEN 256

//-------------------------------------------------------------------------------------------------
//  Types - Enums
//-------------------------------------------------------------------------------------------------

///WLAN Status
typedef enum
{
    E_MI_WLAN_STATUS_MIN = 0,
    /// WLAN empty status
    E_MI_WLAN_STATUS_EMPTY = E_MI_WLAN_STATUS_MIN,
    /// WLAN inited status
    E_MI_WLAN_STATUS_INITED,
    /// WLAN opened status
    E_MI_WLAN_STATUS_OPENED,
    /// WLAN scanning status
    E_MI_WLAN_STATUS_SCANNING,
    /// WLAN connecting status
    E_MI_WLAN_STATUS_CONNECTING,
    /// WLAN running status
    E_MI_WLAN_STATUS_CONNECTED,
    /// WLAN max status
    E_MI_WLAN_STATUS_MAX
} MI_WLAN_Status_e;

typedef enum
{
    E_MI_WLAN_MODE_MIN = 0,
    E_MI_WLAN_MODE_STATION = E_MI_WLAN_MODE_MIN,
    E_MI_WLAN_MODE_ACCESS_POINT,
    E_MI_WLAN_MODE_MAX,
} MI_WLAN_Mode_e;

typedef enum
{
    E_MI_WLAN_DEVICE_INTERFACE_MIN = 0,
    E_MI_WLAN_DEVICE_INTERFACE_USB = E_MI_WLAN_DEVICE_INTERFACE_MIN,
    E_MI_WLAN_DEVICE_INTERFACE_PCIE,
    E_MI_WLAN_DEVICE_INTERFACE_SDIO,
    E_MI_WLAN_DEVICE_INTERFACE_MAX,
} MI_WLAN_DeviceInterface_e;

typedef enum
{
    E_MI_WLAN_EVENT_MIN = 0,
    /// WLAN dongle in
    E_MI_WLAN_EVENT_IN = MI_BIT(0),
    /// WLAN dongle out
    E_MI_WLAN_EVENT_OUT = MI_BIT(1),
    /// WLAN dongle max
    E_MI_WLAN_EVENT_MAX
} MI_WLAN_Event_e;

typedef enum
{
    E_MI_WLAN_SECURITY_MIN = 0,
    /// WLAN module security key off
    E_MI_WLAN_SECURITY_NONE = E_MI_WLAN_SECURITY_MIN,
    /// WLAN module security key unknow
    E_MI_WLAN_SECURITY_UNKNOW_TYPE,
    /// WLAN module security key WEP
    E_MI_WLAN_SECURITY_WEP,
    /// WLAN module security key WPA
    E_MI_WLAN_SECURITY_WPA,
    /// WLAN module security key WPA2
    E_MI_WLAN_SECURITY_WPA2,
    /// WLAN module max
    E_MI_WLAN_SECURITY_MAX
} MI_WLAN_Security_e;

typedef enum
{
    E_MI_WLAN_ENCRYPT_MIN = 0,
    /// WLAN module encrypt type none
    E_MI_WLAN_ENCRYPT_NONE = E_MI_WLAN_ENCRYPT_MIN,
    /// WLAN module encrypt type unknown
    E_MI_WLAN_ENCRYPT_UNKNOWN,
    /// WLAN module encrypt type WEP
    E_MI_WLAN_ENCRYPT_WEP,
    /// WLAN module encrypt type TKIP
    E_MI_WLAN_ENCRYPT_TKIP,
    /// WLAN module encrypt type AES
    E_MI_WLAN_ENCRYPT_AES,
    /// WLAN module max
    E_MI_WLAN_ENCRYPT_MAX
} MI_WLAN_Encrypt_e;

/// Attr type
typedef enum
{
    E_MI_WLAN_ATTR_TYPE_MIN = 0 ,
    /// WLAN get status (enable or disable),Attr type is a pointer to MI_BOOL
    E_MI_WLAN_ATTR_TYPE_CONNECT_STATUS = E_MI_WLAN_ATTR_TYPE_MIN,
    /// WLAN get access point info by index, Attr type is a pointer to MI_WLAN_QueryApInfo_t
    E_MI_WLAN_ATTR_TYPE_APINFO_BY_INDEX,
    /// WLAN get interface name, Attr type is a pointer to MI_U8 array, size should be >= MI_NET_INTERFACE_NAME_MAX
    E_MI_WLAN_ATTR_TYPE_INTERFACE_NAME,
    /// WLAN set bridge enable/disable, Attr type is a pointer to MI_WLAN_BridgeSetting_t
    E_MI_WLAN_ATTR_TYPE_BRIDGE_SETTING,
    /// WLAN Attr max
    E_MI_WLAN_ATTR_TYPE_MAX
}  MI_WLAN_AttrType_e;

typedef enum
{
    E_MI_WLAN_NETWORK_TYPE_MIN = 0,
    /// WLAN network infrastructure type
    E_MI_WLAN_NETWORK_TYPE_INFRASTRUCTURE = E_MI_WLAN_NETWORK_TYPE_MIN,
    /// WLAN network AP type
    E_MI_WLAN_NETWORK_TYPE_AP,
    /// WLAN network AdHoc type
    E_MI_WLAN_NETWORK_TYPE_ADHOC,
    /// WLAN param max
    E_MI_WLAN_NETWORK_TYPE_MAX
} MI_WLAN_NetworkType_e;

//-------------------------------------------------------------------------------------------------
//  Types - Structures
//-------------------------------------------------------------------------------------------------

/// WLAN init parameter
typedef struct MI_WLAN_InitParams_s
{
    /// WLAN module
    MI_WLAN_Mode_e eMode;                                ///[IN]: for passing user-defined parameters.
    /// WLAN reserved for CUS dongle
    MI_U8 szWlanFolderPath[MI_WLAN_MAX_FOLDER_PATH_LEN]; ///[IN]: for passing user-defined parameters.
} MI_WLAN_InitParams_t;

/// WLAN open parameter
typedef struct MI_WLAN_OpenParams_s
{
    // reserved
    MI_U8 u8Reserved;
} MI_WLAN_OpenParams_t;

/// WLAN connect info
typedef struct MI_WLAN_ConnectParams_s
{
    // WLAN network type, currenty only supprot infra mode
    MI_WLAN_NetworkType_e eNetworkType;                  ///[IN]: for passing user-defined parameters.
    // WLan security mode
    MI_WLAN_Security_e eSecurity;                        ///[IN]: for passing user-defined parameters.
    // WLan SSID
    MI_U8 szSsid[MI_WLAN_MAX_SSID_LEN];                  ///[IN]: for passing user-defined parameters.
    // WLan password
    MI_U8 szPassword[MI_WLAN_MAX_PASSWD_LEN];            ///[IN]: for passing user-defined parameters.
} MI_WLAN_ConnectParams_t;

/// WLAN ap info
typedef struct MI_WLAN_ApInfo_s
{
    // WLAN Security mode
    MI_WLAN_Security_e eSecurity;                        ///[OUT]: the returned value of the AP security
    // WLAN Frequency MHz
    MI_U32 u32Frequency;                                 ///[OUT]: the returned value of the AP Freqency
    // WLAN Bitrate Mb/s
    MI_U32 u32BitRate;                                   ///[OUT]: the returned value of the AP bit rate
    // WLAN Quality %
    MI_U32 u32Quality;                                   ///[OUT]: the returned value of the AP signal quality
    // WLAN SSID
    MI_U8 szSsid[MI_WLAN_MAX_SSID_LEN];                  ///[OUT]: the returned value of the AP SSID
    // WLAN Channel
    MI_U8 u8Channel;                                     ///[OUT]: the returned value of the AP channel
    // WLAN MAC
    MI_U8 szMac[MI_WLAN_MAX_MAC_LEN];                    ///[OUT]: the returned value of the AP mac address
    // WLAN Encryption type
    MI_WLAN_Encrypt_e eEncrypt;                          ///[OUT]: the returned value of the AP encryption
    // WLAN AP type (Infrastructure / Ad-Hoc)
    MI_WLAN_NetworkType_e eNetworkType;                  ///[OUT]: the returned value of the AP network mode
    // WLAN Strength %
    MI_U32 u32Strength;                                  ///[OUT]: the returned value of the AP Strength
    // WLAN Support PSK
    MI_BOOL bSupportPsk;                                 ///[OUT]: the returned value of the AP support PSK or not
} MI_WLAN_ApInfo_t;

/// WLAN ap info
typedef struct MI_WLAN_ScanParams_s
{
    // WLan set block mode
    MI_BOOL bBlock;                                      ///[IN]: for passing block or nonblock scanning
} MI_WLAN_ScanParams_t;

/// WLAN ap info
typedef struct MI_WLAN_ScanResult_s
{
    // WLan AP number
    MI_U8 u8ApNumber;                                    ///[OUT]: the returned value of how many AP we found.
} MI_WLAN_ScanResult_t;

typedef struct MI_WLAN_QueryApInfo_s
{
    // WLan AP info
    MI_WLAN_ApInfo_t stApInfo;                           ///[OUT]: the returned structure of AP information
    // WLan AP index
    MI_U8 u8Idx;                                         ///[IN]: for passing AP index
} MI_WLAN_QueryApInfo_t;

/// WLAN dongle device info
typedef struct MI_WLAN_DeviceInfo_s
{
    // WLan dongle vendor ID
    MI_U16 u16IdVendor;                                  ///[IN]: for passing user-defined parameters.
    // WLan dongle product ID
    MI_U16 u16IdProduct;                                 ///[IN]: for passing user-defined parameters.
    // WLan dongle init script path
    MI_U8 szScriptPath[MI_WLAN_MAX_FOLDER_PATH_LEN];     ///[IN]: for passing user-defined parameters.
    // WLan dongle interface name
    MI_U8 szInterfaceName[MI_NET_INTERFACE_NAME_MAX];    ///[IN]: for passing user-defined parameters.
} MI_WLAN_DeviceInfo_t;

typedef struct MI_WLAN_BridgeSetting_s
{
    // WLan enable bridge function
    MI_BOOL bEnable;                                     ///[IN]: for enable network bridge
    // wireless (e.g. apcli0/ap0) or wire (e.g. eth0) interface name (if length = 0, depend on init mode to set default as apcli0/ap0)
    MI_U8 szInterfaceName[MI_NET_INTERFACE_NAME_MAX];   ///[IN]: for bridge interface name
} MI_WLAN_BridgeSetting_t;

// Define the event call back
typedef MI_RESULT (*MI_WLAN_EventCallback)(MI_HANDLE hWlan, MI_U32 u32Event, void *pEventParams, void *pUserParams);

typedef struct MI_WLAN_CallbackInputParams_s
{
    MI_U64 u64CallbackId;                               ///[IN]: for multi-callback, use 0 for first register or single callback.
    MI_WLAN_EventCallback pfEventCallback;              ///[IN]: callback function pointer.
    MI_U32 u32EventFlags;                               ///[IN]: registered events which are bitwise OR operation.
    void * pUserParams;                                 ///[IN]: for passing user-defined parameters.
} MI_WLAN_CallbackInputParams_t;

typedef struct MI_WLAN_CallbackOutputParams_s
{
    MI_U64 u64CallbackId;                               ///[OUT]: the returned ID for update or unregister callback.
} MI_WLAN_CallbackOutputParams_t;

// Use for E_MI_WLAN_EVENT_IN / E_MI_WLAN_EVENT_OUT
typedef struct MI_WLAN_CallbackDeviceInfo_s
{
    MI_U16 u16VendorId;                                 ///[OUT]: the returned VendorID for callback device.
    MI_U16 u16ProductId;                                ///[OUT]: the returned ProductID for callback device.
    MI_WLAN_DeviceInterface_e eDeviceInterface;         ///[OUT]: the returned device interface for callback device.
} MI_WLAN_CallbackDeviceInfo_t;

//-------------------------------------------------------------------------------------------------
//  Global Functions
//-------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------
/// @brief do wlan init , and change wlan status to E_MI_WLAN_STATUS_INITED
/// @param[in] *pstInitParams reserved
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: init fail.
/// @return MI_HAS_INITED: already inited.
//------------------------------------------------------------------------------
MI_RESULT MI_WLAN_Init(const MI_WLAN_InitParams_t *pstInitParams);

//------------------------------------------------------------------------------
/// @brief do wlan deinit , and change wlan status to E_MI_WLAN_STATUS_EMPTY
/// @param[in] none
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: deinit fail.
//------------------------------------------------------------------------------
MI_RESULT MI_WLAN_DeInit(void);

//------------------------------------------------------------------------------
/// @brief Open wlan handler, and change wlan status to E_MI_WLAN_STATUS_OPENED
/// @param[in] *pstOpenParams, reserved.
/// @param[out] *phWlan wlan handler
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process failed
/// @return MI_ERR_INVALID_HANDLE: Null handle
/// @return MI_ERR_INVALID_PARAMETER: Null parameter
//------------------------------------------------------------------------------
MI_RESULT MI_WLAN_Open(const MI_WLAN_OpenParams_t *pstOpenParams, MI_HANDLE *phWlan);

//------------------------------------------------------------------------------
/// @brief close wlan handler, and change wlan status to E_MI_WLAN_STATUS_INITED
/// @param[in] hWlan wlan handle.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process failed
//------------------------------------------------------------------------------
MI_RESULT MI_WLAN_Close(MI_HANDLE hWlan);

//------------------------------------------------------------------------------
/// @brief add device information to support list
/// @param[in] pstDeviceInfo: A pointer to structure MI_WLAN_DeviceInfo_t for device information.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_WLAN_AddDeviceInfo(MI_WLAN_DeviceInfo_t *pstDeviceInfo);

//------------------------------------------------------------------------------
/// @brief set wlan attr, current reserved
/// @param[in] hWlan wlan handle.
/// @param[in] eAttrType attr type.
/// @param[in] *pAttrParams attr param.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process failed
//------------------------------------------------------------------------------
MI_RESULT MI_WLAN_SetAttr(MI_HANDLE hWlan, MI_WLAN_AttrType_e eAttrType, const void *pAttrParams);

//------------------------------------------------------------------------------
/// @brief get wlan attr
/// @param[in] hWlan wlan handle.
/// @param[in] eAttrType attr type.
/// @param[in] *pInputParams
/// @param[out]*pOutputParams
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process failed
//------------------------------------------------------------------------------
MI_RESULT MI_WLAN_GetAttr(MI_HANDLE hWlan, MI_WLAN_AttrType_e eAttrType, const void *pInputParams,void *pOutputParams);

//------------------------------------------------------------------------------
/// @brief connect, and change wlan status to E_MI_WLAN_STATUS_CONNECTING
/// @param[in] hWlan wlan handle.
/// @param[in] *pstConnectParams info param.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process failed
//------------------------------------------------------------------------------
MI_RESULT MI_WLAN_Connect(MI_HANDLE hWlan, MI_WLAN_ConnectParams_t *pstConnectParams);

//------------------------------------------------------------------------------
/// @brief disconnect wlan, and change wlan status to E_MI_WLAN_STATUS_OPENED
/// @param[in] hWlan wlan handle.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process failed
//------------------------------------------------------------------------------
MI_RESULT MI_WLAN_Disconnect(MI_HANDLE hWlan);

//------------------------------------------------------------------------------
/// @brief scan ap info, if use block mode, it will change to E_MI_WLAN_STATUS_SCANNING
/// @param[in] hWlan wlan handle.
/// @param[in] *pstScanParams info param. //reserved
/// @param[out] *pstResult result.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process failed
//------------------------------------------------------------------------------
MI_RESULT MI_WLAN_Scan(MI_HANDLE hWlan, MI_WLAN_ScanParams_t *pstScanParams, MI_WLAN_ScanResult_t *pstResult);

//------------------------------------------------------------------------------
/// @brief for register wlan call back.
/// @param[in] hWlan wlan handle.
/// @param[in] *pstInputParams input parameters
/// @param[out] *pstOutputParams ouput parameters
/// @param[out] *pstResult result.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process failed
//------------------------------------------------------------------------------
MI_RESULT MI_WLAN_RegisterCallback(MI_HANDLE hWlan, const MI_WLAN_CallbackInputParams_t *pstInputParams, MI_WLAN_CallbackOutputParams_t *pstOutputParams);

//------------------------------------------------------------------------------
/// @brief for unregister wlan call back.
/// @param[in] hWlan wlan handle.
/// @param[in] *pstInputParams input parameters
/// @param[out] *pstResult result.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process failed
//------------------------------------------------------------------------------
MI_RESULT MI_WLAN_UnRegisterCallback(MI_HANDLE hWlan, const MI_WLAN_CallbackInputParams_t *pstInputParams);

//------------------------------------------------------------------------------
/// @brief set wlan debug level
/// @param[in] u32DebugLevel debug level.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process failed
//------------------------------------------------------------------------------
MI_RESULT MI_WLAN_SetDebugLevel(MI_DBG_LEVEL u32DebugLevel);

#ifdef __cplusplus
}
#endif

#endif
