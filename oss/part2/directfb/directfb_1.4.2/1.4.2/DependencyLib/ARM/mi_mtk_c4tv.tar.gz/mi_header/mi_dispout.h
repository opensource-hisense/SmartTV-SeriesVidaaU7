/*------------------------------------------------------------------------------
 * MediaTek Inc. (C) 2018. All rights reserved.
 *
 * Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 *----------------------------------------------------------------------------*/

#ifndef _MI_DISPOUT_H_
#define _MI_DISPOUT_H_

#ifdef __cplusplus
extern "C" {
#endif

//Vendor name consists of 8 byte ASCII characters
#define MI_DISPOUT_EDID_VENDOR_NAME_LEN            9
//Product description consists of 16 byte ASCII characters
#define MI_DISPOUT_EDID_PRODUCT_DESCRIPTION_LEN    17

#define MI_DISPOUT_EDID_DATA_BLOCK_SIZE            128

//ProjectName/CustomerName consists of 16 byte ASCII characters
#define MI_DISPOUT_TCON_NAME_LEN                    16

//-------------------------------------------------------------------------------------------------
//  Structures
//-------------------------------------------------------------------------------------------------
typedef enum
{
    E_MI_DISPOUT_DEVICE_TYPE_PANEL       = 0,
    E_MI_DISPOUT_DEVICE_TYPE_HDMI        = 1,
    E_MI_DISPOUT_DEVICE_TYPE_DAC_YPBPR   = 2,
    E_MI_DISPOUT_DEVICE_TYPE_DAC_CVBS    = 3,
    E_MI_DISPOUT_DEVICE_TYPE_DAC_SCART   = 4,
    E_MI_DISPOUT_DEVICE_TYPE_DAC_CH34    = 5,
    E_MI_DISPOUT_DEVICE_TYPE_MAX,
} MI_DISPOUT_DeviceType_e;

typedef enum
{
    ///Set/Get HDMI color format & depth, parameter type is a pointer to MI_DISPOUT_HdmiColorType_t
    E_MI_DISPOUT_HDMI_ATTR_TYPE_COLOR_TYPE = 0,
    ///Set/Get HDMI output mode, parameter type is a pointer to MI_DISPOUT_HdmiOutputMode_e
    E_MI_DISPOUT_HDMI_ATTR_TYPE_OUTPUT_MODE,
    ///Get HDMI hot plug status, parameter type is a pointer to MI_BOOL
    E_MI_DISPOUT_HDMI_ATTR_TYPE_IS_CONNECTED,
    ///Get HDMI device information, parameter type is a pointer to MI_DISPOUT_HdmiDeviceInfo_t
    E_MI_DISPOUT_HDMI_ATTR_TYPE_DEVICE_INFO,
    ///Set HDMI hdcp key, parameter type is a pointer to MI_DISPOUT_HdmiHdcpKeyInfo_t
    E_MI_DISPOUT_HDMI_ATTR_TYPE_HDCP_KEY,
    ///Get HDMI edid block data, parameter type is a pointer to MI_DISPOUT_HdmiEdidBlock_t
    E_MI_DISPOUT_HDMI_ATTR_TYPE_EDID_BLOCK,
    ///Set/Get HDMI SPD info frame, parameter type is a pointer to MI_DISPOUT_HdmiSpdInfoFrame_t
    E_MI_DISPOUT_HDMI_ATTR_TYPE_SPD_INFO,
    //Set HDMI colorimetry, parameter type is a pointer to MI_DISPOUT_HdmiColorimetryParams_t
    E_MI_DISPOUT_HDMI_ATTR_TYPE_COLORIMETRY,
    E_MI_DISPOUT_HDMI_ATTR_TYPE_MAX,
} MI_DISPOUT_HdmiAttrType_e;

typedef enum
{
    ///Set/Get CH34 Audio system, parameter type is a pointer to MI_DISPOUT_Ch34AudioSys_e
    E_MI_DISPOUT_DAC_ATTR_TYPE_CH34_AUDIO_SYSTEM = 0,
    ///Set/Get CH3 or CH4, parameter type is a pointer to MI_DISPOUT_Ch34Channel_e
    E_MI_DISPOUT_DAC_ATTR_TYPE_CH34_SETTING,
    ///Set hot plug detect, parameter type is a pointer to MI_BOOL
    E_MI_DISPOUT_DAC_ATTR_TYPE_HOTPLUG_DETECT_ENABLE,
    ///Set/Get Macrovision, parameter type is a pointer to MI_DISPOUT_DacAcpMode_e
    E_MI_DISPOUT_DAC_ATTR_TYPE_MACROVISION,
    ///Set/Get 525 aps, parameter type is a pointer to MI_DISPOUT_DacApsMode_e
    E_MI_DISPOUT_DAC_ATTR_TYPE_525APS,
    ///Set/Get 525 cgmsa, parameter type is a pointer to MI_DISPOUT_DacCgmsAMode_e
    E_MI_DISPOUT_DAC_ATTR_TYPE_525CGMSA,
    ///Set/Get 525 wss, parameter type is a pointer to MI_DISPOUT_DacWss525Mode_e
    E_MI_DISPOUT_DAC_ATTR_TYPE_525WSS,
    ///Set/Get cgmsa, parameter type is a pointer to MI_DISPOUT_DacCgmsAMode_e
    E_MI_DISPOUT_DAC_ATTR_TYPE_CGMSA,
    ///Set/Get 625 wss, parameter type is a pointer to MI_DISPOUT_DacWssMode_e
    E_MI_DISPOUT_DAC_ATTR_TYPE_WSS,
    ///Set/Get dac ouput setting, parameter type is a pointer to MI_DISPOUT_DacOutputParams_t
    E_MI_DISPOUT_DAC_ATTR_TYPE_OUTPUT_SETTING,
    ///Set/Get dac scart PIN8, parameter type is a pointer to MI_DISPOUT_ScartArInfo_e
    E_MI_DISPOUT_DAC_ATTR_TYPE_SCART_PIN8,
    ///Set/Get dac scart video type, parameter type is a pointer to MI_DISPOUT_ScartVideoType_e
    E_MI_DISPOUT_DAC_ATTR_TYPE_SCART_VIDEO_TYPE,
    E_MI_DISPOUT_DAC_ATTR_TYPE_MAX,
} MI_DISPOUT_DacAttrType_e;

typedef enum
{
    ///Set/Get panel backlight enable/disable, parameter type is a pointer to MI_BOOL
    E_MI_DISPOUT_PANEL_ATTR_TYPE_BACKLIGHT_ENABLE = 0,
    ///Set/Get panel VCC enable/disable, parameter type is a pointer to MI_BOOL
    E_MI_DISPOUT_PANEL_ATTR_TYPE_VCC_ENABLE,
    ///Set/Get panel output mode, parameter type is a pointer to MI_DISPOUT_PanelOutputMode_e
    E_MI_DISPOUT_PANEL_ATTR_TYPE_OUTPUT_MODE,
    ///Set/Get panel backlight value, parameter type is a pointer to MI_U8
    E_MI_DISPOUT_PANEL_ATTR_TYPE_BACKLIGHT_VALUE,
    ///Get panel PWM range, parameter type is a pointer to MI_DISPOUT_PwmRange_t
    E_MI_DISPOUT_PANEL_ATTR_TYPE_PWM_RANGE,
    ///Set/Get panel SSC attribute, parameter type is a pointer to MI_DISPOUT_PanelSsc_t
    E_MI_DISPOUT_PANEL_ATTR_TYPE_SSC,
    ///Set panel output swing level, parameter type is a pointer to MI_U8, the range of this parameter is: 0 ~ 255
    E_MI_DISPOUT_PANEL_ATTR_TYPE_SWING_LEVEL,
    ///Set/Get localdimming status, parameter type is a pointer to MI_DISPOUT_LdmStatus_t
    E_MI_DISPOUT_PANEL_ATTR_TYPE_LDM_STATUS,
    ///Set localdimming demo pattern, parameter type is a pointer to MI_DISPOUT_LdmSingleLed_t
    E_MI_DISPOUT_PANEL_ATTR_TYPE_LDM_DEMO_MARQUEE,
    ///Set localdimming demo pattern, parameter type is a pointer to MI_BOOL
    E_MI_DISPOUT_PANEL_ATTR_TYPE_LDM_DEMO_LR,
    ///Get localdimming data address, parameter type is a pointer to MI_DISPOUT_LdmDataAddr_t
    E_MI_DISPOUT_PANEL_ATTR_TYPE_LDM_DATA_ADDRESS,
    ///Set/Get panel mute status, parameter type is a pointer to MI_BOOL
    E_MI_DISPOUT_PANEL_ATTR_TYPE_MUTE,
    ///Get UCD(Ultra Contrast Diming) info. parameter type is a pointer to MI_DISPOUT_UcdControlInfo_t
    E_MI_DISPOUT_PANEL_ATTR_TYPE_UCD_INFO,
    ///Set/Get Ultra Contrast Diming setting. parameter type is a pointer to MI_BOOL
    E_MI_DISPOUT_PANEL_ATTR_TYPE_UCD_ENABLE,
    ///Set Customer Ultra Contrast Diming curve. parameter type is a pointer to MI_DISPOUT_UcdCurveInfo_t.
    E_MI_DISPOUT_PANEL_ATTR_TYPE_UCD_CURVE,
    ///Get external FRC device info, parameter type is a pointer to MI_DISPOUT_ExtFrcDeviceInfo_t
    E_MI_DISPOUT_PANEL_ATTR_TYPE_EXT_FRC_DEVICE_INFO,
    ///Get external FRC device connect status, parameter type is a pointer to MI_BOOL
    E_MI_DISPOUT_PANEL_ATTR_TYPE_EXT_FRC_CONNECT_STATUS,
    ///Get Customer TCON. parameter type is a pointer to MI_DISPOUT_TconInfo_t.
    E_MI_DISPOUT_PANEL_ATTR_TYPE_TCON_INFO,
    ///Set panel output pecurrent, parameter type is a pointer to MI_DISPOUT_PanelPeCurrent_t
    E_MI_DISPOUT_PANEL_ATTR_TYPE_PE_CURRENT,
    ///Set Customer Ultra Contrast Diming level. parameter type is a pointer to MI_U8. range: 1~3
    E_MI_DISPOUT_PANEL_ATTR_TYPE_UCD_LEVEL,
    ///Get scaler output frequency. pParam is a pointer to MI_U16.
    E_MI_DISPOUT_PANEL_ATTR_TYPE_OUTPUT_FREQUENCY,
    ///Set over drive enable/disable. parameter type is a pointer to MI_BOOL
    E_MI_DISPOUT_PANEL_ATTR_TYPE_OVERDRIVE_ENABLE,
    E_MI_DISPOUT_PANEL_ATTR_TYPE_MAX,
} MI_DISPOUT_PanelAttrType_e;

typedef enum
{
    /// NOT in any category
    E_MI_DISPOUT_EXT_FRC_MODEL_NONE = 0,
    /// URSA 6
    E_MI_DISPOUT_EXT_FRC_MODEL_URSA_6 = 6,
    /// URSA 7
    E_MI_DISPOUT_EXT_FRC_MODEL_URSA_7 = 7,
    /// URSA 8
    E_MI_DISPOUT_EXT_FRC_MODEL_URSA_8 = 8,
    /// URSA 9
    E_MI_DISPOUT_EXT_FRC_MODEL_URSA_9 = 9,
    /// URSA 11
    E_MI_DISPOUT_EXT_FRC_MODEL_URSA_11 = 11,
    /// URSA 14
    E_MI_DISPOUT_EXT_FRC_MODEL_URSA_14 = 14,
    /// URSA 20
    E_MI_DISPOUT_EXT_FRC_MODEL_URSA_20 = 20,
    /// URSA KS2
    E_MI_DISPOUT_EXT_FRC_MODEL_URSA_KS2 = 102,
    /// URSA KS5
    E_MI_DISPOUT_EXT_FRC_MODEL_URSA_KS5 = 105,
    /// URSA MAX
    E_MI_DISPOUT_EXT_FRC_MODEL_URSA_MAX,
} MI_DISPOUT_ExtFrcModel_e;

typedef enum
{
    E_MI_DISPOUT_HDMI_EXT_COLORIMETRY_XVYCC601 = 0x00, ///< xvycc 601
    E_MI_DISPOUT_HDMI_EXT_COLORIMETRY_XVYCC709,        ///< xvycc 709
    E_MI_DISPOUT_HDMI_EXT_COLORIMETRY_SYCC601,         ///< sYCC 601
    E_MI_DISPOUT_HDMI_EXT_COLORIMETRY_ADOBEYCC601,     ///< Adobe YCC 601
    E_MI_DISPOUT_HDMI_EXT_COLORIMETRY_ADOBERGB,        ///< Adobe RGB
    E_MI_DISPOUT_HDMI_EXT_COLORIMETRY_BT2020CYCC,      ///< Adobe BT2020 CYCC
    E_MI_DISPOUT_HDMI_EXT_COLORIMETRY_BT2020YCC,       ///< Adobe BT2020  YCC
    E_MI_DISPOUT_HDMI_EXT_COLORIMETRY_BT2020RGB,       ///< Adobe BT2020 RGB
    E_MI_DISPOUT_HDMI_EXT_COLORIMETRY_UNKNOWN,         ///< Unknow
} MI_DISPOUT_HdmiExtendedColorimetry_e;

typedef enum
{
    E_MI_DISPOUT_HDMI_COLORIMETRY_NODATA = 0x00,  ///< NODATA
    E_MI_DISPOUT_HDMI_COLORIMETRY_ITU601,         ///< ITU601
    E_MI_DISPOUT_HDMI_COLORIMETRY_ITU709,         ///< ITU709
    E_MI_DISPOUT_HDMI_COLORIMETRY_EXTEND_VALID,   ///EXTEND_VALID
    E_MI_DISPOUT_HDMI_COLORIMETRY_UNKNOWN,        ///< Unknow
} MI_DISPOUT_HdmiColorimetry_e;

typedef enum
{
    E_MI_DISPOUT_HDMI_COLOR_FORMAT_RGB        = 0,
    E_MI_DISPOUT_HDMI_COLOR_FORMAT_YUV422     = 1,
    E_MI_DISPOUT_HDMI_COLOR_FORMAT_YUV444     = 2,
    E_MI_DISPOUT_HDMI_COLOR_FORMAT_YUV420     = 3,
    E_MI_DISPOUT_HDMI_COLOR_FORMAT_MAX,
} MI_DISPOUT_HdmiColorFormat_e;

typedef enum
{
    E_MI_DISPOUT_HDMI_COLOR_DEPTH_AUTO = 0,
    E_MI_DISPOUT_HDMI_COLOR_DEPTH_8BITS,
    E_MI_DISPOUT_HDMI_COLOR_DEPTH_10BITS,
    E_MI_DISPOUT_HDMI_COLOR_DEPTH_12BITS,
    E_MI_DISPOUT_HDMI_COLOR_DEPTH_16BITS,
    E_MI_DISPOUT_HDMI_COLOR_DEPTH_MAX,
} MI_DISPOUT_HdmiColorDepth_e;

typedef enum
{
    E_MI_DISPOUT_HDMI_OUTPUT_MODE_HDMI = 0,
    E_MI_DISPOUT_HDMI_OUTPUT_MODE_HDMI_HDCP,
    E_MI_DISPOUT_HDMI_OUTPUT_MODE_DVI,
    E_MI_DISPOUT_HDMI_OUTPUT_MODE_DVI_HDCP,
    E_MI_DISPOUT_HDMI_OUTPUT_MODE_MAX,
} MI_DISPOUT_HdmiOutputMode_e;

/// 625 WSS mode
typedef enum
{
    E_MI_DISPOUT_DAC_WSS_MODE_4X3_FULL                      = 0x08,
    E_MI_DISPOUT_DAC_WSS_MODE_14X9_LETTERBOX_CENTER         = 0x01,
    E_MI_DISPOUT_DAC_WSS_MODE_14X9_LETTERBOX_TOP            = 0x02,
    E_MI_DISPOUT_DAC_WSS_MODE_16X9_LETTERBOX_CENTER         = 0x0B,
    E_MI_DISPOUT_DAC_WSS_MODE_16X9_LETTERBOX_TOP            = 0x04,
    E_MI_DISPOUT_DAC_WSS_MODE_16X9_LETTERBOX_ABOVE_CENTER   = 0x0D,
    E_MI_DISPOUT_DAC_WSS_MODE_14X9_FULL_CENTER              = 0x0E,
    E_MI_DISPOUT_DAC_WSS_MODE_16X9_ANAMORPHIC               = 0x07,
    E_MI_DISPOUT_DAC_WSS_MODE_625_COPYRIGHT                 = 0x1000,
    E_MI_DISPOUT_DAC_WSS_MODE_625_COPY_PROTECTION           = 0x2000
} MI_DISPOUT_DacWssMode_e;

/// 525 WSS mode
typedef enum
{
    E_MI_DISPOUT_DAC_WSS_525_MODE_4X3_NORMAL                = 0x00,
    E_MI_DISPOUT_DAC_WSS_525_MODE_4X3_LETTERBOX             = 0x02,
    E_MI_DISPOUT_DAC_WSS_525_MODE_16X9_ANAMORPHIC           = 0x01,
    E_MI_DISPOUT_DAC_WSS_525_MODE_RESERVED                  = 0x03,
    E_MI_DISPOUT_DAC_WSS_525_MODE_COPYRIGHT                 = 0x40,
    E_MI_DISPOUT_DAC_WSS_525_MODE_COPY_PROTECTION           = 0x80,
    E_MI_DISPOUT_DAC_WSS_525_MODE_APS_NO_APS                = 0x0000,
    E_MI_DISPOUT_DAC_WSS_525_MODE_APS_PSP_CS_OFF            = 0x0200,
    E_MI_DISPOUT_DAC_WSS_525_MODE_APS_PSP_2_LINE_CS         = 0x0100,
    E_MI_DISPOUT_DAC_WSS_525_MODE_APS_PSP_4_LINE_CS         = 0x0300,
} MI_DISPOUT_DacWss525Mode_e;

/// CGMS-A mode, Bit Definitions in CEA-805A
typedef enum
{
    E_MI_DISPOUT_DAC_CGMS_A_MODE_INVALID       = -1,
    E_MI_DISPOUT_DAC_CGMS_A_MODE_COPY_FREELY   = 0x00,
    E_MI_DISPOUT_DAC_CGMS_A_MODE_COPY_NO_MORE  = 0x01,
    E_MI_DISPOUT_DAC_CGMS_A_MODE_COPY_ONCE     = 0x02,
    E_MI_DISPOUT_DAC_CGMS_A_MODE_COPY_NEVER    = 0x03,
} MI_DISPOUT_DacCgmsAMode_e;

/// APS mode, Bit Definitions in IEC 61880 and CEA608
typedef enum
{
    E_MI_DISPOUT_DAC_APS_MODE_INVALID          = -1,
    E_MI_DISPOUT_DAC_APS_MODE_NO_APS           = 0x00,
    E_MI_DISPOUT_DAC_APS_MODE_PSP_ONLY         = 0x01,
    E_MI_DISPOUT_DAC_APS_MODE_PSP_2_LINE_CB    = 0x02,
    E_MI_DISPOUT_DAC_APS_MODE_PSP_4_LINE_CB    = 0x03,
} MI_DISPOUT_DacApsMode_e;

typedef enum
{
    E_MI_DISPOUT_PANEL_OUTPUT_MODE_NO_OUTPUT = 0,     ///< no physical output
    E_MI_DISPOUT_PANEL_OUTPUT_MODE_CLK_ONLY,          ///< output clock only
    E_MI_DISPOUT_PANEL_OUTPUT_MODE_DATA_ONLY,         ///< output data only
    E_MI_DISPOUT_PANEL_OUTPUT_MODE_CLK_DATA,          ///< output clock and data
} MI_DISPOUT_PanelOutputMode_e;

typedef enum
{
    E_MI_DISPOUT_HDMI_AUDIO_TYPE_PCM = 1,
    E_MI_DISPOUT_HDMI_AUDIO_TYPE_DD,
    E_MI_DISPOUT_HDMI_AUDIO_TYPE_MPEG,
    E_MI_DISPOUT_HDMI_AUDIO_TYPE_MP3,
    E_MI_DISPOUT_HDMI_AUDIO_TYPE_MPEG2,
    E_MI_DISPOUT_HDMI_AUDIO_TYPE_AAC_LC,
    E_MI_DISPOUT_HDMI_AUDIO_TYPE_DTS,
    E_MI_DISPOUT_HDMI_AUDIO_TYPE_ATRAC,
    E_MI_DISPOUT_HDMI_AUDIO_TYPE_ONE_BIT_AUDIO,
    E_MI_DISPOUT_HDMI_AUDIO_TYPE_DD_ENHANCED,
    E_MI_DISPOUT_HDMI_AUDIO_TYPE_DTS_HD,
    E_MI_DISPOUT_HDMI_AUDIO_TYPE_MAT,
    E_MI_DISPOUT_HDMI_AUDIO_TYPE_DST,
    E_MI_DISPOUT_HDMI_AUDIO_TYPE_WMA_PRO,
    E_MI_DISPOUT_HDMI_AUDIO_TYPE_DDS_MAX,
} MI_DISPOUT_HdmiAudioType_e;

typedef enum
{
    E_MI_DISPOUT_SCART_SOURCE_ATV = 0,
    E_MI_DISPOUT_SCART_SOURCE_DTV,
    E_MI_DISPOUT_SCART_SOURCE_MAX,
} MI_DISPOUT_ScartSource_e;

typedef enum
{
    //HDCP is disable.
    E_MI_DISPOUT_HDMI_HDCP_STATUS_DISABLE = 0,
    //HDCP authentication status is fail.
    E_MI_DISPOUT_HDMI_HDCP_STATUS_FAIL,
    //HDCP authentication status is pass.
    E_MI_DISPOUT_HDMI_HDCP_STATUS_PASS,
    //HDCP authentication is in progress.
    E_MI_DISPOUT_HDMI_HDCP_STATUS_PROCESS,
} MI_DISPOUT_HdmiHdcpStatus_e;

/// SPD(Source Product Description) infoframe data byte
typedef enum
{
    E_MI_DISPOUT_HDMI_SPD_SOURCE_INFO_UNKNOWN = 0,          ///<Unknown
    E_MI_DISPOUT_HDMI_SPD_SOURCE_INFO_DIGITAL_STB,          ///<Digital STB
    E_MI_DISPOUT_HDMI_SPD_SOURCE_INFO_DVD_PLAYER,           ///<DVD player
    E_MI_DISPOUT_HDMI_SPD_SOURCE_INFO_D_VHS,                ///<D-VHS
    E_MI_DISPOUT_HDMI_SPD_SOURCE_INFO_HDD_VIDEO_RECORDER,   ///<HDD Videocorder
    E_MI_DISPOUT_HDMI_SPD_SOURCE_INFO_DVC,                  ///<Digital Video Camera (DVC)
    E_MI_DISPOUT_HDMI_SPD_SOURCE_INFO_DSC,                  ///<Digital Still Camera (DSC)
    E_MI_DISPOUT_HDMI_SPD_SOURCE_INFO_VIDEO_CD,             ///<Video CD
    E_MI_DISPOUT_HDMI_SPD_SOURCE_INFO_GAME,                 ///<Game
    E_MI_DISPOUT_HDMI_SPD_SOURCE_INFO_PC_GENERAL,           ///<PC general
    E_MI_DISPOUT_HDMI_SPD_SOURCE_INFO_BULE_RAY_DISC,        ///<Blu-Ray Disc(BD)
    E_MI_DISPOUT_HDMI_SPD_SOURCE_INFO_SUPER_AUDIO_CD,       ///<Super Audio CD
    E_MI_DISPOUT_HDMI_SPD_SOURCE_INFO_HD_DVD,               ///<HD DVD
    E_MI_DISPOUT_HDMI_SPD_SOURCE_INFO_PMP,                  ///<Portable Multimedia Player (PMP)
    E_MI_DISPOUT_HDMI_SPD_SOURCE_INFO_MAX,
} MI_DISPOUT_HdmiSpdSourceInfo_e;

typedef enum
{
    E_MI_DISPOUT_TIMING_720X480_60I     = 0,
    E_MI_DISPOUT_TIMING_720X480_60P     = 1,
    E_MI_DISPOUT_TIMING_720X576_50I     = 2,
    E_MI_DISPOUT_TIMING_720X576_50P     = 3,
    E_MI_DISPOUT_TIMING_1280X720_50P    = 4,
    E_MI_DISPOUT_TIMING_1280X720_60P    = 5,
    E_MI_DISPOUT_TIMING_1920X1080_50I   = 6,
    E_MI_DISPOUT_TIMING_1920X1080_60I   = 7,
    E_MI_DISPOUT_TIMING_1920X1080_24P   = 8,
    E_MI_DISPOUT_TIMING_1920X1080_25P   = 9,
    E_MI_DISPOUT_TIMING_1920X1080_30P   = 10,
    E_MI_DISPOUT_TIMING_1920X1080_50P   = 11,
    E_MI_DISPOUT_TIMING_1920X1080_60P   = 12,
    E_MI_DISPOUT_TIMING_3840X2160_24P   = 13,
    E_MI_DISPOUT_TIMING_3840X2160_25P   = 14,
    E_MI_DISPOUT_TIMING_3840X2160_30P   = 15,
    E_MI_DISPOUT_TIMING_3840X2160_50P   = 16,
    E_MI_DISPOUT_TIMING_3840X2160_60P   = 17,
    E_MI_DISPOUT_TIMING_4096X2160_24P   = 18,
    E_MI_DISPOUT_TIMING_4096X2160_25P   = 19,
    E_MI_DISPOUT_TIMING_4096X2160_30P   = 20,
    E_MI_DISPOUT_TIMING_4096X2160_50P   = 21,
    E_MI_DISPOUT_TIMING_4096X2160_60P   = 22,
    E_MI_DISPOUT_TIMING_640X480_60P     = 23,
    E_MI_DISPOUT_TIMING_1024X768_60P    = 24,
    E_MI_DISPOUT_TIMING_1280X1024_60P   = 25,
    E_MI_DISPOUT_TIMING_1440X900_60P    = 26,
    E_MI_DISPOUT_TIMING_1600X1200_60P   = 27,
    E_MI_DISPOUT_TIMING_MAX,
} MI_DISPOUT_OutputTiming_e;

typedef enum
{
    // non HDR
    E_MI_DISPOUT_HDMI_HDR_TYPE_NONE,
    // Open HDR
    E_MI_DISPOUT_HDMI_HDR_TYPE_OPEN,
    // Dolby HDR
    E_MI_DISPOUT_HDMI_HDR_TYPE_DOLBY,
    // tch HDR
    E_MI_DISPOUT_HDMI_HDR_TYPE_TCH,
    // HLG HDR
    E_MI_DISPOUT_HDMI_HDR_TYPE_HLG,
    E_MI_DISPOUT_HDMI_HDR_TYPE_MAX,
} MI_DISPOUT_HdmiHdrType_e;

typedef enum
{
    /// 3D format is None
    E_MI_DISPOUT_HDMI_3D_TYPE_NONE = 0,
    /// 3D format is Frame Packing
    E_MI_DISPOUT_HDMI_3D_TYPE_FRAME_PACKING,
    /// 3D format  is Frame Alternative
    E_MI_DISPOUT_HDMI_3D_TYPE_FRAME_ALTERNATIVE,
    /// 3D format is Field Alternative
    E_MI_DISPOUT_HDMI_3D_TYPE_FIELD_ALTERNATIVE,
    /// 3D format is Line Alternative
    E_MI_DISPOUT_HDMI_3D_TYPE_LINE_ALTERNATIVE,
    /// 3D format is Pixel Alternative
    E_MI_DISPOUT_HDMI_3D_TYPE_PIXEL_ALTERNATIVE,
    /// 3D format is Side by Side Half
    E_MI_DISPOUT_HDMI_3D_TYPE_SIDE_BY_SIDE_HALF,
    /// 3D format is Side by Side Full
    E_MI_DISPOUT_HDMI_3D_TYPE_SIDE_BY_SIDE_FULL,
    /// 3D format is Top and Bottom
    E_MI_DISPOUT_HDMI_3D_TYPE_TOP_BOTTOM,
    /// 3D format is Check board
    E_MI_DISPOUT_HDMI_3D_TYPE_CHECK_BOARD,
    /// 3D format max
    E_MI_DISPOUT_HDMI_3D_TYPE_MAX,
} MI_DISPOUT_Hdmi3DType_e;

//CH34 Audio System
typedef enum
{
    E_MI_DISPOUT_CH34_AUDIO_SYSTEM_MONO = 0,     ///< MONO
    E_MI_DISPOUT_CH34_AUDIO_SYSTEM_BTSC,          ///< BTSC
    E_MI_DISPOUT_CH34_AUDIO_SYSTEM_A2,          ///< A2
    E_MI_DISPOUT_CH34_AUDIO_SYSTEM_MAX,
} MI_DISPOUT_Ch34AudioSystem_e;

typedef enum
{
    E_MI_DISPOUT_CH34_CHANNEL_3 = 0,      ///< ch3
    E_MI_DISPOUT_CH34_CHANNEL_4,          ///< ch4
    E_MI_DISPOUT_CH34_CHANNEL_MAX,
} MI_DISPOUT_Ch34Channel_e;

typedef enum
{
    E_MI_DISPOUT_DAC_ACP_MODE_DISABLE,
    E_MI_DISPOUT_DAC_ACP_MODE_CVBS_NTSC_MODE1           = 0,    //NTSC, AGC only
    E_MI_DISPOUT_DAC_ACP_MODE_CVBS_NTSC_MODE2,                  //NTSC, AGC + 2-line Colorstripe
    E_MI_DISPOUT_DAC_ACP_MODE_CVBS_NTSC_MODE3,                  //NTSC, AGC + 4-line Colorstripe
    E_MI_DISPOUT_DAC_ACP_MODE_CVBS_NTSC_TEST_N01,               //NTSC, RGB Copy Protect on (N01)
    E_MI_DISPOUT_DAC_ACP_MODE_CVBS_NTSC_TEST_N02,               //NTSC, RGB Copy Protect on (N02)
    E_MI_DISPOUT_DAC_ACP_MODE_CVBS_PAL_MODE1            = 0x10, //PAL, Mode1, BPP = 0x40
    E_MI_DISPOUT_DAC_ACP_MODE_CVBS_PAL_MODE2,                   //PAL, Mode2, BPP = 0x60
    E_MI_DISPOUT_DAC_ACP_MODE_CVBS_PAL_MODE3,                   //PAL, Mode3, BPP = 0x50
    E_MI_DISPOUT_DAC_ACP_MODE_CVBS_PAL_TEST_P01,                //PAL, RGB Copy Protect on (P01)
    E_MI_DISPOUT_DAC_ACP_MODE_CVBS_PAL_TEST_P02,                //PAL, RGB Copy Protect on (P02)
    E_MI_DISPOUT_DAC_ACP_MODE_COMPONENT_480I_MODE2      = 0x20, //YPbPr, NTSC-Mode2:700/300 Levels
    E_MI_DISPOUT_DAC_ACP_MODE_COMPONENT_480I_MODE3,             //YPbPr, NTSC-Mode3:714/286 Levels
    E_MI_DISPOUT_DAC_ACP_MODE_COMPONENT_480P_EIA_7701,          //YPbPr, 525P EIA-770.1
    E_MI_DISPOUT_DAC_ACP_MODE_COMPONENT_480P_EIA_7702,          //YPbPr, 525P EIA-770.2
    E_MI_DISPOUT_DAC_ACP_MODE_COMPONENT_576I_TEST_P01,          //YPbPr, Test P01
    E_MI_DISPOUT_DAC_ACP_MODE_COMPONENT_576I_TEST_P02,          //YPbPr, Test P02
    E_MI_DISPOUT_DAC_ACP_MODE_COMPONENT_576P,                   //YPbPr, 625P
    E_MI_DISPOUT_DAC_ACP_MODE_SVIDEO_NTSC_MODE2         = 0x40, //S-video, NTSC-Mode2
    E_MI_DISPOUT_DAC_ACP_MODE_SVIDEO_NTSC_MODE3,                //S-video, NTSC-Mode3
    E_MI_DISPOUT_DAC_ACP_MODE_SVIDEO_PAL_TEST_P01,              //S-video, PAL Test P01
    E_MI_DISPOUT_DAC_ACP_MODE_SVIDEO_PAL_TEST_P02,              //S-video, PAL Test P02
    E_MI_DISPOUT_DAC_ACP_MODE_MAX,
} MI_DISPOUT_DacAcpMode_e;

typedef enum
{
    //1.3V for CVBS + S-Video
    E_MI_DISPOUT_DAC_LEVEL_HIGH = 0,
    //1.0V for YPbPr
    E_MI_DISPOUT_DAC_LEVEL_LOW,
} MI_DISPOUT_DacLevel_e;

/// DAC swap select
typedef enum
{
    E_MI_DISPOUT_DAC_SWAP_SELECT_TYPE_V_Y_U = 0,
    E_MI_DISPOUT_DAC_SWAP_SELECT_TYPE_V_U_Y = 1,
    E_MI_DISPOUT_DAC_SWAP_SELECT_TYPE_Y_V_U = 2,
    E_MI_DISPOUT_DAC_SWAP_SELECT_TYPE_U_Y_V = 4,
    E_MI_DISPOUT_DAC_SWAP_SELECT_TYPE_Y_U_V = 5,
    E_MI_DISPOUT_DAC_SWAP_SELECT_TYPE_U_V_Y = 6,
    E_MI_DISPOUT_DAC_SWAP_SELECT_TYPE_V_V_V = 7,
    E_MI_DISPOUT_DAC_SWAP_SELECT_TYPE_DEFAULT  = 0xFF,
} MI_DISPOUT_DacSwapSelectType_e;

/// DAC current level
typedef enum
{
    E_MI_DISPOUT_DAC_CURRENT_LEVEL_FULL = 0,
    E_MI_DISPOUT_DAC_CURRENT_LEVEL_HALF,
    E_MI_DISPOUT_DAC_CURRENT_LEVEL_QUART,
} MI_DISPOUT_DacCurrentLevel_e;

typedef enum
{
    E_MI_DISPOUT_SCART_AR_INFO_NONE = 0, //Pin8 0v~2v
    E_MI_DISPOUT_SCART_AR_INFO_16_9,     //Pin8 5v~8v
    E_MI_DISPOUT_SCART_AR_INFO_4_3,      //Pin8 9.5v~12v
} MI_DISPOUT_ScartArInfo_e;

typedef enum
{
    E_MI_DISPOUT_SCART_VIDEO_TYPE_NONE = 0,
    E_MI_DISPOUT_SCART_VIDEO_TYPE_AUTO,
    E_MI_DISPOUT_SCART_VIDEO_TYPE_RGB,
    E_MI_DISPOUT_SCART_VIDEO_TYPE_CVBS,
    E_MI_DISPOUT_SCART_VIDEO_TYPE_CVBS_RGB,
    E_MI_DISPOUT_SCART_VIDEO_TYPE_SVIDEO,
    E_MI_DISPOUT_SCART_VIDEO_TYPE_YPBPR,
    E_MI_DISPOUT_SCART_VIDEO_TYPE_MAX,
} MI_DISPOUT_ScartVideoType_e;

typedef struct MI_DISPOUT_HdmiHdcpKeyInfo_s
{
    MI_U8* pu8HdmiHdcpKey;          ///<HDMI Tx HDCP Key
    MI_U16 u16HdmiHdcpKeySize;      ///<Size of HDMI Tx HDCP key
    MI_U8* pu8HdmiHdcp2Key;         ///<HDMI Tx HDCP2.2 Key
    MI_U16 u16HdmiHdcp2KeySize;     ///<Size of HDMI Tx HDCP2.2 key
} MI_DISPOUT_HdmiHdcpKeyInfo_t;

typedef struct MI_DISPOUT_InitParams_s
{
    MI_U8 u8Reserved;       ///[IN]: reserved
} MI_DISPOUT_InitParams_t;

typedef struct MI_DISPOUT_OpenParams_s
{
    MI_DISPOUT_DeviceType_e eDeviceType;
    MI_U32 u32PortIndex;
} MI_DISPOUT_OpenParams_t;

typedef struct MI_DISPOUT_HdmiColorType_s
{
    MI_DISPOUT_HdmiColorFormat_e eColorFormat;
    MI_DISPOUT_HdmiColorDepth_e eColorDepth;
} MI_DISPOUT_HdmiColorType_t;

typedef struct MI_DISPOUT_HdmiColorimetryParams_s
{
    MI_DISPOUT_HdmiColorimetry_e eColorimetry;
    MI_DISPOUT_HdmiExtendedColorimetry_e eExtColorimetry;
} MI_DISPOUT_HdmiColorimetryParams_t;

typedef struct MI_DISPOUT_HdmiDeviceInfo_s
{
    // get Rx supported timing list
    MI_BOOL abSupportedTiming[E_MI_DISPOUT_TIMING_MAX];
    // get Rx supported audio type list
    MI_BOOL abSupportedAudioType[E_MI_DISPOUT_HDMI_AUDIO_TYPE_DDS_MAX];
    // get Rx supported 3D type list
    MI_BOOL abSupported3DType[E_MI_DISPOUT_HDMI_3D_TYPE_MAX];
    // get Rx preferred timing list
    MI_BOOL abPreferredTiming[E_MI_DISPOUT_TIMING_MAX];
    // get HDCP status
    MI_DISPOUT_HdmiHdcpStatus_e eHdcpStatus;
    // get Rx supported HDMI or DVI
    MI_BOOL bIsSupportHdmiMode;
    ///  Support HDR Type
    MI_BOOL abSupportedHdrType[E_MI_DISPOUT_HDMI_HDR_TYPE_MAX];
} MI_DISPOUT_HdmiDeviceInfo_t;

typedef struct MI_DISPOUT_TtxData_s
{
    MI_U8 *pu8DataAddr;
    MI_U32 u32DataLen;
    MI_BOOL bEnable;
} MI_DISPOUT_TtxData_t;

typedef struct MI_DISPOUT_PwmRange_s
{
    MI_U32 u32PwmMinVal;
    MI_U32 u32PwmMaxVal;
} MI_DISPOUT_PwmRange_t;

typedef struct MI_DISPOUT_HdmiSpdInfoFrame_s
{
    ///<Enable or Disable SPD info frame
    MI_BOOL bEnable;
    ///<SPD(Source Product Description) Source Information data byte.
    MI_DISPOUT_HdmiSpdSourceInfo_e eSpdSourceInfo;
    ///<Vendor name consists of 8 byte ASCII characters.
    MI_U8 au8VendorName[MI_DISPOUT_EDID_VENDOR_NAME_LEN];
    ///<Product description consists of 16 byte ASCII characters.
    MI_U8 au8ProductDescription[MI_DISPOUT_EDID_PRODUCT_DESCRIPTION_LEN];
} MI_DISPOUT_HdmiSpdInfoFrame_t;

typedef struct MI_DISPOUT_TconInfo_s
{
    MI_U8 u8TconMajorVersion;                        ///< Tcon Major Version
    MI_U8 u8TconMinorVersion;                        ///< Tcon Minor Version
    MI_U8 u8TconPanelInterface;                      ///< Tcon Panel Interface
    MI_U8 u8TconPanelSize;                           ///< Tcon Panel Size
    MI_U16 u16TconYear;                              ///< Tcon INF Year
    MI_U8 u8TconMonth;                               ///< Tcon INF Month
    MI_U8 u8TconDay;                                 ///< Tcon INF Day
    MI_U8 u8TconProjectName[MI_DISPOUT_TCON_NAME_LEN];   ///< Tcon Project Name
    MI_U8 u8TconCustomerName[MI_DISPOUT_TCON_NAME_LEN];  ///< Tcon CustomerName
    MI_BOOL bIsTconBinEn;                             ///< Tcon EN
} MI_DISPOUT_TconInfo_t;

//Used for API E_MI_DISPOUT_PANEL_ATTR_TYPE_LDM_DEMO_MARQUEE
typedef struct MI_DISPOUT_LdmSingleLed_s
{
    MI_BOOL bEnable;                                   //<Enable or Disable pattern
    MI_U16 u16StartLedNum;                         //<The begin number of led which will be light up
    MI_U16 u16EndLedNum;                           //<The end number of led which will be light up
    MI_U16 u16DelayTime;                           //<The time delay between two led,the unit is ms
} MI_DISPOUT_LdmSingleLed_t;

//Used for API E_MI_DISPOUT_PANEL_ATTR_LDM_GET_ADDRESS
typedef struct MI_DISPOUT_LdmDataAddr_s
{
    MI_PHY phyLdfAddr;                           // The phyaddress of ldf data
    MI_PHY phyLdbAddr;                           // The phyaddress of ldb data
    MI_PHY phySpiAddr;                           // The phyaddress of spi data
} MI_DISPOUT_LdmDataAddr_t;

//Used for API E_MI_DISPOUT_PANEL_ATTR_LDM_ENABLE_STATUS
typedef struct MI_DISPOUT_LdmStatus_s
{
    MI_BOOL bEnable;                                   //<Enable or Disable LDM
    MI_U8 u8Luma;                                  //<when disable the backlight luma
} MI_DISPOUT_LdmStatus_t;

typedef struct MI_DISPOUT_QueryHandleParams_s
{
    MI_DISPOUT_DeviceType_e eDeviceType;
    MI_U32 u32PortIndex;
} MI_DISPOUT_QueryHandleParams_t;

typedef struct MI_DISPOUT_HdmiEdidBlock_s
{
    MI_U16 u16Index;
    MI_U8  au8BlockRawData[MI_DISPOUT_EDID_DATA_BLOCK_SIZE];
} MI_DISPOUT_HdmiEdidBlock_t;

typedef struct  MI_DISPOUT_DacOutputParams_s
{
    MI_DISPOUT_DacLevel_e eDacLevel;
    MI_DISPOUT_DacSwapSelectType_e eDacSwap;
    MI_DISPOUT_DacCurrentLevel_e eDacCurrent;
} MI_DISPOUT_DacOutputParams_t;

typedef struct MI_DISPOUT_PanelSsc_s
{
    MI_BOOL bEnable;    /// SSC enable
    MI_U16 u16SscSpan;  /// SSC frequency, Unit: 0.1Khz
    MI_U16 u16SscStep;  /// SSC ratio, Unit: 1%% (1/10000)
} MI_DISPOUT_PanelSsc_t;

typedef struct MI_DISPOUT_PowerStatus_s
{
    MI_BOOL bPowerOn;   /// TRUE:Power On, FALSE:Power Off.
} MI_DISPOUT_PowerStatus_t;

/// Dispout module capability
typedef struct MI_DISPOUT_Caps_s
{
    MI_U32 u32SupportPanelCount;    // Support Panel Count
    MI_U32 u32SupportHdmiTxCount;   // Support HdmiTx Count
    MI_U32 u32SupportYpbprCount;    // Support Ypbpr Count
    MI_U32 u32SupportCvbsCount;     // Support Cvbs Count
    MI_U32 u32SupportScartCount;    // Support Scart Count
    MI_U32 u32SupportCh34Count;     // Support Channel3,4 Count
} MI_DISPOUT_Caps_t;

typedef struct MI_DISPOUT_UcdControlInfo_s
{
    MI_U8 u8SupportCurveCount; //Get numbers of UCD support curves.
    MI_U8 u8SupportEntryCount; //Get numbers of support entrys for each UCD curve.
}MI_DISPOUT_UcdControlInfo_t;

typedef struct MI_DISPOUT_UcdCurveInfo_s
{
    MI_U8 u8CurveIndex; //UCD Curve Index.
    MI_U8 u8EntryCount;  //Indicate entry number of the specified UCD curve.
    MI_U8 *pu8Strength; //Strength values for the specified UCD curves.
}MI_DISPOUT_UcdCurveInfo_t;


typedef struct MI_DISPOUT_ExtFrcDeviceInfo_s
{
    MI_DISPOUT_ExtFrcModel_e eExtFrcModel; //External device model.
    MI_U32 u32FwVer;
} MI_DISPOUT_ExtFrcDeviceInfo_t;

typedef struct MI_DISPOUT_PanelPeCurrent_s
{
    MI_U16 u16CurrentLevel;   //current setting
    MI_U32 u32ChannelSelect; //each bit for one ch
}MI_DISPOUT_PanelPeCurrent_t;

//-------------------------------------------------------------------------------------------------
//  Global Functions
//-------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------
/// @brief Init DISPOUT module.
/// @param[in] pstInitParams: Init parameters.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_DISPOUT_Init(const MI_DISPOUT_InitParams_t *pstInitParams);

//------------------------------------------------------------------------------
/// @brief Finalize DISPOUT module.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_DISPOUT_DeInit(void);

//------------------------------------------------------------------------------
/// @brief Open a DISPOUT handle.
/// @param[in] pstOpenParam: A pointer to structure MI_DISPOUT_OpenParams_t for open dispout device.
/// @param[out] phDispout: A handle pointer to retrieve an instance of a dispout device.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_RESOURCES: No available resource.
//------------------------------------------------------------------------------
MI_RESULT MI_DISPOUT_Open(const MI_DISPOUT_OpenParams_t *pstOpenParams, MI_HANDLE *phDispout);

//------------------------------------------------------------------------------
/// @brief Get a DISPOUT handle.
/// @param[in] pstQueryParams: A pointer to structure MI_DISPOUT_QueryHandleParams_t for get dispout device.
/// @param[out] phDispout: A handle pointer to retrieve an instance of a dispout device.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_RESOURCES: No available resource.
//------------------------------------------------------------------------------
MI_RESULT MI_DISPOUT_GetHandle(const MI_DISPOUT_QueryHandleParams_t *pstQueryParams, MI_HANDLE *phDispout);

//------------------------------------------------------------------------------
/// @brief Close a DISPOUT handle.
/// @param[in] hDispout: An instance of a dispout device.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_DISPOUT_Close(MI_HANDLE hDispout);

//------------------------------------------------------------------------------
/// @brief Set the value of attribute about Color/Colordepth/Outputmode/Edid/Spd to a dispout device.
/// @param[in] hDispout: An instance of a dispout device.
/// @param[in] eAttrType: Attribute type.
/// @param[in] pAttrParams: Set attribute value.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_DISPOUT_HdmiSetAttr(MI_HANDLE hDispout, MI_DISPOUT_HdmiAttrType_e eAttrType, const void *pAttrParams);

//------------------------------------------------------------------------------
/// @brief Set the value of attribute about DAC setting to a dispout device.
/// @param[in] hDispout: An instance of a dispout device.
/// @param[in] eAttrType: Attribute type.
/// @param[in] pAttrParams: Set attribute value.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_DISPOUT_DacSetAttr(MI_HANDLE hDispout, MI_DISPOUT_DacAttrType_e eAttrType, const void *pAttrParams);

//------------------------------------------------------------------------------
/// @brief Set the value of attribute about BackLight/Vcc/LvdsSsc/Outputmode to a dispout device.
/// @param[in] hDispout: An instance of a dispout device.
/// @param[in] eAttrType: Attribute type.
/// @param[in] pAttrParams: Set attribute value.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_DISPOUT_PanelSetAttr(MI_HANDLE hDispout, MI_DISPOUT_PanelAttrType_e eAttrType, const void *pAttrParams);

//------------------------------------------------------------------------------
/// @brief Get the value of attribute about Color/Colordepth/Outputmode/Edid/Spd to a dispout device.
/// @param[in] hDispout: An instance of a dispout device.
/// @param[in] eAttrType: Attribute type.
/// @param[in] pInputParams: Always null.
/// @param[out] pOutputParams: Get attribute value.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_DISPOUT_HdmiGetAttr(MI_HANDLE hDispout, MI_DISPOUT_HdmiAttrType_e eAttrType, const void *pInputParams, void * pOutputParams);

//------------------------------------------------------------------------------
/// @brief Get the value of attribute about Dac setting from a dispout device.
/// @param[in] hDispout: An instance of a dispout device.
/// @param[in] eAttrType: Attribute type.
/// @param[in] pInputParams: Get attribute value.
/// @param[out] pOutputParams: Get attribute value.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_DISPOUT_DacGetAttr(MI_HANDLE hDispout, MI_DISPOUT_DacAttrType_e eAttrType, const void * pInputParams, void * pOutputParams);

//------------------------------------------------------------------------------
/// @brief Get the value of attribute about BackLight/Vcc/LvdsSsc/Outputmode/PanelInfo/PwmInfo/PwmSetting from a dispout device.
/// @param[in] hDispout: An instance of a dispout device.
/// @param[in] eAttrType: Attribute type.
/// @param[in] pInputParams: Always null.
/// @param[out] pOutputParams: Get attribute value.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_DISPOUT_PanelGetAttr(MI_HANDLE hDispout, MI_DISPOUT_PanelAttrType_e eAttrType, const void * pInputParams, void * pOutputParams);

//------------------------------------------------------------------------------
/// @brief power on dispout device.
/// @param[in] hDispout: An instance of a dispout device.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_DISPOUT_PowerOn(MI_HANDLE hDispout);

//------------------------------------------------------------------------------
/// @brief power off dispout device.
/// @param[in] hDispout: An instance of a dispout device.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_DISPOUT_PowerOff(MI_HANDLE hDispout);

//------------------------------------------------------------------------------
/// @brief power off dispout device.
/// @param[in] hDispout: An instance of a dispout device.
/// @param[out] pstStatus: Indicate status of the device.
/// @return MI_OK: Process success.
//------------------------------------------------------------------------------
MI_RESULT MI_DISPOUT_GetPowerStatus(MI_HANDLE hDispout, MI_DISPOUT_PowerStatus_t *pstStatus);

//------------------------------------------------------------------------------
/// @brief Set debug level for mi_dispout.c.
/// @param[in] u32DebugLevel.
/// @return MI_OK: mask success.
//------------------------------------------------------------------------------
MI_RESULT MI_DISPOUT_SetDebugLevel(MI_DBG_LEVEL u32DebugLevel);

//------------------------------------------------------------------------------
/// @brief Set VBI TTX data.
/// @param[in] pstTtxData->pu8DataAddr: The memory adddress of TTX data.
/// @param[in] pstTtxData->u32DataLen: The data length of TTX data.
/// @param[in] pstTtxData->bEnable: Start to send TTX data or not.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_RESOURCES: Memory allocate fail.
//------------------------------------------------------------------------------
MI_RESULT MI_DISPOUT_SendVbiTtx(MI_HANDLE hDispout, MI_DISPOUT_TtxData_t *pstTtxData);

//------------------------------------------------------------------------------
/// @brief Dispout module capability.
/// @param[in] pstCaps: Dispout module capability.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_DISPOUT_GetCaps(MI_DISPOUT_Caps_t *pstCaps);


#ifdef __cplusplus
}
#endif


#endif///_MI_DISPOUT_H_
