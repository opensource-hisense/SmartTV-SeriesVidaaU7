/*------------------------------------------------------------------------------
 * MediaTek Inc. (C) 2018. All rights reserved.
 *
 * Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 *----------------------------------------------------------------------------*/
//-------------------------------------------------------------------------------------------------
//  GetXxx/SetXxx and GetAttr/SetAttr coexist
//-------------------------------------------------------------------------------------------------

#ifndef _MI_DMX_H_
#define _MI_DMX_H_

#ifdef __cplusplus
extern "C" {
#endif

//-------------------------------------------------------------------------------------------------
//  Defines - Constant
//-------------------------------------------------------------------------------------------------
#define MI_DMX_PID_NULL                                         (0x1FFF)

//-------------------------------------------------------------------------------------------------
//  Defines - Macros
//-------------------------------------------------------------------------------------------------

//-------------------------------------------------------------------------------------------------
//  Types - Enums
//-------------------------------------------------------------------------------------------------
typedef enum
{
    E_MI_DMX_FILTER_TYPE_SECTION_MIN = 0,                             ///< min section type
    E_MI_DMX_FILTER_TYPE_SECTION = E_MI_DMX_FILTER_TYPE_SECTION_MIN,  ///< section data, PAT, PMT, SDT, EIT,....
    E_MI_DMX_FILTER_TYPE_PACKET,                                      ///< 188 bytes packets data
    E_MI_DMX_FILTER_TYPE_PES,                                         ///< PES data, Teletext, subtitles
    E_MI_DMX_FILTER_TYPE_TTX,                                         ///< TTX data, Teletext ES data
    E_MI_DMX_FILTER_TYPE_SECTION_MAX,                                 ///< max section type.

    E_MI_DMX_FILTER_TYPE_AV_MIN = 0x100,                              ///< min av type
    E_MI_DMX_FILTER_TYPE_VIDEO = E_MI_DMX_FILTER_TYPE_AV_MIN,         ///< Video playback
    E_MI_DMX_FILTER_TYPE_AUDIO,                                       ///< Audio playback(main)
    E_MI_DMX_FILTER_TYPE_AV_MAX,                                      ///< max av type

    E_MI_DMX_FILTER_TYPE_PCR = 0x200,                                 ///< PCR
    E_MI_DMX_FILTER_TYPE_PVR,                                         ///< record

    E_MI_DMX_FILTER_TYPE_MAX,                                         ///< Enum of max supported file types
} MI_DMX_FilterType_e;

typedef enum
{
    ///section/pes/packet data ready, callback function output a struct of MI_DMX_DataReadyParams_t
    E_MI_DMX_CALLBACK_EVENT_DATA_READY      = MI_BIT(0),
    E_MI_DMX_CALLBACK_EVENT_BUFFER_OVERFLOW = MI_BIT(1),
    E_MI_DMX_CALLBACK_EVENT_MAX,
} MI_DMX_CallbackEvent_e;

typedef enum
{
    E_MI_DMX_SECT_CRC_IGNORE = 0x00,                    ///< no CRC checking
    E_MI_DMX_SECT_CRC_CHECK,                            ///< force CRC checking
    E_MI_DMX_SECT_CRC_AUTO,                             ///< Auto check CRC depends on section_synctax_indicator

    E_MI_DMX_SECT_CRC_MAX,                              ///< Enum of max supported CRC mode.
} MI_DMX_SectCrcMode_e;

typedef enum
{
    E_MI_DMX_SECT_MODE_CALLBACK = 0,                    ///< get section data by callback mode
    E_MI_DMX_SECT_MODE_NOTIFICATION,                    ///< get section data by notification mode
    E_MI_DMX_SECT_MODE_POLLING,                         ///< get section data by polling mode

    E_MI_DMX_SECT_MODE_MAX,                             ///< Enum of max supported section mode.
} MI_DMX_SectMode_e;

typedef enum
{
    E_MI_DMX_SCMB_DETECT_CLR = 0,
    E_MI_DMX_SCMB_DETECT_SCRAMB,
    E_MI_DMX_SCMB_DETECT_NODATA,
    E_MI_DMX_SCMB_DETECT_NOTSUPPORT,
    E_MI_DMX_SCMB_DETECT_MAX,
} MI_DMX_ScrambleDetect_e;

typedef enum
{
    E_MI_DMX_ATTR_TYPE_LOCKED_PACKET_COUNTER = 0,       ///< Get only, pInputParams is a pointer to MI_DMX_Path_e, and pOutputParams is a pointer to struct MI_DMX_PktCntInfo_t
    E_MI_DMX_ATTR_TYPE_AV_PACKET_COUNTER,               ///< Get only, pInputParams is a pointer to MI_DMX_Path_e, and pOutputParams is a pointer to struct MI_DMX_AvPktCntInfo_t
    E_MI_DMX_ATTR_TYPE_AV_DISCONT_PACKET_COUNTER,       ///< Get only, pInputParams is a pointer to MI_DMX_Path_e, and pOutputParams is a pointer to struct MI_DMX_AvPktCntInfo_t
    E_MI_DMX_ATTR_TYPE_AV_DROPPED_PACKET_COUNTER,       ///< Get only, pInputParams is a pointer to MI_DMX_Path_e, and pOutputParams is a pointer to struct MI_DMX_AvPktCntInfo_t
    E_MI_DMX_ATTR_TYPE_HW_BUFFER_ADDRESS,               ///< Get only, pInputParams is NULL, and pOutputParams is a pointer to struct MI_DMX_HwBufAddr_t
    E_MI_DMX_ATTR_TYPE_SCRAMBLE_STATUS,                 ///< Get only, pInputParams is NULL, and pOutputParams is a pointer to type MI_U32
    E_MI_DMX_ATTR_TYPE_DMX_ID,                          ///< Get only, Get driver dmx id, pInputParams is NULL, and pOutputParams is a pointer to type MI_U32
    E_MI_DMX_ATTR_TYPE_SCRAMBLE_DETECT,                 ///< Get only, pInputParams is a pointer to MI_DMX_ScmbCntParams_t, and pOutputParams is a pointer to type MI_DMX_ScrambleDetect_e.

} MI_DMX_AttrType_e;

//-------------------------------------------------------------------------------------------------
//  Types - Structures
//-------------------------------------------------------------------------------------------------
typedef struct MI_DMX_DataReadyParams_s
{
    MI_U8 *pu8SectionBuf;                               ///< [OUT]: pointer to a section data
    MI_U32 u32SectionLen;                               ///< [OUT]: length of section data
} MI_DMX_DataReadyParams_t;

typedef struct MI_DMX_Caps_s
{
    MI_S32 s32MaxPidFiltNum;                            ///< [OUT]: max supported DMX PID filters
    MI_S32 s32MaxSecFiltDepth;                          ///< [OUT]: max supported depth of section filter
    MI_S32 s32MaxSectFiltNum;                           ///< [OUT]:  max supported DMX Section filters
} MI_DMX_Caps_t;

typedef struct MI_DMX_InitParams_s
{
    MI_PHY phyTspFwBufAddr;                             ///< [IN]: TSP FW buffer physical address
    MI_U32 u32TspFwBufSize;                             ///< [IN]: size of TSP FW buffer

    MI_PHY phyTspVqBufAddr;                             ///< [IN]: TSP VQ buffer physical address
    MI_U32 u32TspVqBufSize;                             ///< [IN]: size of TSP VQ buffer

    MI_U32 u32TspBufPoolId;                             ///< [IN]: pool id for tsp hw buffer allocation
    MI_BOOL bIgnoreSectionCcCheck;                      ///< [IN]: ignore continuity counter check
} MI_DMX_InitParams_t;

///< The prototype of callback function which is called after received a complete section.
typedef MI_RESULT (*MI_DMX_EventCallback)(MI_HANDLE hDmx, MI_U32 u32Event, void *pEventParams, void *pUserParams);

///< The prototype of callback function which is called after received a packet with PUSI and PES start code.
typedef void (*MI_DMX_ScmbDete_NotifyCb)(MI_HANDLE *phAVidDmx, MI_DMX_ScrambleDetect_e *peScmbStat);

typedef struct MI_DMX_CallbackInputParams_s
{
    MI_DMX_EventCallback pfEventCallback;               ///< [IN]: callback function pointer.
    MI_U32 u32EventFlags;                               ///< [IN]: registered events define of MI_DMX_CallbackEvent_e
    void * pUserParams;                                 ///< [IN]: for passing user-defined parameters.
} MI_DMX_CallbackInputParams_t;

typedef struct MI_DMX_FilterParams_s
{
    MI_DMX_SectMode_e eSectMode;                        ///< [IN]: the mode to get section data
    MI_U32 u32HwBufferSize;                             ///< [IN]: Size of buffer for hardware storing the collected section data.
    MI_DMX_SectCrcMode_e eCrcMode;                      ///< [IN]: CRC mode for section filter type
    MI_BOOL bOneShot;                                   ///< [IN]: Auto stop section collection after received a complete section.
} MI_DMX_FilterParams_t;

typedef struct MI_DMX_PathParams_s
{
    MI_HANDLE hTsio;                                    ///< [IN]: The Tsio handle that the filter will connect
    MI_HANDLE hSource;                                  ///< [IN]: When merge stream case, the data source handle that filter will select
} MI_DMX_PathParams_t;

typedef struct MI_DMX_OpenParams_s
{
    MI_DMX_PathParams_t stPathParams;                   ///< [IN]: parameters of the filter source
    MI_DMX_FilterType_e eFiltType;                      ///< [IN]: Filter type

    MI_DMX_FilterParams_t stFiltParams;                 ///< [IN]: parameters of section filter type, only for the following filter types:
    MI_DMX_CallbackInputParams_t stCallbackInputParams; ///< [IN]: the callback parameters,only for the following filter types:
    ///< E_MI_DMX_FILTER_TYPE_SECTION
    ///< E_MI_DMX_FILTER_TYPE_PACKET
    ///< E_MI_DMX_FILTER_TYPE_PES
    ///< E_MI_DMX_FILTER_TYPE_TTX
} MI_DMX_OpenParams_t;

typedef struct MI_DMX_StartParams_s
{
    MI_U8 u8Reserved;                                   ///< [IN]: reserved.
} MI_DMX_StartParams_t;

typedef struct MI_DMX_PatternParams_s
{
    MI_U8 *pu8Match;                                    ///< [IN]: match data of section filter, the data doesn't include section length info
    MI_U8 *pu8Mask;                                     ///< [IN]: mask of section filter, the data doesn't include section length info
    MI_U8 *pu8Negate;                                   ///< [IN]: negate data of section filter, the data doesn't include section length info
    MI_U8 u8Depth;                                      ///< [IN]: depth of section filter
} MI_DMX_PatternParams_t;

typedef struct MI_DMX_WaitParams_s
{
    MI_U32 u32WaitId;                                   ///< [IN]: an ID to distinguish between different wait
    MI_U32 u32DmxFiltNum;                               ///< [IN]: the number of dmx filter to be watched
    MI_HANDLE *phDmxFiltList;                           ///< [IN]: the handle list of dmx filter to be watched
    MI_U32 u32Timeout;                                  ///< [IN]: the waiting time, unit is ms

    MI_U32 u32ArrivedDmxFiltNum;                        ///< [OUT]: IN: the size of phArrivedDmxFiltList, OUT:the number of dmx filter that has section arrived
    MI_HANDLE *phArrivedDmxFiltList;                    ///< [OUT]: the handle list of dmx filter that has section arrived
} MI_DMX_WaitParams_t;

typedef struct MI_DMX_ObtainDataInfo_s
{
    MI_VIRT virtDataAddr;                               ///< [OUT]: data buffer address.
    MI_U32 u32DataSize;                                 ///< [OUT]: data length.
    MI_BOOL bHasMoreData;                               ///< [OUT]: the boolean of remain data.
} MI_DMX_ObtainDataInfo_t;

typedef struct MI_DMX_ReleaseDataInfo_s
{
    MI_VIRT virtDataAddr;                               ///< [IN]: data buffer address.
    MI_U32 u32DataSize;                                 ///< [IN]: data length.
} MI_DMX_ReleaseDataInfo_t;

typedef struct MI_DMX_PktCntInfo_s
{
    MI_U32 u32PktCnt;                                   ///< [OUT]: packet count.

} MI_DMX_PktCntInfo_t;

typedef struct MI_DMX_AvPktCntInfo_s
{
    MI_U32 u32VidPktCnt;                                ///< [OUT]: Video packet count.
    MI_U32 u32AudPktCnt;                                ///< [OUT]: Audio packet count.

} MI_DMX_AvPktCntInfo_t;

typedef struct MI_DMX_ScmbCntParams_s
{
    MI_BOOL                   bScmbCntMode;             ///< [IN]: Switch polling mode or callback mode (0: polling, 1: callback)
} MI_DMX_ScmbCntParams_t;

typedef struct MI_DMX_HwBufAddr_s
{
    MI_VIRT virtStartAddr;                              ///< [OUT]: hardware buffer start address
    MI_VIRT virtEndAddr;                                ///< [OUT]: hardware buffer end address
    MI_VIRT virtReadAddr;                               ///< [OUT]: hardware buffer read pointer address
    MI_VIRT virtWriteAddr;                              ///< [OUT]: hardware buffer write pointer address
} MI_DMX_HwBufAddr_t;

typedef struct MI_DMX_DumpInfoParams_s
{
    MI_BOOL bAll;
} MI_DMX_DumpInfoParams_t;

//-------------------------------------------------------------------------------------------------
//  Functions
//-------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------
/// @brief Get DMX module capibilities.
/// @param[out] pstDmxCap: A pointer to structure MI_DMX_Caps_t to retrieve the information of DMX capabilities
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_DMX_GetCaps(MI_DMX_Caps_t *pstCaps);

//------------------------------------------------------------------------------
/// @brief Init DMX module.
/// @param[in] pstInitParams: A pointer to structure MI_DMX_InitParams_t for initialization.
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_RESOURCES: No available resource.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_DMX_Init(const MI_DMX_InitParams_t *pstInitParams);

//------------------------------------------------------------------------------
/// @brief Finalize DMX module.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_DMX_DeInit(void);

//------------------------------------------------------------------------------
/// @brief Create a DMX handle.
/// @param[in] pstOpenParams: Pointer to MI_DMX_OpenParams_t for creating a DMX pid filter.
/// @param[out] phDmx: A handle pointer to retrieve an instance of a created DMX pid filter.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_RESOURCES: No available resource.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_DMX_Open(const MI_DMX_OpenParams_t *pstOpenParams, MI_HANDLE *phDmx);

//------------------------------------------------------------------------------
/// @brief Destroy a DMX handle.
/// @param[in] hDmx: An instance of a created DMX pid filter.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_DMX_Close(MI_HANDLE hDmx);

//------------------------------------------------------------------------------
/// @brief Set PID for a DMX handle.
/// @param[in] hDmx: An instance of a created DMX pid filter.
/// @param[in] u16Pid: PID value to be set
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_DMX_SetPid(MI_HANDLE hDmx, MI_U16 u16Pid);

//------------------------------------------------------------------------------
/// @brief Get PID for a DMX handle.
/// @param[in] hDmx: An instance of a created DMX pid filter.
/// @param[out] pu16Pid: A pointer to MI_U16 to retrieve the PID value.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_DMX_GetPid(MI_HANDLE hDmx, MI_U16 *pu16Pid);

//------------------------------------------------------------------------------
/// @brief Set CRC mode for a DMX handle.
/// @param[in] hDmx: An instance of a created DMX pid filter.
/// @param[in] eMode: A enum type MI_DMX_SectCrcMode_e to configure the CRC mode of a section.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_DMX_SetCrcMode(MI_HANDLE hDmx, MI_DMX_SectCrcMode_e eCrcMode);

//------------------------------------------------------------------------------
/// @brief Get CRC mode for a DMX handle.
/// @param[in] hDmx: An instance of a created DMX pid filter.
/// @param[out] peMode: A pointer to enum type MI_DMX_SectCrcMode_e to retrieve the current setting of CRC mode.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_DMX_GetCrcMode(MI_HANDLE hDmx, MI_DMX_SectCrcMode_e *peCrcMode);

//------------------------------------------------------------------------------
/// @brief Set pattern for a DMX handle.
/// @param[in] hDmx: An instance of a created DMX pid filter.
/// @param[in] pstPatternParams: A pointer of structure MI_DMX_PatternParams_t for setting the section filter.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_DMX_SetPattern(MI_HANDLE hDmx, MI_DMX_PatternParams_t *pstPatternParams);

//------------------------------------------------------------------------------
/// @brief Get pattern for a DMX handle.
/// @param[in] hDmx: An instance of a created DMX pid filter.
/// @param[in] pstPatternParams: A pointer of structure MI_DMX_PatternParams_t for getting the section filter.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_DMX_GetPattern(MI_HANDLE hDmx, MI_DMX_PatternParams_t *pstPatternParams);

//------------------------------------------------------------------------------
/// @brief Clear pattern for a DMX handle.
/// @param[in] hDmx: An instance of a created DMX pid filter.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_DMX_ClearPattern(MI_HANDLE hDmx);

//------------------------------------------------------------------------------
/// @brief Start PID filter for a DMX handle.
/// @param[in] hDmx: An instance of a created DMX pid filter.
/// @param[in] pstStartParams:Pointer to MI_DMX_StartParams_t set start parameters
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_DMX_Start(MI_HANDLE hDmx, const MI_DMX_StartParams_t *pstStartParams);

//------------------------------------------------------------------------------
/// @brief Stop PID filter for a DMX handle.
/// @param[in] hDmx: An instance of a created DMX pid filter.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_DMX_Stop(MI_HANDLE hDmx);

//------------------------------------------------------------------------------
/// @brief Reset PID filter for a DMX handle.
/// @param[in] hDmx: An instance of a created DMX pid filter.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_DMX_Reset(MI_HANDLE hDmx);

//------------------------------------------------------------------------------
/// @brief Wait data arrived by watching dmx filter list, for E_MI_DMX_SECT_MODE_POLLING only.
/// @param[in] pstWaitParams: A pointer of structure MI_DMX_WaitParams_t for setting wait parameters.
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_TIMEOUT: Timeout.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_DMX_WaitDataArrived (MI_DMX_WaitParams_t *pstWaitParams);

//------------------------------------------------------------------------------
/// @brief Obtain data buffer from dmx filter.
/// @param[in] hDmx: An instance of a created DMX pid filter.
/// @param[out] pstObtainDataInfo: A pointer to MI_DMX_ObtainDataInfo_t for data buffer info.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_DMX_ObtainData(MI_HANDLE hDmx, MI_DMX_ObtainDataInfo_t *pstObtainDataInfo);

//------------------------------------------------------------------------------
/// @brief Release data buffer to dmx filter.
/// @param[in] hDmx: An instance of a created DMX pid filter.
/// @param[in] pstReleaseDataInfo: A pointer to MI_DMX_ReleaseDataInfo_t to data buffer info.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_DMX_ReleaseData(MI_HANDLE hDmx, MI_DMX_ReleaseDataInfo_t *pstReleaseDataInfo);

//------------------------------------------------------------------------------
/// @brief Get DMX information of the specified attribute.
/// @param[in] hDmx: An instance of a created DMX pid filter.
/// @param[in] eAttrType: The attribute type to be set
/// @param[in] pInputParams:A pointer of input parameters
/// @param[out] pOutputParams: The specified parameter correspoing to the enum type MI_SYNC_AttrType_e to retrieve the attribute.
/// @return MI_OK: Set debug level success.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_DMX_GetAttr(MI_HANDLE hDmx, MI_DMX_AttrType_e eAttrType, const void * pInputParams, void * pOutputParams);

//------------------------------------------------------------------------------
/// @brief Change hardware buffer size.
/// @param[in] hDmx: An instance of a created DMX pid filter.
/// @param[in] u32BufferSize: Section buffer size.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_RESOURCES: No available resource.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_DMX_ChangeSectionBufferSize(MI_HANDLE hDmx, MI_U32 u32BufferSize);

//------------------------------------------------------------------------------
/// @brief Update hardware buffer read position.
/// @param[in] hDmx: An instance of a created DMX pid filter.
/// @param[in] virtReadPositionAddr: Read position.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_RESOURCES: No available resource.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_DMX_UpdateHwBufReadPosition(MI_HANDLE hDmx, MI_VIRT virtReadPositionAddr);

//------------------------------------------------------------------------------
/// @brief Dump DMX Info.
/// @param[in] bAll: TRUE for print all resources, FALSE for print opned resources only.
/// @return MI_OK: Dump information success.
//------------------------------------------------------------------------------
MI_RESULT MI_DMX_DumpInfo(const MI_DMX_DumpInfoParams_t *pstDumpInfoParams);

//------------------------------------------------------------------------------
/// @brief Set DMX debug level.
/// @param[in] u32DbgLevel: Debug level defined in enum type MI_DBG_LEVEL
/// @return MI_OK: Set debug level success.
//------------------------------------------------------------------------------
MI_RESULT MI_DMX_SetDebugLevel(MI_DBG_LEVEL u32DebugLevel);

#ifdef __cplusplus
}
#endif

#endif///_MI_DMX_H_


