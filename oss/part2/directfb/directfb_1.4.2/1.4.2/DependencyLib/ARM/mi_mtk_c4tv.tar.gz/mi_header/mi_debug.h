/*------------------------------------------------------------------------------
 * MediaTek Inc. (C) 2018. All rights reserved.
 *
 * Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 *----------------------------------------------------------------------------*/

#ifndef _MI_DEBUG_H_
#define _MI_DEBUG_H_

#ifdef __cplusplus
extern "C" {
#endif

//-------------------------------------------------------------------------------------------------
//  Defines
//-------------------------------------------------------------------------------------------------

#define MI_DEBUG_ENABLE                             1

#define MI_DEBUG_MAX_CMD_NAME_LENGTH                40
#define MI_DEBUG_MAX_CUSTOM_CMD                     32
#define MI_DEBUG_PRINT(fmt, args...)     ({do{MI_PRINT(fmt, ##args);}while(0);})


typedef MI_RESULT (*MI_DEBUG_FUNC)(MI_VIRT p0, MI_VIRT p1, MI_VIRT p2, MI_VIRT p3, MI_VIRT p4, MI_VIRT p5, MI_VIRT p6, MI_VIRT p7);

//-------------------------------------------------------------------------------------------------
//  Structures
//-------------------------------------------------------------------------------------------------
typedef struct MI_DEBUG_InitParams_s
{
    MI_BOOL bDisableAutoRun;                         ///< Disable enter debug mode after init
    MI_BOOL bAutoRunByEnvCfg;                   ///< (linux only) Auto run with spy mode by linux env config: "export MI_DEBUG=spy"

} MI_DEBUG_InitParams_t;

typedef struct MI_DEBUG_RegFunc_s
{
    MI_U8 u8CMDName[MI_DEBUG_MAX_CMD_NAME_LENGTH];  ///< command
    MI_U8 u8InputMask;                              ///< 1: input string(MI_U8*), 0: input (MI_U32), example: if u8InputMask = 0x03, then p0 & p1 are (char*), and p2~p7 are (MI_U32)
    MI_DEBUG_FUNC pfDbgFunc;                        ///< debug function pointer
} MI_DEBUG_RegFunc_t;

//-------------------------------------------------------------------------------------------------
//  Global Functions
//-------------------------------------------------------------------------------------------------

//------------------------------------------------------------------------------
/// @brief Init DEBUG module.
/// @param[in] pstInitParams: A pointer to structure MI_DEBUG_InitParams_t for initialization.
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_RESOURCES: No available resource.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_DEBUG_Init(MI_DEBUG_InitParams_t *pstInitParams);

//------------------------------------------------------------------------------
/// @brief Exit and finalize DEBUG module.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_DEBUG_DeInit(void);

//------------------------------------------------------------------------------
/// @brief Enter DEBUG mode.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_DEBUG_Run(void);

//------------------------------------------------------------------------------
/// @brief Check whether current is under DEBUG mode.
/// @param[in] pIsRunning: A pointer to retrieve whether current is running or not.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_DEBUG_IsRunning(MI_BOOL *pIsRunning);

//------------------------------------------------------------------------------
/// @brief Register a custom command. Maximum custom command is #defined MI_DEBUG_MAX_CUSTOM_CMD
/// @param[in] pstRegFunc: Pointer to struct MI_DEBUG_RegFunc_t for registering a new command.
/// @param[out] pu32RegFuncNum: Pointer to retrieve the current registered custom command.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_INVALID_PARAMETER: Invalid parameter input.
/// @return MI_ERR_RESOURCES: The registration is full.
/// @return MI_ERR_DATA_ERROR: Duplicate command
//------------------------------------------------------------------------------
MI_RESULT MI_DEBUG_RegisterDbgFunc(MI_DEBUG_RegFunc_t *pstRegFunc, MI_U32 *pu32RegFuncNum);

//------------------------------------------------------------------------------
/// @brief Set debug level.
/// @param[in] eDgbLevel: Debug level defined in enum type MI_DBG_LEVEL
/// @return MI_OK: Set debug level success.
//------------------------------------------------------------------------------
MI_RESULT MI_DEBUG_SetDebugLevel(MI_DBG_LEVEL eDgbLevel);


#ifdef __cplusplus
}
#endif

#endif///_MI_DEBUG_H_

