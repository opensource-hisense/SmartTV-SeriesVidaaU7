/*------------------------------------------------------------------------------
 * MediaTek Inc. (C) 2018. All rights reserved.
 *
 * Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 *----------------------------------------------------------------------------*/
//-------------------------------------------------------------------------------------------------
// Use GetXxx/SetXxx Only
//-------------------------------------------------------------------------------------------------
#ifndef _MI_NET_H_
#define _MI_NET_H_

#ifdef __cplusplus
extern "C" {
#endif

//-------------------------------------------------------------------------------------------------
//  Defines
//-------------------------------------------------------------------------------------------------
#define MI_NET_MAC_LENGTH 20
#define MI_NET_INTERFACE_NAME_MAX 16
#define MI_NET_INTERFACE_MAX 20
#define MI_NET_HOST_IP_NAME_MAX 64
#define MI_NET_IP_ADDRESS_LENGTH 64

//-------------------------------------------------------------------------------------------------
//  Structures
//-------------------------------------------------------------------------------------------------
typedef enum
{
    E_MI_NET_NIC_MODE_INVALID = -1,
    E_MI_NET_NIC_MODE_AUTO_CONFIG = 0,
    E_MI_NET_NIC_MODE_10BASE_HALF_DUMPLEX,
    E_MI_NET_NIC_MODE_10BASE_FULL_DUMPLEX,
    E_MI_NET_NIC_MODE_100BASE_HALF_DUMPLEX,
    E_MI_NET_NIC_MODE_100BASE_FULL_DUMPLEX,
    E_MI_NET_NIC_MODE_MAX
} MI_NET_NicMode_e;

typedef enum
{
    E_MI_NET_DEVICE_STATUS_DOWN = 0,                //device down
    E_MI_NET_DEVICE_STATUS_UP,                           //device up
} MI_NET_DeviceStatus_e;

typedef enum
{
    E_MI_NET_PHYSICAL_LINK_STATUS_DISCONNECT = 0, //physical layer not connect: ex.RJ-45 plug-out
    E_MI_NET_PHYSICAL_LINK_STATUS_CONNECT,            //RJ-45 plug-in
} MI_NET_PhysicalLinkStatus_e;

typedef enum
{
    E_MI_NET_NETWORK_TYPE_IPV4 = 0, // ipv4
    E_MI_NET_NETWORK_TYPE_IPV6,     // ipv6
} MI_NET_NetworkType_e;

typedef enum
{
    E_MI_NET_DHCP_TYPE_IPV4_MIN = 0,   // ipv4
    E_MI_NET_DHCP_TYPE_IPV4_DHCPV4 = E_MI_NET_DHCP_TYPE_IPV4_MIN,
    E_MI_NET_DHCP_TYPE_IPV4_MAX,
    E_MI_NET_DHCP_TYPE_IPV6_MIN = 100, // ipv6
    E_MI_NET_DHCP_TYPE_IPV6_STATELESS_AUTO = E_MI_NET_DHCP_TYPE_IPV6_MIN,
    E_MI_NET_DHCP_TYPE_IPV6_STATEFUL_DHCPV6,
    E_MI_NET_DHCP_TYPE_IPV6_STATELESS_DHCPV6,
    E_MI_NET_DHCP_TYPE_IPV6_MAX,
} MI_NET_DhcpType_e;

typedef struct MI_NET_Status_s
{
    MI_NET_DeviceStatus_e eDevStatus;               ///[OUT]: DEVICE STATUS
    MI_NET_PhysicalLinkStatus_e ePhyLinkStatus;  ///[OUT]: PHYSICAL LINK STATUS
} MI_NET_Status_t;

typedef struct MI_NET_PingParams_s
{
    MI_U8 szHostIp[MI_NET_HOST_IP_NAME_MAX];            ///[IN]: Host IP
    MI_U32 u32PingTimes;        ///[IN]: Ping times
    MI_U32 u32Timeout;           ///[IN]: Timeout in msec
    MI_U16 u16DataBlockSize;  ///[IN]: Data block size
} MI_NET_PingParams_t;

typedef struct MI_NET_PingResult_s
{
    MI_U32 u32SuccessCount;  ///[OUT]: Success count
    MI_U32 u32FailCount;         ///[OUT]: Fail count
    MI_U32 u32MinTime;          ///[OUT]: Minimal time in msec
    MI_U32 u32MaxTime;         ///[OUT]: Maximun time in  msec
    MI_U32 u32AvgTime;         ///[OUT]: Average time in msec
} MI_NET_PingResult_t;

typedef struct MI_NET_InitParams_s
{
    MI_U8 u8Reserved;           ///[IN]: Reserved
} MI_NET_InitParams_t;

typedef struct MI_NET_OpenParams_s
{
    MI_U8 szInterfaceName[MI_NET_INTERFACE_NAME_MAX];  ///[IN]: Interface name
} MI_NET_OpenParams_t;

typedef struct MI_NET_IpAddrParams_s
{
    MI_U8 szIpAddress[MI_NET_IP_ADDRESS_LENGTH];
    MI_U8 u8Prefix; // for ipv6
    MI_U8 u8Scope;  // for ipv6
} MI_NET_IpAddrParams_t;

typedef struct MI_NET_NetMaskParams_s
{
    MI_U8 szNetMaskAddress[MI_NET_IP_ADDRESS_LENGTH];
    MI_U8 u8Prefix; // for ipv6
} MI_NET_NetMaskParams_t;

typedef struct MI_NET_GatewayParams_s
{
    MI_U8 szGatewayAddress[MI_NET_IP_ADDRESS_LENGTH];
    MI_U8 u8Prefix; //for ipv6
} MI_NET_GatewayParams_t;

//-------------------------------------------------------------------------------------------------
//  Global Functions
//-------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------
/// @brief Init NET module.
/// @param[in] pstInitParam..
/// @return MI_OK: Process success.
/// @return MI_HAS_INITED: UART module had inited.
//------------------------------------------------------------------------------
MI_RESULT MI_NET_Init(const MI_NET_InitParams_t *pstInitParams);

//------------------------------------------------------------------------------
/// @brief Finalize NET module.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process failed
//------------------------------------------------------------------------------
MI_RESULT MI_NET_DeInit(void);

//------------------------------------------------------------------------------
/// @brief Open the NET handle.
/// @param[in] pstOpenParam. Parameter to open uart
/// @param[out] phNet. return net handle after opening success
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not inted.
/// @return MI_ERR_INVALID_PARAMETER: parameter error.
/// @return MI_ERR_RESOURCES: No available resource.
/// @return MI_ERR_FAILED: Process failed
//------------------------------------------------------------------------------
MI_RESULT MI_NET_Open(const MI_NET_OpenParams_t *pstOpenParams, MI_HANDLE *phNet);

//------------------------------------------------------------------------------
/// @brief Close a NET handle.
/// @param[in] hNet. Net handle to close
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not inted.
/// @return MI_ERR_INVALID_HANDLE: Invalid handle.
//------------------------------------------------------------------------------
MI_RESULT MI_NET_Close(MI_HANDLE hNet);

//------------------------------------------------------------------------------
/// @brief Ping a target server by IP
/// @param[in] hNet. Net handle to process
/// @param[in] eNetworkType. Network address type
/// @param[in] stPingParam. ping parameters to set
/// @param[out] pstPingResult. ping result
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not inted.
/// @return MI_ERR_INVALID_HANDLE: Invalid handle.
/// @return MI_ERR_INVALID_PARAMETER: parameter error.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_NET_Ping(MI_HANDLE hNet, MI_NET_NetworkType_e eNetworkType, MI_NET_PingParams_t stPingParams, MI_NET_PingResult_t *pstPingResult);

//------------------------------------------------------------------------------
/// @brief Network Device Up
/// @param[in] hNet. Net handle to process
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not inted.
/// @return MI_ERR_INVALID_HANDLE: Invalid handle.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_NET_DeviceUp(MI_HANDLE hNet);

//------------------------------------------------------------------------------
/// @brief Network Device Down
/// @param[in] hNet. Net handle to process
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not inted.
/// @return MI_ERR_INVALID_HANDLE: Invalid handle.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_NET_DeviceDown(MI_HANDLE hNet);

//------------------------------------------------------------------------------
/// @brief Use Network DHCP to get IP
/// @param[in] hNet. Net handle to process
/// @param[in] eDhcpType. DHCP type
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not inted.
/// @return MI_ERR_INVALID_HANDLE: Invalid handle.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_NET_DhcpOn(MI_HANDLE hNet, MI_NET_DhcpType_e eDhcpType);

//------------------------------------------------------------------------------
/// @brief Destroy Network DHCP process
/// @param[in] hNet. Net handle to process
/// @param[in] eDhcpType. DHCP type
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not inted.
/// @return MI_ERR_INVALID_HANDLE: Invalid handle.
//------------------------------------------------------------------------------
MI_RESULT MI_NET_DhcpOff(MI_HANDLE hNet, MI_NET_DhcpType_e eDhcpType);

//------------------------------------------------------------------------------
/// @brief Set Mac Address to Device
/// @param[in] hNet. Net handle to process
/// @param[in] pszMac. Mac address to set
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not inted.
/// @return MI_ERR_INVALID_HANDLE: Invalid handle.
/// @return MI_ERR_INVALID_PARAMETER: parameter error.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_NET_SetMac(MI_HANDLE hNet, MI_U8 *pszMac);

//------------------------------------------------------------------------------
/// @brief Set Network DNS address
/// @param[in] bCover. True: Cover dns, False: Add to last
/// @param[in] pszDns. pointer to get dns address
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not inted.
/// @return MI_ERR_INVALID_PARAMETER: parameter error.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_NET_SetDns(MI_HANDLE hNet, MI_BOOL bCover, MI_U8 *pszDns);

//------------------------------------------------------------------------------
/// @brief Set Network IP Address
/// @param[in] hNet. Net handle to process
/// @param[in] eNetworkType. Network address type
/// @param[in] pstIpAddrParams. the ip struct to be set
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not inted.
/// @return MI_ERR_INVALID_HANDLE: Invalid handle.
/// @return MI_ERR_INVALID_PARAMETER: parameter error.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_NET_SetIpAddr(MI_HANDLE hNet, MI_NET_NetworkType_e eNetworkType, MI_NET_IpAddrParams_t* pstIpAddrParams);

//------------------------------------------------------------------------------
/// @brief Set Network Netmask
/// @param[in] hNet. Net handle to process
/// @param[in] eNetworkType. Network address type
/// @param[in] pstNetMaskParams. the netmask struct to be set
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not inted.
/// @return MI_ERR_INVALID_HANDLE: Invalid handle.
/// @return MI_ERR_INVALID_PARAMETER: parameter error.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_NET_SetNetMask(MI_HANDLE hNet, MI_NET_NetworkType_e eNetworkType, MI_NET_NetMaskParams_t *pstNetMaskParams);

//------------------------------------------------------------------------------
/// @brief Set Network Gateway
/// @param[in] hNet. Net handle to process
/// @param[in] eNetworkType. Network address type
/// @param[in] pstGatewayParams. the gateway struct to be set
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not inted.
/// @return MI_ERR_INVALID_HANDLE: Invalid handle.
/// @return MI_ERR_INVALID_PARAMETER: parameter error.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_NET_SetGateway(MI_HANDLE hNet, MI_NET_NetworkType_e eNetworkType, MI_NET_GatewayParams_t *pstGatewayParams);

//------------------------------------------------------------------------------
/// @brief Get Network Connect Status
/// @param[in] hNet. Net handle to process
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not inted.
/// @return MI_ERR_INVALID_PARAMETER: parameter error.
/// @return MI_ERR_INVALID_HANDLE: Invalid handle.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_NET_GetConnectStatus(MI_HANDLE hNet, MI_NET_Status_t *pstStatus);

//------------------------------------------------------------------------------
/// @brief Get Network MAC address
/// @param[in] hNet. Net handle to process
/// @param[out] pszMac. pointer to get mac address
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not inted.
/// @return MI_ERR_INVALID_HANDLE: Invalid handle.
/// @return MI_ERR_INVALID_PARAMETER: parameter error.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_NET_GetMac(MI_HANDLE hNet, MI_U8 *pszMac);

//------------------------------------------------------------------------------
/// @brief Get Network IP address
/// @param[in] hNet. Net handle to process
/// @param[in] eNetworkType. Network address type
/// @param[out] pstIpAddrParams. pointer to get ip info
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not inted.
/// @return MI_ERR_INVALID_HANDLE: Invalid handle.
/// @return MI_ERR_INVALID_PARAMETER: parameter error.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_NET_GetIpAddr(MI_HANDLE hNet, MI_NET_NetworkType_e eNetworkType, MI_NET_IpAddrParams_t* pstIpAddrParams);

//------------------------------------------------------------------------------
/// @brief Get Network netmask address
/// @param[in] hNet. Net handle to process
/// @param[in] eNetworkType. Network address type
/// @param[out] pstNetMaskParams. pointer to get mask info
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not inted.
/// @return MI_ERR_INVALID_HANDLE: Invalid handle.
/// @return MI_ERR_INVALID_PARAMETER: parameter error.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_NET_GetNetMask(MI_HANDLE hNet, MI_NET_NetworkType_e eNetworkType, MI_NET_NetMaskParams_t *pstNetMaskParams);

//------------------------------------------------------------------------------
/// @brief Get Network geteway address
/// @param[in] hNet. Net handle to process
/// @param[in] eNetworkType. Network address type
/// @param[out] pstGatewayParams. pointer to get gateway info
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not inted.
/// @return MI_ERR_INVALID_HANDLE: Invalid handle.
/// @return MI_ERR_INVALID_PARAMETER: parameter error.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_NET_GetGateway(MI_HANDLE hNet, MI_NET_NetworkType_e eNetworkType, MI_NET_GatewayParams_t *pstGatewayParams);

//------------------------------------------------------------------------------
/// @brief Get Network Nic Mode
/// @param[in] hNet. Net handle to process
/// @param[out] peNicMode. pointer to get the module info
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not inted.
/// @return MI_ERR_INVALID_HANDLE: Invalid handle.
/// @return MI_ERR_INVALID_PARAMETER: parameter error.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_NET_GetNicModeInfo(MI_HANDLE hNet, MI_NET_NicMode_e *peNicMode);

//------------------------------------------------------------------------------
/// @brief Get Network Interface Name
/// @param[out] pszInterfaceName. pointer to get the interface name
/// @param[out] pu8InterfaceCount. pointer to get the total interface
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not inted.
/// @return MI_ERR_INVALID_PARAMETER: parameter error.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_NET_GetInterfaceName(MI_U8 aszInterfaceName[MI_NET_INTERFACE_MAX][MI_NET_INTERFACE_NAME_MAX], MI_U8 *pu8InterfaceCount);

//------------------------------------------------------------------------------
/// @brief Get Network DNS address
/// @param[out] pszDns. pointer to get dns address
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not inted.
/// @return MI_ERR_INVALID_PARAMETER: parameter error.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_NET_GetDns(MI_HANDLE hNet, MI_U8 *pszDns);

//------------------------------------------------------------------------------
/// @brief Set Network module debug level
/// @param[in] interface_name.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_NET_SetDebugLevel(MI_DBG_LEVEL u32DebugLevel);

#ifdef __cplusplus
}
#endif

#endif///_MI_NET_H_

