/*------------------------------------------------------------------------------
 * MediaTek Inc. (C) 2018. All rights reserved.
 *
 * Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 *----------------------------------------------------------------------------*/
//------------------------------------------------------------------------------
// Use GetAttr/SetAttr only
//------------------------------------------------------------------------------

#ifndef _MI_INJECT_H_
#define _MI_INJECT_H_

#ifdef __cplusplus
extern "C" {
#endif

//-------------------------------------------------------------------------------------------------
//  Defines
//-------------------------------------------------------------------------------------------------

//-------------------------------------------------------------------------------------------------
//  Structures
//-------------------------------------------------------------------------------------------------

typedef enum
{
    E_MI_INJECT_STREAM_TS = 0,                  ///< Transport stream, support packet size with 188, 192
    E_MI_INJECT_STREAM_VPES,                    ///< Video PES stream, start from prefix code 00 00 01
    E_MI_INJECT_STREAM_APES,                    ///< Audio PES stream, start from prefix code 00 00 01
    E_MI_INJECT_STREAM_VES,                     ///< Video Elementary Stream
    E_MI_INJECT_STREAM_AES,                     ///< Audio Elementary Stream
    E_MI_INJECT_STREAM_AES_BUFFER,              ///< Audio Elementary Stream with buffer mode
    E_MI_INJECT_STREAM_VES_BUFFER,              ///< Video Elementary Stream with buffer mode
    E_MI_INJECT_STREAM_TS_OUTPUT,               ///< Transport stream, for TSO output case

    E_MI_INJECT_STREAM_MAX,                     ///< Enum value of max supported stream
} MI_INJECT_StreamType_e;

typedef enum
{
    E_MI_INJECT_ATTR_TYPE_STREAM_TYPE = 0,          ///< Stream type, support query only, parameter type is a pointer to MI_INJECT_StreamType_e
    E_MI_INJECT_ATTR_TYPE_TS_PACKET_SIZE,           ///< Packet size, support set and query, parameter type is a pointer to MI_U32
    E_MI_INJECT_ATTR_TYPE_PRE_BUFFER_CTRL,          ///< Enable prebuffer control before starting playack, parameter type is a pointer to MI_INJECT_PreBufferCtrl_t. Set NULL param for disable.
    E_MI_INJECT_ATTR_TYPE_BUFFER_INFO,              ///< Get the buffer information of a speicifed injection stream type, parameter is a pointer to MI_INJECT_InjBufferInfo_t.
    E_MI_INJECT_ATTR_TYPE_ES_BUFFER_LEVEL_CTRL,     ///< Set the vdec es buffer level control paras of a speicifed injection stream type, parameter is a pointer to MI_INJECT_ESBufferLevelCtrl_t.
    E_MI_INJECT_ATTR_TYPE_TS_BYPASS_TIMESTAMP,      ///< Set/Get tsio bypass file-in timestamp enable/disable, parameter is a pointer to MI_BOOL
    E_MI_INJECT_ATTR_TYPE_TS_FILEIN_TIMESTAMP,      ///< Get file-in timestamp, 192 bytes per packet's timestamp from previous 4 bytes, parameter type is a pointer to MI_U32
    E_MI_INJECT_ATTR_TYPE_TS_PLAYBACK_TIMESTAMP,    ///< Set/Get playback timestamp, parameter type is a pointer to MI_U32
    E_MI_INJECT_ATTR_TYPE_MAX,                      ///< Enum value of max attr type
} MI_INJECT_AttrType_e;

typedef enum
{
    E_MI_INJECT_EVENT_DECRYPT = MI_BIT(0),          ///< Event to decrypt the data of source buffer and put it at destination buffer. Parameter type is a pointer to MI_INJECT_DecryptCallbackParams_t.
    E_MI_INJECT_EVENT_MEMORY_COPY = MI_BIT(1),      ///< Event to memory copy the data of source buffer and put it at destination buffer. Parameter type is a pointer to MI_INJECT_MemoryCopyCallbackParams_t.
    E_MI_INJECT_EVENT_MAX,
} MI_INJECT_CallbackEvent_e;

typedef enum
{
    E_MI_INJECT_SECURITY_TYPE_NONE = 0,             ///< No secure system, it means content is clear stream
    E_MI_INJECT_SECURITY_TYPE_SECURE_ENCRYPTION,    ///< Secure Encryption
    E_MI_INJECT_SECURITY_TYPE_MAX,
}MI_INJECT_SecurityType_e;

typedef struct MI_INJECT_EsBufferLevelCtrl_s
{
    MI_BOOL bEnableVdecEsBufLevelCtrl;          /// [IN]: < Enable Vdec ES Buf Lev Control by following condition. Each one is satisfied, we will do filein.
    MI_U32 u32VdecBufWaterMarkInMs;             /// [IN]: < User defined buffer level (msec), if es buffer level is smaller than this value, we will do filein.
    MI_U32 u32VdecBufWaterMarkInBytes;          /// [IN]: < User defined buffer level (bytes), if es buffer level is lower than this value, we will do filein.
    MI_BOOL bEnableAdecEsBufLevelCtrl;          /// [IN]: < Enable Adec ES Buf Lev Control by following condition. Each one is satisfied, we will do filein.
    MI_U32 u32AdecBufWaterMarkInMs;             /// [IN]: < User defined buffer level (msec), if audio es buffer level is smaller than this value, we will do filein.
    MI_U32 u32AdecBufWaterMarkInBytes;          /// [IN]: < User defined buffer level (bytes), if audio es buffer level is lower than this value, we will do filein.
} MI_INJECT_EsBufferLevelCtrl_t;

typedef struct MI_INJECT_Caps_s
{
    MI_U32 u32MaxSupportVidDecNum;              /// [OUT]: < Number of max supported video decoder
    MI_U32 u32SupportVidCodecs;                 /// [OUT]: < Bit-wise supported video codecs defined by MI_VIDEO_CodecType_e
    MI_U32 u32MaxSupportAudDecNum;              /// [OUT]: < Number of max supported audio decoder
    MI_U32 u32SupportAudCodecs;                 /// [OUT]: < Bit-wise supported audio codecs define by MI_AUDIO_CodecType_e

    MI_U32 u32MaxTsBufSize;                     /// [OUT]: < Max internal buffer size of TS injection
    MI_U32 u32MaxVpesBufSize;                   /// [OUT]: < Max internal buffer size of VPES injection
    MI_U32 u32MaxApesBufSize;                   /// [OUT]: < Max internal buffer size of APES injection
    MI_U32 u32MaxVesBufSize;                    /// [OUT]: < Max internal buffer size of VES injection
    MI_U32 u32MaxAesBufSize;                    /// [OUT]: < Max internal buffer size of AES injection
} MI_INJECT_Caps_t;

typedef struct MI_INJECT_InitParams_s
{
    MI_U8 u8Reserved;                           ///< Reserved for future
} MI_INJECT_InitParams_t;

typedef struct MI_INJECT_DecryptCallbackParams_s
{
    MI_VIRT virtSrcBufAddr;                     ///< source buffer address
    MI_VIRT virtDstBufAddr;                     ///< destination buffer address
    MI_U32 u32BufSize;                          ///< size of data
}MI_INJECT_DecryptCallbackParams_t;

typedef struct MI_INJECT_MemoryCopyCallbackParams_s
{
    MI_VIRT virtSrcBufAddr;                     ///< source buffer address
    MI_VIRT virtDstBufAddr;                     ///< destination buffer address
    MI_U32 u32BufSize;                          ///< size of data
}MI_INJECT_MemoryCopyCallbackParams_t;

typedef MI_RESULT (* MI_INJECT_EventCallback)(MI_HANDLE hInject, MI_INJECT_CallbackEvent_e eEvent, void *pEventParams, void *pUserParams);
typedef struct MI_INJECT_CallbackParams_s
{
    MI_INJECT_EventCallback pfEventCallback;    ///[IN]:  Callback function pointer
    MI_U32 u32EventFlag;                        ///[IN]:  Event flags defined by MI_INJECT_CallbackEvent_e
    void *pUserParams;                          ///[IN]:  User parameter
} MI_INJECT_CallbackParams_t;

typedef struct MI_INJECT_OpenParams_s
{
    MI_U8 *pszName;                                 /// [IN]: < Custom defined injplay name which is a string
    MI_INJECT_StreamType_e eStreamType;             /// [IN]: < The stream type of content
    MI_INJECT_SecurityType_e eSecureType;           /// [IN]: < The secure type of content
    MI_INJECT_CallbackParams_t stCallbackParams;    /// [IN]: < Parameter of callback control
} MI_INJECT_OpenParams_t;

typedef struct MI_INJECT_QueryHandleParams_s
{
    MI_U8 *pszName;                             /// [IN]: < Custom defined injplay name which is a string
    MI_INJECT_StreamType_e eStreamType;         /// [IN]: < The stream type of content
} MI_INJECT_QueryHandleParams_t;

typedef struct MI_INJECT_StartParams_s
{
    MI_U8 u8Reserved;                           ///[IN]: < Reserved
} MI_INJECT_StartParams_t;

typedef struct MI_INJECT_QueryBufferParams_s
{
    MI_U32 u32BufSize;                          ///[IN]: < Buffer size
} MI_INJECT_QueryBufferParams_t;

typedef struct MI_INJECT_BufferParams_s
{
    MI_U8 *pu8BufAddr;                          /// < Data address for injection
                                                /// [IN] : for MI_INJECT_WriteBufferComplete
                                                /// [OUT]: for MI_INJECT_QueryFreeBuffer
    MI_U32 u32BufSize;                          /// < Size of data for injection
                                                /// [IN] : for MI_INJECT_WriteBufferComplete
                                                /// [OUT]: for MI_INJECT_QueryFreeBuffer
    MI_U64 u64Pts;                              /// < Presentation timestamp with 90KHz unit, MI_INVALID_PTS for invalid timestamp
                                                /// [IN] : for MI_INJECT_WriteBufferComplete
    MI_BOOL bEndOfStream;                       /// < Is end of stream?
                                                /// [IN] : for MI_INJECT_WriteBufferComplete
    MI_BOOL bPictureStart;                      /// < Boolean value to indicator this buffer is the picture start of ES stream. Used for stream type E_MI_INJECT_STREAM_VES with codec as XVID, DIVX,... serial
                                                /// [IN] : for MI_INJECT_WriteBufferComplete
    MI_BOOL bBrokenByUs;                        /// < Boolean value to indicator this buffer is a part of an alignment of ES stream. Used for stream type E_MI_INJECT_STREAM_VES with codec as H264(nal), ,...
                                                /// [IN] : for MI_INJECT_WriteBufferComplete
} MI_INJECT_BufferParams_t;

typedef struct MI_INJECT_PreBufferCtrl_s
{
    MI_U32 u32VideoMinBufInMs;                  /// [IN]: < Video min pre-buffer duration in milli-seconds, set zero for disable.
    MI_U32 u32AudioMinBufInMs;                  /// [IN]: < Audio min pre-buffer duration in milli-seconds, set zero for disable.
    MI_U32 u32VideoMinBufInBytes;               /// [IN]: < Video min pre-buffer size in bytes, set zero for disable
    MI_U32 u32AudioMinBufInBytes;               /// [IN]: < Audio min pre-buffer size in bytes, set zero for disable

    MI_BOOL bMsBytesAndOrCond;                  /// [IN]: < TRUE for AND: min pre-buffer is done if both of ms and bytes conditions are reached. FALSE for OR: min pre-buffer is done if at least one of ms and bytes conditions is reached.
    MI_BOOL bVideoAudioAndOrCond;               /// [IN]: < TRUE for AND: min pre-buffer is done if both of video and audio conditions are reached. FALSE for OR: min pre-buffer is done if at least one of video and audio conditions is reached.

    /// The pre-buffer will abort if at least one of below conditions is reached
    MI_U32 u32VideoMaxBufInMs;                  /// [IN]: < Video max pre-buffer duration in milli-seconds, set zero for disable.
    MI_U32 u32AudioMaxBufInMs;                  /// [IN]: < Audio max pre-buffer duration in milli-seconds, set zero for disable.
    MI_U32 u32VideoMaxBufInBytes;               /// [IN]: < Video max pre-buffer size in bytes, set zero for disable
    MI_U32 u32AudioMaxBufInBytes;               /// [IN]: < Audio max pre-buffer size in bytes, set zero for disable

    MI_U32 u32WaitDataTimeoutInMs;              /// [IN]: < Timeout control for no data available
} MI_INJECT_PreBufferCtrl_t;

typedef struct MI_INJECT_InjBufferInfo_s
{
    MI_VIRT virtBufAddr;                        /// [OUT]: < Virtual address of injection buffer
    MI_U32 u32BufSize;                          /// [OUT]: < Size of injection buffer
    MI_U32 u32ReadPos;                          /// [OUT]: < Related read position between 0~u32BufSize
    MI_U32 u32WritePos;                         /// [OUT]: < Related write position between 0~u32BufSize
    MI_U32 u32FreeSize;                         /// [OUT]: < Size of free injection buffer
} MI_INJECT_InjBufferInfo_t;

//-------------------------------------------------------------------------------------------------
//  Global Functions
//-------------------------------------------------------------------------------------------------

//------------------------------------------------------------------------------
/// @brief Get INJECT module capabilities.
/// @param[out] pstInjCaps: A pointer to structure MI_INJECT_Caps_t to retrieve the information of INJECT capabilities
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_INJECT_GetCaps(MI_INJECT_Caps_t *pstCaps);

//------------------------------------------------------------------------------
/// @brief Init INJECT module.
/// @param[in] pstInitParams: A pointer to structure MI_INJECT_InitParams_t for initialization.
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_RESOURCES: No available resource.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_INJECT_Init(const MI_INJECT_InitParams_t *pstInitParams);

//------------------------------------------------------------------------------
/// @brief Finalize INJECT module.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_INJECT_DeInit(void);

//------------------------------------------------------------------------------
/// @brief Open a injection port for feeding stream to decoder.
/// @param[in] pstOpenParams: A pointer to structure MI_INJECT_OpenParams_t to determine the stream configuration of injection .
/// @param[out] phInject: Pointer to MI_HANDLE to retrieve an instance of injection corresponding to the stream config pstOpenParams.
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_RESOURCES: No available resource.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_INJECT_Open(const MI_INJECT_OpenParams_t *pstOpenParams, MI_HANDLE *phInject);

//------------------------------------------------------------------------------
/// @brief Close a created injection port.
/// @param[in] hInject: A handle of a created injection instance.
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE: Hanlde is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_INJECT_Close(MI_HANDLE hInject);

//------------------------------------------------------------------------------
/// @brief Start playback for a created injection port.
/// @param[in] hInject: A handle of a created injection instance.
/// @param[in] pstStartParams: Start parameter.
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE: Hanlde is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_INJECT_Start(MI_HANDLE hInject, const MI_INJECT_StartParams_t * pstStartParams);

//------------------------------------------------------------------------------
/// @brief Stop playback for a created injection port.
/// @param[in] hInject: A handle of a created injection instance.
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE: Hanlde is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_INJECT_Stop(MI_HANDLE hInject);

//------------------------------------------------------------------------------
/// @brief Pause TSIO filein data for a created injection buffer task. Call MI_INJECT_Resume() for back to the normal filein.
/// @param[in] hInject: A handle of a created injection instance.
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE: Hanlde is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_INJECT_Pause(MI_HANDLE hInject);

//------------------------------------------------------------------------------
/// @brief Resume TSIO filein data for a created injection buffer task.
/// @param[in] hInject: A handle of a created injection instance.
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE: Hanlde is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_INJECT_Resume(MI_HANDLE hInject);

//------------------------------------------------------------------------------
/// @brief Query the free buffer for injection from a created injection port.
/// @param[in] hInject: A handle of a created injection instance.
/// @param[in] pstQueryBufParams: A pointer to structure MI_INJECT_QueryBufferParams_t to query free buffer
/// @param[out] pstBufParams: A pointer to structure MI_INJECT_BufferParams_t to retrieve the free buffer information.
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE: Hanlde is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_CHAOS: The injection hasn't started playback yet.
//------------------------------------------------------------------------------
MI_RESULT MI_INJECT_QueryFreeBuffer(MI_HANDLE hInject, MI_INJECT_QueryBufferParams_t *pstQueryBufParams, MI_INJECT_BufferParams_t *pstBufParams);

//------------------------------------------------------------------------------
/// @brief Info the stream writen into buffer is complete and ready for injecting into a created injection port.
/// @param[in] hInject: A handle of a created injection instance.
/// @param[in] pstBufParams: A pointer to structure MI_INJECT_BufferParams_t describes the stream for injection.
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE: Hanlde is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_CHAOS: The injection hasn't started playback yet.
//------------------------------------------------------------------------------
MI_RESULT MI_INJECT_WriteBufferComplete(MI_HANDLE hInject, MI_INJECT_BufferParams_t *pstBufParams);

//------------------------------------------------------------------------------
/// @brief Clear all the queuing buffer
/// @param[in] hInject: A handle of a created injection instance.
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE: Hanlde is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_CHAOS: The injection hasn't started playback yet.
//------------------------------------------------------------------------------
MI_RESULT MI_INJECT_Clear(MI_HANDLE hInject);

//------------------------------------------------------------------------------
/// @brief Set the attribute/information of a created injection instance.
/// @param[in] hInject: A handle of a created injection instance.
/// @param[in] eAttrType: The parameter type for setting attribute.
/// @param[in] pAttrParam: A pointer to to set attribute corresponding to the eParamType. The prototype of pParam plz see the description of enum MI_INJECT_AttrType_e
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_SUPPORT: eParamType is not supported.
/// @return MI_ERR_INVALID_HANDLE: Hanlde is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_INJECT_SetAttr(MI_HANDLE hInject, MI_INJECT_AttrType_e eAttrType, const void *pAttrParams);

//------------------------------------------------------------------------------
/// @brief Get the attribute/information of a created injection instance.
/// @param[in] hInject: A handle of a created injection instance.
/// @param[in] eAttrType: The parameter type for getting attribute.
/// @param[in] pInputParams:  A pointer to retrieve the attribute corresponding to the eAttrType. The prototype of pInputputParam plz see the description of enum MI_INJECT_AttrType_e
/// @param[out] pOutputParam: A pointer to retrieve the attribute corresponding to the eAttrType. The prototype of pOutputParam plz see the description of enum MI_INJECT_AttrType_e
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_SUPPORT: eParamType is not supported.
/// @return MI_ERR_INVALID_HANDLE: Hanlde is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_INJECT_GetAttr(MI_HANDLE hInject, MI_INJECT_AttrType_e eAttrType, const void *pInputParams, void *pOutputParams);

//------------------------------------------------------------------------------
/// @brief Get the exist injection handle corresponding to the specified ePlaybkPath & eStreamType.
/// @param[in] pstQueryParams: Get Handle parameter
/// @param[out] phInject: A pointer to retrieve the handle.
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE: Hanlde is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_INJECT_GetHandle(const MI_INJECT_QueryHandleParams_t *pstQueryParams, MI_HANDLE *phInject);

//------------------------------------------------------------------------------
/// @brief Set INJECT debug level.
/// @param[in] u32DbgLevel: Debug level defined in enum type MI_DBG_LEVEL
/// @return MI_OK: Set debug level success.
//------------------------------------------------------------------------------
MI_RESULT MI_INJECT_SetDebugLevel(MI_DBG_LEVEL u32DebugLevel);
#ifdef __cplusplus
}
#endif

#endif///_MI_INJECT_H_


