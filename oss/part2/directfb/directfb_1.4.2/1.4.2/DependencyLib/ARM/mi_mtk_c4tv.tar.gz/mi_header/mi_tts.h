/*------------------------------------------------------------------------------
 * MediaTek Inc. (C) 2018. All rights reserved.
 *
 * Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 *----------------------------------------------------------------------------*/

#ifndef _MI_TTS_H_
#define _MI_TTS_H_

#ifdef __cplusplus
extern "C" {
#endif

//-------------------------------------------------------------------------------------------------
//  Defines - Constant
//-------------------------------------------------------------------------------------------------

#define MI_TTS_LANGUAGE_NUM_MAX                            (8)
#define MI_TTS_VOICE_NUM_MAX                               (8)
#define MI_TTS_SPEAKER_NAME_LENGTH_MAX                    (64)
#define MI_TTS_ATTR_DEFAULT_VALUE                 (0xFFFFFFFF)
//-------------------------------------------------------------------------------------------------
//  Types - Enums
//-------------------------------------------------------------------------------------------------

typedef enum
{
    E_MI_TTS_LANGUAGE_ID_DEFAULT = MI_TTS_ATTR_DEFAULT_VALUE,
    E_MI_TTS_LANGUAGE_ID_ENGLISH = 0,       ///< English
    E_MI_TTS_LANGUAGE_ID_FRENCH,            ///< French
    E_MI_TTS_LANGUAGE_ID_SPANISH,           ///< Spanish
    E_MI_TTS_LANGUAGE_ID_KOREAN,            ///< Korean
    E_MI_TTS_LANGUAGE_ID_PORTUGUES,         ///< Portugues
    E_MI_TTS_LANGUAGE_ID_MAX,
} MI_TTS_LanguageId_e;

typedef enum
{
    E_MI_TTS_EVENT_FLAG_SAYING                  = MI_BIT(0),    ///< [bit 0] When TTS server is saying this text, the event will be sent, event parameter is a pointer to struct MI_TTS_FeedbackEventParams_t.
    E_MI_TTS_EVENT_FLAG_SAID                    = MI_BIT(1),    ///< [bit 1] After the text was said, the event will be sent, event parameter is a pointer to struct MI_TTS_FeedbackEventParams_t.
    E_MI_TTS_EVENT_FLAG_STOPPED                 = MI_BIT(2),    ///< [bit 2] After want-to-say-text was flushed when calling MI_TTS_Flush(), the event will be sent, event parameter is a pointer to struct MI_TTS_FeedbackEventParams_t.
    E_MI_TTS_EVENT_FLAG_LOCK_CHANGED            = MI_BIT(3),    ///< [bit 3] After calling MI_TTS_Lock() or MI_TTS_Unlock() was succeed, the event will be sent, event parameter is a pointer to struct MI_TTS_LockEventParams_t.
    E_MI_TTS_EVENT_FLAG_FEATUER_ENABLE_CHANGED  = MI_BIT(4),    ///< [bit 4] When capability of TTS server was changed, the event will be sent, parameter is a pointer to struct MI_TTS_FeatureEnableChangedEventParams_t.
    E_MI_TTS_EVENT_FLAG_GLOBAL_ATTR_CHANGED     = MI_BIT(5),    ///< [bit 5] When global attribute was changed, the event will be sent, parameter is a pointer to struct MI_TTS_AttrChangedEventParams_t.
    E_MI_TTS_EVENT_FLAG_LOCAL_ATTR_CHANGED      = MI_BIT(6),    ///< [bit 6] When local attribute of this process is changed, the event will be sent, parameter is a pointer to struct MI_TTS_AttrChangedEventParams_t.
    E_MI_TTS_EVENT_FLAG_STOPPING                = MI_BIT(7),    ///< [bit 7] When flush (or prepare to flush), the event will be sent, event parameter is a pointer to struct MI_TTS_FeedbackEventParams_t.
} MI_TTS_EventFlag_e;

typedef enum
{
    E_MI_TTS_ATTR_SUBTYPE_LOCAL = 0,        ///< Local attribute for each TTS client.
    E_MI_TTS_ATTR_SUBTYPE_GLOBAL,           ///< Global attribute for every TTS client.
    E_MI_TTS_ATTR_SUBTYPE_MAX,
} MI_TTS_AttrSubtype_e;

typedef enum
{
    E_MI_TTS_FEATURE_ENABLE_TYPE_TTS_SERVER = 0,                    ///<[Set/Get] Enable/disable feature for the saying ability of TTS server.
    E_MI_TTS_FEATUER_ENABLE_TYPE_VERBOSITY,                         ///<[Set/Get] Enable/disable feature for saying text with 'verbose' text input.
    E_MI_TTS_FEATUER_ENABLE_TYPE_SPEED,                             ///<[Set/Get] Enable/disable feature for saying text with rate value.
    E_MI_TTS_FEATUER_ENABLE_TYPE_PITCH,                             ///<[Set/Get] Enable/disable feature for saying text with the pitch value.
    E_MI_TTS_FEATUER_ENABLE_TYPE_VOICE,                             ///<[Set/Get] Enable/disable feature for saying text with the voice value.
    E_MI_TTS_FEATUER_ENABLE_TYPE_VOLUME,                            ///<[Set/Get] Enable/disable feature for saying text with the volume values.
    E_MI_TTS_FEATUER_ENABLE_TYPE_SYSTEM_BACKGROUND_CHANNEL_VOLUME,  ///<[Set/Get] Enable/disable feature for saying text with the background volume values.
    E_MI_TTS_FEATUER_ENABLE_TYPE_SYSTEM_TTS_CHANNEL_VOLUME,         ///<[Set/Get] Enable/disable feature for saying text with the tts channel volume values.
    E_MI_TTS_FEATUER_ENABLE_TYPE_MAX,
} MI_TTS_FeatureEnableType_e;

typedef enum
{
    E_MI_TTS_ATTR_TYPE_SPEED = 0,                                ///<[Set/Get] Text saying rate for TTS Server, unit in Words-per-Minute. the output parameter is a value of MI_U32.
    E_MI_TTS_ATTR_TYPE_PITCH,                                    ///<[Set/Get] TTS engine generate audio pcm files with pitch values by saying text. the output parameter is a value of MI_U32.
    E_MI_TTS_ATTR_TYPE_VOICE,                                    ///<[Set/Get] Engine voice to say text, the output parameter is a value of MI_U32.
    E_MI_TTS_ATTR_TYPE_VOLUME,                                   ///<[Set/Get] TTS engine generate audio pcm files by saying text. It will change amplitude of wave according to the volume. The output parameter is a value of MI_U32.
    E_MI_TTS_ATTR_TYPE_SYSTEM_BACKGROUND_CHANNEL_VOLUME,         ///<[Set/Get] The background volume mean include video channel, UI sound channel and 5.1 multi-channel. The output parameter is a value of MI_U32.
    E_MI_TTS_ATTR_TYPE_SYSTEM_TTS_CHANNLE_VOLUME,                ///<[Set/Get] Target volume is set for TTS channel. The TV system would adjust audio output volume about tts channel according to the value. The output parameter is a value of MI_U32.
    E_MI_TTS_ATTR_TYPE_LANGUAGE,                                 ///<[Set/Get] TTS server say with language, the output parameter is a value to MI_TTS_LanguageId_e.
    E_MI_TTS_ATTR_TYPE_MAX,
} MI_TTS_AttrType_e;

typedef enum
{
    E_MI_TTS_CAPABILITY_INFO_TYPE_RANGE = 0,       ///< Range of value.
    E_MI_TTS_CAPABILITY_INFO_TYPE_VOICE,           ///< Voice information.
    E_MI_TTS_CAPABILITY_INFO_TYPE_LANGUAGE,        ///< Language information.
    E_MI_TTS_CAPABILITY_INFO_TYPE_MAX,
} MI_TTS_CapabilityInfoType_e;

//-------------------------------------------------------------------------------------------------
//  Types - Structures
//-------------------------------------------------------------------------------------------------

typedef struct MI_TTS_FeedbackEventParams_s
{
    void *pUserData;                        ///< [OUT] Identified user-defined parameters to denote to say, silence or flush request.
} MI_TTS_FeedbackEventParams_t;

typedef struct MI_TTS_LockEventParams_s
{
    MI_BOOL bLocked;                        ///< [OUT] Changed value. To identify the value definition TTS server is locked or not.
} MI_TTS_LockEventParams_t;

typedef struct MI_TTS_FeatureEnableChangedEventParams_s
{
    MI_TTS_FeatureEnableType_e eFeatureType;  ///< [OUT] The specified feature type.
    MI_BOOL bEnabled;                         ///< [OUT] Enable value of feature changed.
} MI_TTS_FeatureEnableChangedEventParams_t;

typedef struct MI_TTS_AttrChangedEventParams_s
{
    MI_TTS_AttrType_e eAttrType;            ///< [OUT] The specified attribute type
    MI_U32 u32Value;                        ///< [OUT] Attribute of capability changed.
} MI_TTS_AttrChangedEventParams_t;

typedef struct MI_TTS_AttrInputParams_s
{
    MI_TTS_AttrSubtype_e eAttrSubtype;      ///< [IN] Set local or global attribute.
} MI_TTS_AttrInputParams_t;

typedef struct MI_TTS_AttrParams_s
{
    MI_TTS_AttrSubtype_e eAttrSubtype;      ///< [IN] Set local or global attribute.
                                            ///< [OUT] Get local or global attribute.
    MI_U32 u32Value;                        ///< [OUT] Attribute value.
} MI_TTS_AttrParams_t;

typedef struct MI_TTS_RangeInfo_s
{
    MI_U32 u32MinValue;                     ///< [OUT] Minimum value.
    MI_U32 u32MaxValue;                     ///< [OUT] Maximum value.
} MI_TTS_RangeInfo_t;

typedef struct MI_TTS_LanguageInfo_s
{
    MI_U8 u8Number;                                                ///< [OUT] Lanugage number.
    MI_TTS_LanguageId_e aeLanguageId[MI_TTS_LANGUAGE_NUM_MAX];     ///< [OUT] Lanugage id.
} MI_TTS_LanguageInfo_t;

typedef struct MI_TTS_VoiceInfoUnit_s
{
    MI_U32 u32VoiceId;                                      ///< [OUT] Voice id.
    MI_TTS_LanguageId_e eLanguageId;                        ///< [OUT] Language id.
    MI_U8 szSpeakerName[MI_TTS_SPEAKER_NAME_LENGTH_MAX];    ///< [OUT] Speaker name.
} MI_TTS_VoiceInfoUnit_t;

typedef struct MI_TTS_VoiceInfo_s
{
    MI_U8 u8Number;                                             ///< [OUT] Voice number.
    MI_TTS_VoiceInfoUnit_t astVoice[MI_TTS_VOICE_NUM_MAX];      ///< [OUT] Voice informations.
} MI_TTS_VoiceInfo_t;

typedef struct MI_TTS_GetCapabilityParams_s
{
    MI_BOOL bSupported;                        ///< [OUT] Supported capability of TTS server.
    MI_TTS_CapabilityInfoType_e eInfoType;     ///< [OUT] The specified type of capability information.
    union {
        MI_TTS_RangeInfo_t stRangeInfo;        ///< [OUT] Using MI_TTS_RangeInfo_t type when MI_TTS_CapabilityRangeType_e is E_MI_TTS_CAPABILITY_INFO_TYPE_RANGE.
        MI_TTS_VoiceInfo_t stVoiceInfo;        ///< [OUT] Using MI_TTS_VoiceInfo_t type when MI_TTS_CapabilityRangeType_e is E_MI_TTS_CAPABILITY_INFO_TYPE_VOICE.
        MI_TTS_LanguageInfo_t stLanguageInfo;  ///< [OUT] Using MI_TTS_LanguageInfo_t type when MI_TTS_CapabilityRangeType_e is E_MI_TTS_CAPABILITY_INFO_TYPE_LANGUAGE.
    };
} MI_TTS_GetCapabilityParams_t;

//------------------------------------------------------------------------------
/// @brief Callback function to notify getting the event from the TTS server.
/// @param[in] hTts: An instance of a created TTS client.
/// @param[in] u32Event: Event type that client want to request. use MI_TTS_EventFlag_e define value.
/// @param[in] pEventParams: A pointer to structure for the notifying event. The structure type is corresponding to MI_TTS_EventFlag_e.
/// @param[in] pUserParams: For passing user-defined parameters.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters are invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
typedef MI_RESULT (*MI_TTS_EventCallback)(MI_HANDLE hTts, MI_U32 u32Event, void *pEventParams, void *pUserParams);

typedef struct MI_TTS_InitParams_s
{
    MI_U8 u8Reserved;                      ///< Reserve for the future.
} MI_TTS_InitParams_t;

typedef struct MI_TTS_OpenParams_s
{
    MI_U8 *pszName;                        ///< TTS client name
} MI_TTS_OpenParams_t;

typedef struct MI_TTS_StartParams_s
{
    MI_U8 u8Reserved;                      ///< Reserve for the future.
} MI_TTS_StartParams_t;

typedef struct MI_TTS_CallbackInputParams_s
{
    MI_U64 u64CallbackId;                   ///[IN]: only support one user each process, use 0 for first register or single callback.
    MI_TTS_EventCallback pfEventCallback;   ///[IN]: callback function pointer.
    MI_U32 u32EventFlags;                   ///[IN]: registered events which are bitwise OR operation. Use MI_TTS_EventFlag_e define value.
    void * pUserParams;                     ///[IN]: for passing user-defined parameters.
} MI_TTS_CallbackInputParams_t;

typedef struct MI_TTS_CallbackOutputParams_s
{
    MI_U64 u64CallbackId;                   ///[OUT]: the returned ID for update or unregister callback.
} MI_TTS_CallbackOutputParams_t;

//-------------------------------------------------------------------------------------------------
//  Functions
//-------------------------------------------------------------------------------------------------

//------------------------------------------------------------------------------
/// @brief Init TTS client.
/// @param[in] pstInitParams: A pointer to structure MI_TTS_InitParams_t for initialization.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_TTS_Init(const MI_TTS_InitParams_t *pstInitParams);

//------------------------------------------------------------------------------
/// @brief Finalize TTS client.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_TTS_DeInit(void);

//------------------------------------------------------------------------------
/// @brief Open a TTS client and prepare the TTS server.
/// @param[in] pstOpenParams: A pointer to structure MI_TTS_OpenParams_t for opening TTS client.
/// @param[out] phTts: A handle pointer to retrieve an instance of a created TTS client.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_PARAMETER: Parameters are invalid.
/// @return MI_ERR_RESOURCES: No available resource.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_LIMITION: TTS Server is not allowed to use.
//------------------------------------------------------------------------------
MI_RESULT MI_TTS_Open(const MI_TTS_OpenParams_t *pstOpenParams, MI_HANDLE *phTts);

//--------------------------------------------------- ---------------------------
/// @brief Close a TTS client and close TTS server.
/// @param[in] hTts: An instance of a created TTS client.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_TTS_Close(MI_HANDLE hTts);

//------------------------------------------------------------------------------
/// @brief Start TTS client
/// @param[in] hTts: An instance of a created TTS client.
/// @param[in] pstStartParams: A pointer to structure MI_TTS_StartParams_t for starting a TTS client.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_HANDLE: hanlde is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters are invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_TTS_Start(MI_HANDLE hTts, const MI_TTS_StartParams_t *pstStartParams);

//------------------------------------------------------------------------------
/// @brief Stop TTS client
/// @param[in] hTts: An instance of a created TTS client.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_HANDLE: hanlde is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_TTS_Stop(MI_HANDLE hTts);

//------------------------------------------------------------------------------
/// @brief Register Callback function
/// @param[in] hTts: An instance of a created TTS client.
/// @param[in] pstInputParams: A pointer to structure MI_TTS_CallbackInputParams_t for registering callback function.
/// @param[out] pstOutputParams: A pointer to structure MI_TTS_CallbackOutputParams_t. it will be NULL because of not used.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_HANDLE: hanlde is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters are invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_TTS_RegisterCallback(MI_HANDLE hTts, const MI_TTS_CallbackInputParams_t *pstInputParams, MI_TTS_CallbackOutputParams_t *pstOutputParams);

//------------------------------------------------------------------------------
/// @brief Unregister Callback function
/// @param[in] hTts: An instance of a created TTS client.
/// @param[in] pstInputParams: A pointer to structure MI_TTS_CallbackInputParams_t for unregister.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_HANDLE: hanlde is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters are invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_TTS_UnRegisterCallback(MI_HANDLE hTts, const MI_TTS_CallbackInputParams_t *pstInputParams);

//------------------------------------------------------------------------------
/// @brief To obtain dominated privilege to use TTS server.
/// All other processes can not operate any major functionality
/// and modify global configuration after MI_TTS_Lock() is called.
/// MI_TTS_Lock() will fail when other process has already locked.
/// @param[in] hTts: An instance of a created TTS client.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_TTS_Lock(MI_HANDLE hTts);

//------------------------------------------------------------------------------
/// @brief To release dominated priviledge to use TTS server.
/// Calling MI_TTS_Unlock() after MI_TTS_Lock() to release lock state to all other processes.
/// @param[in] hTts: An instance of a created TTS client.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_TTS_Unlock(MI_HANDLE hTts);

//------------------------------------------------------------------------------
/// @brief To request TTS server to say text one by one.
/// @param[in] hTts: An instance of a created TTS client.
/// @param[in] pText: text buffer in UTF8 encoding.
/// @param[in] u32Length: length of buffer in byte unit.
/// @param[in] pUserData: identified user-defined parameters to denote this request. it would be in sync of pUserParams in EventParams.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters are invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_TTS_Say(MI_HANDLE hTts, const MI_U8 *pu8Text, MI_U32 u32Length, void *pUserData);

//------------------------------------------------------------------------------
/// @brief To request TTS server to keep silent of ms after current saying text.
/// @param[in] hTts: An instance of a created TTS client.
/// @param[in] u32Time: silence time you want, the unit is millisecond.
/// @param[in] pUserData identified user-defined parameters to denote this request. it would be in sync of pUserParams in EventParams.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_TTS_Silence(MI_HANDLE hTts, MI_U32 u32Time, void *pUserData);

//------------------------------------------------------------------------------
/// @brief To stop current saying text and flush all queued texts before this request.
/// @param[in] hTts: An instance of a created TTS client.
/// @param[in] pUserData: identified user-defined parameters to denote this request. it would be in sync of pUserParams in EventParams.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_TTS_Flush(MI_HANDLE hTts, void *pUserData);

//------------------------------------------------------------------------------
/// @brief Set the feature enable of a created TTS server.
/// @param[in] hTts: An instance of a created TTS client.
/// @param[in] eFeatureType: The feature type for setting enable.
/// @param[in] bEnable: The enable value corresponding to the eFeatureType.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters are invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_TTS_SetFeatureEnable(MI_HANDLE hTts, MI_TTS_FeatureEnableType_e eFeatureType, const MI_BOOL bEnable);

//------------------------------------------------------------------------------
/// @brief Get the feature enable of a created TTS server.
/// @param[in] hTts: An instance of a created TTS client.
/// @param[in] eFeatureType: The feature type for getting enable.
/// @param[out] pbEnable: pointer to retrieve the enable value corresponding to the eFeatureType
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters are invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_TTS_GetFeatureEnable(MI_HANDLE hTts, MI_TTS_FeatureEnableType_e eFeatureType, MI_BOOL *pbEnable);

//------------------------------------------------------------------------------
/// @brief Set the attribute of a created TTS client and TTS server.
/// @param[in] hTts: An instance of a created TTS client.
/// @param[in] eAttrType: The attribute type for setting attribute.
/// @param[in] pAttrParams: A pointer to structure MI_TTS_AttrParams_t.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters are invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_TTS_SetAttr(MI_HANDLE hTts, MI_TTS_AttrType_e eAttrType, const void *pAttrParams);

//------------------------------------------------------------------------------
/// @brief Get the attribute of a created TTS client and TTS server.
/// @param[in] hTts: An instance of a created TTS client.
/// @param[in] eAttrType: The attribute type for getting attribute.
/// @param[in] pInputParams: A pointer to structure MI_TTS_AttrInputParams_t.
/// @param[out] pOutputParams: A pointer to structure MI_TTS_AttrParams_t.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters are invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_TTS_GetAttr(MI_HANDLE hTts, MI_TTS_AttrType_e eAttrType, const void *pInputParams, void *pOutputParams);

//------------------------------------------------------------------------------
/// @brief Get the capability of a created TTS server.
/// @param[in] hTts: An instance of a created TTS client.
/// @param[in] eAttrType: The attribute type for getting capability from TTS server.
/// @param[out] pstParams: pointer to output the result corresponding to the eAttrType
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters are invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_TTS_GetCapability(MI_HANDLE hTts, MI_TTS_AttrType_e eAttrType, MI_TTS_GetCapabilityParams_t *pstParams);

//------------------------------------------------------------------------------
/// @brief Save local attribute for each TTS client
/// @param[in] hTts: An instance of a created TTS client.
/// @param[in] pszFilePath: File path
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters are invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_TTS_SaveProfile(MI_HANDLE hTts, MI_U8 *pszFilePath);

//------------------------------------------------------------------------------
/// @brief Load local attribute for each TTS client
/// @param[in] hTts: An instance of a created TTS client.
/// @param[in] pszFilePath: File path
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters are invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_TTS_LoadProfile(MI_HANDLE hTts, MI_U8 *pszFilePath);

//------------------------------------------------------------------------------
/// @brief Reset to factory default setting
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_TTS_FactoryReset(void);

//------------------------------------------------------------------------------
/// @brief Set TTS debug level.
/// @param[in] u32DebugLevel: Debug level defined in enum type MI_DBG_LEVEL
/// @return MI_OK: Set debug level success.
/// @return MI_ERR_INVALID_PARAMETER: Parameters are invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_TTS_SetDebugLevel(MI_DBG_LEVEL u32DebugLevel);

#ifdef __cplusplus
}
#endif

#endif///_MI_TTS_H_
