/*------------------------------------------------------------------------------
 * MediaTek Inc. (C) 2018. All rights reserved.
 *
 * Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 *----------------------------------------------------------------------------*/
//-------------------------------------------------------------------------------------------------
// Use GetXxx/SetXxx Only
//-------------------------------------------------------------------------------------------------
#ifndef _MI_TSENSOR_H_
#define _MI_TSENSOR_H_

#ifdef __cplusplus
extern "C" {
#endif

typedef MI_RESULT (*MI_TSENSOR_EventCallback)(MI_HANDLE hTsensor, MI_U32 u32Event, void *pEventParams, void *pUserParams);

/// Define TSENSOR related event
typedef enum
{
    E_MI_TSENSOR_CALLBACK_EVENT_OVER_HIGH_BOUND   = MI_BIT(0),    ///notify temperature over setting high bound
    E_MI_TSENSOR_CALLBACK_EVENT_OVER_LOW_BOUND    = MI_BIT(1),    ///notify temperature over setting high bound
    E_MI_TSENSOR_CALLBACK_EVENT_ALL            = 0xFFFFFFFF            ///Event number
} MI_TSENSOR_CallbackEvent_e;

typedef struct MI_TSENSOR_InitParams_s
{
    MI_U8 u8Reserved;    ///[IN]: reserve for future use.
} MI_TSENSOR_InitParams_t;

typedef struct MI_TSENSOR_OpenParams_s
{
    MI_S16 s16HighBound;    ///[OUT]: used for setting high bound temperature
    MI_S16 s16LowBound;    ///[OUT]: used for setting low bound temperature
} MI_TSENSOR_OpenParams_t;

/// Callback function input parameter struct.
typedef struct MI_TSENSOR_CallbackInputParams_s
{
    MI_U64 u64CallbackId;    ///[IN]: for multi-callback, use 0 for first register or single callback.
    MI_TSENSOR_EventCallback pfEventCallback;    ///[IN]: callback function pointer.
    MI_U32 u32EventFlags;    ///[IN]: registered events which are bitwise OR operation.
    void * pUserParams;    ///[IN]: for passing user-defined parameters.
} MI_TSENSOR_CallbackInputParams_t;

/// Callback function output parameter struct.
typedef struct MI_TSENSOR_CallbackOutputParams_s
{
    MI_U64 u64CallbackId;    ///[OUT]: the returned ID for update or unregister callback.
} MI_TSENSOR_CallbackOutputParams_t;

//-------------------------------------------------------------------------------------------------
//  Global Functions
//-------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------
/// @brief TSENSOR system initial
/// @param[in] pstInitParams tsensor init parameter
/// @return MI_OK: Process success.
/// @return MI_HAS_INITED: TSENSOR module is inited
/// @return MI_ERR_FAILED: Process failed
//------------------------------------------------------------------------------
MI_RESULT MI_TSENSOR_Init(const MI_TSENSOR_InitParams_t *pstInitParams);

//------------------------------------------------------------------------------
/// @brief TSENSOR de-init
/// @param[in] None
/// @return MI_OK: Process success.
//------------------------------------------------------------------------------
MI_RESULT MI_TSENSOR_DeInit(void);

//------------------------------------------------------------------------------
/// @brief Open the TSENSOR
/// @param[in] pstOpenParm: Parameter setting for opening TSENSOR.
/// @param[out] phTsensor: return the TSENSOR handle
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not intited.
/// @return MI_ERR_INVALID_PARAMETER: parameter error.
/// @return MI_ERR_RESOURCES: No available resource.
/// @return MI_ERR_FAILED: Process failed
//------------------------------------------------------------------------------
MI_RESULT MI_TSENSOR_Open(const MI_TSENSOR_OpenParams_t *pstOpenParams, MI_HANDLE *phTsensor);

//------------------------------------------------------------------------------
/// @brief Close the TSENSOR
/// @param[in] hTSensor: The TSENSOR handle to be closed
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not inted.
/// @return MI_ERR_INVALID_HANDLE: handle error.
//------------------------------------------------------------------------------
MI_RESULT MI_TSENSOR_Close(MI_HANDLE hTsensor);

//------------------------------------------------------------------------------
/// @brief Register the callback function for receiving the events of TSENSOR related.
/// @param[in] hTsendor: A Handle of a created TSENSOR instance.
/// @param[in] pstInputParams: A pointer to structure MI_TSENSOR_CallbackInputParams_t for events registered.
/// @param[out] pstOutputParams: A pointer to structure MI_TSENSOR_CallbackOutputParams_t.
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE: hanlde is invalid.
/// @return MI_ERR_INVALID_PARAMETER: parameters is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_TSENSOR_RegisterCallback(MI_HANDLE hTsensor, const MI_TSENSOR_CallbackInputParams_t *pstInputParams, MI_TSENSOR_CallbackOutputParams_t *pstOutputParams);

//------------------------------------------------------------------------------
/// @brief UnRegister the callback function for receiving the events of TSENSOR related.
/// @param[in] hTsendor: A Handle of a created TSENSOR instance.
/// @param[in] pstInputParams: A pointer to structure MI_TSENSOR_CallbackInputParams_t for events registered.
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE: hanlde is invalid.
/// @return MI_ERR_INVALID_PARAMETER: parameters is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_TSENSOR_UnRegisterCallback(MI_HANDLE hTsensor, const MI_TSENSOR_CallbackInputParams_t *pstInputParams);

//------------------------------------------------------------------------------
/// @brief Get TSENSOR Current Temperature
/// @param[in] hTsensor : TSENSOR handle
/// @param[out] pUsrParam : User parameter
/// @return MI_OK: Get TSENSOR Current Temperature success
/// @return MI_ERR_NOT_INITED: TSENSOR module is not inited
/// @return MI_ERR_INVALID_HANDLE: Invalid TSENSOR handle
/// @return MI_ERR_FAILED: Process failed
//------------------------------------------------------------------------------
MI_RESULT MI_TSENSOR_GetCurrentTemperature(MI_HANDLE hTsensor, MI_S16 *ps16Temperature);

//------------------------------------------------------------------------------
/// @brief Get TSENSOR High Bound Temperature
/// @param[in] hTsensor : TSENSOR handle
/// @param[out] pUsrParam : User parameter
/// @return MI_OK: Get TSENSOR High Bound Temperature success
/// @return MI_ERR_NOT_INITED: TSENSOR module is not inited
/// @return MI_ERR_INVALID_HANDLE: Invalid TSENSOR handle
/// @return MI_ERR_FAILED: Process failed
//------------------------------------------------------------------------------
MI_RESULT MI_TSENSOR_GetHighBoundTemperature(MI_HANDLE hTsensor, MI_S16 *ps16Temperature);

//------------------------------------------------------------------------------
/// @brief Get TSENSOR Low Bound Temperature
/// @param[in] hTsensor : TSENSOR handle
/// @param[out] pUsrParam : User parameter
/// @return MI_OK: Get TSENSOR Low Bound Temperature success
/// @return MI_ERR_NOT_INITED: TSENSOR module is not inited
/// @return MI_ERR_INVALID_HANDLE: Invalid TSENSOR handle
/// @return MI_ERR_FAILED: Process failed
//------------------------------------------------------------------------------
MI_RESULT MI_TSENSOR_GetLowBoundTemperature(MI_HANDLE hTsensor, MI_S16 *ps16Temperature);

//------------------------------------------------------------------------------
/// @brief Set TSENSOR debug level.
/// @param[in] u32DebugLevel.
/// @return MI_OK: Set debug level success.
//------------------------------------------------------------------------------
MI_RESULT MI_TSENSOR_SetDebugLevel(MI_DBG_LEVEL u32DebugLevel);

#ifdef __cplusplus
}
#endif

#endif///_MI_TSENSOR_H_


