/*------------------------------------------------------------------------------
 * MediaTek Inc. (C) 2018. All rights reserved.
 *
 * Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 *----------------------------------------------------------------------------*/
// ------------------------------------------------------------------------------
// Use GetXxx/SetXxx Only
// ------------------------------------------------------------------------------

#ifndef _MI_SOCKET_H_
#define _MI_SOCKET_H_

#ifdef __cplusplus
extern "C" {
#endif

//-------------------------------------------------------------------------------------------------
//  Defines
//-------------------------------------------------------------------------------------------------
#define MI_SOCKET_INVALID_SOCKET_FD (-1)

#define MI_SOCKET_FDSET_SIZE    1024
#define MI_SOCKET_NFDBITS       (8*sizeof(MI_U32))
#define MI_SOCKET_FDSET     (MI_SOCKET_FDSET_SIZE/MI_SOCKET_NFDBITS)
#define MI_SOCKET_FD_SET(fd, pstFdset)   ((pstFdset)->au32FdBits[(fd) / MI_SOCKET_NFDBITS] |= (1 << ((fd) % MI_SOCKET_NFDBITS)))
#define MI_SOCKET_FD_CLR(fd, pstFdset)   ((pstFdset)->au32FdBits[(fd) / MI_SOCKET_NFDBITS] &= ~(1 << ((fd) % MI_SOCKET_NFDBITS)))
#define MI_SOCKET_FD_ISSET(fd, pstFdset) ((pstFdset)->au32FdBits[(fd) / MI_SOCKET_NFDBITS] &   (1 << ((fd) % MI_SOCKET_NFDBITS)))
#define MI_SOCKET_FD_ZERO(pstFdset)       do{\
        MI_U32 u32Idx = 0; \
        for (; u32Idx < MI_SOCKET_FDSET; u32Idx++) { \
            (pstFdset)->au32FdBits[u32Idx] = 0; \
        } \
    }while(0);
//-------------------------------------------------------------------------------------------------
//  Structures
//-------------------------------------------------------------------------------------------------
typedef enum
{
    E_MI_SOCKET_TYPE_STREAM = 0,
    E_MI_SOCKET_TYPE_DGRAM,
    E_MI_SOCKET_TYPE_RAW,
    E_MI_SOCKET_TYPE_RDM,
    E_MI_SOCKET_TYPE_SEQPACKET,
} MI_SOCKET_Type_e;

typedef enum
{
    E_MI_SOCKET_ADDRESS_FAMILY_AF_INET = 0,  //AF_INET
    E_MI_SOCKET_ADDRESS_FAMILY_AF_INET6 = 1,  //AF_INET6
    E_MI_SOCKET_ADDRESS_FAMILY_AF_UNSPEC = 2,  //AF_UNSPEC
} MI_SOCKET_AddrFamily_e;

typedef enum
{
    E_MI_SOCKET_IP_PROTOCOL_AUTO = 0,
    E_MI_SOCKET_IP_PROTOCOL_ICMP,
} MI_SOCKET_IpProtocol_e;

typedef enum
{
    E_MI_SOCKET_SHUTDOWN_OPS_RD = 0,
    E_MI_SOCKET_SHUTDOWN_OPS_WR,
    E_MI_SOCKET_SHUTDOWN_OPS_RDWR,
} MI_SOCKET_ShutdownOps_e;

typedef enum
{
    E_MI_SOCKET_OPT_LEVEL_SOL_SOCKET = 0,
    E_MI_SOCKET_OPT_LEVEL_IP_PROTOCOL_TCP,
    E_MI_SOCKET_OPT_LEVEL_IP_PROTOCOL_IP,
} MI_SOCKET_OptLevel_e;

typedef enum
{
    E_MI_SOCKET_OPT_NAME_SOCKET_DEBUG = 0x0001,
    E_MI_SOCKET_OPT_NAME_SOCKET_REUSEADDR = 0x0004,
    E_MI_SOCKET_OPT_NAME_SOCKET_KEEPALIVE = 0x0008,
    E_MI_SOCKET_OPT_NAME_SOCKET_DONTROUTE = 0x0010,
    E_MI_SOCKET_OPT_NAME_SOCKET_BROADCAST = 0x0020,
    E_MI_SOCKET_OPT_NAME_SOCKET_LINGER = 0x0080,
    E_MI_SOCKET_OPT_NAME_SOCKET_OOBINLINE = 0x0100,
    E_MI_SOCKET_OPT_NAME_SOCKET_SNDBUF = 0x1001,
    E_MI_SOCKET_OPT_NAME_SOCKET_RCVBUF = 0x1002,
    E_MI_SOCKET_OPT_NAME_SOCKET_SNDLOWAT = 0x1003,
    E_MI_SOCKET_OPT_NAME_SOCKET_RCVLOWAT = 0x1004,
    E_MI_SOCKET_OPT_NAME_SOCKET_SNDTIMEO = 0x1005,
    E_MI_SOCKET_OPT_NAME_SOCKET_RCVTIMEO = 0x1006,
    E_MI_SOCKET_OPT_NAME_SOCKET_ERROR = 0x1007,
    E_MI_SOCKET_OPT_NAME_SOCKET_TYPE = 0x1008,
    E_MI_SOCKET_OPT_NAME_SOCKET_NO_CHECK=0x000B,
    E_MI_SOCKET_OPT_NAME_SOCKET_PRIORITY=0x000C,
} MI_SOCKET_OptNameSocket_e;

typedef enum
{
    E_MI_SOCKET_OPT_NAME_TCP_NODELAY=1,
    E_MI_SOCKET_OPT_NAME_TCP_MAXSEG=2,
} MI_SOCKET_OptNameTcp_e;

typedef enum
{
    E_MI_SOCKET_OPT_NAME_IP_TOS=1,
    E_MI_SOCKET_OPT_NAME_IP_TTL=2,
    E_MI_SOCKET_OPT_NAME_IP_HDRINCL=3,
    E_MI_SOCKET_OPT_NAME_IP_OPTIONS=4,
    E_MI_SOCKET_OPT_NAME_IP_ADD_MEMBERSHIP=35,
    E_MI_SOCKET_OPT_NAME_IP_DROP_MEMBERSHIP=36,
} MI_SOCKET_OptNameIp_e;

//flags can be or together
typedef enum
{
    E_MI_SOCKET_FLAGS_MSG_NULL          = 0x0,
    E_MI_SOCKET_FLAGS_MSG_OOB       = 0x1,
    E_MI_SOCKET_FLAGS_MSG_PEEK      = 0x2,
    E_MI_SOCKET_FLAGS_MSG_DONTROUTE = 0x4,
    E_MI_SOCKET_FLAGS_MSG_CTRUNC    = 0x8,
    E_MI_SOCKET_FLAGS_MSG_TRUNC     = 0x10,
    E_MI_SOCKET_FLAGS_MSG_DONTWAIT  = 0x20,
    E_MI_SOCKET_FLAGS_MSG_EOR       = 0x40,
    E_MI_SOCKET_FLAGS_MSG_WAITALL   = 0x80,
    E_MI_SOCKET_FLAGS_MSG_CONFIRM   = 0x100,
    E_MI_SOCKET_FLAGS_MSG_ERRQUEUE  = 0x200,
    E_MI_SOCKET_FLAGS_MSG_NOSIGNAL  = 0x400,
    E_MI_SOCKET_FLAGS_MSG_MORE      = 0x800,
} MI_SOCKET_FlagsMsg_e;

typedef enum
{
    E_MI_SOCKET_IOCTL_CMD_FIONBIO=0, //set the blocking flag
    E_MI_SOCKET_IOCTL_CMD_FIONREAD,  //get how many bytes could be read in the socket
} MI_SOCKET_IoctlCmd_e;

typedef struct MI_SOCKET_OptName_s
{
    union
    {
        MI_SOCKET_OptNameSocket_e eOptNameSocket;   ///[IN]: Opt Name Socket
        MI_SOCKET_OptNameTcp_e eOptNameTcp;    ///[IN]: Opt Name Tcp
        MI_SOCKET_OptNameIp_e eOptNameIp;    ///[IN]: Opt Name IP
    };
} MI_SOCKET_OptName_t;

typedef struct MI_SOCKET_InitParams_s
{
    MI_U8 u8Reserved;    ///[IN]: Reserved for future
} MI_SOCKET_InitParams_t;

typedef struct MI_SOCKET_Fdset_s
{
    MI_U32 au32FdBits[MI_SOCKET_FDSET];    ///[IN]: File descriptor Set
} MI_SOCKET_Fdset_t;

typedef struct MI_SOCKET_SocketAddr_s
{
    MI_SOCKET_AddrFamily_e  eFamily:16;    ///[IN]: Address family
    MI_U8   au8SaData[14];    ///[IN]: SA Data
} MI_SOCKET_SocketAddr_t;

typedef struct MI_SOCKET_InAddr_s
{
    MI_U32  u32Addr;    ///[IN]: IP Address
} MI_SOCKET_InAddr_t;

typedef struct MI_SOCKET_InAddr6_s
{
    MI_U8  au8Addr[16];    ///[IN]: IPV6 Address
} MI_SOCKET_InAddr6_t;

typedef struct MI_SOCKET_SocketAddrIn_s
{
    MI_SOCKET_AddrFamily_e eSinFamily:16;    ///[IN]: sin family
    MI_U16 u16SinPort;    ///[IN]: port number
    MI_SOCKET_InAddr_t stSinAddr;    ///[IN]: internet address
    MI_U8 au8SinZero[8];    ///[IN]: reserved
} MI_SOCKET_SocketAddrIn_t;

typedef struct MI_SOCKET_SocketAddrIn6_s
{
    MI_SOCKET_AddrFamily_e eSinFamily:16;    ///[IN]: sin family
    MI_U16 u16SinPort;    ///[IN]: port number
    MI_U32 u32Flowinfo;    ///[IN]: IPV6 flow information
    MI_SOCKET_InAddr6_t stSinAddr;    ///[IN]: IPV6 internet address
    MI_U32 u32ScopeId;    ///[IN]: scope id
} MI_SOCKET_SocketAddrIn6_t;

typedef struct MI_SOCKET_Timevalue_s
{
    MI_U32 u32TimeValueSec;    ///[OUT]: seconds
    MI_U32 u32TimeValueUSec;    ///[OUT]: micro seconds
} MI_SOCKET_Timevalue_t;

typedef struct MI_SOCKET_Linger_s
{
    MI_U16 u16OnOff;     ///[OUT]: Linger on-off
    MI_U16 u16Linger;    ///[OUT]: Linger time
} MI_SOCKET_Linger_t;

typedef struct MI_SOCKET_IpMreq_s
{
    MI_SOCKET_InAddr_t stImrMultiAddr;    ///[IN]: Multi-Address
    MI_SOCKET_InAddr_t stImrInterface;    ///[IN]: Interface
} MI_SOCKET_IpMreq_t;

//Data entry of the host
typedef struct MI_SOCKET_Hostent_s
{
    MI_U8 *pszHostName;    ///[OUT]: host name
    MI_U8 **ppszHostAliases;    ///[OUT]: Alias list
    MI_S32 s32HostAddrType;    ///[OUT]: host address type
    MI_S32 s32HostLength;    ///[OUT]: Length of address
    MI_U8 **ppszHostAddrList;    ///[OUT]: address list from name server
} MI_SOCKET_Hostent_t;

typedef struct MI_SOCKET_AddrInfo_s
{
    MI_S32 s32Flag;    ///[OUT]: flag
    MI_S32 s32Family;    ///[OUT]: address family
    MI_S32 s32Socktype;    ///[OUT]: socket type
    MI_S32 s32Protocol;    ///[OUT]: protocol
    MI_U32 u32Addrlen;    ///[OUT]: address length
    MI_SOCKET_SocketAddr_t *pstSocketAddr;    ///[OUT]: socket address
    MI_U8 *pszCanonname;    ///[OUT]: canonical name
    struct MI_SOCKET_AddrInfo_s *pstAddrInfoNext;    ///[OUT]: next structure
} MI_SOCKET_AddrInfo_t;

//-------------------------------------------------------------------------------------------------
//  Global Functions
//-------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------
/// @brief Init socket module.
/// @param[in]. pstInitParam: Parameter to init socket module
/// @return MI_OK: Process success.
/// @return MI_HAS_INITED: UART module had inited.
//------------------------------------------------------------------------------
MI_RESULT MI_SOCKET_Init(const MI_SOCKET_InitParams_t *pstInitParams);

//------------------------------------------------------------------------------
/// @brief Finalize socket module.
/// @param[none].
/// @return MI_OK: Process success.
//------------------------------------------------------------------------------
MI_RESULT MI_SOCKET_DeInit(void);

//------------------------------------------------------------------------------
/// @brief Open a socket to access.
/// @param[in] u16Family: The address family type(Ex. D_MI_SOCKET_ADDRESS_FAMILY_AF_INET)
/// @param[in] eType: The connection type
/// @param[in] eProtocol: The used transmission protocol(Usually E_MI_SOCKET_AUTO)
/// @return -1: Open socket failed.
/// @return >=0: The created socket fd.
/// @Note. Please reference socket api in linux for more info.
//------------------------------------------------------------------------------
MI_S32 MI_SOCKET_Open(MI_SOCKET_AddrFamily_e eFamily, MI_SOCKET_Type_e eType, MI_SOCKET_IpProtocol_e eProtocol);

//------------------------------------------------------------------------------
/// @brief Close a socket.
/// @param[in] s32SocketFd: The socket to close.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not inted.
/// @return MI_ERR_FAILED: Close socket fail.
/// @Note. Please reference close api in linux for more info.
//------------------------------------------------------------------------------
MI_RESULT MI_SOCKET_Close(MI_S32 s32SocketFd);

//------------------------------------------------------------------------------
/// @brief Terminate the communication of the socket.
/// @param[in] s32SocketFd: The socket to termincate.
/// @param[in] eShutdownOps: Shutdown operation.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not inted.
/// @return MI_ERR_FAILED: Shutdown socket fail.
/// @Note. Please reference shutdown api in linux for more info.
//------------------------------------------------------------------------------
MI_RESULT MI_SOCKET_Shutdown(MI_S32 s32SocketFd, MI_SOCKET_ShutdownOps_e eShutdownOps);

//------------------------------------------------------------------------------
/// @brief Accept the socket connection.
/// @param[in] s32SocketFd: The socket fd.
/// @param[out] pSocketAddr: Pointer to the address structure to store info. when success
/// @param[out] ps32AddrLen: The structure length of pSocketAddr
/// @return -1: Processing fail.
/// @return >=0: Processing success and return the new socket fdl.
/// @Note. Please reference accept api in linux for more info.
//------------------------------------------------------------------------------
MI_S32 MI_SOCKET_Accept(MI_S32 s32SocketFd, void *pSocketAddr, MI_S32 *ps32AddrLen);

//------------------------------------------------------------------------------
/// @brief Binding the socket to a host.
/// @param[in] s32SocketFd: The socket fd to bind.
/// @param[in] pMyAddr: Pointer of address structure to bind
/// @param[in] s32AddrLen: The length of input sturcture of pMyAddr
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not inted.
/// @return MI_ERR_FAILED: Shutdown socket fail.
/// @return MI_ERR_INVALID_PARAMETER: Invalid parameter.
/// @Note. Please reference bind api in linux for more info.
//------------------------------------------------------------------------------
MI_RESULT MI_SOCKET_Bind(MI_S32 s32SocketFd, void *pMyAddr, MI_S32 s32AddrLen);

//------------------------------------------------------------------------------
/// @brief Connect the socket to a server.
/// @param[in] s32SocketFd: The socket fd to bind.
/// @param[in] pstSocketAddrServer: Pointer to the server address info
/// @param[in] s32AddrLen: The structure length of pServerAddr
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not inted.
/// @return MI_ERR_FAILED: Shutdown socket fail.
/// @return MI_ERR_INVALID_PARAMETER: Invalid parameter.
/// @Note. Please reference connect api in linux for more info.
//------------------------------------------------------------------------------
MI_RESULT MI_SOCKET_Connect(MI_S32 s32SocketFd, MI_SOCKET_SocketAddr_t *pstSocketAddrServer, MI_S32 s32AddrLen);

//------------------------------------------------------------------------------
/// @brief Listen to the connection.
/// @param[in] s32SocketFd: The socket fd to listen.
/// @param[in] s32Backlog: The max number of connect request
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not inted.
/// @return MI_ERR_FAILED: Shutdown socket fail.
/// @Note. Please reference listen api in linux for more info.
//------------------------------------------------------------------------------
MI_RESULT MI_SOCKET_Listen(MI_S32 s32SocketFd, MI_S32 s32Backlog);

//------------------------------------------------------------------------------
/// @brief Listen to the connection.
/// @param[in] s32SocketFd: The socket fd to listen.
/// @param[in] eCmd: IO control command
/// @param[in] pArg: Arguments of the command
/// @return -1: Processing failed.
/// @return >=0: Processing success.
/// @Note. Please reference ioctl api in linux for more info.
//------------------------------------------------------------------------------
MI_S32 MI_SOCKET_Ioctl(MI_S32 s32SocketFd, MI_SOCKET_IoctlCmd_e eCmd, void *pArg);

//------------------------------------------------------------------------------
/// @brief Get the max support number.
/// @param[in] ps32Sockets: Return the support number.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not inted.
/// @return MI_ERR_FAILED: Processing failed.
/// @return MI_ERR_INVALID_PARAMETER: Invalid parameter.
//------------------------------------------------------------------------------
MI_RESULT MI_SOCKET_GetMaxSockets(MI_S32 *ps32Sockets);

//------------------------------------------------------------------------------
/// @brief Get the Host infomation by address.
/// @param[in] pszAddr: The host address.
/// @param[in] s32Len: The size of the host address
/// @param[in] u16FamilyType: The address family type
/// @return NULL: Processing failed.
/// @return >0: Return the point pointer to the host infomation structure.
/// @Note. Please reference gethostbyaddr api in linux for more info.
/// @Note. In IPV6, we suggest to use MI_SOCKET_GetNameInfo.
//------------------------------------------------------------------------------
MI_SOCKET_Hostent_t* MI_SOCKET_GetHostByAddr(const MI_U8 *pszAddr, MI_S32 s32Len, MI_SOCKET_AddrFamily_e eFamilyType);

//------------------------------------------------------------------------------
/// @brief Get the host infomation by host name.
/// @param[in] pszName: The host address.
/// @return NULL: Processing failed.
/// @return >0: Return the point pointer to the host infomation structure.
/// @Note. Please reference gethostbyname api in linux for more info.
/// @Note. For IPV4 only.
//------------------------------------------------------------------------------
MI_SOCKET_Hostent_t* MI_SOCKET_GetHostByName(const MI_U8 *pszName);

//------------------------------------------------------------------------------
/// @brief Get the host name infomation by host address.
/// @param[in] pstSocketAddr: The host address.
/// @param[in] u32AddrLength: The length of pstAddr.
/// @param[out] pszHost: The host name info.
/// @param[out] u32HostLength: The length of pszHost.
/// @param[out] pszService: The service name.
/// @param[out] u32ServiceLength: The length of pszService.
/// @param[in] s32Flags: The flags.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Processing failed.
/// @Note. Please reference getnameinfo api in linux for more info.
//------------------------------------------------------------------------------
MI_RESULT MI_SOCKET_GetNameInfo(MI_SOCKET_SocketAddr_t *pstSocketAddr, MI_U32 u32AddrLength, MI_U8* pszHost, MI_U32 u32HostLength, MI_U8* pszService, MI_U32 u32ServiceLength, MI_S32 s32Flags);

//------------------------------------------------------------------------------
/// @brief Get the host address infomation by host name.
/// @param[in] pszName: The host name.
/// @param[in] pszService: The service.
/// @param[in] pstAddrInfoHints: The hints.
/// @param[out] ppstAddrInfoResult: The address information.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Processing failed.
/// @Note. Please reference getaddrinfo api in linux for more info.
//------------------------------------------------------------------------------
MI_RESULT MI_SOCKET_GetAddrInfo(const MI_U8 *pszName, const MI_U8 *pszService, MI_SOCKET_AddrInfo_t* pstAddrInfoHints, MI_SOCKET_AddrInfo_t** ppstAddrInfoResult);

//------------------------------------------------------------------------------
/// @brief Free the address infomation.
/// @param[in] pstAddrInfo: The pointer of addrinfo that you want to free.
/// @Note. Please reference freeaddrinfo api in linux for more info.
//------------------------------------------------------------------------------
void MI_SOCKET_FreeAddrInfo(MI_SOCKET_AddrInfo_t* pstAddrInfo);

//------------------------------------------------------------------------------
/// @brief Get the host name.
/// @param[out] pszHostName: The buffer to store host name.
/// @param[in] s32Size: The size of the buffer.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not inted.
/// @return MI_ERR_FAILED: Processing failed.
/// @return MI_ERR_INVALID_PARAMETER: Invalid parameter.
/// @Note. Please reference gethostname api in linux for more info.
//------------------------------------------------------------------------------
MI_RESULT MI_SOCKET_GetHostName(MI_U8 *pszHostName, MI_S32 s32Size);

//------------------------------------------------------------------------------
/// @brief Get name of connected peer socket
/// @param[in] s32SocketFd: The buffer to store host name.
/// @param[out] pAddr: Pointer to the address structure to store info when success.
/// @param[in] ps32AddrLen: The size of the structure of pstAddr .
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not inted.
/// @return MI_ERR_FAILED: Processing failed.
/// @return MI_ERR_INVALID_PARAMETER: Invalid parameter.
/// @Note. Please reference gethostname api in linux for more info.
//------------------------------------------------------------------------------
MI_RESULT MI_SOCKET_GetPeerName(MI_S32 s32SocketFd, void *pAddr, MI_S32 *ps32AddrLen);

//------------------------------------------------------------------------------
/// @brief Get the local address of the socket.
/// @param[in] s32SocketFd: The socket fd.
/// @param[out] pstSocketAddr: Pointer to the address structure to store info when success
/// @param[in/out] ps32SocketAddrLen:  As input, it indicate the structure size of pstSockAddr,
///                                                  As output, it contains the actual size of the socket address
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not inted.
/// @return MI_ERR_FAILED: Processing failed.
/// @return MI_ERR_INVALID_PARAMETER: Invalid parameter.
/// @Note. Please reference getsockname api in linux for more info.
//------------------------------------------------------------------------------
MI_RESULT MI_SOCKET_GetSockName(MI_S32 s32SocketFd, void *pSocketAddr, MI_S32 *ps32SockAddrLen);

//------------------------------------------------------------------------------
/// @brief Get the option of the socket.
/// @param[in] s32SocketFd: The socket fd.
/// @param[in] eLevel: The level of the option
/// @param[in] eOptName: The option name
/// @param[out] pOptValue: Pointer to the option value buffer
/// @param[in] ps32OptLen: The length of the option value buffer
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not inted.
/// @return MI_ERR_FAILED: Processing failed.
/// @return MI_ERR_INVALID_PARAMETER: Invalid parameter.
/// @Note. Please reference getsockname api in linux for more info.
//------------------------------------------------------------------------------
MI_RESULT MI_SOCKET_GetSockOpt(MI_S32 s32SocketFd, MI_SOCKET_OptLevel_e eLevel, MI_SOCKET_OptName_t stOptName, void *pOptValue, MI_S32 *ps32OptLen);

//------------------------------------------------------------------------------
/// @brief Check the read/write/exception status of the sockets.
/// @param[in] u32NFds: The max fd-values plus one
/// @param[in] pstReadFdSet: Pointer to the fd set to check if readable
/// @param[in] pstWriteFdSet: Pointer to the fd set to check if writable
/// @param[in] pstExceptFdSet: Pointer to the fd set to check if exception occurring
/// @param[in] s32Timeout: The waiting time to timeout in ms
/// @return -1: Processing Failed.
/// @return 0: Timeout error.
/// @return >0: The number of fd which is ready.
/// @Note. Please reference select api in linux for more info.
//------------------------------------------------------------------------------
MI_S32 MI_SOCKET_Select(MI_U32 u32NFds, MI_SOCKET_Fdset_t *pstReadFdSet, MI_SOCKET_Fdset_t *pstWriteFdSet, MI_SOCKET_Fdset_t *pstExceptFdSet, MI_S32 s32Timeout);

//------------------------------------------------------------------------------
/// @brief Set the status of the socket.
/// @param[in] s32SocketFd: The socket fd to set.
/// @param[in] eLevel: The level of the option
/// @param[in] eOptName: The option name
/// @param[in] pOptValue: Pointer to the option value buffer
/// @param[in] s32OptLen: The length of the option value buffer
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not inted.
/// @return MI_ERR_FAILED: Processing failed.
/// @return MI_ERR_INVALID_PARAMETER: Invalid parameter.
/// @Note. Please reference setsockopt api in linux for more info.
//------------------------------------------------------------------------------
MI_RESULT MI_SOCKET_SetSockOpt(MI_S32 s32SocketFd, MI_SOCKET_OptLevel_e eLevel, MI_SOCKET_OptName_t stOptName, void *pOptValue, MI_S32 s32OptLen);

//------------------------------------------------------------------------------
/// @brief Receive data from socket.
/// @param[in] s32SocketFd: The fd of the receiving socket.
/// @param[out] pBuf: Buffer to get data
/// @param[in] s32Len: The size of the buffer
/// @param[in] eFlags: The operation flag, usually set E_MI_SOCKET_FLAGS_NULL
/// @return -1: Processing fail.
/// @return >=0: Processing success and return the number of the receiving data.
/// @Note. Please reference recv api in linux for more info.
//------------------------------------------------------------------------------
MI_S32 MI_SOCKET_Recv(MI_S32 s32SocketFd, void *pBuf, MI_S32 s32Len, MI_SOCKET_FlagsMsg_e eFlags);

//------------------------------------------------------------------------------
/// @brief Receive data from socket and get the address transmitter.
/// @param[in] s32SocketFd: The fd of the receiving socket.
/// @param[out] pBuf: Buffer to get data
/// @param[in] s32Len: The size of the buffer
/// @param[in] eFlags: The operation flag, usually set E_MI_SOCKET_FLAGS_NULL
/// @param[out] pFromAddr: Pointer to get the address of transmitter
/// @param[in] pu32FromAddrLen: The structure length of pstFromAddr
/// @return -1: Processing fail.
/// @return >=0: Processing success and return the number of the receiving data.
/// @Note. Please reference recv api in linux for more info.
//------------------------------------------------------------------------------
MI_S32 MI_SOCKET_RecvFrom(MI_S32 s32SocketFd, void *pBuf, MI_S32 s32Len, MI_SOCKET_FlagsMsg_e eFlags, void *pFromAddr, MI_U32 *pu32FromAddrLen);

//------------------------------------------------------------------------------
/// @brief send data through socket.
/// @param[in] s32SocketFd: The socket fd of the trasmitter.
/// @param[in] pMsg: Msg buffer to send
/// @param[in] s32Len: The size of the msg buffer
/// @param[in] eFlags: The operation flag, usually set E_MI_SOCKET_FLAGS_NULL
/// @return -1: Processing fail.
/// @return >=0: Processing success and return the number of the sending data.
/// @Note. Please reference send api in linux for more info.
//------------------------------------------------------------------------------
MI_S32 MI_SOCKET_Send(MI_S32 s32SocketFd, void *pMsg, MI_S32 s32Len, MI_SOCKET_FlagsMsg_e eFlags);

//------------------------------------------------------------------------------
/// @brief send data to specific address through socket.
/// @param[in] s32SocketFd: The socket fd of the trasmitter.
/// @param[in] pMsg: Msg buffer to send
/// @param[in] s32Len: The size of the msg buffer
/// @param[in] eFlags: The operation flag, usually set E_MI_SOCKET_FLAGS_NULL
/// @param[in] pToAddr: Pointer to the address of receiver
/// @param[in] s32ToAddrLen: The structure size of pstToAddr
/// @return -1: Processing fail.
/// @return >=0: Processing success and return the number of the sending data.
/// @Note. Please reference sendto api in linux for more info.
//------------------------------------------------------------------------------
MI_S32 MI_SOCKET_SendTo(MI_S32 s32SocketFd, void *pMsg, MI_S32 s32Len, MI_SOCKET_FlagsMsg_e eFlags, void *pToAddr, MI_S32 s32ToAddrLen);

//------------------------------------------------------------------------------
/// @brief Translate the 32-bit host byte order to network byte order.
/// @param[in] u32HostLong: The long integer host byte order.
/// @return long integer network byte order.
/// @Note. Please reference htonl api in linux for more info.
//------------------------------------------------------------------------------
MI_U32 MI_SOCKET_Htonl(MI_U32 u32HostLong);

//------------------------------------------------------------------------------
/// @brief Translate the 16-bit host byte order to network byte order.
/// @param[in] u16HostShort: The short integer host byte order.
/// @return short integer network byte order.
/// @Note. Please reference htons api in linux for more info.
//------------------------------------------------------------------------------
MI_U16 MI_SOCKET_Htons(MI_U16 u16HostShort);

//------------------------------------------------------------------------------
/// @brief Translate the 32-bit network byte order to host byte order.
/// @param[in] u32NetLong: The long integer network byte order.
/// @return long integer host byte order.
/// @Note. Please reference ntohl api in linux for more info.
//------------------------------------------------------------------------------
MI_U32 MI_SOCKET_Ntohl(MI_U32 u32NetLong);

//------------------------------------------------------------------------------
/// @brief Translate the 16-bit network byte order to host byte order.
/// @param[in] u16NetLong: The short integer network byte order.
/// @return short integer host byte order.
/// @Note. Please reference ntohs api in linux for more info.
//------------------------------------------------------------------------------
MI_U16 MI_SOCKET_Ntohs(MI_U16 u16NetShort);

//------------------------------------------------------------------------------
/// @brief Translate the ASCII network address to 32-bit interger(host-byte-order).
/// @param[in] pszIp: The ASCII network address.
/// @return 0: Processing fail.
/// @return 32-bit interger of the input address .
/// @Note. Take "255.255.255.255" as a noneffective value
/// @Note. Please reference inet_addr api in linux for more info.
/// @Note. IPV4 only.
//------------------------------------------------------------------------------
MI_S32 MI_SOCKET_InetAddr(const MI_U8 *pszIp);

//------------------------------------------------------------------------------
/// @brief Translate the ASCII network address to 32-bit interger.
/// @param[in] pszIp: The ASCII network address.
/// @param[out] pstInAddr: Pointer to the structure to store the 32-bit integer.
/// @return -1: Module not inited or Invalid Parameter.
/// @return 0: Processing fail.
/// @return non-zero: Processing success .
/// @Note. Take "255.255.255.255" as a effective value
/// @Note. Please reference inet_aton api in linux for more info.
/// @Note. IPV4 only.
//------------------------------------------------------------------------------
MI_S32 MI_SOCKET_InetAton(MI_U8 *pszIp, MI_SOCKET_InAddr_t *pstInAddr);

//------------------------------------------------------------------------------
/// @brief Translate the 32-bit interger to ASCII address string.
/// @param[in] stInAddr: The 32-bit network address.
/// @return NULL: Processing fail
/// @return the pointer point to the address string.
/// @Note. Please reference inet_ntoa api in linux for more info.
/// @Note. IPV4 only.
//------------------------------------------------------------------------------
MI_U8* MI_SOCKET_InetNtoa(MI_SOCKET_InAddr_t stInAddr);

//------------------------------------------------------------------------------
/// @brief Translate the text network address to binary form.
/// @param[in] eAddrFamily: The address family
/// @param[in] pszIp: The text network address.
/// @param[out] pInAddr: Pointer to the structure to store ipv4 or ipv6 binary form network address.
/// @return -1: Module not inited or Invalid Parameter.
/// @return 0: Processing fail.
/// @return non-zero: Processing success .
/// @Note. Take "255.255.255.255" or "FFFF:FFFF:FFFF:FFFF:FFFF:FFFF:FFFF:FFFF" as a effective value
/// @Note. Please reference inet_pton api in linux for more info.
//------------------------------------------------------------------------------
MI_S32 MI_SOCKET_InetPton(MI_SOCKET_AddrFamily_e eAddrFamily, MI_U8 *pszIp, void *pInAddr);

//------------------------------------------------------------------------------
/// @brief Translate the binary address to text form.
/// @param[in] s32AddressFamily: The address family
/// @param[in] pSrc: The source network address structure.
/// @param[out] pszDst: Pointer to the structure to store ipv4 or ipv6 text form network address.
/// @param[in] u32Length: The maximum length of pszDst.
/// @return pszDst: Processing success.
/// @return NULL: Processing fail.
/// @Note. Please reference inet_ntop api in linux for more info.
//------------------------------------------------------------------------------
MI_U8* MI_SOCKET_InetNtop(MI_S32 s32AddressFamily, void *pSrc, MI_U8 *pszDst, MI_U32 u32Length);

//------------------------------------------------------------------------------
/// @brief Set socket debug level.
/// @param[in] eDgbLevel.
/// @return MI_OK: Set debug level success.
//------------------------------------------------------------------------------
MI_RESULT MI_SOCKET_SetDebugLevel(MI_DBG_LEVEL u32DebugLevel);

#ifdef __cplusplus
}
#endif

#endif///_MI_SOCKET_H_

