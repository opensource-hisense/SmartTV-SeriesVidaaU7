/*------------------------------------------------------------------------------
 * MediaTek Inc. (C) 2018. All rights reserved.
 *
 * Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 *----------------------------------------------------------------------------*/
//------------------------------------------------------------------------------
//GetXxx/SetXxx and GetAttr/SetAttr coexist
//------------------------------------------------------------------------------

#ifndef _MI_AEXTIN_H_
#define _MI_AEXTIN_H_

#ifdef __cplusplus
extern "C" {
#endif

//-------------------------------------------------------------------------------------------------
//  Defines
//-------------------------------------------------------------------------------------------------
#define MI_AEXTIN_PAL_THRESHOLD_BUFFER_NUM      56
#define MI_AEXTIN_BTSC_THRESHOLD_BUFFER_NUM     10
//-------------------------------------------------------------------------------------------------
//  Structures
//-------------------------------------------------------------------------------------------------
typedef enum
{
    E_MI_AEXTIN_TYPE_HDMI = 0,
    E_MI_AEXTIN_TYPE_COMPONENT,
    E_MI_AEXTIN_TYPE_ATV,
    E_MI_AEXTIN_TYPE_VGA,
    E_MI_AEXTIN_TYPE_CVBS,
    E_MI_AEXTIN_TYPE_SVIDEO,
    E_MI_AEXTIN_TYPE_SCART,
    E_MI_AEXTIN_TYPE_YPBPR,
    E_MI_AEXTIN_TYPE_DVI,
    E_MI_AEXTIN_TYPE_MIC,           ///< microphone input source.
    E_MI_AEXTIN_TYPE_MAX,

    //legacy enum, deprecated  enum, compatible to new enum
    E_MI_AEXTIN_HDMI  = E_MI_AEXTIN_TYPE_HDMI,
    E_MI_AEXTIN_COMPONENT = E_MI_AEXTIN_TYPE_COMPONENT,
    E_MI_AEXTIN_ATV = E_MI_AEXTIN_TYPE_ATV,
    E_MI_AEXTIN_MAX = E_MI_AEXTIN_TYPE_MAX,

} MI_AEXTIN_Type_e;

typedef enum
{
    E_MI_AEXTIN_ATTR_TYPE_HDMI_MIN = 0x0,
    E_MI_AEXTIN_ATTR_TYPE_HDMI_MAX,

    E_MI_AEXTIN_ATTR_TYPE_COMPONENT_MIN = 0x1000,
    E_MI_AEXTIN_ATTR_TYPE_COMPONENT_MAX,

    E_MI_AEXTIN_ATTR_TYPE_ATV_MIN = 0x2000,
    E_MI_AEXTIN_ATTR_TYPE_ATV_AUTO_DETECT_STANDARD, ///< Set atv detect audio standard, pParam is a pointer to MI_BOOL: TRUE:start auto detect; FALSE:stop auto detect
    E_MI_AEXTIN_ATTR_TYPE_ATV_MONITOR,              ///< Set atv monitor. Check Atv standard and Atv Soundmode. Need to start before play ATV. parameter type is pointer to MI_BOOL.
    E_MI_AEXTIN_ATTR_TYPE_ATV_SOUND_MODE,           ///< Set/Get atv sound mode, parameter type is a pointer to MI_AEXTIN_AtvSoundModeType_e.
    E_MI_AEXTIN_ATTR_TYPE_ATV_SUPPORTED_SOUND_MODE, ///< Get atv max supported sound mode, parameter type is a pointer to MI_AEXTIN_AtvSoundModeType_e.
    E_MI_AEXTIN_ATTR_TYPE_ATV_HIGH_DEVIATION_MODE,  ///< Set atv high deviation mode, parameter type is a pointer to MI_AEXTIN_AtvHighDeviationMode_e.
    E_MI_AEXTIN_ATTR_TYPE_ATV_PRESCALE,             ///< Set atv audio prescale, parameter type is a pointer to MI_AEXTIN_AtvPrescale_t.
    E_MI_AEXTIN_ATTR_TYPE_ATV_THRESHOLD,            ///< Set atv audio standard detect threshold table, parameter type is a pointer to MI_AEXTIN_AtvThresholdTable_t.
    E_MI_AEXTIN_ATTR_TYPE_ATV_AUTO_MUTE,            ///< Set atv auto mute control,threshold is set in E_MI_AEXTIN_ATTR_TYPE_ATV_THRESHOLD, paramter type is a pointer to MI_AEXTIN_AtvAutoMuteParams_t.
    E_MI_AEXTIN_ATTR_TYPE_ATV_MAX,

    E_MI_AEXTIN_ATTR_TYPE_OUTPUT_MIN = 0x8000,
    E_MI_AEXTIN_ATTR_TYPE_MULTI_MUTE,              ///< Set mute of sif device, parameter type is a pointer to MI_SIF_MultiMuteParams_t, get status of mute, parameter type is a pointer to MI_BOOL.
    E_MI_AEXTIN_ATTR_TYPE_VOLUME,                  ///< Set/Get the volume of sif device, parameter type is a pointer to MI_U8. (Maximum volume is 100).
    E_MI_AEXTIN_ATTR_TYPE_VOLUME_DB,               ///< Set/Get the volume of sif device by DB, parameter type is a pointer to MI_AEXTIN_VolumeDb_t.
    E_MI_AEXTIN_ATTR_TYPE_VOLUME_TABLE,            ///< Set the volume table of sif device, parameter type is a pointer to array which size is 101.
    E_MI_AEXTIN_ATTR_TYPE_OUTPUT_DELAY,            ///< Set/Get the delay of sif device, parameter type is a pointer to to MI_U32.
    E_MI_AEXTIN_ATTR_TYPE_EASE,                    ///< Set or get the ease effect of output channel, parameter type is a pointer to MI_AEXTIN_EaseParams_t.
    E_MI_AEXTIN_ATTR_TYPE_OUTPUT_MAX,

    E_MI_AEXTIN_ATTR_TYPE_MAX,
} MI_AEXTIN_AttrType_e;

//ATV standard type
typedef enum
{
    //invalid standard type
    E_MI_AEXTIN_ATV_STANDARD_TYPE_INVALID          = -1,
    //B/G standard
    E_MI_AEXTIN_ATV_STANDARD_TYPE_BG               = 0,
    //I standard
    E_MI_AEXTIN_ATV_STANDARD_TYPE_I,
    //D/K standard
    E_MI_AEXTIN_ATV_STANDARD_TYPE_DK,
    //L standard
    E_MI_AEXTIN_ATV_STANDARD_TYPE_L,
    //M standard
    E_MI_AEXTIN_ATV_STANDARD_TYPE_M,
    //BTSC M standard
    E_MI_AEXTIN_ATV_STANDARD_TYPE_M_BTSC,
    //N standard
    E_MI_AEXTIN_ATV_STANDARD_TYPE_N,
    //standar max
    E_MI_AEXTIN_ATV_STANDARD_TYPE_MAX,
} MI_AEXTIN_AtvStandardType_e;

typedef enum
{
    //invalid sound mode
    E_MI_AEXTIN_ATV_SOUND_MODE_TYPE_INVALID        = -1,
    //mono
    E_MI_AEXTIN_ATV_SOUND_MODE_TYPE_MONO           = 0x00,
    //stereo
    E_MI_AEXTIN_ATV_SOUND_MODE_TYPE_STEREO,
    //BTSC mono + sap
    E_MI_AEXTIN_ATV_SOUND_MODE_TYPE_MONO_SAP,
    //BTSC stereo + sap
    E_MI_AEXTIN_ATV_SOUND_MODE_TYPE_STEREO_SAP,
    //A2 Dual A
    E_MI_AEXTIN_ATV_SOUND_MODE_TYPE_DUAL_A,
    //A2 Dual B
    E_MI_AEXTIN_ATV_SOUND_MODE_TYPE_DUAL_B,
    //A2 Dual AB
    E_MI_AEXTIN_ATV_SOUND_MODE_TYPE_DUAL_AB,
    //Nicam mono
    E_MI_AEXTIN_ATV_SOUND_MODE_TYPE_NICAM_MONO,
    //Nicam stereo
    E_MI_AEXTIN_ATV_SOUND_MODE_TYPE_NICAM_STEREO,
    //Nicam dual A
    E_MI_AEXTIN_ATV_SOUND_MODE_TYPE_NICAM_DUAL_A,
    //Nicam dual B
    E_MI_AEXTIN_ATV_SOUND_MODE_TYPE_NICAM_DUAL_B,
    //Nicam dual AB
    E_MI_AEXTIN_ATV_SOUND_MODE_TYPE_NICAM_DUAL_AB,
    //sound mode max
    E_MI_AEXTIN_ATV_SOUND_MODE_TYPE_MAX,
}MI_AEXTIN_AtvSoundModeType_e;

typedef enum
{
    //high deviation mode off
    E_MI_AEXTIN_ATV_HIGH_DEVIATION_MODE_OFF,
    //high deviation mode min level
    E_MI_AEXTIN_ATV_HIGH_DEVIATION_MODE_MIN_LEVEL,
    //high deviation mode normal level
    E_MI_AEXTIN_ATV_HIGH_DEVIATION_MODE_NORMAL_LEVEL,
    //high deviation mode max level
    E_MI_AEXTIN_ATV_HIGH_DEVIATION_MODE_MAX_LEVEL,
    //high deviation mode max
    E_MI_AEXTIN_ATV_HIGH_DEVIATION_MODE_MAX,
}MI_AEXTIN_AtvHighDeviationMode_e;

typedef struct MI_AEXTIN_InitParams_s
{
    MI_U8 u8Reserved;                  ///< [IN]: Reserved.
} MI_AEXTIN_InitParams_t;

typedef struct MI_AEXTIN_OpenParams_s
{
    MI_AEXTIN_Type_e  eAextinType;    ///[IN]:Audio Extin device
    MI_U32 u32Index;                  ///[IN]:Index of Selected Audio Extin device,range:0~1.
} MI_AEXTIN_OpenParams_t;

typedef struct MI_AEXTIN_Caps_s
{
    MI_U8 u8Reserved;              ///< [OUT]: Reserved.
} MI_AEXTIN_Caps_t;

typedef struct MI_AEXTIN_QueryHandleParams_s
{
    MI_AEXTIN_Type_e  eAextinType; ///[IN]:Audio Extin device
    MI_U32 u32Index;               ///[IN]:Index of Selected Audio Extin device,range:0~1.
} MI_AEXTIN_QueryHandleParams_t;

typedef struct MI_AEXTIN_AtvPrescale_s
{
    //[-12 ~ +10]dB, 0.25dB/step
    //eg:  Fm + 5dB---->s32Fm = 5dB/0.25dB
    MI_S32 s32Fm;               ///< [IN]:A2 & Fm
    MI_S32 s32FmInM;            ///< [IN]:Fm M Standard:differernt filter
    MI_S32 s32HighDeviation;    ///< [IN]:High deviation
    MI_S32 s32HighDeviationM;   ///< [IN]:High deviation M standard: different filter
    MI_S32 s32Nicam;            ///< [IN]:Nicam
    MI_S32 s32Am;               ///< [IN]:Am eg:France
    MI_S32 s32Btsc;             ///< [IN]:BTSC
} MI_AEXTIN_AtvPrescale_t;

typedef struct MI_AEXTIN_AtvThresholdTable_s
{
    MI_AEXTIN_AtvStandardType_e eStandard; ///<[IN]:Audio Standard.BTSC or  PAL
    MI_U32  u32ThresholdBufSize;           ///<[IN]:size of Threshold.BTSC table size 10*U16  PAL VIF/SIF table size  56*U16
    MI_U16 *pu16ThresholdBuf;              ///<[IN]:Buffer of Threshold,eg:First threshold value is 0x1234. High value:12 low value:34.
} MI_AEXTIN_AtvThresholdTable_t;

typedef struct MI_AEXTIN_VolumeDb_s
{
   MI_S32      s32Integer;          //[IN]:Integer part of volume, range from -114 to +12dB
   MI_S32      s32Fraction;         //[IN]:Fractional part of volume, 125: 0.125dB resolution:0.125dB
} MI_AEXTIN_VolumeDb_t;

typedef struct MI_AEXTIN_MultiMuteParams_s
{
    MI_U8*  pszMuteName;                 ///< [IN]:Set Mute Event name.eg: "atv mute". Max length of name size: 64.
    MI_BOOL bMute;                       ///< [IN]:True: Mute; False Unmute;
    MI_U32  u32AutoUnmuteTimer;          ///< [IN]:Auto unmute audio in a period of millisecond. 0 is disable auto unmute.
} MI_AEXTIN_MultiMuteParams_t;

typedef struct MI_AEXTIN_AtvAutoMuteParams_s
{
    MI_BOOL bEnable;                  ///< [IN]:True:Enable auto mute; False:Disable auto mute.
} MI_AEXTIN_AtvAutoMuteParams_t;

//-------------------------------------------------------------------------------------------------
//  Global Functions
//-------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------
/// @brief Init Audio Extin module.
/// @param[in] *pstInitParams. Init parameter
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_AEXTIN_Init(const MI_AEXTIN_InitParams_t* pstInitParams);
//------------------------------------------------------------------------------
/// @brief Finalize Audio Extin module.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_AEXTIN_DeInit(void);
//------------------------------------------------------------------------------
/// @brief Get Audio Extin capability.
/// @param[out] *pstCaps. Output Aextin capacities.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_AEXTIN_GetCaps(MI_AEXTIN_Caps_t *pstCaps);
//------------------------------------------------------------------------------
/// @brief Open a Aextin handle.
/// @param[in] *pstOpenParams. Inputed open paramters.
/// @param[out] *phAextin. Output Aextin handle.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_RESOURCES: No available resource.
//------------------------------------------------------------------------------
MI_RESULT MI_AEXTIN_Open(const MI_AEXTIN_OpenParams_t* pstOpenParams, MI_HANDLE* phAextin);
//------------------------------------------------------------------------------
/// @brief Close a hAextin handle.
/// @param[in] hAextin. Aextin handle to process.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_AEXTIN_Close(MI_HANDLE hAextin);
//------------------------------------------------------------------------------
/// @brief Set atv Standard
/// @param[in] hAextin. Aextin handle to process.
/// @param[in] eStandard. Atv audio standard.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_AEXTIN_SetAtvStandard(MI_HANDLE hAextin, MI_AEXTIN_AtvStandardType_e eStandard);
//------------------------------------------------------------------------------
/// @brief Get atv Standard
/// @param[in] hAextin. Aextin handle to process.
/// @param[out] * peStandard. Atv audio standard.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_AEXTIN_GetAtvStandard(MI_HANDLE hAextin, MI_AEXTIN_AtvStandardType_e* peStandard);
//------------------------------------------------------------------------------
/// @brief Get aextin attribute.
/// @param[in] hAextin. Aextin handle to process.
/// @param[in] eAttrType. Type of attribution.
/// @param[in] *pInputParams. Input paramters.
/// @param[out] *pOutputParams. Output paramters.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_AEXTIN_GetAttr(MI_HANDLE hAextin, MI_AEXTIN_AttrType_e eAttrType, const void *pInputParams, void *pOutputParams);
//------------------------------------------------------------------------------
/// @brief Set aextin attribute.
/// @param[in] hAextin. Aextin handle to process.
/// @param[in] eAttrType. Type of attribution.
/// @param[in] *pAttrParams. Input paramters.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_AEXTIN_SetAttr(MI_HANDLE hAextin, MI_AEXTIN_AttrType_e eAttrType, const void *pAttrParams);
//------------------------------------------------------------------------------
/// @brief Get a Aextin handle.
/// @param[in] *pstQueryParams. Paramters for getting handle.
/// @param[out] *phAextin. Output Audio Extin handle.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_AEXTIN_GetHandle(const MI_AEXTIN_QueryHandleParams_t *pstQueryParams, MI_HANDLE *phAextin);
//------------------------------------------------------------------------------
/// @brief Set debug level for mi_aextin.c.
/// @param[in] u32DebugLevel. Debug level to be setted.
/// @return MI_OK: Process success.
//------------------------------------------------------------------------------
MI_RESULT MI_AEXTIN_SetDebugLevel(MI_DBG_LEVEL u32DebugLevel);
//------------------------------------------------------------------------------


#ifdef __cplusplus
}
#endif

#endif///_MI_AEXTIN_H_
