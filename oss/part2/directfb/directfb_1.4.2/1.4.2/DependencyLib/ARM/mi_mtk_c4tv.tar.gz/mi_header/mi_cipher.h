/*------------------------------------------------------------------------------
 * MediaTek Inc. (C) 2018. All rights reserved.
 *
 * Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 *----------------------------------------------------------------------------*/
//-------------------------------------------------------------------------------------------------
//  Use GetAttr/SetAttr only
//-------------------------------------------------------------------------------------------------

#ifndef _MI_CIPHER_H_
#define _MI_CIPHER_H_

#ifdef __cplusplus
extern "C" {
#endif

//-------------------------------------------------------------------------------------------------
//  Defines
//-------------------------------------------------------------------------------------------------
#define MI_CIPHER_KEY_SIZE_MAX                             (16)
#define MI_CIPHER_DES_KEY_SIZE_MAX                         (8)
#define MI_CIPHER_DIGEST_SIZE_MD5                          (16)
#define MI_CIPHER_DIGEST_SIZE_SHA_1                        (20)
#define MI_CIPHER_DIGEST_SIZE_SHA_256                      (32)
#define MI_CIPHER_RSAKEY_DEFAULT_SIZE                      (512)
#define MI_CIPHER_HASH_BLOCK_SIZE_SHA1                     (64)
#define MI_CIPHER_HASH_BLOCK_SIZE_SHA256                   (64)
#define MI_CIPHER_HASH_BLOCK_SIZE_MD5                      (64)

//-------------------------------------------------------------------------------------------------
//  Structures
//-------------------------------------------------------------------------------------------------

typedef enum
{
    E_MI_CIPHER_ALGO_AES = 0,
    E_MI_CIPHER_ALGO_DES,
    E_MI_CIPHER_ALGO_TDES,
    E_MI_CIPHER_ALGO_MAX,
} MI_CIPHER_Algo_e;

typedef enum
{
    ///the following work mode is ECB
    E_MI_CIPHER_WORK_MODE_ECB = 0,
    E_MI_CIPHER_WORK_MODE_CTS_ECB,
    E_MI_CIPHER_WORK_MODE_ECB_MAX,
    ///the following work mode is CBC
    E_MI_CIPHER_WORK_MODE_CBC=0x100,
    E_MI_CIPHER_WORK_MODE_CTS_CBC,
    E_MI_CIPHER_WORK_MODE_CBC_MAC,
    E_MI_CIPHER_WORK_MODE_CBC_MAX,
    ///the following work mode is CTR
    E_MI_CIPHER_WORK_MODE_CTR=0x200,
    E_MI_CIPHER_WORK_MODE_CTR_MAX,
} MI_CIPHER_WorkMode_e;

typedef enum
{
    E_MI_CIPHER_CA_VENDOR_ID_INVALID = 0,
    E_MI_CIPHER_CA_VENDOR_ID_NDS,
    E_MI_CIPHER_CA_VENDOR_ID_NAGRA,
    E_MI_CIPHER_CA_VENDOR_ID_VIACCESS,
    E_MI_CIPHER_CA_VENDOR_ID_IRDETO,
    E_MI_CIPHER_CA_VENDOR_ID_VMX,
    E_MI_CIPHER_CA_VENDOR_ID_SMI,
    E_MI_CIPHER_CA_VENDOR_ID_CONAX,
    E_MI_CIPHER_CA_VENDOR_ID_LATENS,
    E_MI_CIPHER_CA_VENDOR_ID_DRM,
    E_MI_CIPHER_CA_VENDOR_ID_DRE,
    E_MI_CIPHER_CA_VENDOR_ID_CTI,
    E_MI_CIPHER_CA_VENDOR_ID_SUMA,
    E_MI_CIPHER_CA_VENDOR_ID_TFCA,
    E_MI_CIPHER_CA_VENDOR_ID_NSTV,
    E_MI_CIPHER_CA_VENDOR_ID_BESTCAS,
    E_MI_CIPHER_CA_VENDOR_ID_DEFAULT,
    E_MI_CIPHER_CA_VENDOR_ID_MAX,
}MI_CIPHER_CaVendorId_e;

typedef enum
{
    E_MI_CIPHER_KEY_SOURCE_CPU = 0,                         /// < Using Key in MI_CIPHER_AttrParams_t
    E_MI_CIPHER_KEY_SOURCE_KL,                              /// < Key is generated by Key Ladder
    E_MI_CIPHER_KEY_SOURCE_MAX
} MI_CIPHER_KeySource_e;

typedef enum
{
    E_MI_CIPHER_HASH_ALGO_SHA1 = 0,                        /// < HSAH algorithm: SHA-1
    E_MI_CIPHER_HASH_ALGO_SHA256 ,                         /// < HASH algorithm: SHA-256
    E_MI_CIPHER_HASH_ALGO_MD5 ,                            /// < HSAH algorithm: MD5
    E_MI_CIPHER_HASH_ALGO_MAX
} MI_CIPHER_HashAlgo_e;


typedef enum
{
    E_MI_CIPHER_RSA1024_PUBLIC = 0,                        /// < RsaMode: RSA1024 public
    E_MI_CIPHER_RSA1024_PRIVATE,                           /// < RsaMode: RSA1024 private
    E_MI_CIPHER_RSA2048_PUBLIC,                            /// < RsaMode: RSA2048 public
    E_MI_CIPHER_RSA2048_PRIVATE,                           /// < RsaMode: RSA2048 private
    E_MI_CIPHER_RSA256_PUBLIC,                             /// < RsaMode: RSA256 public
    E_MI_CIPHER_RSA256_PRIVATE,                            /// < RsaMode: RSA256 private
    E_MI_CIPHER_RSA_MAX
} MI_CIPHER_RsaMode_e;

typedef enum
{
    E_MI_CIPHER_DATA_FORMAT_NONE,
    E_MI_CIPHER_DATA_FORMAT_TS_PKT188,
    E_MI_CIPHER_DATA_FORMAT_TS_PKT192,
    E_MI_CIPHER_DATA_FORMAT_MAX
} MI_CIPHER_DataFormat_e;

typedef enum
{
    E_MI_CIPHER_KEY_TYPE_EVEN = 0,
    E_MI_CIPHER_KEY_TYPE_ODD,
    E_MI_CIPHER_KEY_TYPE_MAX
} MI_CIPHER_DscKeyType_e;

typedef struct MI_CIPHER_InitParams_s
{
    MI_U8 u8MiuNum;                                         ///[IN]: Miu Number
} MI_CIPHER_InitParams_t;

typedef struct MI_CIPHER_OpenParams_s
{
    MI_U8 * pszName;                                        ///< [IN]: Custom defined module instance name which is a string with zero terminated.
    MI_U32 u32CipherId;                                     ///< [IN]: Cihper module ID
    MI_CIPHER_CaVendorId_e eCaVendorId;                     ///< [IN]: CA Vender ID
} MI_CIPHER_OpenParams_t;

typedef struct MI_CIPHER_TsPktDataFormatParams_s
{
    MI_U32 u32PidNum;
    MI_U16 *pu16Pid;
    MI_CIPHER_DscKeyType_e eKeyType;
} MI_CIPHER_TsPktDataFormatParams_t;

typedef struct MI_CIPHER_ConfigParams_s
{
    MI_CIPHER_Algo_e eCipherAlgo;                           ///[IN]: Algorithm of cipher module
    MI_CIPHER_WorkMode_e eCipherWorkMode;                   ///[IN]: Algorithm of cipher module
    MI_CIPHER_KeySource_e eKeySrc;                          ///[IN]: Indicate where the key source from
    MI_U32 u32KeySize;                                      ///[IN]: Key size
    MI_U8 au8Key[MI_CIPHER_KEY_SIZE_MAX];                   ///[IN]: Key date
    MI_U8 au8Iv[MI_CIPHER_KEY_SIZE_MAX];                    ///[IN]: IV data
    MI_CIPHER_DataFormat_e eDataFormat;
    union
    {
         MI_CIPHER_TsPktDataFormatParams_t stTsPkt;
    };
} MI_CIPHER_ConfigParams_t;

typedef struct MI_CIPHER_DataParams_s
{
    MI_U32 u32DataSize;                                     ///[IN]: Data buffer size
    MI_U8 *pu8SrcBuf;                                       ///[IN]: Source data buffer, virtual address and physically continuous
    MI_U8 *pu8DestBuf;                                      ///[IN]: Dest data buffer, virtual address and physically continuous
} MI_CIPHER_DataParams_t;

typedef struct MI_CIPHER_HashParams_s
{
    MI_CIPHER_HashAlgo_e eAlgo;                             ///[IN]: HSAH algorithm
    MI_CIPHER_DataParams_t stCipherData;                    ///[IN]: Data information
    MI_BOOL bMoreData;                                      ///[IN]: Set true when not the last fragment

}MI_CIPHER_HashParams_t;

typedef struct MI_CIPHER_HmacParams_s
{
    MI_CIPHER_HashAlgo_e eAlgo;                             ///[IN]: HSAH algorithm
    MI_CIPHER_DataParams_t stCipherData;                    ///[IN]: Data information
    MI_CIPHER_KeySource_e eKeySrc;                          ///[IN]: Indicate where the key source from
    MI_U32 u32KeySize;                                      ///[IN]: Key size
    MI_U8 au8Key[MI_CIPHER_KEY_SIZE_MAX];                   ///[IN]: Key date
    MI_BOOL bMoreData;                                      ///[IN]: Set true when not the last fragment
}MI_CIPHER_HmacParams_t;

typedef struct MI_CIPHER_DumpInfoParams_s
{
    MI_BOOL bAll;                                           ///[IN]: enable info
}MI_CIPHER_DumpInfoParams_t;

typedef struct MI_CIPHER_RsaParams_s
{
    MI_CIPHER_RsaMode_e eRsaMode;
    MI_U8 *pu8SrcBuf;                                       ///[IN]: inpout Data  buffer
    MI_U32 u32SrcBufLen;                                    ///[IN]: inpout Data  buffer size
    MI_U8 *pu8DestBuf;                                      ///[IN]: output Data  buffer
    MI_U32 u32DestBufLen;                                   ///[IN]: output Data  buffer size
    MI_U8 *pu8RsaKeyBuf;                                    ///[IN]: RSA key buffer
    MI_U32 u32RsaKeyBufLen;                                 ///[IN]: RSA key buffer size
} MI_CIPHER_RsaParams_t;

typedef struct MI_CIPHER_RandomParams_s
{
    MI_U8* pu8DataBuf;                                      ///[OUT]: Random Data buffer, virtual address
    MI_U32 u32DataBufLen;                                   ///[IN]: Random Data buffer size
} MI_CIPHER_RandomParams_t;

typedef struct MI_CIPHER_QueryHandleParams_s
{
    MI_U8 *pszName;                                         ///[IN]: cipher handle with string name.
}MI_CIPHER_QueryHandleParams_t;

//-------------------------------------------------------------------------------------------------
//  Global Functions
//-------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------
/// @brief Init Cipher module.
/// @param[in] pstInitParam: A pointer to structure MI_CIPHER_InitParams_t for initialization.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_CIPHER_Init(const MI_CIPHER_InitParams_t *pstInitParams);

//------------------------------------------------------------------------------
/// @brief Finalize Cipher module.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_CIPHER_DeInit(void);

//------------------------------------------------------------------------------
/// @brief Open a Cipher handle.
/// @param[in] pstOpenParam: A pointer to structure MI_CIPHER_OpenParams_t for open cipher module.
/// @param[out] phCipher: A handle pointer to retrieve an instance of a created cipher module.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_RESOURCES: No available resource.
//------------------------------------------------------------------------------
MI_RESULT MI_CIPHER_Open(const MI_CIPHER_OpenParams_t *pstOpenParams, MI_HANDLE *phCipher);

//------------------------------------------------------------------------------
/// @brief Close a Cipher handle.
/// @param[in] hCipher: An instance of a created cipher module.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_CIPHER_Close(MI_HANDLE hCipher);

//------------------------------------------------------------------------------
/// @brief setup Cipher.
/// @param[in] hCipher: An instance of a created cipher module.
/// @param[in] pstConfigParams: A pointer to structure MI_CIPHER_ConfigParams_t for cipher module parameters.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_CIPHER_ConfigEngine(MI_HANDLE hCipher, MI_CIPHER_ConfigParams_t *pstConfigParams);

//------------------------------------------------------------------------------
/// @brief Encrypt data.
/// @param[in] hCipher: An instance of a created cipher module.
/// @param[in] pstDataParam: A pointer to structure MI_CIPHER_DataParams_t for doing encryption.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_CIPHER_Encrypt(MI_HANDLE hCipher, MI_CIPHER_DataParams_t *pstDataParams);

//------------------------------------------------------------------------------
/// @brief Decrypt data.
/// @param[in] hCipher: An instance of a created cipher module.
/// @param[in] pstDataParam: A pointer to structure MI_CIPHER_DataParams_t for doing decryption.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_CIPHER_Decrypt(MI_HANDLE hCipher, MI_CIPHER_DataParams_t *pstDataParams);

//------------------------------------------------------------------------------
/// @brief Calculate HASH value.
/// @param[in] hCipher: An instance of a created cipher module.
/// @param[in] pstHashParams: A pointer to structure MI_CIPHER_HashParams_t for calculating HASH.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_TIMEOUT: Process timeout.
/// @return MI_ERR_NOT_SUPPORT: Not support HASH.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_CIPHER_CalculateHash (MI_HANDLE hCipher, MI_CIPHER_HashParams_t *pstHashParams);

//------------------------------------------------------------------------------
/// @brief Calculate HMAC value.
/// @param[in] hCipher: An instance of a created cipher module.
/// @param[in] pstHmacParams: A pointer to structure MI_CIPHER_HmacParams_t for calculating MAC.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_TIMEOUT: Process timeout.
/// @return MI_ERR_NOT_SUPPORT: Not support HMAC.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_CIPHER_CalculateHmac (MI_HANDLE hCipher, MI_CIPHER_HmacParams_t *pstHmacParams);

//------------------------------------------------------------------------------
/// @brief Dump Cipher Info.
/// @param[in] pstDumpInfoParams: TRUE for print all resources, FALSE for print opned resources only.
/// @return MI_OK: Dump information success.
//------------------------------------------------------------------------------
MI_RESULT MI_CIPHER_DumpInfo(const MI_CIPHER_DumpInfoParams_t *pstDumpInfoParams);

//------------------------------------------------------------------------------
/// @brief RSA signature verify
/// @param[in] hCipher: An instance of a created cipher module.
/// @param[in] pstRsaParams: struct for rsa calculate parameters.
/// @return MI_OK: Dump information success.
//------------------------------------------------------------------------------
MI_RESULT MI_CIPHER_CalculateRsa(MI_HANDLE hCipher, MI_CIPHER_RsaParams_t *pstRsaParams);

//------------------------------------------------------------------------------
/// @brief Get Random from HW AESDMA IP.
/// @param[in] An instance of a created cipher module.
/// @param[in] pstRandomParams: struct for geting random info parameters.
/// @return MI_OK: Dump information success.
//------------------------------------------------------------------------------
MI_RESULT MI_CIPHER_GetRandom(MI_HANDLE hCipher, MI_CIPHER_RandomParams_t *pstRandomParams);

//------------------------------------------------------------------------------
/// @brief Set Cipher debug level.
/// @param[in] u32DebugLevel.
/// @return MI_OK: Set debug level success.
//------------------------------------------------------------------------------
MI_RESULT MI_CIPHER_SetDebugLevel(MI_DBG_LEVEL u32DebugLevel);

//------------------------------------------------------------------------------
/// @brief get Cipher handle.
/// @param[in]  pstQueryParams: Query parameters
/// @param[out] *phCipher: cipher handler
/// @return MI_OK: Get cipher handle success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_INVALID_PARAMETER: parameter null
//------------------------------------------------------------------------------
MI_RESULT MI_CIPHER_GetHandle(const MI_CIPHER_QueryHandleParams_t *pstQueryParams, MI_HANDLE *phCipher);
#ifdef __cplusplus
}
#endif

#endif///_MI_CIPHER_H_
