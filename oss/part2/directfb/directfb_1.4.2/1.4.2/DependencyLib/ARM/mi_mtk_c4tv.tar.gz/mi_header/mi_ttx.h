/*------------------------------------------------------------------------------
 * MediaTek Inc. (C) 2018. All rights reserved.
 *
 * Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 *----------------------------------------------------------------------------*/
//----------------------------------------------------------------------------------------
//   GetXxx/SetXxx and GetAttr/SetAttr coexit
//----------------------------------------------------------------------------------------

#ifndef _MI_TTX_H_
#define _MI_TTX_H_

#ifdef __cplusplus
extern "C" {
#endif
//-------------------------------------------------------------------------------------------------
//  Defines
//-------------------------------------------------------------------------------------------------
#define MI_TTX_INVALID_PAGE_NUMBER 0xFFFF

//-------------------------------------------------------------------------------------------------
//  Enums
//-------------------------------------------------------------------------------------------------
///TTX Source mode
typedef enum
{
    /// Disable source in
    E_MI_TTX_SRC_MODE_NONE = 0,
    /// source path use ANALOG(ATV/AV/SV/SCART)
    E_MI_TTX_SRC_MODE_ANALOG,
    /// source path use digital input(TS LiveIn/FileIn)
    E_MI_TTX_SRC_MODE_DIGITAL,
    /// source path use raw data(for MM)
    E_MI_TTX_SRC_MODE_RAW_DATA,
    /// source mode max
    E_MI_TTX_SRC_MODE_MAX,
} MI_TTX_SrcMode_e;

///TTX Show Mode
typedef enum
{
    /// Teletext normal mode
    E_MI_TTX_SHOW_MODE_NORMAL = 0,
    /// Teletext subtitle mode
    E_MI_TTX_SHOW_MODE_SUBTITLE,
    /// Teletext clock mode
    E_MI_TTX_SHOW_MODE_CLOCK,
    /// Teletext show mode max
    E_MI_TTX_SHOW_MODE_MAX,
} MI_TTX_ShowMode_e;

///TTX Language group
typedef enum
{
    /// Teletext Language group WEST
    E_MI_TTX_LANGUAGE_GROUP_WEST = 0,
    /// Teletext Language group EAST,
    E_MI_TTX_LANGUAGE_GROUP_EAST,
    /// Teletext Language group RUSSIAN,
    E_MI_TTX_LANGUAGE_GROUP_RUSSIAN,
    /// Teletext Language group ARABIC,
    E_MI_TTX_LANGUAGE_GROUP_ARABIC,
    /// Teletext Language group FARSI,
    E_MI_TTX_LANGUAGE_GROUP_FARSI,
    /// Teletext Language group max
    E_MI_TTX_LANGUAGE_GROUP_MAX,
} MI_TTX_LanguageGroup_e;

///Set/Get Attr Parameter type
typedef enum
{
    /// Teletext set attr min
    E_MI_TTX_ATTR_TYPE_SET_MIN = 0x100,
    /// Teletext set language group: pAttrParams : MI_TTX_LanguageGroup_e
    E_MI_TTX_ATTR_TYPE_SET_LANGUAGE_GROUP = E_MI_TTX_ATTR_TYPE_SET_MIN,
    /// Teletext set list page number:  pAttrParams :MI_TTX_ListPageNumber_t *
    E_MI_TTX_ATTR_TYPE_SET_LIST_PAGE_NUMBER,
    /// Teletext set index page number:  pAttrParams :MI_TTX_PageNumber_t *
    E_MI_TTX_ATTR_TYPE_SET_INDEX_PAGE_NUMBER,
    /// Teletext set attr max
    E_MI_TTX_ATTR_TYPE_SET_MAX,
    /// Teletext get attr min
    E_MI_TTX_ATTR_TYPE_GET_MIN = 0x200,
    /// Teletext get status :pOutputParams : MI_TTX_Status_t *
    E_MI_TTX_ATTR_TYPE_GET_STATUS = E_MI_TTX_ATTR_TYPE_GET_MIN,
    /// Teletext get has valid ttx data  or not :pOutputParams : MI_BOOL *
    E_MI_TTX_ATTR_TYPE_GET_DATA_READY,
    /// Teletext get has valid ttx clock data or not :pOutputParams : MI_BOOL *
    E_MI_TTX_ATTR_TYPE_GET_CLOCK_EXISTED,
    /// Teletext get attr max
    E_MI_TTX_ATTR_TYPE_GET_MAX,
} MI_TTX_AttrType_e;

/// TTX key event
typedef enum
{
    ///< 0: IR input digit 0 : param: void *
    E_MI_TTX_INPUT_KEY_DIGIT0 = 0,
    ///< 1: IR input digit 1 : param: void *
    E_MI_TTX_INPUT_KEY_DIGIT1 = 1,
    ///< 2: IR input digit 2 : param: void *
    E_MI_TTX_INPUT_KEY_DIGIT2 = 2,
    ///< 3: IR input digit 3 : param: void *
    E_MI_TTX_INPUT_KEY_DIGIT3 = 3,
    ///< 4: IR input digit 4 : param: void *
    E_MI_TTX_INPUT_KEY_DIGIT4 = 4,
    ///< 5: IR input digit 5 : param: void *
    E_MI_TTX_INPUT_KEY_DIGIT5 = 5,
    ///< 6: IR input digit 6 : param: void *
    E_MI_TTX_INPUT_KEY_DIGIT6 = 6,
    ///< 7: IR input digit 7 : param: void *
    E_MI_TTX_INPUT_KEY_DIGIT7 = 7,
    ///< 8: IR input digit 8 : param: void *
    E_MI_TTX_INPUT_KEY_DIGIT8 = 8,
    ///< 9: IR input digit 9 : param: void *
    E_MI_TTX_INPUT_KEY_DIGIT9 = 9,
    ///< 10: IR input Page UP : param: void *
    E_MI_TTX_INPUT_KEY_PAGE_UP = 10,
    ///< 11: IR input Page DOWN : param: void *
    E_MI_TTX_INPUT_KEY_PAGE_DOWN = 11,
    ///< 12: IR input Page LEFT : param: void *
    E_MI_TTX_INPUT_KEY_PAGE_LEFT = 12,
    ///< 13: IR input Page RIGHT : param: void *
    E_MI_TTX_INPUT_KEY_PAGE_RIGHT = 13,
    ///< 14: IR input RED key : param: void *
    E_MI_TTX_INPUT_KEY_RED = 14,
    ///< 15: IR input GREEN key : param: void *
    E_MI_TTX_INPUT_KEY_GREEN = 15,
    ///< 16: IR input YELLOW key : param: void *
    E_MI_TTX_INPUT_KEY_YELLOW = 16,
    ///< 17: IR input CYAN key : param: void *
    E_MI_TTX_INPUT_KEY_CYAN = 17,
    ///< 18: Go to "INDEX" page : param: void *
    E_MI_TTX_INPUT_KEY_INDEX = 18,
    ///< 19: Enable "Clock" mode (Show Clock when Teletext is OFF)  : param: MI_TTX_KeyTriggerMode_t *
    /// this key is invalid, pls use MI_TTX_Show when ttx is hidden instead.
    E_MI_TTX_INPUT_KEY_CLOCK = 19,
    ///< 20: Enable "MIX" mode : param: MI_TTX_KeyTriggerMode_t *
    E_MI_TTX_INPUT_KEY_MIX = 20,
    ///< 21: Enable "UPDATE" mode : param: MI_TTX_KeyTriggerMode_t *
    E_MI_TTX_INPUT_KEY_UPDATE = 21,
    ///< 22: Enable "HOLD" mode : param: MI_TTX_KeyTriggerMode_t *
    E_MI_TTX_INPUT_KEY_HOLD = 22,
    ///< 23: Change Teletext "SIZE" mode (Toggle: Zoom In Uphalf -> Zoom In Lowhalf -> Normal) : param: MI_TTX_KeyTriggerMode_t *
    E_MI_TTX_INPUT_KEY_SIZE = 23,
    ///< 24: Enable "Reveal" function : param: MI_TTX_KeyTriggerMode_t *
    E_MI_TTX_INPUT_KEY_REVEAL = 24,
    ///< 25:  show subpage function : param: MI_TTX_KeyTriggerMode_t *
    E_MI_TTX_INPUT_KEY_SUBPAGE = 25,
    ///< 26: list mode function : param: MI_TTX_KeyTriggerMode_t *
    E_MI_TTX_INPUT_KEY_LIST = 26,
    ///< 27: ttx index page number set function : param: MI_TTX_KeyParamsPageNumber_t
    /// this key is invalid, pls use MI_TTX_SetAttr instead.
    E_MI_TTX_INPUT_KEY_SET_INDEX_PAGE = 27,
     ///< 28: go to subtitle page, no params
    E_MI_TTX_INPUT_KEY_SUBTITLE_NAVI = 28,
    ///< 29: input key max
    E_MI_TTX_INPUT_KEY_MAX,
} MI_TTX_InputKey_e;

/// TTX key params Open/Close/Toggle
typedef enum
{
    E_MI_TTX_KEY_TRIGGER_MODE_OFF = 0,
    E_MI_TTX_KEY_TRIGGER_MODE_ON = 1,
    E_MI_TTX_KEY_TRIGGER_MODE_TOGGLE  = 2,
    E_MI_TTX_KEY_TRIGGER_MODE_MAX
}MI_TTX_KeyTriggerMode_e;

//-------------------------------------------------------------------------------------------------
//  Structures
//-------------------------------------------------------------------------------------------------
/// TTX init parameter
typedef struct MI_TTX_InitParams_s
{
    MI_U8 u8Reserved;
} MI_TTX_InitParams_t;

// Analog source params
typedef struct MI_TTX_AnalogSrcParams_s
{
    MI_HANDLE hVbi;
}MI_TTX_AnalogSrcParams_t;

// Digital source params
typedef struct MI_TTX_DigitalSrcParams_s
{
    MI_DMX_PathParams_t stDmxPathParams;
    MI_U16 u16Pid;
}MI_TTX_DigitalSrcParams_t;

/// TTX open parameter
typedef struct MI_TTX_OpenParams_s
{
    /// TTX SrcMode
    MI_TTX_SrcMode_e eSrcMode;
    /// TTX Source info
    union
    {
        MI_TTX_AnalogSrcParams_t stAnalogTtxParams;
        MI_TTX_DigitalSrcParams_t stDigitalTtxParams;
    };
    /// Open vbi output or not
    MI_BOOL bEnableAnalogOutput ;
} MI_TTX_OpenParams_t;

/// TTX show parameter
typedef struct MI_TTX_ShowParams_s
{
    /// TTX SrcMode
    MI_TTX_ShowMode_e eShowMode;
    /// page number
    MI_U16 u16PageNumber;
    /// subpage number
    MI_U16 u16SubpageNumber;
} MI_TTX_ShowParams_t;

/// TTX start parameter
typedef struct MI_TTX_StartParams_s
{
    /// show or not
    MI_BOOL bShow;
    ///TTX  show params
    MI_TTX_ShowParams_t stShowParams;
} MI_TTX_StartParams_t;

/// TTX key param  Open/Close/Toggle
typedef struct MI_TTX_KeyTriggerMode_s
{
    MI_TTX_KeyTriggerMode_e eKeyTriggerMode;
} MI_TTX_KeyTriggerMode_t;

/// TTX key param common
typedef struct MI_TTX_KeyParamsPageNumber_s
{
    MI_U32 u32Page;
    MI_U32 u32Subpage;
} MI_TTX_KeyParamsPageNumber_t;

/// TTX page number param
typedef struct MI_TTX_PageNumber_s
{
    MI_U16 u16Page;
    MI_U16 u16Subpage;
} MI_TTX_PageNumber_t;

/// TTX status
typedef struct MI_TTX_Status_s
{
    /// RUNNING or not
    MI_BOOL bRunning;
    /// Shown or not
    MI_BOOL bShown;
} MI_TTX_Status_t;

/// TTX list page number
typedef struct MI_TTX_ListPageNumber_s
{
    /// Red page number
    MI_U16 u16RedPage;
    /// Green page number
    MI_U16 u16GreenPage;
    /// Yellow page number
    MI_U16 u16YellowPage;
    /// Cyan page number
    MI_U16 u16CyanPage;
}MI_TTX_ListPageNumber_t;

/// TTX push raw data params for MM
typedef struct MI_TTX_PushDataParams_s
{
    ///< [IN]: Data buffer for TTX
    MI_U8   *pu8DataBuf;
    ///< [IN]: Size of data for buffer, unit: byte
    MI_U32  u32BufSize;
} MI_TTX_PushDataParams_t;

/// TTX push raw data output params
typedef struct MI_TTX_PushDataOutputParams_s
{
    ///< [OUT]Return Size of data.Valid written data size.
    MI_U32  u32ReturnSize;
} MI_TTX_PushDataOutputParams_t;

//-------------------------------------------------------------------------------------------------
//  Global Functions
//-------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------
/// @brief do ttx init
/// @param[in] *pstInitParams
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: init fail.
//------------------------------------------------------------------------------
MI_RESULT MI_TTX_Init(const MI_TTX_InitParams_t *pstInitParams);

//------------------------------------------------------------------------------
/// @brief do ttx deinit
/// @param[in] none
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: deinit fail.
//------------------------------------------------------------------------------
MI_RESULT MI_TTX_DeInit(void);

//------------------------------------------------------------------------------
/// @brief Open ttx handler
/// @param[in] *pstOpenParams : open params
/// @param[out] *phTtx: ttx handler
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process failed
/// @return MI_ERR_INVALID_PARAMETER: Null parameter
//------------------------------------------------------------------------------
MI_RESULT MI_TTX_Open(const MI_TTX_OpenParams_t *pstOpenParams, MI_HANDLE *phTtx);

//------------------------------------------------------------------------------
/// @brief close ttx handler
/// @param[in] hTtx ttx handle.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process failed
//------------------------------------------------------------------------------
MI_RESULT MI_TTX_Close(MI_HANDLE hTtx);

//------------------------------------------------------------------------------
/// @brief start ttx decode, show (can config) ttx
/// @param[in] hTtx ttx handle.
/// @param[in] pstStartParams : start params.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process failed
//------------------------------------------------------------------------------
MI_RESULT MI_TTX_Start(MI_HANDLE hTtx, const MI_TTX_StartParams_t *pstStartParams);

//------------------------------------------------------------------------------
/// @brief stop ttx decode
/// @param[in] hTtx ttx handle.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process failed
//------------------------------------------------------------------------------
MI_RESULT MI_TTX_Stop(MI_HANDLE hTtx);

//------------------------------------------------------------------------------
/// @brief show ttx / ttx subtitle
/// @param[in] hTtx ttx handle.
/// @param[in] pstShowParams : show params
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process failed
//------------------------------------------------------------------------------
MI_RESULT MI_TTX_Show(MI_HANDLE hTtx, const MI_TTX_ShowParams_t *pstShowParams);

//------------------------------------------------------------------------------
/// @brief hide ttx / ttx subtitle
/// @param[in] hTtx ttx handle.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process failed
//------------------------------------------------------------------------------
MI_RESULT MI_TTX_Hide(MI_HANDLE hTtx);

//------------------------------------------------------------------------------
/// @brief set ttx attr
/// @param[in] hTtx ttx handle.
/// @param[in] eAttrType : attr type.
/// @param[in] *pAttrParams: attr param.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process failed
//------------------------------------------------------------------------------
MI_RESULT MI_TTX_SetAttr(MI_HANDLE hTtx, MI_TTX_AttrType_e eAttrType, const void *pAttrParams);

//------------------------------------------------------------------------------
/// @brief get ttx attr
/// @param[in] hTtx ttx handle.
/// @param[in] eAttrType: attr type.
/// @param[in] pInputParams : attr input param pointer.
/// @param[out] pOutputParams : output params pointer.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process failed
//------------------------------------------------------------------------------
MI_RESULT MI_TTX_GetAttr(MI_HANDLE hTtx, MI_TTX_AttrType_e eAttrType, const void *pInputParams, void *pOutputParams);

//------------------------------------------------------------------------------
/// @brief process key event
/// @param[in] hTtx ttx handle.
/// @param[in] eKey key event type.
/// @param[in] pKeyParams: key params
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process failed
//------------------------------------------------------------------------------
MI_RESULT MI_TTX_SendKey(MI_HANDLE hTtx, MI_TTX_InputKey_e eKey, const void *pKeyParams);

//------------------------------------------------------------------------------
/// @brief push raw data to ttx for mm
/// @param[in] hTtx ttx handle.
/// @param[in] pstWriteParams: raw data params
/// @param[out] pstOutputParams: output params
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process failed
//------------------------------------------------------------------------------
MI_RESULT MI_TTX_PushSourceData(MI_HANDLE hTtx, const MI_TTX_PushDataParams_t *pstPushDataParams, MI_TTX_PushDataOutputParams_t *pstOutputParams);

//------------------------------------------------------------------------------
/// @brief set ttx debug level
/// @param[in] u32DbgLevel debug level.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process failed
//------------------------------------------------------------------------------
MI_RESULT MI_TTX_SetDebugLevel(MI_DBG_LEVEL u32DebugLevel);

#ifdef __cplusplus
}
#endif

#endif
