/*------------------------------------------------------------------------------
 * MediaTek Inc. (C) 2018. All rights reserved.
 *
 * Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 *----------------------------------------------------------------------------*/
//-------------------------------------------------------------------------------------------------
//  Use GetAttr/SetAttr only
//-------------------------------------------------------------------------------------------------

#ifndef _MI_KL_H_
#define _MI_KL_H_

#ifdef __cplusplus
extern "C" {
#endif

//-------------------------------------------------------------------------------------------------
//  Defines
//-------------------------------------------------------------------------------------------------
#define MI_KL_LEVEL_MAX                                    (3)
#define MI_KL_INPUT_SIZE_MAX                               (16)

//-------------------------------------------------------------------------------------------------
//  Structures
//-------------------------------------------------------------------------------------------------
typedef enum
{
    E_MI_KL_ALGO_TDES = 0,                                      /// < Algorithm used in key ladder: TDES
    E_MI_KL_ALGO_AES,                                           /// < Algorithm used in key ladder: AES

    E_MI_KL_ALGO_MAX
} MI_KL_Algorithm_e;

typedef enum
{
    E_MI_KL_KEY_SRC_INVALID = -1,
    E_MI_KL_KEY_SRC_ACPU = 0,                                    /// < Root Key is from memory
    E_MI_KL_KEY_SRC_SECRET_MIN = 0x100,
    E_MI_KL_KEY_SRC_SECRET_1 = E_MI_KL_KEY_SRC_SECRET_MIN,    /// < Using Key1 in OTP as root key
    E_MI_KL_KEY_SRC_SECRET_2,                                         /// < Using Key2 in OTP as root key
    E_MI_KL_KEY_SRC_SECRET_3,                                         /// < Using Key3 in OTP as root key
    E_MI_KL_KEY_SRC_SECRET_4,                                         /// < Using Key4 in OTP as root key
    E_MI_KL_KEY_SRC_SECRET_5,                                         /// < Using Key5 in OTP as root key
    E_MI_KL_KEY_SRC_SECRET_6,                                         /// < Using Key6 in OTP as root key
    E_MI_KL_KEY_SRC_SECRET_7,                                         /// < Using Key7 in OTP as root key
    E_MI_KL_KEY_SRC_SECRET_8,                                         /// < Using Key8 in OTP as root key
    E_MI_KL_KEY_SRC_SECRET_MAX,

    E_MI_KL_KEY_SRC_PRIVATE_MIN = 0x200,
    E_MI_KL_KEY_SRC_PRIVATE_0 = E_MI_KL_KEY_SRC_PRIVATE_MIN,
    E_MI_KL_KEY_SRC_PRIVATE_1,
    E_MI_KL_KEY_SRC_PRIVATE_2,
    E_MI_KL_KEY_SRC_PRIVATE_3,
    E_MI_KL_KEY_SRC_MAX

} MI_KL_KeySource_e;

typedef enum
{
    E_MI_KL_OUT_DST_INVALID = -1,
    E_MI_KL_OUT_DST_DSCMB = 1,                                              /// < Send Key to descrambler (ESA)
    E_MI_KL_OUT_DST_DMA_CIPHER_ENGINE,                                      /// < Send Key to AESDMA(Cipher module)

    E_MI_KL_OUT_DST_PRIVATE_MIN = 0x200,
    E_MI_KL_OUT_DST_PRIVATE_0 = E_MI_KL_OUT_DST_PRIVATE_MIN,
    E_MI_KL_OUT_DST_PRIVATE_1,
    E_MI_KL_OUT_DST_PRIVATE_2,
    E_MI_KL_OUT_DST_PRIVATE_3,

    E_MI_KL_OUT_DST_LOCAL_DSCMB_ENGINE_MIN = 0x300,
    E_MI_KL_OUT_DST_LOCAL_DSCMB = E_MI_KL_OUT_DST_LOCAL_DSCMB_ENGINE_MIN,   /// < send Key to local descrambler (LSAD)
    E_MI_KL_OUT_DST_LOCAL_SCMB,                                             /// < send Key to local scrambler (LSAS)

    E_MI_KL_OUT_DST_MAX
} MI_KL_OutputDestination_e;

typedef enum
{
    E_MI_KL_KEY_ODD = 1,                                       /// < Set descrambler odd key slot
    E_MI_KL_KEY_EVEN,                                      /// < Set descrambler even key slot

    E_MI_KL_KEY_MAX
} MI_KL_KeyType_e;

typedef enum
{
    E_MI_KL_CA_VENDOR_ID_INVALID = 0,
    E_MI_KL_CA_VENDOR_ID_NDS,
    E_MI_KL_CA_VENDOR_ID_NAGRA,
    E_MI_KL_CA_VENDOR_ID_VIACCESS,
    E_MI_KL_CA_VENDOR_ID_IRDETO,
    E_MI_KL_CA_VENDOR_ID_VMX,
    E_MI_KL_CA_VENDOR_ID_SMI,
    E_MI_KL_CA_VENDOR_ID_CONAX,
    E_MI_KL_CA_VENDOR_ID_LATENS,
    E_MI_KL_CA_VENDOR_ID_DRM,
    E_MI_KL_CA_VENDOR_ID_DRE,
    E_MI_KL_CA_VENDOR_ID_CTI,
    E_MI_KL_CA_VENDOR_ID_SUMA,
    E_MI_KL_CA_VENDOR_ID_TFCA,
    E_MI_KL_CA_VENDOR_ID_NSTV,
    E_MI_KL_CA_VENDOR_ID_BESTCAS,
    E_MI_KL_CA_VENDOR_ID_DEFAULT,
    E_MI_KL_CA_VENDOR_ID_MAX,
} MI_KL_CaVendorId_e;

typedef struct MI_KL_Caps_s
{
    MI_BOOL bSupport;                                   ///[OUT]: support key ladder
} MI_KL_Caps_t;

typedef struct MI_KL_InitParams_s
{
    MI_U8 u8Reserved;                                   ///[IN]: reserved
} MI_KL_InitParams_t;

typedef struct MI_KL_OpenParams_s
{
    MI_U8 * pszName;                                      ///[IN]: Custom defined module instance name which is a string with zero terminated.
    MI_U32 u32KeyLadderId;                                ///[IN]: Key ladder ID
    MI_KL_Algorithm_e eGenerateAlgo;                      ///[IN]: Algorithm used in key ladder
    MI_KL_KeySource_e eRootKeySrc;                        ///[IN]: Indicate the root key source of key ladder
    MI_KL_OutputDestination_e eOutputDst;                 ///[IN]: Indicate the output target of key ladder
    MI_BOOL bIsEncrypt;                                   ///[IN]: A flag to indicate: TRUE for encryption, FALSE for decryption
    MI_KL_CaVendorId_e eCaVendorId;                       ///[IN]: CA Vendor ID
} MI_KL_OpenParams_t;

typedef struct MI_KL_ChallengeRspnsParams_s
{
    MI_U8 u8NonceLength;                                    ///[IN]: length of buffer for nonce data
    MI_U8 *pu8Nonce;                                        ///[IN]: input data of nonce
    MI_U8 u8ResponseLength;                                 ///[IN]: length of buffer for challenge response data
    MI_U8 *pu8Response;                                     ///[OUT]: output data of Challenge Response
} MI_KL_ChallengeRspnsParams_t;

typedef struct MI_KL_GenerateParams_s
{
    MI_HANDLE hDscHandle;                                           ///[IN]: Descramber handle: need be set if output target is descrambler
    MI_KL_KeyType_e eKeyType;                                       ///[IN]: Key type: need be set if output target is descrambler
    MI_U32 u32Level;                                                ///[IN]: Configure level of key ladder, max is 3
    MI_U8 au8Data[MI_KL_LEVEL_MAX][MI_KL_INPUT_SIZE_MAX];           ///[IN]: Input data of each key level
    MI_KL_ChallengeRspnsParams_t *pstChallengeRspnsParams;          ///[IN]: Parameter for challenge response
} MI_KL_GenerateParams_t;

typedef struct MI_KL_DumpInfoParams_s
{
    MI_BOOL bAll;                             ///[IN] on to dump info
}MI_KL_DumpInfoParams_t;

typedef struct MI_KL_QueryHandleParams_s
{
    MI_U8 *pszName;                                    ///[IN]: kl handle with string name.
}MI_KL_QueryHandleParams_t;

//-------------------------------------------------------------------------------------------------
//  Global Functions
//-------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------
/// @brief Get Key Ladder module capibilities.
/// @param[out] pstCaps: A pointer to structure MI_KL_Caps_t to retrieve the information of Key Ladder capabilities
/// @return MI_OK: Process success.
//------------------------------------------------------------------------------
MI_RESULT MI_KL_GetCaps(MI_KL_Caps_t *pstCaps);

//------------------------------------------------------------------------------
/// @brief Init Key Ladder module.
/// @param[in] pstInitParam: A pointer to structure MI_KL_InitParams_t for initialization.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_KL_Init(const MI_KL_InitParams_t *pstInitParams);

//------------------------------------------------------------------------------
/// @brief Finalize Key Ladder module.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_KL_DeInit(void);

//------------------------------------------------------------------------------
/// @brief Open a Key Ladder handle.
/// @param[in] pstOpenParam: A pointer to structure MI_KL_OpenParams_t for open key ladder.
/// @param[out] phKl: A handle pointer to retrieve an instance of a created key ladder.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_RESOURCES: No available resource.
//------------------------------------------------------------------------------
MI_RESULT MI_KL_Open(const MI_KL_OpenParams_t *pstOpenParams, MI_HANDLE *phKl);

//------------------------------------------------------------------------------
/// @brief Close a Key Ladder handle.
/// @param[in] hKl: An instance of a created key ladder.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_KL_Close(MI_HANDLE hKl);

//------------------------------------------------------------------------------
/// @brief Set input data to Key Ladder, and start Key Ladder.
/// @param[in] hKeyLadder: An instance of a created key ladder.
/// @param[in] pstGenerateParams: A pointer to structure MI_KL_GenerateParams_t for setting key.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_KL_GenerateKey(MI_HANDLE hKeyLadder, MI_KL_GenerateParams_t *pstGenerateParams);

//------------------------------------------------------------------------------
/// @brief Dump Key Ladder Info.
/// @param[in] pstDumpInfoParams: struct for printing resources .
/// @return MI_OK: Dump information success.
//------------------------------------------------------------------------------
MI_RESULT MI_KL_DumpInfo(const MI_KL_DumpInfoParams_t* pstDumpInfoParams);

//------------------------------------------------------------------------------
/// @brief Set Key Ladder debug level.
/// @param[in] u32DebugLevel.
/// @return MI_OK: Set debug level success.
//------------------------------------------------------------------------------
MI_RESULT MI_KL_SetDebugLevel(MI_DBG_LEVEL u32DebugLevel);

//------------------------------------------------------------------------------
/// @brief get KL handle.
/// @param[in]  pstQueryParams: Query parameters
/// @param[out] *phKeyLadder: kl handler
/// @return MI_OK: Get kl handle success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_INVALID_PARAMETER: parameter null
//------------------------------------------------------------------------------
MI_RESULT MI_KL_GetHandle(const MI_KL_QueryHandleParams_t *pstQueryParams, MI_HANDLE *phKl);


#ifdef __cplusplus
}
#endif

#endif///_MI_KL_H_

