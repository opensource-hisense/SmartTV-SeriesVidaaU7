/*------------------------------------------------------------------------------
 * MediaTek Inc. (C) 2018. All rights reserved.
 *
 * Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 *----------------------------------------------------------------------------*/

// -------------------------------------------------------------------------------------------------------------------
// GetXxx/SetXxx and GetAttr/SetAttr coexist
// -------------------------------------------------------------------------------------------------------------------
#ifndef _MI_BLUETOOTH_H_
#define _MI_BLUETOOTH_H_
#ifdef __cplusplus
extern "C" {
#endif

/// BLUETOOTH max path len
#define MI_BLUETOOTH_FOLDER_PATH_LEN                        256     //path length
#define MI_BLUETOOTH_FIRMWARE_NAME_LEN                      40      //device firmware name length
#define MI_BLUETOOTH_DEVICE_NAME_LEN                        64      //device name length
#define MI_BLUETOOTH_DEVICE_MAC_ADDR_SIZE                   6       //mac address size

//device module
typedef enum
{
    E_MI_BLUETOOTH_DEVICE_MT7632 = 0,       /// Bluetooth module MT7632
    E_MI_BLUETOOTH_DEVICE_MT7662,           /// Bluetooth module MT7662
    E_MI_BLUETOOTH_DEVICE_MT76X2_LIKE,      ///reserved for 76x2 like new device, it compatibles with 76x2 active flow
    E_MI_BLUETOOTH_DEVICE_MT7668,           /// Bluetiith module MT7668
    E_MI_BLUETOOTH_DEVICE_MAX,              /// max number
} MI_BLUETOOTH_Device_e;

//device baseband can support mode
typedef enum
{
    E_MI_BLUETOOTH_REMOTE_DEVICE_MODE_BLE = 0,        //bluetooth low energy mode
    E_MI_BLUETOOTH_REMOTE_DEVICE_MODE_CLASSIC,         //bluetooth classic mode, device below v3.0 only can support this mode
    E_MI_BLUETOOTH_REMOTE_DEVICE_MODE_DUAL_MODE,       //the device can work on both mode
}MI_BLUETOOTH_RemoteDeviceMode_e;

//device hotplug event
typedef enum
{
    E_MI_BLUETOOTH_EVENT_INSERT = 0,    /// BLUETOOTH dongle in
    E_MI_BLUETOOTH_EVENT_REMOVE,        /// BLUETOOTH dongle out
    E_MI_BLUETOOTH_EVENT_MAX,           /// BLUETOOTH dongle max
} MI_BLUETOOTH_Event_e;

//supported bluetooth profiles
typedef enum
{
    E_MI_BLUETOOTH_PROFILE_AUTO = 0,    /// MI_BLUETOOTH can decide profile, if the remote device capablity presented from scan.
    E_MI_BLUETOOTH_PROFILE_GAP,         /// BLUETOOTH Generic Access Profile
    E_MI_BLUETOOTH_PROFILE_A2DP,        ///BLUETOOTH Advanced Audio distribute profile
    E_MI_BLUETOOTH_PROFILE_HID,         ///BLUETOOTH HID profile
    E_MI_BLUETOOTH_PROFILE_UNKNOWN,     ///BLUETOOTH profile unknown, unrecgonised
}MI_BLUETOOTH_Profile_e;

// attribute type
typedef enum
{
    // host device
    E_MI_BLUETOOTH_ATTR_TYPE_DEVICE_MIN = 0,
    E_MI_BLUETOOTH_ATTR_TYPE_DEVICE_POWER_ON = E_MI_BLUETOOTH_ATTR_TYPE_DEVICE_MIN, // boolean value to indicate powner on/off, the parameter is a pointer to MI_BOOL
    E_MI_BLUETOOTH_ATTR_TYPE_DEVICE_SCAN_STATE,                      //the parameter is a pointer to enum MI_BLUETOOTH_ScanState_e.
    E_MI_BLUETOOTH_ATTR_TYPE_DEVICE_INFO,                            // devlices info, the parameter is a pointer to struct MI_BLUETOOTH_DeviceInfo_t
    E_MI_BLUETOOTH_ATTR_TYPE_DEVICE_MAX,
    // remote device
    E_MI_BLUETOOTH_ATTR_TYPE_REMOTE_DEVICE_MIN = 0x200,
    E_MI_BLUETOOTH_ATTR_TYPE_REMOTE_DEVICE_CONNECT_STATE = E_MI_BLUETOOTH_ATTR_TYPE_REMOTE_DEVICE_MIN,   //the parameter is a pointer to struct MI_BLUETOOTH_RemoteDeviceConnectState_t.
    E_MI_BLUETOOTH_ATTR_TYPE_REMOTE_DEVICE_PAIR_STATE,              //the parameter is a pointer to struct MI_BLUETOOTH_RemoteDevicePairState_t .
    E_MI_BLUETOOTH_ATTR_TYPE_REMOTE_DEVICE_RSSI,                    //the parameter is a pointer to struct MI_BLUETOOTH_RemoteDeviceRssi_t.
    E_MI_BLUETOOTH_ATTR_TYPE_REMOTE_DEVICE_INFO,                     // remote devices info, the parameter is a pointer to struct MI_BLUETOOTH_RemoteDeviceInfo_t
    E_MI_BLUETOOTH_ATTR_TYPE_REMOTE_DEVICE_MAX
} MI_BLUETOOTH_AttrType_e;

//scan state
typedef enum
{
    E_MI_BLUETOOTH_SCAN_STATE_NONE = 0,         //the default state
    E_MI_BLUETOOTH_SCAN_STATE_SCANING,          //the state means the scan process is on going.
    E_MI_BLUETOOTH_SCAN_STATE_SCANED,           //scan process was done before
} MI_BLUETOOTH_ScanState_e;

//pair state
typedef enum
{
    E_MI_BLUETOOTH_PAIR_STATE_NONE = 0,         //there is no paired
    E_MI_BLUETOOTH_PAIR_STATE_PAIRING,          //it's in pairing
    E_MI_BLUETOOTH_PAIR_STATE_PAIRED,           //the device paired
} MI_BLUETOOTH_PairState_e;

//connection state
typedef enum
{
    E_MI_BLUETOOTH_CONNECT_STATE_NONE = 0,      //the device is not connected
    E_MI_BLUETOOTH_CONNECT_STATE_CONNECTING,    //it's in connecting
    E_MI_BLUETOOTH_CONNECT_STATE_CONNECTED,     //the device is connected.
} MI_BLUETOOTH_ConnectState_e;

//-----------------------------------------------------------------------------
//  enum for profile specified operation
//-----------------------------------------------------------------------------

// A2DP profile operations
typedef enum
{
    E_MI_BLUETOOTH_A2DP_CMD_ENABLE_SRC_MODE = 0,        ///< [Set/Get] host as source mode, parameter is a pointer to MI_BOOL
    E_MI_BLUETOOTH_A2DP_CMD_ENABLE_SINK_MODE,           ///< [Set/Get] host as sink mode, parameter is a pointer to MI_BOOL
    E_MI_BLUETOOTH_A2DP_CMD_ENABLE_2ND_CONNECTION,      ///< [Set/Get] host can connect 2nd remote device, parameter is a pointer to MI_BOOL
    E_MI_BLUETOOTH_A2DP_CMD_AUDIO_ENCODE_FORMAT,        ///< [Set/Get] audio output encode format for delivering to remote device, parameter is a pointer to struct MI_BLUETOOTH_AudioEncodeFormat_t
    E_MI_BLUETOOTH_A2DP_CMD_AUDIO_PCM_FORMAT,           ///< [Set/Get] audio input PCM format for delivering to remote device, parameter is a struct to enum MI_BLUETOOTH_AudioPcmFormat_t

    E_MI_BLUETOOTH_A2DP_CMD_PLAY_STREAM = 0x100,        ///< [Set] Play audio stream, parameter is a pointer to MI_BLUETOOTH_A2dpStreamData_t
    E_MI_BLUETOOTH_A2DP_CMD_STOP_STREAM,                ///< [Set] Stop audio stream, parameter is none
    E_MI_BLUETOOTH_A2DP_CMD_PLAYBACK_FEEDBACK_CALLBACK,  ///< [Set] set feedback request callback function, parameter is callback func. of MI_BLUETOOTH_A2dpFeedbackCallback

    E_MI_BLUETOOTH_A2DP_CMD_MAX,
}MI_BLUETOOTH_A2dpCmd_e;

typedef enum
{
    E_MI_BLUETOOTH_AUDIO_ENCODE_TYPE_NONE = 0,          ///< None for delivering with orignial PCM format
    E_MI_BLUETOOTH_AUDIO_ENCODE_TYPE_AAC,               ///< Encode as AAC format to deliver
    E_MI_BLUETOOTH_AUDIO_ENCODE_TYPE_LDAC,              ///< Encode as LDAC format to deliver
    E_MI_BLUETOOTH_AUDIO_ENCODE_TYPE_APTX,              ///< Encode as APT-X format to deliver
    E_MI_BLUETOOTH_AUDIO_ENCODE_TYPE_MP3,               ///< Encode as MP3 format to deliver

    E_MI_BLUETOOTH_AUDIO_ENCODE_TYPE_MAX,
}MI_BLUETOOTH_AudioEncodeType_e;

typedef enum
{
    E_MI_BLUETOOTH_AUDIO_FEEDBACK_STOP=0,               ///<feedback request audio playback STOP
    E_MI_BLUETOOTH_AUDIO_FEEDBACK_PLAY,                 ///<feedback request audio playback PLAY
    E_MI_BLUETOOTH_AUDIO_FEEDBACK_PAUSE,                ///<feedback request audio playback PAUSE
    E_MI_BLUETOOTH_AUDIO_FEEDBACK_FWD_SEEK,             ///<feedback request audio playback Forward Seek
    E_MI_BLUETOOTH_AUDIO_FEEDBACK_REV_SEEK,             ///<feedback request audio playback Reverse Seek
    E_MI_BLUETOOTH_AUDIO_FEEDBACK_FIRST_PLAY,           ///<feedback request audio playback First time play

    E_MI_BLUETOOTH_AUDIO_FEEDBACK_VOL_UP=0x20,          ///<feedback request audio playback to increase volume of audio
    E_MI_BLUETOOTH_AUDIO_FEEDBACK_VOL_DOWN,             ///<feedback request audio playback to decrease volume of audio

    E_MI_BLUETOOTH_AUDIO_FEEDBACK_ERR=0xFF              ///<feedback request audio playback error happens
}MI_BLUETOOTH_A2dpPlaybackFeedback_e;

// HID profile operations
typedef enum
{
    E_MI_BLUETOOTH_HID_CMD_DEVICE_TYPE=0,       ///< [Get] Hid device class, pointer at MI_BLUETOOTH_HidDeviceType_e data

    E_MI_BLUETOOTH_HID_CMD_MAX,
}MI_BLUETOOTH_HidCmd_e;

//HID device type
typedef enum
{
    E_MI_BLUETOOTH_HID_TYPE_KEYBOARD=0,         ///< keyboard
    E_MI_BLUETOOTH_HID_TYPE_MOUSE,              ///< mouse

    E_MI_BLUETOOTH_HID_TYPE_MAX,
}MI_BLUETOOTH_HidDeviceType_e;

//the callback phototype is used in device hotplug event callback to application
typedef MI_RESULT (*MI_BLUETOOTH_EventCallback)(MI_HANDLE hBluetooth, MI_U32 u32Event, void *pEventParams, void *pUserParams);

/// BLUETOOTH init parameter
typedef struct MI_BLUETOOTH_InitParams_s
{                                               //[in]
    MI_BLUETOOTH_EventCallback pfEventCallback; //hotplug event callback
    void *pUsrParam;                            //user defined
} MI_BLUETOOTH_InitParams_t;

/// BLUETOOTH device info
typedef struct MI_BLUETOOTH_DeviceInfo_s
{
    MI_BLUETOOTH_Device_e eDevice;      //// Bluetooth device
    MI_U16 u16IdVendor;                 // Bluetooth device vendor ID
    MI_U16 u16IdProduct;                // Bluetooth device product ID
    MI_U8 au8DriverPath[MI_BLUETOOTH_FOLDER_PATH_LEN];          // Bluetooth device location
    MI_U8 au8FirmwareName[MI_BLUETOOTH_FIRMWARE_NAME_LEN];      // Bluetooth device firmware name
} MI_BLUETOOTH_DeviceInfo_t;

//remote device infomation
typedef struct MI_BLUETOOTH_RemoteDeviceInfo_s
{                                                           //[out]
    MI_U8 au8MacAddr[MI_BLUETOOTH_DEVICE_MAC_ADDR_SIZE];    //remote device mac address size

    MI_U8 azDeviceName[MI_BLUETOOTH_DEVICE_NAME_LEN];       //remote device name //NOLINT
    MI_U32 u32Cod;  //The Class of Device/Service (CoD) field has a variable format. The format is indicated using the 'Format Type field' within the CoD.
    MI_BLUETOOTH_RemoteDeviceMode_e eDeviceMode;    //remote device energy mode
    MI_U32 u32Rssi;     //Received  Signal Strength Indicator, dBm
} MI_BLUETOOTH_RemoteDeviceInfo_t;

typedef struct MI_BLUETOOTH_CallbackInputParams_s
{
    MI_U64 u64CallbackId; 	///[IN]: for multi-callback, use 0 for first register or single callback.
    MI_BLUETOOTH_EventCallback pfEventCallback; 	///[IN]: callback function pointer.
    MI_U32 u32EventFlags;  ///[IN]: registered events which are bitwise OR operation.
    void * pUserParams;  ///[IN]: for passing user-defined parameters.
} MI_BLUETOOTH_CallbackInputParams_t;

typedef struct MI_BLUETOOTH_CallbackOutputParams_s
{
    MI_U64 u64CallbackId;  ///[OUT]: the returned ID for update or unregister callback.
} MI_BLUETOOTH_CallbackOutputParams_t;

/// BLUETOOTH open parameter
typedef struct MI_BLUETOOTH_OpenParams_s
{                               // [in]
    MI_BLUETOOTH_Device_e eDevice;
    MI_U16 u16IdVendor;  // Bluetooth device vendor ID
    MI_U16 u16IdProduct;   // Bluetooth device product ID
} MI_BLUETOOTH_OpenParams_t;

//pair parameters
typedef struct MI_BLUETOOTH_PairParams_s
{
    MI_U8 au8MacAddr[MI_BLUETOOTH_DEVICE_MAC_ADDR_SIZE];    // [in] remote dev. mac address
} MI_BLUETOOTH_PairParams_t;

//connection parameters
typedef struct MI_BLUETOOTH_ConnectParams_s
{
    MI_BLUETOOTH_Profile_e eProfile;                        //[in] use the profile to connect
    MI_U8 au8MacAddr[MI_BLUETOOTH_DEVICE_MAC_ADDR_SIZE];    //[in] remote dev. mac address
} MI_BLUETOOTH_ConnectParams_t;

//A2dp Ctrl input parameters
typedef struct MI_BLUETOOTH_A2dpCtrlInput_s
{
    MI_U8 *pu8MacAddr;
    MI_BLUETOOTH_A2dpCmd_e eCmd;
    void *pParam;
} MI_BLUETOOTH_A2dpCtrlInput_t;

//A2dp Ctrl output parameters
typedef struct MI_BLUETOOTH_A2dpCtrlOutput_s
{
    void *pParam;
} MI_BLUETOOTH_A2dpCtrlOutput_t;

//Hid Ctrl input parameters
typedef struct MI_BLUETOOTH_HidCtrlInput_s
{
    MI_U8 *pu8MacAddr;
    MI_BLUETOOTH_HidCmd_e eCmd;
    void *pParam;
} MI_BLUETOOTH_HidCtrlInput_t;

//Hid Ctrl  output parameters
typedef struct MI_BLUETOOTH_HidCtrlOutput_s
{
    void *pParam;
} MI_BLUETOOTH_HidCtrlOutput_t;

typedef struct MI_BLUETOOTH_RemoteDeviceConnectState_s
{
    MI_U8 au8MacAddr[MI_BLUETOOTH_DEVICE_MAC_ADDR_SIZE];            // remote device's mac addr.
    MI_BLUETOOTH_ConnectState_e eConnectState;                      //[out] connection state
}MI_BLUETOOTH_RemoteDeviceConnectState_t;

typedef struct MI_BLUETOOTH_RemoteDevicePairState_s
{
    MI_U8 au8MacAddr[MI_BLUETOOTH_DEVICE_MAC_ADDR_SIZE];            // remote device's mac addr.
    MI_BLUETOOTH_PairState_e ePairState;                            //[out] pair state
}MI_BLUETOOTH_RemoteDevicePairState_t;

 typedef struct MI_BLUETOOTH_RemoteDeviceRssi_s
{
    MI_U8 au8MacAddr[MI_BLUETOOTH_DEVICE_MAC_ADDR_SIZE];            // remote device's mac addr.
    MI_U32 u32Rssi;                                                 //[out] Received  Signal Strength Indicator, dBm
}MI_BLUETOOTH_RemoteDeviceRssi_t;
//-----------------------------------------------------------------------------
// bluetooth profile specified data structures
//-----------------------------------------------------------------------------
typedef struct MI_BLUETOOTH_AudioEncodeFormat_s
{                                                       ///< [in/out]
    MI_BLUETOOTH_AudioEncodeType_e eEncType;            ///< audio Encode type
}MI_BLUETOOTH_AudioEncodeFormat_t;

typedef struct MI_BLUETOOTH_AudioPcmFormat_s
{                                                        ///< [in]
    MI_U32  u32SampleRate;                               ///< Sampling rate: 44100, 48000,...
    MI_U8   u8Channels;                                   ///< Channel count: 1, 2,
    MI_U8   u8BitsPerSample;                              ///< Bits per sample: 8, 16,...
}MI_BLUETOOTH_AudioPcmFormat_t;

///information of bluetooth A2DP Stream Data
typedef struct MI_BLUETOOTH_A2dpStreamData_s
{                                           /// [in]
    MI_U32 u32AudioBufferLength;            ///the length of audio buffer
    MI_U8* pu8AudioBuffer;                  ///the pointer at audio buffer
}MI_BLUETOOTH_A2dpStreamData_t;

//-------------------------------------------------------------------------------------------------
//  Global Functions
//-------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------
/// @brief do bluetooth init , and change bluetooth status to E_MI_BLUETOOTH_STATUS_INITED
/// @param[in] *pstInitParams reserved
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: init fail.
/// @return MI_HAS_INITED: already inited.
//------------------------------------------------------------------------------
MI_RESULT MI_BLUETOOTH_Init(const MI_BLUETOOTH_InitParams_t *pstInitParams);

//------------------------------------------------------------------------------
/// @brief do bluetooth deinit , and change bluetooth status to E_MI_BLUETOOTH_STATUS_EMPTY
/// @param[in] none
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: deinit fail.
//------------------------------------------------------------------------------
MI_RESULT MI_BLUETOOTH_DeInit(void);

//------------------------------------------------------------------------------
/// @brief Open bluetooth handler, and change bluetooth status to E_MI_BLUETOOTH_STATUS_OPENED
/// @param[in] *pstParam points at open parameters
/// @param[in] *phBluetooth an empty handle pointer
/// @param[out] *phBluetooth bluetooth handler
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process failed
/// @return MI_ERR_INVALID_HANDLE: Null handle
/// @return MI_ERR_INVALID_PARAMETER: Null parameter
//------------------------------------------------------------------------------
MI_RESULT MI_BLUETOOTH_Open(const MI_BLUETOOTH_OpenParams_t *pstOpenParams, MI_HANDLE *phBluetooth);

//------------------------------------------------------------------------------
/// @brief close bluetooth handler, and change bluetooth status to E_MI_BLUETOOTH_STATUS_INITED
/// @param[in] hBluetooth bluetooth handle.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process failed
//------------------------------------------------------------------------------
MI_RESULT MI_BLUETOOTH_Close(MI_HANDLE hBluetooth);

//------------------------------------------------------------------------------
/// @brief set bluetooth attr,
/// @param[in] hBluetooth bluetooth handle.
/// @param[in] eParamType attr type.
/// @param[in] *pAttrParams attr param.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process failed
//------------------------------------------------------------------------------
MI_RESULT MI_BLUETOOTH_SetAttr(MI_HANDLE hBluetooth, MI_BLUETOOTH_AttrType_e eAttrType, const void *pAttrParams);

//------------------------------------------------------------------------------
/// @brief get bluetooth attr
/// @param[in] hBluetooth bluetooth handle.
/// @param[in] eParamType attr type.
/// @param[in] *pInputParams attr param.
/// @param[out] *pOutputParams attr param.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process failed
//------------------------------------------------------------------------------
MI_RESULT MI_BLUETOOTH_GetAttr(MI_HANDLE hBluetooth, MI_BLUETOOTH_AttrType_e eAttrType, const void *pInputParams, void *pOutputParams);

//------------------------------------------------------------------------------
/// @brief start scanning
/// @param[in] hBluetooth bluetooth handle.
/// @param[in] *pstParam info param to scan info & callback
/// @param[out] *pstResult result.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process failed
//------------------------------------------------------------------------------
MI_RESULT MI_BLUETOOTH_StartScan(MI_HANDLE hBluetooth, MI_BLUETOOTH_CallbackInputParams_t *pstParam);

//------------------------------------------------------------------------------
/// @brief it cancels current scanning
/// @param[in] hBluetooth bluetooth handle.
/// @param[in] *pstParam info param to scan info
/// @param[out] *pstResult result.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process failed
//------------------------------------------------------------------------------
MI_RESULT MI_BLUETOOTH_StopScan(MI_HANDLE hBluetooth, MI_BLUETOOTH_CallbackInputParams_t *pstParam);

//------------------------------------------------------------------------------
/// @brief start pairing
/// @param[in] hBluetooth bluetooth handle.
/// @param[in] pstPairParam points at pairing parameters
/// @param[out] *pstResult result.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process failed
//------------------------------------------------------------------------------
MI_RESULT MI_BLUETOOTH_Pair(MI_HANDLE hBluetooth,MI_BLUETOOTH_PairParams_t *pstPairParam);

//------------------------------------------------------------------------------
/// @brief it will cancel current pairing
/// @param[in] hBluetooth bluetooth handle.
/// @param[in] pstPairParam points at pairing parameters
/// @param[out] *pstResult result.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process failed
//------------------------------------------------------------------------------
MI_RESULT MI_BLUETOOTH_UnPair(MI_HANDLE hBluetooth, MI_BLUETOOTH_PairParams_t *pstPairParam);

//------------------------------------------------------------------------------
/// @brief connect, and change bluetooth status to E_MI_BLUETOOTH_STATUS_CONNECTING
/// @param[in] hBluetooth bluetooth handle.
/// @param[in] *pstConnectParam info param.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process failed
//------------------------------------------------------------------------------
MI_RESULT MI_BLUETOOTH_Connect(MI_HANDLE hBluetooth, MI_BLUETOOTH_ConnectParams_t *pstConnectParam);

//------------------------------------------------------------------------------
/// @brief disconnect bluetooth, and change bluetooth status to E_MI_BLUETOOTH_STATUS_OPENED
/// @param[in] hBluetooth bluetooth handle.
/// @param[in] *pstConnectParam info param to the specified connection
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process failed
//------------------------------------------------------------------------------
MI_RESULT MI_BLUETOOTH_Disconnect(MI_HANDLE hBluetooth,MI_BLUETOOTH_ConnectParams_t *pstConnectParam);

//------------------------------------------------------------------------------
/// @brief Set Control for A2DP profile
/// @param[in] hBluetooth Bluetooth handle.
/// @param[in] pA2dpSetCtrlInputParams pointer to an input params structure
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process failed
//------------------------------------------------------------------------------
MI_RESULT MI_BLUETOOTH_A2dpSetCtrl(MI_HANDLE hBluetooth, const MI_BLUETOOTH_A2dpCtrlInput_t *pstA2dpCtrlInputParams);

//------------------------------------------------------------------------------
/// @brief Get Control for A2DP profile
/// @param[in] hBluetooth Bluetooth handle.
/// @param[in] pA2dpSetCtrlInputParams pointer to an input params structure
/// @param[out] pA2dpSetCtrlOutputParams pointer to an output params structure
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process failed
//------------------------------------------------------------------------------
MI_RESULT MI_BLUETOOTH_A2dpGetCtrl(MI_HANDLE hBluetooth, const MI_BLUETOOTH_A2dpCtrlInput_t *pstA2dpCtrlInputParams, MI_BLUETOOTH_A2dpCtrlOutput_t *pstA2dpCtrlOutputParams);


//------------------------------------------------------------------------------
/// @brief Set Control for HID profile
/// @param[in] hBluetooth Bluetooth handle.
/// @param[in] pHidCtrlInputParams pointer to an input params structure
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process failed
//------------------------------------------------------------------------------
MI_RESULT MI_BLUETOOTH_HidSetCtrl(MI_HANDLE hBluetooth, const MI_BLUETOOTH_HidCtrlInput_t *pstHidCtrlInputParams);

//------------------------------------------------------------------------------
/// @brief Get Control for HID profile
/// @param[in] hBluetooth Bluetooth handle.
/// @param[in] pHidCtrlInputParams pointer to an input params structure
/// @param[out] pHidCtrlOutputParams pointer to an output params structure
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process failed
//------------------------------------------------------------------------------
MI_RESULT MI_BLUETOOTH_HidGetCtrl(MI_HANDLE hBluetooth, const MI_BLUETOOTH_HidCtrlInput_t *pstHidCtrlInputParams, MI_BLUETOOTH_HidCtrlOutput_t * pstHidCtrlOutputParams);

//------------------------------------------------------------------------------
/// @brief add device information to support list
/// @param[in] pstDeviceInfo: A pointer to structure MI_BLUETOOTH_DeviceInfo_t for device information.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_BLUETOOTH_AddDeviceInfo(MI_BLUETOOTH_DeviceInfo_t *pstDeviceInfo);

//------------------------------------------------------------------------------
/// @brief set bluetooth debug level
/// @param[in] eDgbLevel debug level.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process failed
//------------------------------------------------------------------------------
MI_RESULT MI_BLUETOOTH_SetDebugLevel(MI_DBG_LEVEL u32DebugLevel);

#ifdef __cplusplus
}
#endif

#endif
