/*------------------------------------------------------------------------------
 * MediaTek Inc. (C) 2018. All rights reserved.
 *
 * Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 *----------------------------------------------------------------------------*/
//----------------------------------------------------------------------------------------
//  GetXxx/SetXxx and GetAttr/SetAttr coexit
//----------------------------------------------------------------------------------------

#ifndef _MI_AUDIO_H_
#define _MI_AUDIO_H_

#ifdef __cplusplus
extern "C" {
#endif

//-------------------------------------------------------------------------------------------------
//  Defines
//-------------------------------------------------------------------------------------------------
#define MI_AUDIO_CODEC_EXTRA_DATA_MAX_SIZE      88
#define MI_AUDIO_RA8_MAX_CODECS                 5
#define MI_AUDIO_CHANNEL_MAPPING_MAX_NUM        10
#define MI_AUDIO_LANG_LENGTH_MAX                4


typedef MI_RESULT (*MI_AUDIO_EventCallback)(MI_HANDLE hAudio, MI_U32 u32Event, void * pEventParams, void * pUserParams);

//-------------------------------------------------------------------------------------------------
//  Structures
//-------------------------------------------------------------------------------------------------

typedef enum
{
    E_MI_AUDIO_DOLBY_VERSION_NONE = 0,
    E_MI_AUDIO_DOLBY_VERSION_MS10,
    E_MI_AUDIO_DOLBY_VERSION_MS11,
    E_MI_AUDIO_DOLBY_VERSION_MS12_V1,
    E_MI_AUDIO_DOLBY_VERSION_MS12_V2,
    E_MI_AUDIO_DOLBY_VERSION_MS12_V13_A,
    E_MI_AUDIO_DOLBY_VERSION_MS12_V13_B,
    E_MI_AUDIO_DOLBY_VERSION_MS12_V13_C,
    E_MI_AUDIO_DOLBY_VERSION_MS12_V13_D,
    E_MI_AUDIO_DOLBY_VERSION_MS12_V22_Y,
    E_MI_AUDIO_DOLBY_VERSION_MS12_V22_Z,
} MI_AUDIO_DolbyVersion_e;

typedef enum
{
    E_MI_AUDIO_STREAM_TYPE_LIVE = 0,          ///< DTV input stream.
    E_MI_AUDIO_STREAM_TYPE_TS,                ///< TS input stream.
    E_MI_AUDIO_STREAM_TYPE_PES,               ///< PES input stream.
    E_MI_AUDIO_STREAM_TYPE_ES,                ///< ES input stream.
    E_MI_AUDIO_STREAM_TYPE_HDMI,              ///< HDMI input stream.
} MI_AUDIO_StreamType_e;

typedef enum
{
    E_MI_AUDIO_EVENT_DEC_OK = 0x00,         ///< The decoder is decoding normally.
    E_MI_AUDIO_EVENT_PCM_BUF_EMPTY,         ///< The PCM buffer is empty.
    E_MI_AUDIO_EVENT_ES_BUF_EMPTY,          ///< The ES buffer is empty.
    E_MI_AUDIO_EVENT_DEC_ERROR,             ///< An error frame has been decoded.
    E_MI_AUDIO_EVENT_FORMAT_NOT_SUPPORT,    ///< The stream format is not supported. e.g., WMA has many profiles, but not all the profiles are supported.

    E_MI_AUDIO_EVENT_MAX,
} MI_AUDIO_CallbackEvent_e;

typedef enum
{
    E_MI_AUDIO_FLAG_TYPE_NONE = 0,
    E_MI_AUDIO_FLAG_TYPE_END_OF_STREAM = MI_BIT(0),
    E_MI_AUDIO_FLAG_TYPE_METADATA_EXIST = MI_BIT(1),
    E_MI_AUDIO_FLAG_TYPE_MULTI_CHANNELS = MI_BIT(2),
} MI_AUDIO_FlagType_e;

typedef enum
{
    E_MI_AUDIO_SAMPLE_RATE_NONE = 0xFF,

    E_MI_AUDIO_SAMPLE_RATE_8000 = 0,
    E_MI_AUDIO_SAMPLE_RATE_11025,
    E_MI_AUDIO_SAMPLE_RATE_12000,
    E_MI_AUDIO_SAMPLE_RATE_16000,
    E_MI_AUDIO_SAMPLE_RATE_22050,
    E_MI_AUDIO_SAMPLE_RATE_24000,
    E_MI_AUDIO_SAMPLE_RATE_32000,
    E_MI_AUDIO_SAMPLE_RATE_44100,
    E_MI_AUDIO_SAMPLE_RATE_48000,

} MI_AUDIO_SampleRate_e;

typedef enum
{
    E_MI_AUDIO_CHANNEL_COUNT_MODE_DECODER,           ///< Channel count is decided by decoder. Default setting.
    E_MI_AUDIO_CHANNEL_COUNT_MODE_STREAM_CONTENT,    ///< Channel count is decided by stream content.
    E_MI_AUDIO_CHANNEL_COUNT_MODE_MAX,
} MI_AUDIO_ChannelCountMode_e;

typedef enum
{
    // common decoder attribute
    E_MI_AUDIO_ATTR_TYPE_CODEC_TYPE     = 0,    ///< Get code type, parameter type is a pointer to MI_AUDIO_CodecType_e.
    E_MI_AUDIO_ATTR_TYPE_SAMPLE_RATE,           ///< Get Sampling frequency(after decode), parameter type is a pointer to MI_U32.
    E_MI_AUDIO_ATTR_TYPE_CHANNEL_COUNT,         ///< Get Channel count (after decode), includes LFE channel, parameter type is a pointer to MI_U32.
    E_MI_AUDIO_ATTR_TYPE_CHANNEL_MAPPING,       ///< Get channel mapping(after decode), parameter type is a pointer to MI_AUDIO_ChannelMappingType_e.
    E_MI_AUDIO_ATTR_TYPE_STREAM_TYPE,           ///< Set/Get stream type, parameter type is a pointer to enum type MI_AUDIO_StreamType_e.
    E_MI_AUDIO_ATTR_TYPE_CHANNEL_COUNT_MODE,    ///< Set/Get channel count mode of the current playback, parameter type is a pointer to MI_AUDIO_ChannelCountMode_e.
    E_MI_AUDIO_ATTR_TYPE_CHANNEL_ATTR,          ///< Get the attribute of channel(after decode), parameter type is a pointer to MI_AUDIO_ChannelAttr_t.
    E_MI_AUDIO_ATTR_TYPE_ATMOS_LOGO_INDICATOR,  ///< Get the attribute of indicating ATMOS logo, parameter type is a pointer to MI_BOOL.

    //common decoder debug status
    E_MI_AUDIO_ATTR_TYPE_ES_BUF_LEVEL   = 0x100,///< Get current ES buffer size from audio decoder, parameter type is a pointer to MI_U32.
    E_MI_AUDIO_ATTR_TYPE_PCM_BUF_LEVEL,         ///< Get current PCM buffer size from audio decoder, parameter type is a pointer to MI_U32.
    E_MI_AUDIO_ATTR_TYPE_DEC_OK_FRAME_COUNT,    ///< Get success decoded frame count, parameter type is a pointer to MI_U32.
    E_MI_AUDIO_ATTR_TYPE_DEC_ERROR_FRAME_COUNT, ///< Get error decode cnt, parameter type is a pointer to MI_U32.
    E_MI_AUDIO_ATTR_TYPE_ES_BUFFER_INFO,        ///< Get current Es buffer info from audio decoder, parameter type is a pointer to MI_AUDIO_EsBufferInfo_t.
    E_MI_AUDIO_ATTR_TYPE_DEC_ES_COUNT,          ///< Get the sum of decode es data, unit is byte, paramter type is a pointer to MI_U32.
    E_MI_AUDIO_ATTR_TYPE_DEC_DELAY,             ///< Get current decoder delay(ms), paramter type is a pointer to MI_U32.

    //PTS status
    E_MI_AUDIO_ATTR_TYPE_CURRENT_PTS    = 0x200,///< Get current PTS from audio decoder with unit 90kHz, value range  is 32bit, parameter type is a pointer to MI_U64.
    E_MI_AUDIO_ATTR_TYPE_GET_PARSER_PTS,        ///< Get latest PTS at parsing time in parser, parameter type is a pointer to MI_U64
    E_MI_AUDIO_ATTR_TYPE_CURRENT_PTS64,         ///< Get current PTS from audio decoder with unit 90kHz, value range  is 33bit, parameter type is a pointer to MI_U64.
    E_MI_AUDIO_ATTR_TYPE_PTS_OFFSET,            ///< Set PTS offset with unit 90kHz according to the decoder currently in use for media sync, paramter type is a pointer to MI_S32.

    //DTV setting
    E_MI_AUDIO_ATTR_TYPE_ES_BUF_MONITOR = 0x300,///< Set only for live TS used. pause to feed data to the Audio ES buffer if ES buffer level more than threshold. parameter type is pointer to MI_BOOL.
    E_MI_AUDIO_ATTR_TYPE_LIVE_PAUSE_ENABLE,     ///< Set attribute of enable the Pause & Resume in Live stream. parameter type is pointer to MI_BOOL.
    E_MI_AUDIO_ATTR_TYPE_SYNC_MODE,             ///< Set/Get audio sync/free-run mode, parameter is a pointer to MI_AUDIO_SyncMode_e
    E_MI_AUDIO_ATTR_TYPE_FIFO_CTRL,             ///< Set audio FIFO control by MI_AUDIO or porting layer, parameter type is a pointer to MI_AUDIO_FifoCtrl_e

    //DTV audio description setting
    E_MI_AUDIO_ATTR_TYPE_AD_MUTE        = 0x400,///< AD Mute, parameter type is a pointer to MI_BOOL.
    E_MI_AUDIO_ATTR_TYPE_AD_VOLUME,             ///< AD Volume Index, parameter type is a pointer to MI_U8 (0~100).
    E_MI_AUDIO_ATTR_TYPE_AD_PAN_FADE,           ///< Enable/disable feature, default enable, apply AD pan/fade inside stream, parameter type is a pointer to MI_BOOL.
    E_MI_AUDIO_ATTR_TYPE_AD_FADE_CONTROL,       ///< Set/Get the mixing ratio of Main and AD, parameter type is a pointer to MI_U8 (0~100).

    //MM attribute
    E_MI_AUDIO_ATTR_TYPE_CODEC_DATA     = 0x500,///< Set/Get audio codec data, parameter type is a pointer to MI_AUDIO_CodecParams_t.
    E_MI_AUDIO_ATTR_TYPE_CODEC_SAMPLE_RATE,     ///< Set/Get the sample rate info of codec param(before decode), parameter type is a pointer to MI_U32.
    E_MI_AUDIO_ATTR_TYPE_CODEC_CHANNEL_COUNT,   ///< Set/Get the channel number of codec param(before decode), parameter type is a pointer to MI_U8.
    E_MI_AUDIO_ATTR_TYPE_CODEC_PROFILE,         ///< Set/Get the profile info of codec param(before decode), parameter type is a pointer to MI_U8.(only AAC used, 0: AAC_MAIN, 1: AAC_LC, ...)
    E_MI_AUDIO_ATTR_TYPE_CHECK_PLAY_DONE ,      ///< Get play statues, return True if residual PCM buffer equals 0, parameter type is a pointer to MI_BOOL.
    E_MI_AUDIO_ATTR_TYPE_HANDSHAKE_DECODE_DONE, ///< Get PCM size from decoder after handshake decode done, parameter type is a pointer to MI_U32.

    //MM setting
    E_MI_AUDIO_ATTR_TYPE_TSFILE_SYNC    = 0x600,///< Trigger audio sync to STC, Audio PTS sync to STC, parameter type is a pointer to MI_BOOL.
    E_MI_AUDIO_ATTR_TYPE_TSFILE_DECODE_MUTE,    ///< Audio decoder mute statues, parameter type is a pointer to MI_BOOL.
    E_MI_AUDIO_ATTR_TYPE_TRICK_MODE_SPEED2X,    ///< Enable speed 2x in MM mode, parameter type is a pointer to MI_BOOL.
    E_MI_AUDIO_ATTR_TYPE_HANDSHAKE_OUTPUT_FRAME_BATCH, ///< Set frame number to get decoder data every batch in handshake mode, parameter type is a pointer to MI_U16. Default is 1.
    E_MI_AUDIO_ATTR_TYPE_FREERUN_TOLERANCE,     ///< Set freerun tolerance. Unit is millisecond. Parameter type is a pointer to MI_S32.
    E_MI_AUDIO_ATTR_TYPE_ENABLE_FREERUN_TOLERANCE, ///< Set to enable/disable the freerun tolerance. Parameter type is a pointer to MI_BOOL.

    //Audio decoder output setting
    E_MI_AUDIO_ATTR_TYPE_MULTI_MUTE     = 0x4000,///< Set mute of decoder device, parameter type is a pointer to MI_AUDIO_MultiMuteParams_t.
    E_MI_AUDIO_ATTR_TYPE_VOLUME,                 ///< Set the volume of decoder device, parameter type is a pointer to MI_U8. (Maximum volume is 100).
    E_MI_AUDIO_ATTR_TYPE_VOLUME_DB,              ///< Set the volume of decoder device by DB, parameter type is a pointer to MI_AUDIO_VolumeDb_t.
    E_MI_AUDIO_ATTR_TYPE_VOLUME_TABLE,           ///< Set the volume table of decoder device, parameter type is a pointer to array which size is 101.
    E_MI_AUDIO_ATTR_TYPE_OUTPUT_DELAY,           ///< Set the delay of decoder device, parameter type is a pointer to to MI_U32.
    E_MI_AUDIO_ATTR_TYPE_EASE,                   ///< Set/Get the ease effect of output channel, parameter type is a pointer to MI_AUDIO_EaseParams_t.
    E_MI_AUDIO_ATTR_TYPE_DOWNMIX_MODE,           ///< Set/Get the downmix mode of decoder device, parameter type is a pointer to MI_AUDIO_DownmixMode_e.
    E_MI_AUDIO_ATTR_TYPE_DRC_MODE,               ///< Set/Get the DRC(Dynamic Range Control) mode of decoder device, parameter type is a pointer to MI_AUDIO_DrcMode_e.
    E_MI_AUDIO_ATTR_TYPE_DRC_SCALE,              ///< Set/Get the scale of DRC mode, parameter type is a pointer to MI_AUDIO_DrcScale_t;
    E_MI_AUDIO_ATTR_TYPE_AC4_DIALOG_GAIN,        ///< Set AC4 dialog gain
    E_MI_AUDIO_ATTR_TYPE_AC4_MAIN_PRESENTATION_INDEX, ///< Set AC4 main presentation index
    E_MI_AUDIO_ATTR_TYPE_AC4_ASSOCIATE_PRESENTATION_INDEX, ///< Set AC4 associate presentation index
    E_MI_AUDIO_ATTR_TYPE_AC4_1ST_PREFER_LANGUAGE,///< Set AC4 1st perfer language
    E_MI_AUDIO_ATTR_TYPE_AC4_2ND_PREFER_LANGUAGE,///< Set AC4 2nd perfer language
    E_MI_AUDIO_ATTR_TYPE_DTS_DRC_SCALE,          ///< Set DTS DRC level
    //Global Attibute
    E_MI_AUDIO_ATTR_TYPE_CODEC_LICENSE  = 0x5000,///< Get codec license,input parameter type is a pointer to MI_AUDIO_CodecType_e, output paramter is a pointer to MI_BOOL.
    E_MI_AUDIO_ATTR_TYPE_DOLBY_VERSION,          ///< Get Dolby SDK version

} MI_AUDIO_AttrType_e;

typedef enum
{
    E_MI_AUDIO_FIFO_CTRL_AUTO_ENABLE = 0,
    E_MI_AUDIO_FIFO_CTRL_MANUAL_ENABLE,
    E_MI_AUDIO_FIFO_CTRL_MANUAL_DISABLE,
} MI_AUDIO_FifoCtrl_e;

typedef enum
{
    E_MI_AUDIO_RENDER_MODE_HARDWIRE = 0, //decoder output pcm to hw automatically
    E_MI_AUDIO_RENDER_MODE_HANDSHAKE,    //decoder output pcm to user manually
} MI_AUDIO_RenderMode_e;

typedef enum
{
    E_MI_AUDIO_CODEC_TYPE_MIN = 0x0,
    E_MI_AUDIO_CODEC_TYPE_NONE = E_MI_AUDIO_CODEC_TYPE_MIN,
    E_MI_AUDIO_CODEC_TYPE_MPEG,
    E_MI_AUDIO_CODEC_TYPE_MPEG_H,
    E_MI_AUDIO_CODEC_TYPE_MP3,
    E_MI_AUDIO_CODEC_TYPE_AC3,
    E_MI_AUDIO_CODEC_TYPE_AC3P,
    E_MI_AUDIO_CODEC_TYPE_AC4,
    E_MI_AUDIO_CODEC_TYPE_AAC,
    E_MI_AUDIO_CODEC_TYPE_DOLBY_TRUEHD,
    E_MI_AUDIO_CODEC_TYPE_DTS,
    E_MI_AUDIO_CODEC_TYPE_DTS_LBR,
    E_MI_AUDIO_CODEC_TYPE_DTSHD,
    E_MI_AUDIO_CODEC_TYPE_CDLPCM,
    E_MI_AUDIO_CODEC_TYPE_XPCM,
    E_MI_AUDIO_CODEC_TYPE_RA8_LBR,
    E_MI_AUDIO_CODEC_TYPE_WMA,
    E_MI_AUDIO_CODEC_TYPE_WMA_PRO,
    E_MI_AUDIO_CODEC_TYPE_FLAC,
    E_MI_AUDIO_CODEC_TYPE_VORBIS,
    E_MI_AUDIO_CODEC_TYPE_AMR_NB,
    E_MI_AUDIO_CODEC_TYPE_AMR_WB,
    E_MI_AUDIO_CODEC_TYPE_DRA,
    E_MI_AUDIO_CODEC_TYPE_OPUS,
    E_MI_AUDIO_CODEC_TYPE_MAX,

    //DTV Audio description decoder
    E_MI_AUDIO_CODEC_TYPE_AD_MIN = 0x1000,
    E_MI_AUDIO_CODEC_TYPE_AD_NONE = E_MI_AUDIO_CODEC_TYPE_AD_MIN,
    E_MI_AUDIO_CODEC_TYPE_AD_MPEG,
    E_MI_AUDIO_CODEC_TYPE_AD_AC3,
    E_MI_AUDIO_CODEC_TYPE_AD_AAC,
    E_MI_AUDIO_CODEC_TYPE_AD_AC3P,
    E_MI_AUDIO_CODEC_TYPE_AD_MAX,

} MI_AUDIO_CodecType_e;

typedef enum
{
    E_MI_AUDIO_SYNC_MODE_FREERUN,           ///< set audio free-run
    E_MI_AUDIO_SYNC_MODE_AVSYNC,            ///< set audio sync play

}MI_AUDIO_SyncMode_e;

typedef enum
{
    E_MI_AUDIO_EASE_TYPE_LINEAR = 0x0,         //ease linear type
    E_MI_AUDIO_EASE_TYPE_IN_CUBIC,             //ease in-cubic type
    E_MI_AUDIO_EASE_TYPE_OUT_CUBIC,            //ease out-cubic type
    E_MI_AUDIO_EASE_TYPE_IN_OUT_CUBIC,         //ease inout-cubic type
} MI_AUDIO_EaseType_e;

///decoder channel mapping definition
///reference from android define
typedef enum
{
    E_MI_AUDIO_CHANNEL_MAPPING_NONE                  = 0x00,

    E_MI_AUDIO_CHANNEL_MAPPING_FRONT_LEFT            = MI_BIT(0),
    E_MI_AUDIO_CHANNEL_MAPPING_FRONT_RIGHT           = MI_BIT(1),
    E_MI_AUDIO_CHANNEL_MAPPING_FRONT_CENTER          = MI_BIT(2),
    E_MI_AUDIO_CHANNEL_MAPPING_LOW_FREQUENCY         = MI_BIT(3),
    E_MI_AUDIO_CHANNEL_MAPPING_BACK_LEFT             = MI_BIT(4),
    E_MI_AUDIO_CHANNEL_MAPPING_BACK_RIGHT            = MI_BIT(5),
    E_MI_AUDIO_CHANNEL_MAPPING_BACK_CENTER           = MI_BIT(6),
    E_MI_AUDIO_CHANNEL_MAPPING_SIDE_LEFT             = MI_BIT(7),
    E_MI_AUDIO_CHANNEL_MAPPING_SIDE_RIGHT            = MI_BIT(8),
    E_MI_AUDIO_CHANNEL_MAPPING_TOP_FRONT_LEFT        = MI_BIT(9),
    E_MI_AUDIO_CHANNEL_MAPPING_TOP_FRONT_RIGHT       = MI_BIT(10),
    E_MI_AUDIO_CHANNEL_MAPPING_TOP_BACK_LEFT         = MI_BIT(11),
    E_MI_AUDIO_CHANNEL_MAPPING_TOP_BACK_RIGHT        = MI_BIT(12),

} MI_AUDIO_ChannelMappingType_e;

typedef enum
{
    E_MI_AUDIO_PCM_TYPE_LPCM     = 0,
    E_MI_AUDIO_PCM_TYPE_LPCM_ALAW   ,
    E_MI_AUDIO_PCM_TYPE_LPCM_MULAW  ,
    E_MI_AUDIO_PCM_TYPE_MS_ADPCM    ,
    E_MI_AUDIO_PCM_TYPE_IMA_ADPCM   ,
    E_MI_AUDIO_PCM_TYPE_MAX         ,
} MI_AUDIO_PcmType_e;

typedef enum
{
    E_MI_AUDIO_AAC_FORMAT_NONE = 0,
    E_MI_AUDIO_AAC_FORMAT_LOAS,
    E_MI_AUDIO_AAC_FORMAT_LATM,
    E_MI_AUDIO_AAC_FORMAT_ADTS,
    E_MI_AUDIO_AAC_FORMAT_MAX,
}MI_AUDIO_AacFormat_e;

typedef enum
{
    E_MI_AUDIO_AAC_VERSION_NONE = -1,
    E_MI_AUDIO_AAC_VERSION_AAC = 0,           //AAC Low-Complexity version.
    E_MI_AUDIO_AAC_VERSION_HEAAC_V1,          //High-Efficiency Advanced Audio Coding Version 1.
    E_MI_AUDIO_AAC_VERSION_HEAAC_V2,          //High-Efficiency Advanced Audio Coding Version 2.
    E_MI_AUDIO_AAC_VERSION_MAX,
}MI_AUDIO_AacVersion_e;

typedef enum
{
    E_MI_AUDIO_DRC_LINE_MODE = 0,      // line mode, for mm using
    E_MI_AUDIO_DRC_RF_MODE,            // RF mode, for live stream(DTV) using
    E_MI_AUDIO_DRC_ARIB_MODE,          // Discarded enum, should not use in DRC mode setting.
}MI_AUDIO_DrcMode_e;

typedef enum
{
    E_MI_AUDIO_DOWNMIX_MODE_LTRT = 0,      // downmix LtRt(left total, right total) mode, default use expect mm mode
    E_MI_AUDIO_DOWNMIX_MODE_LORO,          // downmix LoRo(left only, right only) mode, for mm using
    E_MI_AUDIO_DOWNMIX_MODE_ARIB,          // downmix ARIB(Association of Radio Industries and Businesses) mode, for japanese standard
}MI_AUDIO_DownmixMode_e;

typedef enum
{
    E_MI_AUDIO_EASE_TARGET_SELF = 0,        //ease active to own device
    E_MI_AUDIO_EASE_TARGET_OTHERS,          //ease active to others device
}MI_AUDIO_EaseTarget_e;

typedef enum
{
    E_MI_AUDIO_SPEED_0_25X,              //Slow down paly speed,play with 0.25 * normal speed.
    E_MI_AUDIO_SPEED_0_5X,               //Slow down paly speed,play with 0.5 * normal speed.
    E_MI_AUDIO_SPEED_0_75X,              //Slow down paly speed,play with 0.75 * normal speed.
    E_MI_AUDIO_SPEED_1X,                 //Normal paly speed.
    E_MI_AUDIO_SPEED_1_25X,              //Fast forward paly speed,play with 1.25 * normal speed.
    E_MI_AUDIO_SPEED_1_5X,               //Fast forward paly speed,play with 1.5 * normal speed.
    E_MI_AUDIO_SPEED_1_75X,              //Fast forward paly speed,play with 1.75 * normal speed.
    E_MI_AUDIO_SPEED_2X,                 //Fast forward paly speed,play with 2 * normal speed.
    E_MI_AUDIO_SPEED_MANUAL,             //Customized playing speed,.range:250~2000,real speed = u32ManualSpeed/1000.
} MI_AUDIO_Speed_e;

typedef struct MI_AUDIO_InitParams_s
{
    MI_U8 u8Reserved;                   ///< [IN]: Reserved.
} MI_AUDIO_InitParams_t;

typedef struct MI_AUDIO_OpenParams_s
{
    MI_U8 * pszName;                    ///< [IN]: Custom defined audio name which is a string with zero terminated.
    MI_AUDIO_StreamType_e eStreamType;  ///< [IN]: Stream type.
    MI_AUDIO_RenderMode_e eRenderMode;  ///< [IN]: Render mode.
} MI_AUDIO_OpenParams_t;

typedef struct MI_AUDIO_StartParams_s
{
    MI_AUDIO_CodecType_e eAudioType;    ///< [IN]: Audio codec type
} MI_AUDIO_StartParams_t;

typedef struct MI_AUDIO_WriteParams_s
{
    MI_U8   *pu8DataBuf;         ///< [IN]: Buffer for write data.
    MI_U32  u32BufSize;          ///< [IN]: Size of data for buffer,unit: byte
    MI_U64  u64Pts;              ///< [IN]: Presentation timestamp with 90KHz unit, MI_INVALID_PTS for invalid timestamp
    MI_U64  u64StreamFlag;       ///< [IN]: Stream flag, a bitwise operation which indicates the infomation of data in this buffer.information refer to MI_AUDIO_FlagType_e
    MI_U64  u64MetadataIndex;    ///< [IN]: Index for extra data, indicate metadata.
} MI_AUDIO_WriteParams_t;

typedef struct MI_AUDIO_WriteOutputParams_s
{
    MI_U32 u32ReturnSize;       ///< [OUT]Return Size of data.Valid written or read data size.
} MI_AUDIO_WriteOutputParams_t;

typedef struct MI_AUDIO_ReadParams_s
{
    MI_U8   *pu8DataBuf;         ///< [IN]: Buffer  for read data.
    MI_U32  u32BufSize;          ///< [IN]: Size of data for buffer,unit: byte.
} MI_AUDIO_ReadParams_t;

typedef struct MI_AUDIO_ReadOutputParams_s
{
    MI_U32  u32ReturnSize;       ///< [OUT]: Return Size of data.Valid written or read data size.
    MI_U64  u64StreamFlag;       ///< [OUT]: Stream flag, indicate the infomation of data in this buffer.information refer to MI_AUDIO_FlagType_e
    MI_U64  u64Pts;              ///< [OUT]: Presentation timestamp with 90KHz unit, MI_INVALID_PTS for invalid timestamp
    MI_U64  u64MetadataIndex;    ///< [OUT]: Index for extra data, indicate metadata.
} MI_AUDIO_ReadOutputParams_t;

typedef struct MI_AUDIO_EsBufferInfo_s
{
   MI_U32      u32MaxBufferSize;        ///< [OUT]: Return the max es buffer size.
   MI_U32      u32Level;                ///< [OUT]: Return the level of es buffer.
   MI_U32      u32FreeSize;             ///< [OUT]: Return the free size of es buffer.
} MI_AUDIO_EsBufferInfo_t;

typedef struct MI_AUDIO_VolumeDb_s
{
   MI_S32      s32Integer;          ///< [IN]: Integer part of volume, range from -114 to +12dB
   MI_S32      s32Fraction;         ///< [IN]: Fractional part of volume, 125: 0.125dB resolution:0.125dB
} MI_AUDIO_VolumeDb_t;

typedef struct MI_AUDIO_MultiMuteParams_s
{
    MI_U8   *pszMuteName;               ///< [IN]: Set Mute Event name.eg: "dtv mute". Max length of name size: 64.
    MI_BOOL bMute;                      ///< [IN]: True: Mute; False Unmute;
    MI_U32  u32AutoUnmuteTimer;         ///< [IN]: Auto unmute audio in a period of millisecond. 0 is disable auto unmute.
} MI_AUDIO_MultiMuteParams_t;

typedef struct MI_AUDIO_EaseParams_s
{
    MI_AUDIO_EaseTarget_e        eTarget;            ///< [IN]: Easing target, player self or other sounds.
    MI_AUDIO_EaseType_e          eType;              ///< [IN]: a type of curve ,eg linear ,in-cubic ,out-cubic,in-out-cubic
    MI_U16                       u16Duration;        ///< [IN]: duration time of fade-in or fade-out,unit: minisecond.
    MI_U16                       u16Scale;           ///< [IN]: Scale value, range from 0 to 100
} MI_AUDIO_EaseParams_t;

typedef struct MI_AUDIO_Caps_s
{
    MI_U32  u32DecoderNum;                          ///< [OUT]: The number of decoder.
    MI_BOOL bAudioDescription;                      ///< [OUT]: Audio description is supported or not.
    MI_U32  u32EsBufSize;                           ///< [OUT]: Maximum ES buffer size.
    MI_U32  u32SupportAudCodecs;                    ///< [OUT]: Bitwise supported audio codecs defined by MI_AUDIO_CodecType_e excluding AD.
} MI_AUDIO_Caps_t;

/// Xpcm codec data
typedef struct MI_AUDIO_XpcmCodecData_s
{
    MI_AUDIO_PcmType_e ePcmType;                    ///< [IN]: specify the LPCM, ADPCM,...both used in get or set.
    MI_U8   u8BitsPerSample;                        ///< [IN]: Bits per sample, 8(bits), 16(bits), 24(bits),...both used in get or set.
    MI_U8   u8BigEndian;                            ///< [IN]: For LPCM, 0x0: little endian, 0xFF: big endian,both used in get or set.
    MI_U32  u32BlockAlign;                          ///< [IN]: ADPCM block align is WORD,both used in get or set.
} MI_AUDIO_XpcmCodecData_t;

// Wma, Wma Pro codec data
typedef struct MI_AUDIO_WmaCodecData_s
{
    MI_U16  u16FormatTag;                            ///< [IN]: format tag for WMA 0x161, 0x162,...both used in get or set.
    MI_U32  u32AvgBytesPerSec;                       ///< [IN]: average byte per second,both used in get or set.
    MI_U16  u16BlockSize;                            ///< [IN]: Size of block align defined in WMA header,both used in get or set.
    MI_U16  u16ExtDataSize;                          ///< [IN]: the count in bytes of the size of extension data,both used in get or set.
    MI_U8   au8ExtData[MI_AUDIO_CODEC_EXTRA_DATA_MAX_SIZE];                            ///< [IN]: extension data
    ///<WMAV1: need  4 Bytes extra information at least
    ///<WMAV2: need 10 Bytes extra information at least
    ///<WMAV3: need 18 Bytes extra information at least
} MI_AUDIO_WmaCodecData_t;

// Ra8 codec data
typedef struct MI_AUDIO_Ra8CodecData_s
{
    MI_U16  u16ExtDataSize;                          ///< [IN]: the count in bytes of the size of extension data,both used in get or set.
    MI_U8   au8ExtData[MI_AUDIO_CODEC_EXTRA_DATA_MAX_SIZE];                            ///< [IN]: extension data
    ///< RA8LBR(Cook): first fixed 8 bytes put the frame size information, [0] is the high byte of total frame size, [1] is the low byte of total frame size,
    //////< and [2], [3], ... are the (frame size/2) of multi-channel.
    //////< The remain data is "Type Specific Data, bytes 0~3:Cook version, bytes 4~5:samples per frame per channel, bytes 6~7:number of subbands used in the frequency domain,...."
} MI_AUDIO_Ra8CodecData_t;

typedef struct MI_AUDIO_Ac3pCodecData_s
{
    MI_AUDIO_DrcMode_e      eDrcMode;                ///< [IN]: RF mode or Line mode
    MI_AUDIO_DownmixMode_e  eDownmixMode;            ///< [IN]: LtRt mode or LoRo mode
    MI_U32                  u32DrcHighCutScale;      ///< [IN]: 0--100 percent of high compression level
    MI_U32                  u32DrcLowBoostScale;     ///< [IN]: 0--100 percent of low  compensation level
    MI_U32                  u32AudioDelayMs;         ///< [IN]: 30ms-300ms  dolby audio delay:only for DTV
    MI_BOOL                 bBulletin11Enable;       ///< [IN]: enable or not:bulletin11 for 8dB attenuation
    MI_BOOL                 bAtmos;                  ///< [OUT]: Get the status that if the audio stream is atmos audio;
} MI_AUDIO_Ac3pCodecData_t;

typedef struct MI_AUDIO_DtsCodecData_s
{
    MI_BOOL                 bDtsSeamless;            ///< [IN]: enable or not:DTS seamless
    MI_U32                  u32DrcScale;             ///< [IN]: DTS dynamic range control scale. Range is 0~100. 0 is disable.
} MI_AUDIO_DtsCodecData_t;

typedef struct MI_AUDIO_Ac4CodecData_s
{
    MI_U8  szLanguageCode[MI_AUDIO_LANG_LENGTH_MAX];       ///<[IN]: Defined by ISO-639 Language Code, . e.g., ara, fas, zho..., it's global setting
    MI_U32 u32DialogGain;                                  ///<[IN]: Dialog enhancer gain,0db ~ +12db, step is 1 db.
    MI_BOOL bAtmos;                                        ///<[OUT]: Get the status that if the audio stream is atmos audio;
    MI_U32 u32MdPresentationIndex;                         ///<[IN]: Main Audio presentation index, 0~31
    MI_U32 u32AdPresentationIndex;                         ///<[IN]: Associate Audio presentation index, 0~31
} MI_AUDIO_Ac4CodecData_t;

typedef struct MI_AUDIO_AacCodecData_s
{
    MI_AUDIO_AacFormat_e eAacFormat;                ///<[OUT]: Get aac format type,eq. NONE, LOAS, LATM,...
    MI_AUDIO_AacVersion_e eAacVersion;              ///<[OUT]: Get aac version, eq. AAC, HEAAC_v1, ...
} MI_AUDIO_AacCodecData_t;

typedef struct MI_AUDIO_DolbyTrueHdCodecData_s
{
    MI_BOOL bAtmos;                                        ///<[OUT]: Get the status that if the audio stream is atmos audio;
} MI_AUDIO_DolbyTrueHdCodecData_t;

typedef struct MI_AUDIO_CodecParams_s
{
    //common codec parameters
    MI_AUDIO_CodecType_e eCodecType;                 ///< [IN]: Audio codec type, such as MPEG.
    MI_U32  u32SampleRate;                           ///< [IN]: Sampling rate, 48000(48KHz), 44100(44.1KHz), 32000(32KHz),....both used in get or set.
    MI_U32  u32BitRate;                              ///< [IN]: Bit rate,both used in get or set.
    MI_U8   u8Channels;                              ///< [IN]: Channels, 1(mono), 2(stereo),...both used in get or set.
    //private codec parameters
    union
    {
        MI_AUDIO_XpcmCodecData_t            stXpcmCodecData;             ///< [IN]: Attribution of Xpcm codec.
        MI_AUDIO_WmaCodecData_t             stWmaCodecData;              ///< [IN]: Attribution of Wma codec.
        MI_AUDIO_Ra8CodecData_t             stRa8CodecData;              ///< [IN]: Attribution of Ra8 codec.
        MI_AUDIO_Ac3pCodecData_t            stAc3pCodecData;             ///< [IN]: Attribution of Ac3p codec.
        MI_AUDIO_DtsCodecData_t             stDtsCodecData;              ///< [IN]: Attribution of Dts codec.
        MI_AUDIO_Ac4CodecData_t             stAc4CodecData;              ///< [IN]: Attribution of Ac4 codec.
        MI_AUDIO_AacCodecData_t             stAacCodecData;              ///< [IN]: Attribution of Aac codec.
        MI_AUDIO_DolbyTrueHdCodecData_t     stDolbyTrueHdCodecData;      ///< [IN]: Attribution of Dolby TrueHD codec.
    }attr;
} MI_AUDIO_CodecParams_t;

typedef struct MI_AUDIO_CallbackInputParams_s
{
    MI_U64 u64CallbackId;                   ///[IN]: for multi-callback, use 0 for first register or single callback.
    MI_AUDIO_EventCallback pfEventCallback; ///[IN]: callback function pointer.
    MI_U32 u32EventFlags;                   ///[IN]: registered events which are bitwise OR operation.Information refer to MI_AUDIO_CallbackEvent_e.
    void *pUserParams;                      ///[IN]: for passing user-defined parameters,both used in get or set.
} MI_AUDIO_CallbackInputParams_t;

typedef struct MI_AUDIO_CallbackOutputParams_s
{
    MI_U64 u64CallbackId;               ///[OUT]: the returned ID for update or unregister callback.
} MI_AUDIO_CallbackOutputParams_t;

typedef struct MI_AUDIO_QueryHandleParams_s
{
    MI_U8 * pszName;                   ///<[IN]: Query audio handle by finding the custom defined audio name which is a string with zero terminated.
}MI_AUDIO_QueryHandleParams_t;

typedef struct MI_AUDIO_ConnectInputParams_s
{
    MI_HANDLE hAudDmxFilt;             ///< [IN]: Handle of Audio DMX filter opened by MI_DMX_Open()
}MI_AUDIO_ConnectInputParams_t;

typedef struct MI_AUDIO_DumpInfoParams_s
{
    MI_U8 u8Reserved;                  ///< [IN]: Debug info setting.
}MI_AUDIO_DumpInfoParams_t;

typedef struct MI_AUDIO_ConnectedConds_s
{
    MI_BOOL bIsInput;
    MI_U32 u32Module;

    //if need other conditions add here
} MI_AUDIO_ConnectedConds_t;

typedef struct MI_AUDIO_EnableAdParams_s
{
    MI_U16      u16Pid;
} MI_AUDIO_EnableAdParams_t;

typedef struct MI_AUDIO_Speed_s
{
    MI_AUDIO_Speed_e eSpeed;          ///< [IN]: Playing speed.Step is 0.25X.
    MI_U32 u32ManualSpeed;            ///< [IN]: Customized playing speed, only used in case E_MI_AUDIO_SPEED_MANUAL,range:250~2000,real speed = u32ManualSpeed/1000.
} MI_AUDIO_Speed_t;

typedef struct MI_AUDIO_DrcScale_s
{
    MI_U32 u32HighCutScale;             ///< [IN]: 0--100 percent of high compression level
    MI_U32 u32LowBoostScale;            ///< [IN]: 0--100 percent of low compression level
} MI_AUDIO_DrcScale_t;

typedef struct MI_AUDIO_ChannelAttr_s
{
    MI_BOOL bIsDualMono;                ///< [OUT]: the channel is dual mono or not

} MI_AUDIO_ChannelAttr_t;


//-------------------------------------------------------------------------------------------------
//  Global Functions
//-------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------
/// @brief Init audio module.
/// @param[in] *pstInitParams. init parameters
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_AUDIO_Init(const MI_AUDIO_InitParams_t *pstInitParams);

//------------------------------------------------------------------------------
/// @brief Finalize audio module.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_AUDIO_DeInit(void);

//------------------------------------------------------------------------------
/// @brief Get audio capability.
/// @param[out] *pstCaps. The capabilty of audio
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_AUDIO_GetCaps(MI_AUDIO_Caps_t *pstCaps);

//------------------------------------------------------------------------------
/// @brief Open an audio handle.
/// @param[in] *pstOpenParams. open parameters
/// @param[out] *phAudio. Audio handle
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_RESOURCES: No available resource.
//------------------------------------------------------------------------------
MI_RESULT MI_AUDIO_Open(const MI_AUDIO_OpenParams_t *pstOpenParams, MI_HANDLE *phAudio);

//------------------------------------------------------------------------------
/// @brief Close an audio handle.
/// @param[in] hAudio. Audio handle
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_AUDIO_Close(MI_HANDLE hAudio);

//------------------------------------------------------------------------------
/// @brief Start audio player.
/// @param[in] hAudio. Audio handle
/// @param[in] *pstStartParams. Parameters of decoder start.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_AUDIO_Start(MI_HANDLE hAudio, const MI_AUDIO_StartParams_t * pstStartParams);

//------------------------------------------------------------------------------
/// @brief Stop audio player.
/// @param[in] hAudio. Audio handle
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_AUDIO_Stop(MI_HANDLE hAudio);

//------------------------------------------------------------------------------
/// @brief Reset audio player.
/// @param[in] hAudio. Audio handle
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_AUDIO_Reset(MI_HANDLE hAudio);

//------------------------------------------------------------------------------
/// @brief Write es data to audio player by frame.
/// @param[in] hAudio. Audio handle
/// @param[in] *pstWriteParams. Parameters of write data to audio.
/// @param[out] *pstOutputParams. Parameter of output by audio after writting data.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_AUDIO_Write(MI_HANDLE hAudio, const MI_AUDIO_WriteParams_t *pstWriteParams, MI_AUDIO_WriteOutputParams_t *pstOutputParams);

//------------------------------------------------------------------------------
/// @brief Read pcm data from audio decoder.
/// @param[in] hAudio. Audio handle
/// @param[in] *pstReadParams. Parameters of reading data from audio.
/// @param[out] *pstOutputParams. Parameter of output by audio after reading data.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_AUDIO_Read(MI_HANDLE hAudio, const MI_AUDIO_ReadParams_t *pstReadParams, MI_AUDIO_ReadOutputParams_t *pstOutputParams);

//------------------------------------------------------------------------------
/// @brief Flush the data in decoder.
/// @param[in] hAudio. Audio handle
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_AUDIO_Clear(MI_HANDLE hAudio);

//------------------------------------------------------------------------------
/// @brief Enable AD feature.
/// @param[in] hAudio. Audio handle
/// @param[in] pstEnableAdParams. Audio AD info.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_AUDIO_EnableAd(MI_HANDLE hAudio, MI_AUDIO_EnableAdParams_t *pstEnableAdParams);

//------------------------------------------------------------------------------
/// @brief Disable AD feature.
/// @param[in] hAudio. Audio handle
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_AUDIO_DisableAd(MI_HANDLE hAudio);

//------------------------------------------------------------------------------
/// @brief Set the audio codec parameter
/// @param[in] hAudio. Audio handle
/// @param[in] pstCodecParams pointer to struct MI_AUDIO_CodecParams_t for a specified codec
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Audio module is not inited
/// @return MI_ERR_INVALID_HANDLE: Invalid Audio handle
//------------------------------------------------------------------------------
MI_RESULT MI_AUDIO_SetCodecParams(MI_HANDLE hAudio, MI_AUDIO_CodecParams_t *pstCodecParams);

//------------------------------------------------------------------------------
/// @brief Get the audio codec parameter
/// @param[in] hAudio. Audio handle
/// @param[out] pstCodecParams pointer to struct MI_AUDIO_CodecParams_t for a specified codec
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Audio module is not inited
/// @return MI_ERR_INVALID_HANDLE: Invalid Audio handle
//------------------------------------------------------------------------------
MI_RESULT MI_AUDIO_GetCodecParams(MI_HANDLE hAudio, MI_AUDIO_CodecParams_t *pstCodecParams);

//------------------------------------------------------------------------------
/// @brief Register audio event.
/// @param[in] hAudio. Audio handle
/// @param[in] *pstInputParams. Parameters of register callback
/// @param[out] *pstOutputParams. Parameters of output afer register callback.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_AUDIO_RegisterCallback(MI_HANDLE hAudio, const MI_AUDIO_CallbackInputParams_t * pstInputParams, MI_AUDIO_CallbackOutputParams_t *pstOutputParams);

//------------------------------------------------------------------------------
/// @brief Unregister audio event.
/// @param[in] hAudio. Audio handle
/// @param[in] *pstInputParams.Parameters of unregister callback
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_AUDIO_UnRegisterCallback(MI_HANDLE hAudio, const MI_AUDIO_CallbackInputParams_t * pstInputParams);

//------------------------------------------------------------------------------
/// @brief Finalize audio module.
/// @param[in] hAudio. Audio handle
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_AUDIO_Pause(MI_HANDLE hAudio);

//------------------------------------------------------------------------------
/// @brief Finalize audio module.
/// @param[in] hAudio. Audio handle
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_AUDIO_Resume(MI_HANDLE hAudio);

//------------------------------------------------------------------------------
/// @brief Get audio attr.
/// @param[in] hAudio. Audio handle
/// @param[in] eAttrType. Audio attribute type
/// @param[in] *pInputParams. Parameters of getting attribute that send to audio.
/// @param[out] *pOutputParams. Parameters of output after calling get attribute.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_AUDIO_GetAttr(MI_HANDLE hAudio, MI_AUDIO_AttrType_e eAttrType, const void * pInputParams, void * pOutputParams);

//------------------------------------------------------------------------------
/// @brief Set audio attribute.
/// @param[in] hAudio. Audio handle
/// @param[in] eAttrType. Audio attribute type
/// @param[in] *pAttrParams. Parameters of input for calling set attribute.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_AUDIO_SetAttr(MI_HANDLE hAudio, MI_AUDIO_AttrType_e eAttrType, const void *pAttrParams);

//------------------------------------------------------------------------------
/// @brief Get audio handle.
/// @param[in] *pstQueryParams. The parameters of getting handle.
/// @param[out] *phAudio. Audio handle user will be acquired.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_AUDIO_GetHandle(const MI_AUDIO_QueryHandleParams_t * pstQueryParams, MI_HANDLE * phAudio);
//------------------------------------------------------------------------------
/// @brief Dump debug message.
/// @param[in] *pstDumpInfoParams. Dump info will be print according to command.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_AUDIO_DumpDbgInfo(MI_AUDIO_DumpInfoParams_t * pstDumpInfoParams);
//------------------------------------------------------------------------------
/// @brief Set debug level for mi_audio.c.
/// @param[in] u32DebugLevel. Debug info will be print according to u32DebugLevel.
/// @return MI_OK: Process success.
//------------------------------------------------------------------------------
MI_RESULT MI_AUDIO_SetDebugLevel(MI_DBG_LEVEL u32DebugLevel);

//------------------------------------------------------------------------------
/// @brief For audio is a down stream module. Audio connect its input with hInput, i.e. hInput --> hAudio
/// @param[in] hAudio: Audio handle
/// @param[in] hInput: Handle of up stream to connect with Audio's input
/// @param[in] pstParams: Pointer to struct MI_AUDIO_ConnectInputParams_t to speicified the parameters for audio connect input with hUpHdl
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE: invalid handle.
/// @return MI_ERR_FAILED: Process failed
//------------------------------------------------------------------------------
MI_RESULT MI_AUDIO_ConnectInput(MI_HANDLE hAudio, MI_HANDLE hInput, const MI_AUDIO_ConnectInputParams_t *pstParams);

//------------------------------------------------------------------------------
/// @brief For audio is a down stream module. Audio disconnect its input hInput, i.e. hInput -X-> hAudio
/// @param[in] hAudio: Audio handle
/// @param[in] hInput: Handle of up stream to connect with audio's input
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE: invalid handle.
/// @return MI_ERR_FAILED: Process failed
//------------------------------------------------------------------------------
MI_RESULT MI_AUDIO_DisconnectInput(MI_HANDLE hAudio, MI_HANDLE hInput);

//------------------------------------------------------------------------------
/// @brief Get the element which is connected to the specified element.
/// @param[in] hAudio: Audio handle
/// @param[in] pstAudioConds: bIsinput-The direction for finding the connected module.
///                           u32ModuleType-The module type of connected with AUDIO. it defined in mi_common.h with prefix MI_MODULE_TYPE_XXX.
///                                         If it is MI_MODULE_TYPE_NONE it find all type of connected modules.
///                                         e.g. MI_AUDIO_GetConnectedNum(hAudio, TRUE, MI_MODULE_TYPE_TSIO, pu32ConnectedNum)
/// @param[out] pu32ConnectedNum: The number of connected handle
/// @return MI_OK: Process success.
//------------------------------------------------------------------------------
MI_RESULT MI_AUDIO_GetConnectedNum(const MI_HANDLE hAudio, const MI_AUDIO_ConnectedConds_t *pstAudioConds, MI_U32 *pu32ConnectedNum);

//------------------------------------------------------------------------------
/// @brief Get the element which is connected to the specified element.
/// @param[in] hAudio: Audio handle
/// @param[in] pstAudioConds: bIsinput-The direction for finding the connected module.
///                           u32ModuleType-The module type of connected with AUDIO. it defined in mi_common.h with prefix MI_MODULE_TYPE_XXX.
///                                         If it is MI_MODULE_TYPE_NONE it find all type of connected modules.
///                                         e.g. MI_AUDIO_GetConnected(hAudio, TRUE, MI_MODULE_TYPE_TSIO, u32ConnectedNum, phConnectedArray)
/// @param[in] u32ConnectedNum: The number of get handle
/// @param[out] phConnectedArray: Pointer to handle buffer to retrieve the handle of MI module which is connected to the specified element with the specified direction.
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_FAILED: Process fail, no connection is available.
//------------------------------------------------------------------------------
MI_RESULT MI_AUDIO_GetConnected(const MI_HANDLE hAudio, const MI_AUDIO_ConnectedConds_t *pstAudioConds, const MI_U32 u32ConnectedNum, MI_HANDLE *phConnectedArray);

//------------------------------------------------------------------------------
/// @brief Set audio playing speed.
/// @param[in] hAudio. Audio handle.
/// @param[in] *pstSpeed. Playing speed parameters,range:0.25~2.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_AUDIO_SetSpeed(MI_HANDLE hAudio, const MI_AUDIO_Speed_t *pstSpeed);
#ifdef __cplusplus
}
#endif

#endif///_MI_AUDIO_H_

