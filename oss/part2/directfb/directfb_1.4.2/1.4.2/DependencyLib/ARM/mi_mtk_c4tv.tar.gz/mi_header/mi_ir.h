/*------------------------------------------------------------------------------
 * MediaTek Inc. (C) 2018. All rights reserved.
 *
 * Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 *----------------------------------------------------------------------------*/
//------------------------------------------------------------------------------
// Use GetXxx/SetXxx only
//------------------------------------------------------------------------------

#ifndef _MI_IR_H_
#define _MI_IR_H_

#ifdef __cplusplus
extern "C" {
#endif

//-------------------------------------------------------------------------------------------------
//  Defines
//-------------------------------------------------------------------------------------------------

//-------------------------------------------------------------------------------------------------
//  Structures
//-------------------------------------------------------------------------------------------------
typedef enum
{
    E_MI_IR_PROTOCOL_NONE = 0,
    E_MI_IR_PROTOCOL_NEC,
    E_MI_IR_PROTOCOL_RC5,
    E_MI_IR_PROTOCOL_PZ_OCN,
    E_MI_IR_PROTOCOL_MAX,
} MI_IR_Protocol_e;

typedef enum
{
    E_MI_IR_KEY_STATE_PRESS = 0,
    E_MI_IR_KEY_STATE_REPEAT,
    E_MI_IR_KEY_STATE_RELEASE,
    E_MI_IR_KEY_STATE_MAX = 0xff,
} MI_IR_KeyState_e;

typedef enum
{
    E_MI_IR_EVENT_ID_NONE = 0,
    E_MI_IR_EVENT_ID_GET_KEY_U32 = MI_BIT(0),
    E_MI_IR_EVENT_ID_GET_KEY_U64 = MI_BIT(1),

    E_MI_IR_EVENT_ID_ALL = -1,
} MI_IR_EventId_e;

typedef enum
{
    E_MI_IR_EVENT_DATA_TYPE_INVALID = -1,
    E_MI_IR_EVENT_DATA_TYPE_MIN = 0,

    E_MI_IR_EVENT_DATA_TYPE_U32 = E_MI_IR_EVENT_DATA_TYPE_MIN,
    E_MI_IR_EVENT_DATA_TYPE_U64,

    E_MI_IR_EVENT_DATA_TYPE_MAX,
} MI_IR_EventDataType_e;

typedef struct MI_IR_MultiProtocol_s
{
    MI_IR_Protocol_e eProtocol;  ///[IN]: multi key protocol
    void *pNext;            ///[IN]: pointer to next MI_IR_MultiProtocol_t
} MI_IR_MultiProtocol_t;

typedef struct MI_IR_RepeatKey_s
{
    MI_U32 u32TimeToGet1stRepeatKey; ///[IN]: Delay time to ensure repeat key
    MI_U32 u32RepeatKeyDuration; ///[IN]: Time duration between two repeat key
    MI_U8  u8Data;                           ///[IN]: Repeat key data
} MI_IR_RepeatKey_t;

typedef enum
{
    E_MI_IR_ATTR_TYPE_INVALID = -1,
    E_MI_IR_ATTR_TYPE_MIN = 0,
    E_MI_IR_ATTR_TYPE_BLOCKING_KEY_ENABLE = E_MI_IR_ATTR_TYPE_MIN,          ///Set block key enable or disable, pAttrParams is a pointer to MI_BOOL
    E_MI_IR_ATTR_TYPE_INPUT_EVENT_ENABLE,                                   ///Set input event enable or disable, pAttrParams is a pointer to MI_BOOL
    E_MI_IR_ATTR_TYPE_INVERT_KEY_ENABLE,                                    ///Set invert key enable or disable, pAttrParams is a pointer to MI_BOOL
    E_MI_IR_ATTR_TYPE_ADD_BLOCKING_KEY,                                     ///Add key to be blocked, pAttrParams is a pointer to MI_IR_KeyCodeInfo_t
    E_MI_IR_ATTR_TYPE_ADD_SOFTWARE_TRIGGER_KEY,                             ///Add key to be software triggered, pAttrParams is a pointer to MI_IR_KeyCodeInfo_t

    E_MI_IR_ATTR_TYPE_MAX
} MI_IR_AttrType_e;

typedef struct MI_IR_KeyCodeInfo_s
{
    MI_U64 u64ScanCode;      ///[IN]:Scan code
    MI_U64 u64KeyCode;       ///[IN]:Key code
} MI_IR_KeyCodeInfo_t;

typedef struct MI_IR_InitParams_s
{
    MI_BOOL bDisableInputEvent;    ///[IN]: disable input event
} MI_IR_InitParams_t;

typedef struct MI_IR_OpenParams_s
{
    MI_U16 u16CustomCode;          ///[IN]: Custom key code
    MI_U32 u32ExtCustomCode;     ///[IN]: Extension custom key code
    MI_IR_RepeatKey_t stRepeatKey; ///[IN]: Struct for repeat key
    MI_BOOL bReturnRawData;       ///[IN]: Return raw data in callback
    MI_U8 au8DfbKeyMapPath[128];      ///[IN]: Path of DFB IR key map
} MI_IR_OpenParams_t;

typedef MI_RESULT (*MI_IR_EventCallback)(MI_HANDLE hIr, MI_U32 u32Event, void *pEventParams, void *pUserParams);

typedef struct MI_IR_CallbackInputParams_s
{
    MI_U64 u64CallbackId;                     ///[IN]: Use 0 for first register, other valid value(returned by MI_IR_CallbackOutputParams_t) for update callback event.
    MI_IR_EventCallback pfEventCallback;      ///[IN]: Registered events MI_TSMUX_Event_e which are bitwise OR operation.
    MI_U32 u32EventFlags;                   ///[IN]: Event callback function pointer.
    void *pUserParams;                       ///[IN]: For passing user-defined parameters.
} MI_IR_CallbackInputParams_t;

typedef struct MI_IR_CallbackOutputParams_s
{
    MI_U64 u64CallbackId;                           ///[OUT]: the returned ID for update or unregister callback.
} MI_IR_CallbackOutputParams_t;

typedef struct MI_IR_EventParams_s
{
    MI_IR_EventDataType_e eDataType;                    ///[OUT]: key data's type
    union
    {
        MI_U32 u32Data;                                 ///[OUT]: U32 key data
        MI_U64 u64Data;                                 ///[OUT]: U64 key data
    } uData;                                            ///[OUT]: key data
} MI_IR_EventParams_t;

//-------------------------------------------------------------------------------------------------
//  Global Functions
//-------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------
/// @brief Initialize the IR module
/// @param[in] pstInitParams: Parameter to init ir module
/// @return MI_OK: Process success.
/// @return MI_HAS_INITED: UART module had inited.
/// @return MI_ERR_INVALID_PARAMETER: parameter error.
/// @return MI_ERR_RESOURCES: No available resource.
/// @return MI_ERR_MEMORY_ALLOCATE: Allocate memory fail
/// @return MI_ERR_NOT_SUPPORT: Not supported.
/// @return MI_ERR_FAILED: Process failed
/// @sa
/// @note
//------------------------------------------------------------------------------
MI_RESULT MI_IR_Init(const MI_IR_InitParams_t *pstInitParams);

//------------------------------------------------------------------------------
/// @brief Finalize the IR module
/// @param[in] None
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module is not inited.
/// @return MI_ERR_NOT_SUPPORT: Not supported.
/// @sa
/// @note
//------------------------------------------------------------------------------
MI_RESULT MI_IR_DeInit(void);

//------------------------------------------------------------------------------
/// @brief Open the IR device
/// @param[in] pstOpenParams: Parameter setting for opening IR
/// @param[out] phIr: return the IR handle
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module is not inited.
/// @return MI_ERR_INVALID_PARAMETER: parameter error.
/// @return MI_ERR_RESOURCES: No available resource.
/// @return MI_ERR_FAILED: Process failed
/// @sa
/// @note
//------------------------------------------------------------------------------
MI_RESULT MI_IR_Open(const MI_IR_OpenParams_t *pstOpenParams, MI_HANDLE *phIr);

//------------------------------------------------------------------------------
/// @brief Close the IR device
/// @param[in] hIr: The IR handle to close
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module is not inited.
/// @return MI_ERR_INVALID_HANDLE: handle error.
/// @return MI_ERR_FAILED: Process failed
/// @sa
/// @note
//------------------------------------------------------------------------------
MI_RESULT MI_IR_Close(MI_HANDLE hIr);

//------------------------------------------------------------------------------
/// @brief Register callback function to get key code
/// @param[in] hIr: The IR handle to close
/// @param[in] pstInputParams: Paramters for callback function to getkey
/// @param[in] pstOutputParams: Paramters for getting callback id
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module is not inited.
/// @return MI_ERR_INVALID_PARAMETER: parameter error.
/// @return MI_ERR_INVALID_HANDLE: handle error.
/// @return MI_ERR_MEMORY_ALLOCATE: Allocate memory fail
/// @sa
/// @note
//------------------------------------------------------------------------------
MI_RESULT MI_IR_RegisterCallback(MI_HANDLE hIr, const MI_IR_CallbackInputParams_t *pstInputParams, MI_IR_CallbackOutputParams_t *pstOutputParams);

//------------------------------------------------------------------------------
/// @brief Register callback function to get key code
/// @param[in] hIr: The IR handle to close
/// @param[in] pstInputParams: Paramters to unregister callback
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module is not inited.
/// @return MI_ERR_INVALID_PARAMETER: parameter error.
/// @return MI_ERR_INVALID_HANDLE: handle error.
/// @sa
/// @note
//------------------------------------------------------------------------------
MI_RESULT MI_IR_UnRegisterCallback(MI_HANDLE hIr, const MI_IR_CallbackInputParams_t *pstInputParams);

//------------------------------------------------------------------------------
/// @brief Setting the IR delay time on key repeat
/// @param[in] hIr: The IR handle to close
/// @param[in] pstRepeatKey: structure to set time for repeat key
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module is not inited.
/// @return MI_ERR_INVALID_HANDLE: handle error.
/// @sa
/// @note
//------------------------------------------------------------------------------
MI_RESULT MI_IR_SetRepeatKeyTime(MI_HANDLE hIr, MI_IR_RepeatKey_t *pstRepeatKey);

//------------------------------------------------------------------------------
/// @brief Setting the support protocol
/// @param[in] hIr: The IR handle to close
/// @param[in] pstProtocolCfg: pointer structure to set protocol list
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module is not inited.
/// @return MI_ERR_INVALID_HANDLE: handle error.
/// @return MI_ERR_NOT_SUPPORT: Not supported.
/// @return MI_ERR_FAILED: Process failed
/// @sa
/// @note
//------------------------------------------------------------------------------
MI_RESULT MI_IR_SetProtocol(MI_HANDLE hIr, MI_IR_MultiProtocol_t *pstProtocolCfg);

//------------------------------------------------------------------------------
/// @brief Setting the debug level for IR module
/// @param[in] u32DbgLevel: debug level
/// @return MI_OK: Process success.
/// @sa
/// @note
//------------------------------------------------------------------------------
MI_RESULT MI_IR_SetDebugLevel(MI_DBG_LEVEL u32DebugLevel);

//------------------------------------------------------------------------------
/// @brief set attr
/// @param[in] hIr. The IR handle
/// @param[in] eAttrType assign which attr. user want to set
/// @param[in] pAttrParams for user to set
/// @return MI_OK: Process success
/// @return MI_ERR_FAILED: Process failure
/// @sa
/// @note
//------------------------------------------------------------------------------
MI_RESULT MI_IR_SetAttr(MI_HANDLE hIr, MI_IR_AttrType_e eAttrType, const void * pAttrParams);

#ifdef __cplusplus
}
#endif

#endif///_MI_IR_H_

