/*------------------------------------------------------------------------------
 * MediaTek Inc. (C) 2018. All rights reserved.
 *
 * Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 *----------------------------------------------------------------------------*/
//----------------------------------------------------------------------------------------
//  GetXxx/SetXxx and GetAttr/SetAttr coexist
//----------------------------------------------------------------------------------------

#ifndef _MI_USB_H_
#define _MI_USB_H_

#ifdef __cplusplus
extern "C" {
#endif

//-------------------------------------------------------------------------------------------------
//  Defines
//-------------------------------------------------------------------------------------------------
#define MI_USB_SYS_FILE_NAME_LEN    32

//-------------------------------------------------------------------------------------------------
//  Structures
//-------------------------------------------------------------------------------------------------
typedef enum
{
    E_MI_USB_STORAGE_EVENT_NONE = 0,
    E_MI_USB_STORAGE_EVENT_SHEATHE = MI_BIT(0),             //Device plug-in or partition is found
    E_MI_USB_STORAGE_EVENT_CHECKING = MI_BIT(1),            //Partition checking
    E_MI_USB_STORAGE_EVENT_READY = MI_BIT(2),               //Device or partition is mounted successfully
    E_MI_USB_STORAGE_EVENT_ERROR = MI_BIT(3),               //Device or partition is mounted failed
    E_MI_USB_STORAGE_EVENT_PLUGOUT = MI_BIT(4),             //Device plug-out or partition is unmounted
    E_MI_USB_STORAGE_EVENT_PLUGOUT_UNMOUNT_OK = MI_BIT(5),  //Device plug-out and is unmounted successfully
    E_MI_USB_STORAGE_EVENT_PLUGOUT_UNMOUNT_FAIL = MI_BIT(6),//Device plug-out but is unmounted failedly

    E_MI_USB_STORAGE_EVENT_ALL = -1,
} MI_USB_StorageEvent_e;

typedef enum
{
    E_MI_USB_PARTITION_FORMAT_TYPE_INVALID = -1,
    E_MI_USB_PARTITION_FORMAT_TYPE_MIN = 0,

    E_MI_USB_PARTITION_FORMAT_TYPE_UNKNOWN = E_MI_USB_PARTITION_FORMAT_TYPE_MIN,
    E_MI_USB_PARTITION_FORMAT_TYPE_AUTO,
    E_MI_USB_PARTITION_FORMAT_TYPE_CRAMFS,              //Read only
    E_MI_USB_PARTITION_FORMAT_TYPE_ROMFS,               //Read only
    E_MI_USB_PARTITION_FORMAT_TYPE_FAT32 ,
    E_MI_USB_PARTITION_FORMAT_TYPE_EXT2,
    E_MI_USB_PARTITION_FORMAT_TYPE_EXT3,
    E_MI_USB_PARTITION_FORMAT_TYPE_JFFS2,
    E_MI_USB_PARTITION_FORMAT_TYPE_NTFS,
    E_MI_USB_PARTITION_FORMAT_TYPE_UBIFS,
    E_MI_USB_PARTITION_FORMAT_TYPE_YAFFS2,

    E_MI_USB_PARTITION_FORMAT_TYPE_MAX,
} MI_USB_PartitionFormatType_e;

typedef enum
{
    E_MI_USB_IOCHARSET_TYPE_INVALID = -1,
    E_MI_USB_IOCHARSET_TYPE_MIN = 0,

    E_MI_USB_IOCHARSET_TYPE_UTF8 = E_MI_USB_IOCHARSET_TYPE_MIN,                     //Default used type
    E_MI_USB_IOCHARSET_TYPE_GB2312,                                                 //Support Simplified Chinese

    E_MI_USB_IOCHARSET_TYPE_MAX,
} MI_USB_IocharsetType_e;

typedef enum
{
    E_MI_USB_ATTR_TYPE_INVALID = -1,
    E_MI_USB_ATTR_TYPE_MIN = 0,

    E_MI_USB_ATTR_TYPE_GET_PARTITION_MIN = E_MI_USB_ATTR_TYPE_MIN,
    E_MI_USB_ATTR_TYPE_GET_PARTITION_TOTAL_SIZE,                                    //Partition's total size
    E_MI_USB_ATTR_TYPE_GET_PARTITION_FREE_SIZE,                                     //Partition's free size
    E_MI_USB_ATTR_TYPE_GET_PARTITION_FORMAT_TYPE,                                   //Partition's format type
    E_MI_USB_ATTR_TYPE_GET_PARTITION_LOGIC_CHAR,                                    //Partition's logic character
    E_MI_USB_ATTR_TYPE_GET_PARTITION_MOUNT_PATH,                                    //Partition's mount path
    E_MI_USB_ATTR_TYPE_GET_PARTITION_DEVICE_PATH,                                   //Partition's device path
    E_MI_USB_ATTR_TYPE_GET_PARTITION_MAX,

    E_MI_USB_ATTR_TYPE_GET_DEVICE_MIN = 0x100,
    E_MI_USB_ATTR_TYPE_GET_DEVICE_PORT_NUMBER = E_MI_USB_ATTR_TYPE_GET_DEVICE_MIN,  //Device's port number
    E_MI_USB_ATTR_TYPE_GET_DEVICE_PARTITION_TOTAL_NUMBER,                           //Device's partition total number
    E_MI_USB_ATTR_TYPE_GET_DEVICE_DISKDEV_INFO,                                     //Device's partition count, sector size and sector total number
    E_MI_USB_ATTR_TYPE_GET_DEVICE_MBR_PARTITION_INFO,                               //Device's all partition info list
    E_MI_USB_ATTR_TYPE_GET_DEVICE_MAX_FREE_SECTOR_TOTAL_NUMBER,                     //Device's max continue free sector number
    E_MI_USB_ATTR_TYPE_GET_DEVICE_MAX,

    E_MI_USB_ATTR_TYPE_SET_MIN = 0x200,
    E_MI_USB_ATTR_TYPE_SET_IOCHARSET_TYPE = E_MI_USB_ATTR_TYPE_SET_MIN,
    E_MI_USB_ATTR_TYPE_SET_MAX,

    E_MI_USB_ATTR_TYPE_MAX,
} MI_USB_AttrType_e;

typedef enum
{
    E_MI_USB_PARTITION_CMD_INVALID = -1,
    E_MI_USB_PARTITION_CMD_MIN = 0,

    E_MI_USB_PARTITION_CMD_CREATE_MAIN = E_MI_USB_PARTITION_CMD_MIN,//Create main partition
    E_MI_USB_PARTITION_CMD_DELETE,                                  //Delete one partition
    E_MI_USB_PARTITION_CMD_ERASE_ALL,                               //Delete all partitions

    E_MI_USB_PARTITION_CMD_MAX,
} MI_USB_PartitionCmd_e;

typedef struct MI_USB_PartitionInfo_s
{
    MI_S32 s32PartitionId;                              ///[OUT]: Partition id
    MI_U32 u32SecTotalNumber;                           ///[OUT]: Sector total number
    MI_USB_PartitionFormatType_e eFormat;               ///[OUT]: Partition format
} MI_USB_PartitionInfo_t;

typedef struct MI_USB_PartitionEraseCmdParams_s
{
    MI_S16 s16DevIndex;                                 ///[IN]: Device index
} MI_USB_PartitionEraseCmdParams_t;

typedef struct MI_USB_PartitionDeleteCmdParams_s
{
    MI_S16 s16DevIndex;                                 ///[IN]: Device index
    MI_S32 s32PartitionId;                              ///[IN]: Partition id
} MI_USB_PartitionDeleteCmdParams_t;

typedef struct MI_USB_PartitionCreateCmdInputParams_s
{
    MI_S16 s16DevIndex;                                 ///[IN]: Device index
    MI_U32 u32SecTotalNumber;                           ///[IN]: Sector total number
    MI_USB_PartitionFormatType_e eFormat;               ///[IN]: Partition format
} MI_USB_PartitionCreateCmdInputParams_t;

typedef struct MI_USB_PartitionCreateCmdOutputParams_s
{
    MI_S16 s16DevIndex;                                 ///[OUT]: Device index
    MI_S32 s32PartitionId;                                ///[OUT]: Partition id
} MI_USB_PartitionCreateCmdOutputParams_t;

typedef struct MI_USB_FreeSpace_s
{
    MI_S16 s16DevIndex;                                 ///[OUT]: Device index
    MI_U32 u32FreeSectors;                              ///[OUT]: Max free sector number
} MI_USB_FreeSpace_t;

typedef struct MI_USB_PartitionInfoList_s
{
    MI_S16 s16DevIndex;                                 ///[OUT]: Device index
    MI_USB_PartitionInfo_t *pstPartitionInfo;           ///[OUT]: List of MI_USB_PartitionInfo_t
} MI_USB_PartitionInfoList_t;

typedef struct MI_USB_DiskDevInfo_s
{
    MI_S16 s16DevIndex;                                 ///[OUT]: Device index
    MI_U8 u8MbrPartCount;                               ///[OUT]: Partition count by MBR
    MI_U32 u32SectorSize;                               ///[OUT]: Size of sector in bytes
    MI_U32 u32SectorTotalNumber;                        ///[OUT]: Total number of sector in device
} MI_USB_DiskDevInfo_t;

typedef struct MI_USB_DumpInfoParams_s
{
    MI_U8 u8Reserved;                                   ///[IN]: Reserved
} MI_USB_DumpInfoParams_t;

typedef void (*MI_USB_EventCallback)(MI_HANDLE hUsb, MI_U32 u32Event, void *pEventParams, void *pUserParams);

typedef struct MI_USB_FormatParams_s
{
    MI_U8 szDevicePath[MI_USB_SYS_FILE_NAME_LEN];       ///[IN]: Device path
    MI_USB_PartitionFormatType_e eFormat;               ///[IN]: Partition format
    MI_BOOL bForceFormat;                               ///[IN]: Format it forcedly
} MI_USB_FormatParams_t;

typedef struct MI_USB_MountParams_s
{
    MI_U8 szMountPath[MI_USB_SYS_FILE_NAME_LEN];        ///[IN]: Mount path
    MI_U8 szDevicePath[MI_USB_SYS_FILE_NAME_LEN];       ///[IN]: Device path
} MI_USB_MountParams_t;

typedef struct MI_USB_UnMountParams_s
{
    MI_U8 szMountPath[MI_USB_SYS_FILE_NAME_LEN];        ///[IN]: Path to be unmounted
} MI_USB_UnMountParams_t;

typedef struct MI_USB_InitParams_s
{
    MI_BOOL bManualMount;                               ///[IN]: TRUE for manually mount
} MI_USB_InitParams_t;

typedef struct MI_USB_CallbackInputParams_s
{
    MI_U64 u64CallbackId;                               ///[IN]: Use 0 for first register, other valid value(returned via MI_USB_CallbackOutputParams_t) for update callback event.
    MI_USB_EventCallback pfEventCallback;               ///[IN]: Event callback function pointer.
    MI_U32 u32EventFlags;                               ///[IN]: Registered events which are bitwise OR operation.
    void *pUserParams;                                  ///[IN]: For passing user-defined parameters.
} MI_USB_CallbackInputParams_t;

typedef struct MI_USB_CallbackOutputParams_s
{
    MI_U64 u64CallbackId;                               ///[OUT]: the returned ID for update or unregister callback.
} MI_USB_CallbackOutputParams_t;

typedef struct MI_USB_StorageEventParams_s
{
    MI_S16 s16MountIndex;                               ///[OUT]: Mount index
    MI_S16 s16PartitionIndex;                           ///[OUT]: Partition index
    MI_U8 *pszUnMountPath;                              ///[OUT]: Unmounted path
} MI_USB_StorageEventParams_t;

typedef struct MI_USB_OpenParams_s
{
    MI_U8 u8Reserved;                                   ///[IN]:  Reserved
} MI_USB_OpenParams_t;

typedef struct MI_USB_DevIndexParams_s
{
    MI_S16 s16DevIndex;                                 ///[IN]: Device index
} MI_USB_DevIndexParams_t;

typedef struct MI_USB_DevPartitionIndexParams_s
{
    MI_S16 s16DevIndex;                                 ///[OUT]: for function MI_USB_GetIndexByLogicChar
                                                        ///[IN]:  for the others
                                                        ///Device index

    MI_S16 s16PartitionIndex;                           ///[OUT]: for function MI_USB_GetIndexByLogicChar
                                                        ///[IN]:  for the others
                                                        ///Partition index
} MI_USB_DevPartitionIndexParams_t;

typedef struct MI_USB_RetryAutoUnMountParams_s
{
    MI_U8 u8Reserved;                                   ///[IN]:  Reserved
} MI_USB_RetryAutoUnMountParams_t;

//-------------------------------------------------------------------------------------------------
//  Global Functions
//-------------------------------------------------------------------------------------------------

//------------------------------------------------------------------------------
/// @brief Usb Module initialize
/// @param[in] pstInitParams: Parameters for init
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: parameter error.
/// @return MI_HAS_INITED: Module inited before.
/// @return MI_ERR_MEMORY_ALLOCATE: memory allocation fail
/// @return MI_ERR_RESOURCES: No available resource.
/// @return MI_ERR_FAILED: Process fail.
/// @sa
/// @note
//------------------------------------------------------------------------------
MI_RESULT MI_USB_Init(const MI_USB_InitParams_t *pstInitParams);

//------------------------------------------------------------------------------
/// @brief Device De-Initialization
/// @param[in] None
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: moudle hasn't be inited
/// @return MI_ERR_FAILED: Process failed.
/// @sa
/// @note
//------------------------------------------------------------------------------
MI_RESULT MI_USB_DeInit(void);

//------------------------------------------------------------------------------
/// @brief Open the USB
/// @param[in] pstOpenParam: Parameters for opening USB
/// @param[out] phUsb: return the USB handle
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process failed.
/// @return MI_ERR_NOT_INITED: Module not initialed.
/// @return MI_ERR_INVALID_PARAMETER: parameter error.
/// @return MI_ERR_RESOURCES: No available resource.
/// @sa
/// @note
//------------------------------------------------------------------------------
MI_RESULT MI_USB_Open(const MI_USB_OpenParams_t *pstOpenParams, MI_HANDLE *phUsb);

//------------------------------------------------------------------------------
/// @brief Close the USB
/// @param[in] hUsb: The USB handle to close
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not inted.
/// @return MI_ERR_INVALID_PARAMETER: parameter error.
/// @return MI_ERR_INVALID_HANDLE: handle error.
/// @sa
/// @note
//------------------------------------------------------------------------------
MI_RESULT MI_USB_Close(MI_HANDLE hUsb);

//------------------------------------------------------------------------------
/// @brief Register the callback
/// @param[in] pstInputParams: Input parameters for callback registering
/// @param[out] pstOutputParams: Output parameters for callback registering
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not inted.
/// @return MI_ERR_INVALID_PARAMETER: parameter error.
/// @return MI_ERR_INVALID_HANDLE: handle error.
/// @return MI_ERR_FAILED: Process failed.
/// @sa
/// @note
//------------------------------------------------------------------------------
MI_RESULT MI_USB_RegisterCallback(MI_HANDLE hUsb, const MI_USB_CallbackInputParams_t *pstInputParams, MI_USB_CallbackOutputParams_t *pstOutputParams);

//------------------------------------------------------------------------------
/// @brief Unregister the callback
/// @param[in] hUsb: The USB handle to unregister
/// @param[in] pstInputParams: Input parameters for callback unregistering
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process failed.
/// @return MI_ERR_NOT_INITED: Module not inted.
/// @return MI_ERR_INVALID_PARAMETER: parameter error.
/// @return MI_ERR_INVALID_HANDLE: handle error.
/// @sa
/// @note
//------------------------------------------------------------------------------
MI_RESULT MI_USB_UnRegisterCallback(MI_HANDLE hUsb, const MI_USB_CallbackInputParams_t *pstInputParams);

//------------------------------------------------------------------------------
/// @brief Get device total number
/// @param[in] hUsb: the USB handle
/// @param[out] pu8DeviceTotalNumber: pointer to get the device's total number
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not inited.
/// @return MI_ERR_INVALID_PARAMETER: Invalid parameter.
/// @return MI_ERR_INVALID_HANDLE: handle error.
/// @sa
/// @note
//------------------------------------------------------------------------------
MI_RESULT MI_USB_GetDeviceTotalNumber(MI_HANDLE hUsb, MI_U8 *pu8DeviceTotalNumber);

//------------------------------------------------------------------------------
/// @brief Get the device index and partition index by logic
/// @param[in] hUsb: the USB handle
/// @param[in] u8LogicChar: Logic character
/// @param[out] pstIndexParams: pointer to MI_USB_DevPartitionIndexParams_t
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not inited.
/// @return MI_ERR_INVALID_PARAMETER: Invalid parameter.
/// @return MI_ERR_INVALID_HANDLE: handle error.
/// @return MI_ERR_FAILED: Process fail.
/// @sa
/// @note
//------------------------------------------------------------------------------
MI_RESULT MI_USB_GetIndexByLogicChar(MI_HANDLE hUsb, MI_U8 u8LogicChar, MI_USB_DevPartitionIndexParams_t *pstIndexParams);

//------------------------------------------------------------------------------
/// @brief Mount a disk
/// @param[in] hUsb: the USB handle
/// @param[in] pstMountParams: pointer to the mount parameters
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not inited.
/// @return MI_ERR_INVALID_PARAMETER: Invalid parameter.
/// @return MI_ERR_INVALID_HANDLE: handle error.
/// @return MI_ERR_FAILED: Process fail.
/// @sa
/// @note
//------------------------------------------------------------------------------
MI_RESULT MI_USB_Mount(MI_HANDLE hUsb, const MI_USB_MountParams_t *pstMountParams);

//------------------------------------------------------------------------------
/// @brief Umount a disk
/// @param[in] hUsb: the USB handle
/// @param[in] pstUnMountParams: pointer to the unmount parameters
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not inited.
/// @return MI_ERR_INVALID_PARAMETER: Invalid parameter.
/// @return MI_ERR_INVALID_HANDLE: handle error.
/// @return MI_ERR_FAILED: Process fail.
/// @sa
/// @note
//------------------------------------------------------------------------------
MI_RESULT MI_USB_UnMount(MI_HANDLE hUsb, const MI_USB_UnMountParams_t *pstUnMountParams);

//------------------------------------------------------------------------------
/// @brief Format a disk by device path
/// @param[in] hUsb: the USB handle
/// @param[in] pstFormatParams: pointer to the format parameters
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not inited.
/// @return MI_ERR_INVALID_PARAMETER: Invalid parameter.
/// @return MI_ERR_INVALID_HANDLE: handle error.
/// @return MI_ERR_FAILED: Process fail.
/// @sa
/// @note
//------------------------------------------------------------------------------
MI_RESULT MI_USB_Format(MI_HANDLE hUsb, const MI_USB_FormatParams_t *pstFormatParams);

//------------------------------------------------------------------------------
/// @brief Partition a usb disk
/// @param[in] hUsb: The USB handle
/// @param[in] eCmd: The command to perform
/// @param[in] pInputParams: Input parameters for the command
/// @param[out] pOutputParams: Output parameters for the command
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not inited.
/// @return MI_ERR_INVALID_PARAMETER: Invalid parameter.
/// @return MI_ERR_INVALID_HANDLE: handle error.
/// @return MI_ERR_FAILED: Process fail.
/// @sa
/// @note
//------------------------------------------------------------------------------
MI_RESULT MI_USB_ExecutePartitionCmd(MI_HANDLE hUsb, MI_USB_PartitionCmd_e eCmd, const void *pInputParams, void *pOutputParams);

//------------------------------------------------------------------------------
/// @brief Get the attribute/information
/// @param[in] hUsb: The USB handle
/// @param[in] eAttrType: The type for attribute.
/// @param[in] pInputParams: pointer to the attribute conditions corresponding to the eAttrType.
/// @param[out] pOutputParams: Output attribute
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not inited.
/// @return MI_ERR_INVALID_PARAMETER: Invalid parameter.
/// @return MI_ERR_FAILED: Process fail.
/// @sa
/// @note
//------------------------------------------------------------------------------
MI_RESULT MI_USB_GetAttr(MI_HANDLE hUsb, MI_USB_AttrType_e eAttrType, const void *pInputParams, void *pOutputParams);

//------------------------------------------------------------------------------
/// @brief Set the attribute/information
/// @param[in] hUsb: the USB handle
/// @param[in] eAttrType: The type for attribute.
/// @param[in] pAttrParams: A pointer to to set attribute corresponding to the eAttrType.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not inited.
/// @return MI_ERR_INVALID_PARAMETER: Invalid parameter.
/// @return MI_ERR_FAILED: Process fail.
/// @sa
/// @note
//------------------------------------------------------------------------------
MI_RESULT MI_USB_SetAttr(MI_HANDLE hUsb, MI_USB_AttrType_e eAttrType, const void *pAttrParams);

//------------------------------------------------------------------------------
/// @brief Dump all device information
/// @param[in] pstDumpInfoParams: the dump info parameters
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @sa
/// @note
//------------------------------------------------------------------------------
MI_RESULT MI_USB_DumpInfo(const MI_USB_DumpInfoParams_t * pstDumpInfoParams);

//------------------------------------------------------------------------------
/// @brief Retry unmount plug-out usb device
/// @pstRetryAutoUnMountParams[in] hUsb: the USB handle
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER:  Invalid parameter.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_BUSY: The required operation can not be done due to current system being busy.
/// @return MI_ERR_NOT_SUPPORT: Not support retry auto unmount.
/// @sa
/// @note
//------------------------------------------------------------------------------
MI_RESULT MI_USB_RetryAutoUnMount(MI_HANDLE hUsb, const MI_USB_RetryAutoUnMountParams_t *pstRetryAutoUnMountParams);

//------------------------------------------------------------------------------
/// @brief Set USB debug level.
/// @param[in] u32DebugLevel.
/// @return MI_OK: Set debug level success.
//------------------------------------------------------------------------------
MI_RESULT MI_USB_SetDebugLevel(MI_DBG_LEVEL u32DebugLevel);

#ifdef __cplusplus
}
#endif

#endif///_MI_USB_H_
