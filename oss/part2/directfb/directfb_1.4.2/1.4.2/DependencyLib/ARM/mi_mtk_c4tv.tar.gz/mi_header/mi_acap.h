/*------------------------------------------------------------------------------
 * MediaTek Inc. (C) 2018. All rights reserved.
 *
 * Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 *----------------------------------------------------------------------------*/
//----------------------------------------------------------------------------------------
//  Use GetXxx/SetXxx only
//----------------------------------------------------------------------------------------

#ifndef _MI_ACAP_H_
#define _MI_ACAP_H_

#ifdef __cplusplus
extern "C" {
#endif

//-------------------------------------------------------------------------------------------------
//  Types - Enums
//-------------------------------------------------------------------------------------------------
typedef enum
{
    E_MI_ACAP_CALLBACK_EVENT_DATA_READY = MI_BIT(0),  ///< Audio capture data is ready: parameter type is a pointer to MI_ACAP_FrameInfo_t
} MI_ACAP_CallbackEvent_e;

typedef enum
{
    E_MI_ACAP_SOURCE_TYPE_PCM,       ///< PCM
    E_MI_ACAP_SOURCE_TYPE_PCM_SE,    ///< PCM+Delay+Sound Effect
    E_MI_ACAP_SOURCE_TYPE_KTV,      ///< mix Microphone and BGM without Delay+Sound Effect
    E_MI_ACAP_SOURCE_TYPE_MAX,
}MI_ACAP_SourceType_e;

typedef enum
{
    E_MI_ACAP_ATTR_TYPE_CAPTURE_SOURCE_TYPE,    ///< The capture source of the audio capture, parameter type is a pointer to MI_ACAP_SourceType_e.
    E_MI_ACAP_ATTR_TYPE_CAPTURE_BUFFER_LEVEL,   ///< Bytes of data which can be read from audio capture buffer, parameter type is a pointer to MI_U32.
    E_MI_ACAP_ATTR_TYPE_MAX,
}MI_ACAP_AttrType_e;

typedef enum
{
    E_MI_ACAP_MUTE_TYPE_BY_USER = 0x0,    ///<Mute by user
    E_MI_ACAP_MUTE_TYPE_MAX,
} MI_ACAP_MuteType_e;

//-------------------------------------------------------------------------------------------------
//  Types - Structures
//-------------------------------------------------------------------------------------------------
typedef struct MI_ACAP_InitParams_s
{
    MI_U8  u8Reserved;                     ///< [IN]: Reserved.
}MI_ACAP_InitParams_t;

typedef struct MI_ACAP_Caps_s
{
    MI_U32 u32CapNum;            ///< [OUT]: Chip capability can support the number of audio capture.
}MI_ACAP_Caps_t;

typedef struct MI_ACAP_BufferInfo_s
{
    MI_U8 *pu8AcapBuf;        /// [OUT]: Buffer of capture data.
    MI_U32 u32AcapBufSize;    /// [OUT]: Data buffer size.
    MI_U64 u64Pts;            /// [OUT]: u64PTS (unit: 90k Hz), MI_INVALID_PTS represent no pts info.
}MI_ACAP_BufferInfo_t;

typedef MI_RESULT (* MI_ACAP_EventCallback)(MI_HANDLE hAcap, MI_U32 u32Event, void *pEventParams, void *pUserParams);
typedef struct MI_ACAP_CallbackInputParams_s
{
    MI_U64 u64CallbackId;                          ///< [IN]: for multi-callback, use 0 for first register or single callback.
    MI_ACAP_EventCallback pfEventCallback;         ///< [IN]: A function pointer for event notifcation, used to notify capture data is ready.
    MI_U32 u32EventFlags;                          ///< [IN]: Bit-wise events defined by MI_ACAP_CallbackEvent_e.
    void *pUserParams;                             ///< [IN]: User parameters for the event callback function.
}MI_ACAP_CallbackInputParams_t;

typedef struct MI_ACAP_CallbackOutputParams_s
{
    MI_U64 u64CallbackId;                         ///< [OUT]: The returned ID for update or unregister callback.
} MI_ACAP_CallbackOutputParams_t;


typedef struct MI_ACAP_OpenParams_s
{
    MI_U8 * pszName;                              ///< [IN]: Custom defined acap name which is a string with zero terminated.
    MI_ACAP_SourceType_e eSourceType;             ///< [IN]: Capture source type.
}MI_ACAP_OpenParams_t;

typedef struct MI_ACAP_StartParams_s
{
    MI_U8  u8Reserved;                     ///< [IN]: Reserved.
}MI_ACAP_StartParams_t;

typedef struct MI_ACAP_QueryHandleParams_s
{
    MI_U8 * pszName;                       ///< [IN]: Query acap handle by finding the custom defined acap name which is a string with zero terminated.
}MI_ACAP_QueryHandleParams_t;

typedef struct MI_ACAP_ConnectInputParams_s
{
    MI_U8  u8Reserved;                     ///< [IN]: Reserved.
}MI_ACAP_ConnectInputParams_t;

typedef struct MI_ACAP_ConnectedConds_s
{
    MI_BOOL bIsInput;                     ///< [IN]: The direction for finding the connected module.
    MI_U32 u32Module;                     ///< [IN]: The module type of connected with ACAP.

    //if need other conditions add here
} MI_ACAP_ConnectedConds_t;

typedef struct MI_ACAP_ReadParams_s
{
    MI_U8 *pu8DataBuf;                      ///< [IN]: Buffer for read data.
    MI_U32 u32BufSize;                      ///< [IN]: Size of data for buffer, unit: byte.
} MI_ACAP_ReadParams_t;

typedef struct MI_ACAP_ReadOutputParams_s
{
    MI_U32 u32ReturnSize;                   ///< [OUT]: Bytes of PCM data successfully read.
    MI_U64 u64Pts;                          ///< [OUT]: Presentation timestamp with 90KHz unit, MI_INVALID_PTS for invalid timestamp
} MI_ACAP_ReadOutputParams_t;

typedef struct MI_ACAP_MuteParams_s
{
    MI_ACAP_MuteType_e eType;               ///< [IN]: Mute type.
    MI_BOOL bMute;                          ///< [IN]: To be mute or unmute.
} MI_ACAP_MuteParams_t;

typedef struct MI_ACAP_VolumeDb_s
{
   MI_S32      s32Integer;          ///< [IN]: Integer part of volume, range from -114 to +12dB
   MI_S32      s32Fraction;         ///< [IN]: Fractional part of volume, 125: 0.125dB resolution:0.125dB
} MI_ACAP_VolumeDb_t;

//-------------------------------------------------------------------------------------------------
//  Functions
//-------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------
/// @brief Init audio capture module.
/// @param[in] pstInitParams.
/// @return MI_OK: Init success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_ACAP_Init(const MI_ACAP_InitParams_t *pstInitParams);

//------------------------------------------------------------------------------
/// @brief Deinit audio capture module.
/// @param[in] none.
/// @return MI_OK: Deinit success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_ACAP_DeInit(void);

//------------------------------------------------------------------------------
/// @brief Open an audio capture handle and audio capture.
/// @param[in] pstOpenParams: Set OpenParams of audio capture(capture source type, acap name, callback function, pass capture data to audio capture or not).
/// @param[out] phAcap: A handle pointer to retrieve an instance of a created audio capture interface.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_ACAP_Open(const MI_ACAP_OpenParams_t *pstOpenParams, MI_HANDLE *phAcap);

//------------------------------------------------------------------------------
/// @brief Close an audio capture handle and audio capture.
/// @param[in] hAcap: An instance of a created audio capture interface.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_ACAP_Close(MI_HANDLE hAcap);

//------------------------------------------------------------------------------
/// @brief Start an audio capture.
/// @param[in] hAcap: Handle of audio capture
/// @param[in] pstStartParams:Reserved parameter.
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE: Invalid aenc handle
/// @return MI_ERR_INVALID_PARAMETER: parameter null
/// @return MI_ERR_FAILED: Process failed
//------------------------------------------------------------------------------
MI_RESULT MI_ACAP_Start(MI_HANDLE hAcap, const MI_ACAP_StartParams_t *pstStartParams);

//------------------------------------------------------------------------------
/// @brief Stop an audio capture.
/// @param[in] hAcap: Handle of audio capture
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process failed
//------------------------------------------------------------------------------
MI_RESULT MI_ACAP_Stop(MI_HANDLE hAcap);

//------------------------------------------------------------------------------
/// @brief Register audio event.
/// @param[in] hAcap: Handle of audio capture
/// @param[in] pstInputParams: Input parameters
/// @param[out] pstOutputParams: Output parameters
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process failed
//------------------------------------------------------------------------------
MI_RESULT MI_ACAP_RegisterCallback(MI_HANDLE hAcap, const MI_ACAP_CallbackInputParams_t *pstInputParams, MI_ACAP_CallbackOutputParams_t *pstOutputParams);

//------------------------------------------------------------------------------
/// @brief UnRegister audio event.
/// @param[in] hAcap: Handle of audio capture
/// @param[in] pstInputParams Input parameters
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process failed
//------------------------------------------------------------------------------
MI_RESULT MI_ACAP_UnRegisterCallback(MI_HANDLE hAcap, const MI_ACAP_CallbackInputParams_t *pstInputParams);

//------------------------------------------------------------------------------
/// @brief Get the attribute of an audio capture.
/// @param[in] hAcap: Handle of audio capture.
/// @param[in] eAttrType: Attribute type of audio capture.
/// @param[in] pInputParam: A void pointer to input parameters of the specific attribute type.
/// @param[out] pOutputParam: A void pointer to retrieve the attribute of the audio capture.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_ACAP_GetAttr(MI_HANDLE hAcap, MI_ACAP_AttrType_e eAttrType, const void *pInputParams, void *pOutputParams);

//------------------------------------------------------------------------------
/// @brief Set the attribute of an audio capture.
/// @param[in] hAcap: Handle of audio capture.
/// @param[in] eAttrType: Attribute type of audio capture.
/// @param[in] pAttrParams: A void pointer to input parameters of the specific attribute type.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_ACAP_SetAttr(MI_HANDLE hAcap, MI_ACAP_AttrType_e eAttrType, const void *pAttrParams);

//------------------------------------------------------------------------------
/// @brief get an audio capture handle with capture device name.
/// @param[in] pstQueryParams: Paramter for querying audio capture handle.
/// @param[out] phAcap: A handle pointer to retrieve an instance of a created audio capture interface.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_ACAP_GetHandle(const MI_ACAP_QueryHandleParams_t *pstQueryParams, MI_HANDLE *phAcap);

//------------------------------------------------------------------------------
/// @brief Get the hardware capability of audio capture.
/// @param[out] pstCaps.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_ACAP_GetCaps(MI_ACAP_Caps_t *pstCaps);

//------------------------------------------------------------------------------
/// @brief Set debug level for mi_acap.c.
/// @param[in] u32DebugLevel. Debug info will be print according to u32DebugLevel.
/// @return MI_OK: Process success.
//------------------------------------------------------------------------------
MI_RESULT MI_ACAP_SetDebugLevel(MI_DBG_LEVEL u32DebugLevel);

//------------------------------------------------------------------------------
/// @brief For acap is a down stream module. Acap connect its input with hInput, i.e. hInput --> hacap
/// @param[in] hAcap: Acap handle
/// @param[in] hInput: Handle of up stream to connect with Acap's input
/// @param[in] pstParams: Pointer to struct MI_ACAP_ConnectInputParams_t to speicified the parameters for acap connect input with hUpHdl
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE: invalid handle.
/// @return MI_ERR_FAILED: Process failed
//------------------------------------------------------------------------------
MI_RESULT MI_ACAP_ConnectInput(MI_HANDLE hAcap, MI_HANDLE hInput, const MI_ACAP_ConnectInputParams_t *pstParams);

//------------------------------------------------------------------------------
/// @brief For acap is a down stream module. Acap disconnect its input hInput, i.e. hInput -X-> hacap
/// @param[in] hAcap: hAcap handle
/// @param[in] hInput: Handle of up stream to connect with acap's input
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE: invalid handle.
/// @return MI_ERR_FAILED: Process failed
//------------------------------------------------------------------------------
MI_RESULT MI_ACAP_DisconnectInput(MI_HANDLE hAcap, MI_HANDLE hInput);

//------------------------------------------------------------------------------
/// @brief Get the element which is connected to the specified element.
/// @param[in] hAcap: Acap handle
/// @param[in] pstAcapConds: bIsinput-The direction for finding the connected module.
///                           u32ModuleType-The module type of connected with ACAP. it defined in mi_common.h with prefix MI_MODULE_TYPE_XXX.
///                                         If it is MI_MODULE_TYPE_NONE it find all type of connected modules.
///                                         e.g. MI_ACAP_GetConnectedNum(hAudio, TRUE, MI_MODULE_TYPE_AUDIO, pu32ConnectedNum)
/// @param[out] pu32ConnectedNum: The number of connected handle
/// @return MI_OK: Process success.
//------------------------------------------------------------------------------
MI_RESULT MI_ACAP_GetConnectedNum(const MI_HANDLE hAcap, const MI_ACAP_ConnectedConds_t *pstAcapConds, MI_U32 *pu32ConnectedNum);

//------------------------------------------------------------------------------
/// @brief Get the element which is connected to the specified element.
/// @param[in] hAcap: Acap handle
/// @param[in] pstAcapConds: bIsinput-The direction for finding the connected module.
///                           u32ModuleType-The module type of connected with ACAP. it defined in mi_common.h with prefix MI_MODULE_TYPE_XXX.
///                                         If it is MI_MODULE_TYPE_NONE it find all type of connected modules.
///                                         e.g. MI_ACAP_GetConnected(hAudio, TRUE, MI_MODULE_TYPE_AUDIO, u32ConnectedNum, phConnectedArray)
/// @param[in] u32ConnectedNum: The number of get handle
/// @param[out] phConnectedArray: Pointer to handle buffer to retrieve the handle of MI module which is connected to the specified element with the specified direction.
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_FAILED: Process fail, no connection is available.
//------------------------------------------------------------------------------
MI_RESULT MI_ACAP_GetConnected(const MI_HANDLE hAcap, const MI_ACAP_ConnectedConds_t *pstAcapConds, const MI_U32 u32ConnectedNum, MI_HANDLE *phConnectedArray);

//------------------------------------------------------------------------------
/// @brief Read the data from audio capture buffer.
/// @param[in] hAcap: ACAP handle
/// @param[in] pstReadParams: Input parameter for reading.
/// @param[out] pstOutputParams: Output parameter for reading.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_ACAP_Read(MI_HANDLE hAcap, const MI_ACAP_ReadParams_t *pstReadParams, MI_ACAP_ReadOutputParams_t *pstOutputParams);

//------------------------------------------------------------------------------
/// @brief Set mute.
/// @param[in] hAcap: Handle of audio capture
/// @param[in] *pstMuteParams. Mute paramters,including mute type and mute status.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_ACAP_SetMute(MI_HANDLE hAcap, const MI_ACAP_MuteParams_t *pstMuteParams);
//------------------------------------------------------------------------------
/// @brief Get mute status.
/// @param[in] hAcap: Handle of audio capture
/// @param[out] *pstMuteParams. Mute paramters,including mute type and mute status.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_ACAP_GetMute(MI_HANDLE hAcap, MI_ACAP_MuteParams_t *pstMuteParams);
//------------------------------------------------------------------------------
/// @brief Set volume, 0~100.
/// @param[in] hAcap: Handle of audio capture
/// @param[in] u8Volume. Value of volume.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_ACAP_SetVolume(MI_HANDLE hAcap, const MI_U8 u8Volume);
//------------------------------------------------------------------------------
/// @brief Get volume.
/// @param[in] hAcap: Handle of audio capture
/// @param[out] *pu8Volume. Output the value of volume.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_ACAP_GetVolume(MI_HANDLE hAcap, MI_U8 *pu8Volume);
//------------------------------------------------------------------------------
/// @brief Set volume by dB, support -114dB~+12dB.
/// @param[in] hAcap: Handle of audio capture
/// @param[in] *pstVolumeDb : Gain index range from -114*8 ~ +12*8 (-114dB~+12db) ; 0.125dB/step.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_ACAP_SetVolumeDb(MI_HANDLE hAcap,const MI_ACAP_VolumeDb_t *pstVolumeDb);
//------------------------------------------------------------------------------
/// @brief Get volume by dB, support -114dB~+12dB.
/// @param[in] hAcap: Handle of audio capture
/// @param[out] *pstVolumeDb: Gain index range from -114*8 ~ +12*8 (-114dB~+12db) ; 0.125dB/step.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_ACAP_GetVolumeDb(MI_HANDLE hAcap, MI_ACAP_VolumeDb_t *pstVolumeDb);
//------------------------------------------------------------------------------

#ifdef __cplusplus
}
#endif

#endif ///_MI_ACAP_H_
