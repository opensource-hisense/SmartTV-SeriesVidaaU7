/*------------------------------------------------------------------------------
 * MediaTek Inc. (C) 2018. All rights reserved.
 *
 * Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 *----------------------------------------------------------------------------*/
//------------------------------------------------------------------------------
// Use GetAttr/SetAttr only
//------------------------------------------------------------------------------

#ifndef _MI_PCM_H_
#define _MI_PCM_H_

#ifdef __cplusplus
extern "C" {
#endif

//-------------------------------------------------------------------------------------------------
//  Defines
//-------------------------------------------------------------------------------------------------
#define MI_PCM_CHANNEL_MAPPING_MAX_NUM         10

typedef enum
{
    E_MI_PCM_EASE_TYPE_LINEAR = 0x0,         //ease linear type
    E_MI_PCM_EASE_TYPE_IN_CUBIC,             //ease in-cubic type
    E_MI_PCM_EASE_TYPE_OUT_CUBIC,            //ease out-cubic type
    E_MI_PCM_EASE_TYPE_IN_OUT_CUBIC,         //ease inout-cubic type
} MI_PCM_EaseType_e;

typedef enum
{
    E_MI_PCM_EASE_TARGET_SELF = 0,        //ease active to own device
    E_MI_PCM_EASE_TARGET_OTHERS,          //ease active to others device
}MI_PCM_EaseTarget_e;

typedef enum
{
    E_MI_PCM_FLAG_TYPE_NONE          = 0x0,
    E_MI_PCM_FLAG_TYPE_END_OF_STREAM = 0x1,
    E_MI_PCM_FLAG_TYPE_METADATA_EXIST= 0x2,
} MI_PCM_FlagType_e;

typedef enum
{
    E_MI_PCM_RENDER_SOURCE_MODE_AUTO           = 0x0,
    E_MI_PCM_RENDER_SOURCE_MODE_STEREO,
    E_MI_PCM_RENDER_SOURCE_MODE_MULTI_CHANNEL,
} MI_PCM_RenderSourceMode_e;

typedef enum
{
    //Audio pcm device status
    E_MI_PCM_ATTR_TYPE_STATUS_MIN = 0,
    ///< Get the information of PCM buffer, inputParams is a pointer to NULL, and outputParams is a pointer to to MI_PCM_BufferInfo_t.
    E_MI_PCM_ATTR_TYPE_BUFFER_INFO = E_MI_PCM_ATTR_TYPE_STATUS_MIN,
    ///< Get the time stamps of pcm data by unit 90kHz, inputParams is a pointer to NULL, and outputParams is a pointer to MI_U64.
    E_MI_PCM_ATTR_TYPE_PTS,
    //Audio pcm device status
    E_MI_PCM_ATTR_TYPE_STATUS_MAX,

    //Audio pcm device attribute
    E_MI_PCM_ATTR_TYPE_INPUT_SETTING_MIN = 0x100,
    //Set pcm device render output mode, inputParams is a pointer to to MI_PCM_RenderSourceMode_e.
    E_MI_PCM_ATTR_TYPE_RENDER_SOURCE_MODE = E_MI_PCM_ATTR_TYPE_INPUT_SETTING_MIN,
    //Audio pcm device attribute Max
    E_MI_PCM_ATTR_TYPE_INPUT_SETTING_MAX,

    //Audio pcm device output setting Min
    E_MI_PCM_ATTR_TYPE_OUTPUT_SETTING_MIN = 0x1000,
    ///< Set mute of PCM device, intput parameter type is a pointer to MI_PCM_MultiMuteParams_t.
    E_MI_PCM_ATTR_TYPE_MULTI_MUTE = E_MI_PCM_ATTR_TYPE_OUTPUT_SETTING_MIN,
    ///< Set the volume of PCM device, intput parameter type is a pointer to MI_U8. (Maximum volume is 100).
    E_MI_PCM_ATTR_TYPE_VOLUME,
    ///< Set the volume of PCM device by DB, intput parameter type is a pointer to MI_PCM_VolumeDb_t.
    E_MI_PCM_ATTR_TYPE_VOLUME_DB,
    ///< Set the volume table of PCM device, intput parameter type is a pointer to array which size is 101.
    E_MI_PCM_ATTR_TYPE_VOLUME_TABLE,
    ///< Set the delay of PCM device, intput parameter type is a pointer to to MI_U32.
    E_MI_PCM_ATTR_TYPE_OUTPUT_DELAY,
    ///< Set or get the ease effect of Pcm channel, input parameter type is a pointer to MI_PCM_EaseParams_t(set) or a pointer to NULL(get).
    E_MI_PCM_ATTR_TYPE_EASE,
    //Audio pcm device output setting Max
    E_MI_PCM_ATTR_TYPE_OUTPUT_SETTING_MAX,
    //Audio pcm device attribute Max
    E_MI_PCM_ATTR_TYPE_MAX,
} MI_PCM_AttrType_e;

///decoder channel mapping definition
///reference from android define
typedef enum
{
    E_MI_PCM_CHANNEL_MAPPING_NONE                  = 0x00,

    E_MI_PCM_CHANNEL_MAPPING_FRONT_LEFT            = 0x1,
    E_MI_PCM_CHANNEL_MAPPING_FRONT_RIGHT           = 0x2,
    E_MI_PCM_CHANNEL_MAPPING_FRONT_CENTER          = 0x4,
    E_MI_PCM_CHANNEL_MAPPING_LOW_FREQUENCY         = 0x8,
    E_MI_PCM_CHANNEL_MAPPING_BACK_LEFT             = 0x10,
    E_MI_PCM_CHANNEL_MAPPING_BACK_RIGHT            = 0x20,
    E_MI_PCM_CHANNEL_MAPPING_BACK_CENTER           = 0x40,
    E_MI_PCM_CHANNEL_MAPPING_SIDE_LEFT             = 0x80,
    E_MI_PCM_CHANNEL_MAPPING_SIDE_RIGHT            = 0x100,
    E_MI_PCM_CHANNEL_MAPPING_TOP_FRONT_LEFT        = 0x200,
    E_MI_PCM_CHANNEL_MAPPING_TOP_FRONT_RIGHT       = 0x400,
    E_MI_PCM_CHANNEL_MAPPING_TOP_BACK_LEFT         = 0x800,
    E_MI_PCM_CHANNEL_MAPPING_TOP_BACK_RIGHT        = 0x1000,

} MI_PCM_ChannelMappingType_e;

//-------------------------------------------------------------------------------------------------
//  Structures
//-------------------------------------------------------------------------------------------------
typedef struct MI_PCM_InitParams_s
{
    MI_U8 u8Reserved;           ///< [IN]:Reserved
} MI_PCM_InitParams_t;

typedef struct MI_PCM_Format_s
{
    MI_U32  u32SampleRate;      ///< [IN]: Sampling rate, 48000(48KHz), 44100(44.1KHz), 32000(32KHz),....
    MI_U8   u8Channels;         ///< [IN]: Channels, 1(mono), 2(stereo),...
    MI_U8   u8BitsPerSample;    ///< [IN]: Bits Per Sample, 8(bits), 16(bits), 24(bits),...
    MI_BOOL bBigEndian;         ///< [IN]: PCM endian, TRUE: Big Endian, FALSE: Little Endian.
} MI_PCM_Format_t;

typedef struct MI_PCM_OpenParams_s
{
    MI_U8   *pszName;                   ///< [IN]: Custom defined pcm name which is a string with zero terminated.
    MI_BOOL bBlocking;                  ///< [IN]: blocking mode True: blocking mode FALSE:non blocking mode
    MI_BOOL bMixing;                    ///< [IN]: mixing mode  True: mixing  False: unmixing mode
    MI_PCM_Format_t stPcmFormat;        ///< [IN]: PCM format
    MI_U32  au32ChannelMapping[MI_PCM_CHANNEL_MAPPING_MAX_NUM];     ///< [IN]: PCM Channel Mapping: fill MI_PCM_ChannelMappingType_e need, fill E_MI_PCM_CHANNEL_MAPPING_NONE noneed
    MI_BOOL bBufferDurationControl;     ///< [IN] PCM buffer duration can be configure or not.
    MI_U32 u32BufferDuration;           ///< [IN]: PCM buffer duration. Unit is ms. Default is 100 ms.
} MI_PCM_OpenParams_t;

typedef struct MI_PCM_StartParams_s
{
    MI_U8 u8Reserved;            ///< [IN]: <Reserved
} MI_PCM_StartParams_t;

typedef struct MI_PCM_WriteParams_s
{
    MI_U8   *pu8DataBuf;      ///< [IN]: Data buffer for pcm
    MI_U32  u32BufSize;          ///< [IN]: Size of data for buffer,unit: byte
    MI_U64  u64Pts;              ///< [IN]: Presentation timestamp with 90KHz unit, MI_INVALID_PTS for invalid timestamp
    MI_U64  u64StreamFlag;       ///< [IN]: Stream flag, indicate the infomation of data in this buffer.information refer to MI_PCM_FlagType_e
    MI_U64  u64MetadataIndex;    ///< [IN]: Index for extra data, indicate metadata.
} MI_PCM_WriteParams_t;

typedef struct MI_PCM_WriteOutputParams_s
{
    MI_U32  u32ReturnSize;       ///< [OUT]Return Size of data.Valid written or read data size.
} MI_PCM_WriteOutputParams_t;

typedef struct MI_PCM_VolumeDb_s
{
   MI_S32      s32Integer;          ///< [IN]: Integer part of volume, range from -114 to +12dB
   MI_S32      s32Fraction;         ///< [IN]: Fractional part of volume, 125: 0.125dB resolution:0.125dB
} MI_PCM_VolumeDb_t;

typedef struct MI_PCM_MultiMuteParams_s
{
    MI_U8   *pszMuteName;               ///< [IN]: Set Mute Event name.eg: "tts mute". Max length of name size: 64.
    MI_BOOL bMute;                      ///< [IN]: True: Mute; False Unmute;
    MI_U32  u32AutoUnmuteTimer;         ///< [IN]: Auto unmute audio in a period of millisecond. 0 is disable auto unmute.
} MI_PCM_MultiMuteParams_t;

typedef struct MI_PCM_BufferInfo_s
{
   MI_U32      u32MaxBufferSize;        ///< [OUT]: Return the max buffer size.
   MI_U32      u32Level;                ///< [OUT]: Return the level of buffer.
   MI_U32      u32FreeSize;             ///< [OUT]: Return the free size of buffer.
} MI_PCM_BufferInfo_t;

typedef struct MI_PCM_EaseParams_s
{
    MI_PCM_EaseTarget_e        eTarget;            ///< [IN]: Easing target, player self or other sounds.
    MI_PCM_EaseType_e          eType;              ///< [IN]: a type of curve ,eg linear ,in-cubic ,out-cubic,in-out-cubic,both used in get or set.
    MI_U16                     u16Duration;        ///< [IN]: duration time of fade-in or fade-out. unit: minisecond,both used in get or set.
    MI_U16                     u16Scale;           ///< [IN]: Scale value, range from 0 to 100,both used in  get or set.
} MI_PCM_EaseParams_t;

//-------------------------------------------------------------------------------------------------
//  Global Functions
//-------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------
/// @brief Init Pcm module.
/// @param[in] pstInitParams.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_PCM_Init(const MI_PCM_InitParams_t *pstInitParams);
//------------------------------------------------------------------------------
/// @brief Deinit Pcm module.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_PCM_DeInit(void);
//------------------------------------------------------------------------------
/// @brief Open a Pcm handle.
/// @param[in] pstOpenParams.
/// @param[out] *phPcm.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_RESOURCES: No available resource.
//------------------------------------------------------------------------------
MI_RESULT MI_PCM_Open(const MI_PCM_OpenParams_t *pstOpenParams, MI_HANDLE *phPcm);
//------------------------------------------------------------------------------
/// @brief Close a Pcm handle.
/// @param[in] hPcm.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_PCM_Close(MI_HANDLE hPcm);
//------------------------------------------------------------------------------
/// @brief Start Pcm device.
/// @param[in] hPcm.
/// @param[in] *pstStartParams.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_PCM_Start(MI_HANDLE hPcm,  const MI_PCM_StartParams_t *pstStartParams);
//------------------------------------------------------------------------------
/// @brief Stop Pcm device.
/// @param[in] hPcm.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_PCM_Stop(MI_HANDLE hPcm);
//------------------------------------------------------------------------------
/// @brief Pause Pcm device.
/// @param[in] hPcm.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_PCM_Pause(MI_HANDLE hPcm);
//------------------------------------------------------------------------------
/// @brief Resume Pcm device.
/// @param[in] hPcm.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_PCM_Resume(MI_HANDLE hPcm);
//------------------------------------------------------------------------------
/// @brief Write pcm data to pcm device.
/// @param[in] hPcm.
/// @param[in] *pstWriteParams.
/// @param[out] *pstOutputParams u32BufSize will fill the valid size when function return failed.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_PCM_Write(MI_HANDLE hPcm, const MI_PCM_WriteParams_t *pstWriteParams, MI_PCM_WriteOutputParams_t *pstOutputParams);
//------------------------------------------------------------------------------
/// @brief Flush the data in pcm device.
/// @param[in] hPcm.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_PCM_Clear(MI_HANDLE hPcm);
//------------------------------------------------------------------------------
/// @brief Get Pcm attribute.
/// @param[in] hPcm.
/// @param[in] eAttrType.
/// @param[in] *pInputParams.
/// @param[out] *pOutputParams.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_PCM_GetAttr(MI_HANDLE hPcm, MI_PCM_AttrType_e eAttrType, const void *pInputParams, void *pOutputParams);
//------------------------------------------------------------------------------
/// @brief Set Pcm attribute.
/// @param[in] hPcm.
/// @param[in] eAttrType.
/// @param[in] *pAttrParams.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_PCM_SetAttr(MI_HANDLE hPcm, MI_PCM_AttrType_e eAttrType, const void *pAttrParams);
//------------------------------------------------------------------------------
/// @brief Set debug level for mi_pcm.c.
/// @param[in] u32DebugLevel.
/// @return MI_OK: Process success.
//------------------------------------------------------------------------------
MI_RESULT MI_PCM_SetDebugLevel(MI_DBG_LEVEL u32DebugLevel);
//------------------------------------------------------------------------------

#ifdef __cplusplus
}
#endif

#endif///_MI_PCM_H_
