/*------------------------------------------------------------------------------
 * MediaTek Inc. (C) 2018. All rights reserved.
 *
 * Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 *----------------------------------------------------------------------------*/
//----------------------------------------------------------------------------------------
//Use GetAttr/SetAttr only
//----------------------------------------------------------------------------------------


#ifndef _MI_VMON_H_
#define _MI_VMON_H_

#ifdef __cplusplus
extern "C" {
#endif

/// Define callback function type.
typedef MI_RESULT(* MI_VMON_EventCallback)(MI_HANDLE hVmon, MI_U32 u32Event, void *pEventParams, void *pUserParams);

/// Parameter type
typedef enum
{
    ///Set/Get Attr Min
    E_MI_VMON_ATTR_TYPE_MIN = 0,
    ///Set/ Get mute type, parameter type is a pointer to MI_VMON_MuteType_e.
    E_MI_VMON_ATTR_TYPE_MUTE_TYPE = E_MI_VMON_ATTR_TYPE_MIN,
    ///Set/ Get display mode, parameter type is a pointer to MI_VMON_DispMode_e.
    E_MI_VMON_ATTR_TYPE_DISP_MODE,
    ///Set/ Get DS mode, parameter type is a pointer to MI_VMON_DsMode_e.
    E_MI_VMON_ATTR_TYPE_DS_MODE,
    ///Set/ Get reach sync timeout with unit ms., parameter type is a pointer to MI_U32.
    E_MI_VMON_ATTR_TYPE_REACH_SYNC_TIMEOUT,
    ///Set/Get Attr Max
    E_MI_VMON_ATTR_TYPE_MAX,

    ///Get Attr Min
    E_MI_VMON_ATTR_TYPE_GET_MIN = 0x100,
    ///Get decode frame ready, parameter type is a pointer to MI_BOOL.
    E_MI_VMON_ATTR_TYPE_GET_FRAMERDY = E_MI_VMON_ATTR_TYPE_GET_MIN,
    ///Get Attr Max
    E_MI_VMON_ATTR_TYPE_GET_MAX,

    ///Set Attr Min
    E_MI_VMON_ATTR_TYPE_SET_MIN = 0x200,
    ///Set AV sync info, parameter type is a pointer to MI_U32.
    E_MI_VMON_ATTR_TYPE_AVSYNC_INFO = E_MI_VMON_ATTR_TYPE_SET_MIN,
    ///Set Attr Max
    E_MI_VMON_ATTR_TYPE_SET_MAX,

} MI_VMON_AttrType_e;

/// VMon mute type
typedef enum
{
    ///Mute by video blank
    E_MI_VMON_MUTE_BLANK = 0,
    ///Mute by still image
    E_MI_VMON_MUTE_SEAMLESS,
    ///Mute by manual
    E_MI_VMON_MUTE_MANUALLY
} MI_VMON_MuteType_e;

/// Un-blank AV sync display mode
typedef enum
{
    ///Un-blank until av sync
    E_MI_VMON_DISP_UNTIL_SYNC = 0,
    ///Slow motion with slow sync
    E_MI_VMON_DISP_SLOW_MOTION,
    ///Show first frame
    E_MI_VMON_DISP_FIRST_FRAME
} MI_VMON_DispMode_e;


/// DS mode
typedef enum
{
    //Do nothing
    E_MI_VMON_DS_OFF = 0,
    //Enable DS Flow
    E_MI_VMON_DS_ON,
} MI_VMON_DsMode_e;


/// Define Vidoe related event
typedef enum
{
    ///Start done event
    E_MI_VMON_CALLBACK_EVENT_VIDEO_ON = MI_BIT(0),
    ///Video mute request
    E_MI_VMON_CALLBACK_EVENT_VIDEO_OFF = MI_BIT(1),
    ///Video frame buffer is not enough
    E_MI_VMON_CALLBACK_EVENT_VIDEO_NOT_ENOUGH_FRAME_BUFFER = MI_BIT(16),
    ///Video not supported resolution
    E_MI_VMON_CALLBACK_EVENT_VIDEO_NOT_SUPPORT_RESOLUTION = MI_BIT(17),
    ///Video fatal error and need to restart video.
    E_MI_VMON_CALLBACK_EVENT_VIDEO_FATAL_ERROR = MI_BIT(18),
    ///Event number
    E_MI_VMON_CALLBACK_EVENT_ALL            = 0xFFFFFFFF
} MI_VMON_CallbackEvent_e;

typedef enum
{
    E_MI_VMON_FZ_SIGNAL_VIDEO_DECODER_READY = (1<<0),       ///< signal that video decoder is ready for decoding
    E_MI_VMON_FZ_SIGNAL_VIDEO_DEMUX_READY   = (1<<1),       ///< signal that video dmx filter is ready for receiving
    E_MI_VMON_FZ_SIGNAL_VIDEO_CA_KEY_READY  = (1<<2),       ///< signal that video CA's control word  is ready for descrambling
} MI_VMON_FastZapSignal_e;

/// Video init parameter
typedef struct MI_VMON_InitParams_s
{
    ///Reserved
    MI_U8 u8Reserved;
} MI_VMON_InitParams_t;

/// Callback function Input parameter struct.
typedef struct MI_VMON_CallbackInputParams_s
{
    ///[IN]: for multi-callback, use 0 for first register or single callback.
    MI_U64 u64CallbackId;
    ///[IN]: Callback function pointer.
    MI_VMON_EventCallback pfEventCallback;
        ///[IN]: Event flags defined by MI_VMON_CallbackEvent_e
    MI_U32 u32EventFlags;
    ///[IN]: User parameter
    void *pUserParams;
} MI_VMON_CallbackInputParams_t;

/// Callback function output parameter struct.
typedef struct MI_VMON_CallbackOutputParams_s
{
    ///[OUT]: for multi-callback, use 0 for first register or single callback.
    MI_U64 u64CallbackId;
} MI_VMON_CallbackOutputParams_t;

typedef struct MI_VMON_OpenParams_s
{
    MI_U8 *pszName;             ///[IN]: Vmon handle with string name, mi_vmon string name must as same as mi_video's.
}MI_VMON_OpenParams_t;

/// Vmon Query Handle Parameters
/// video handle > string name
typedef struct MI_VMON_QueryHandleParams_s
{
    MI_U8 *pszName;             ///[IN]: Vmon handle with string name, mi_vmon string name must as same as mi_video's.
    MI_HANDLE hVideo;           ///[IN]: Video handle has precedence over string name, since string name can be null.
}MI_VMON_QueryHandleParams_t;

/// Vmon start parameters
typedef struct MI_VMON_StartParams_s
{
    /// reserve
    MI_U8 u8Reserved;
}MI_VMON_StartParams_t;

//-------------------------------------------------------------------------------------------------
//  Global Functions
//-------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------
/// @brief VMON system initial
/// @param[in] pstInitParams VMON init parameter
/// @return MI_OK: Process success.
/// @return MI_HAS_INITED: VMon re-init
/// @return MI_ERR_FAILED: VMon control failed
//------------------------------------------------------------------------------
MI_RESULT MI_VMON_Init(const MI_VMON_InitParams_t *pstInitParams);

//------------------------------------------------------------------------------
/// @brief Video De-init
/// @param[in] None
/// @return MI_OK: Process success.
//------------------------------------------------------------------------------
MI_RESULT MI_VMON_DeInit(void);

//------------------------------------------------------------------------------
/// @brief Open Vmon handler
/// @param[in] pstOpenParams:open parameter
/// @param[out] *phVmon video path handler
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process failed
/// @return MI_ERR_INVALID_HANDLE: Null handle
/// @return MI_ERR_INVALID_PARAMETER: Null parameter
//------------------------------------------------------------------------------
MI_RESULT MI_VMON_Open(const MI_VMON_OpenParams_t *pstOpenParams, MI_HANDLE *phVmon);


//------------------------------------------------------------------------------
/// @brief Close vmon handler
/// @param[in] hVmon vmon path handler
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Get handle failed
/// @return MI_ERR_INVALID_PARAMETER: Invalid parameter
//------------------------------------------------------------------------------
MI_RESULT MI_VMON_Close(MI_HANDLE hVmon);

//------------------------------------------------------------------------------
/// @brief Get Vmon handler
/// @param[in] pstQueryParams Query params
/// @param[out] *phVmon vmon path handler
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Get handle failed
/// @return MI_ERR_INVALID_PARAMETER: Invalid parameter
//------------------------------------------------------------------------------
MI_RESULT MI_VMON_GetHandle(const MI_VMON_QueryHandleParams_t *pstQueryParams, MI_HANDLE *phVmon);


//------------------------------------------------------------------------------
/// @brief VMon start
/// @param[in] hVmon VMon handle
/// @param[in] pstStartParams vmon start params
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: VMon module is not inited
/// @return MI_ERR_INVALID_HANDLE: Invalid vmon handle
/// @return MI_ERR_FAILED: Process failed
//------------------------------------------------------------------------------
MI_RESULT MI_VMON_Start(MI_HANDLE hVmon, const MI_VMON_StartParams_t *pstStartParams);


//------------------------------------------------------------------------------
/// @brief Video stop
/// @param[in] hVmon VMon handle
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: VMon module is not inited
/// @return MI_ERR_INVALID_HANDLE: Invalid vmon handle
/// @return MI_ERR_FAILED: Process failed
//------------------------------------------------------------------------------
MI_RESULT MI_VMON_Stop(MI_HANDLE hVmon);

//------------------------------------------------------------------------------
/// @brief Register VMon notify event
/// @param[in] hVmon VMon handle
/// @param[in] pstInputParams: Struce pointer for register callback event
/// @param[out] pstOutputParams: Struce pointer for register callback event
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: VMon module is not inited
/// @return MI_ERR_INVALID_HANDLE: Invalid vmon handle
/// @return MI_HAS_INITED: Re-register call back event
//------------------------------------------------------------------------------
MI_RESULT MI_VMON_RegisterCallback(MI_HANDLE hVmon, const MI_VMON_CallbackInputParams_t *pstInputParams, MI_VMON_CallbackOutputParams_t *pstOutputParams);

//------------------------------------------------------------------------------
/// @brief Unregister VMon notify event
/// @param[in] hVmon VMon handle
/// @param[in] pstInputParams to unregister
/// @return MI_OK: un-register vmon event
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: VMon module is not inited
/// @return MI_ERR_INVALID_HANDLE: Invalid vmon handle
//------------------------------------------------------------------------------
MI_RESULT MI_VMON_UnRegisterCallback(MI_HANDLE hVmon, const MI_VMON_CallbackInputParams_t *pstInputParams);

//------------------------------------------------------------------------------
/// @brief set vmon attribute
/// @param[in] hVmon VMon handle
/// @param[in] eAttrType attribute type
/// @param[in] pAttrParams A pointer to set attribute corresponding to the eAttrType. The prototype of pAttrParams plz see the description of enum MI_VMON_AtteType_e
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: VMon module is not inited
/// @return MI_ERR_INVALID_HANDLE: Invalid vmon handle
/// @return MI_ERR_FAILED: Process failed
//------------------------------------------------------------------------------
MI_RESULT MI_VMON_SetAttr(MI_HANDLE hVmon, MI_VMON_AttrType_e eAttrType, const void *pAttrParams);

//------------------------------------------------------------------------------
/// @brief Get vmon attribute
/// @param[in] hVmon VMon handle
/// @param[in] eAttrType attribute type
/// @param[in] pInputParams Input Params
/// @param[out] pOutputParams A pointer to get attribute corresponding to the eAttrType. The prototype of pOutputParams plz see the description of enum MI_VMON_AtteType_e
/// @return MI_OK: Get vmon attribute success
/// @return MI_ERR_NOT_INITED: VMon module is not inited
/// @return MI_ERR_INVALID_HANDLE: Invalid vmon handle
/// @return MI_ERR_FAILED: Get vmon attribute failed
//------------------------------------------------------------------------------
MI_RESULT MI_VMON_GetAttr(MI_HANDLE hVmon, MI_VMON_AttrType_e eAttrType, const void *pInputParams, void *pOutputParams);

//------------------------------------------------------------------------------
/// @brief Set video debug level.
/// @param[in] hVMon Video Monitor handle
/// @param[in] u32DebugLevel.
/// @return MI_OK: Set debug level success.
//------------------------------------------------------------------------------
MI_RESULT MI_VMON_SetDebugLevel(MI_DBG_LEVEL u32DebugLevel);

//------------------------------------------------------------------------------
/// @brief Send Fast Zapping Signal event to video monitor.
/// @param[in] hVMon Video Monitor handle
/// @param[in] eFzSignal Signal event.
/// @return MI_OK: Succeeded to sending signal.
/// @return MI_ERR_FAILED: Failed to send signal.
//------------------------------------------------------------------------------
MI_RESULT MI_VMON_SendFastZapSignal(MI_HANDLE hVMon, MI_VMON_FastZapSignal_e eFzSignal);

//------------------------------------------------------------------------------
/// @brief Clear Fast Zapping Signal event
/// @param[in] hVMon Video Monitor handle
/// @param[in] eFzSignal Signal event to be clear.
/// @return MI_OK: Succeeded to clear signal
/// @return MI_ERR_FAILED: Failed to clear signal.
//------------------------------------------------------------------------------
MI_RESULT MI_VMON_ClearFastZapSignal(MI_HANDLE hVMon, MI_VMON_FastZapSignal_e eFzSignal);

//------------------------------------------------------------------------------
/// @brief Enable Fast Zapping functional. Depends on CHIP's capabilities.
/// @param[in] bEnable Enable or Disable fast zapping.
/// @return MI_OK: Get Enalbe fast zapping succeeded
/// @return MI_ERR_NOT_SUPPORT: CHIP doesn't support this functional.
/// @return MI_ERR_FAILED: Failed to enable fast zapping functional.
//------------------------------------------------------------------------------
MI_RESULT MI_VMON_EnableFastZap(MI_BOOL bEnable);

#ifdef __cplusplus
}
#endif

#endif///_MI_VMON_H_
