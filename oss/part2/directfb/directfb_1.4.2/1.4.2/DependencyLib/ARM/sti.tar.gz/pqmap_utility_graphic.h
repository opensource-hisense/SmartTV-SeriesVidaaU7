////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2020-2024 MediaTek Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MediaTek Inc. and be kept in strict confidence
// ("MediaTek Confidential Information") by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MediaTek Confidential
// Information is unlawful and strictly prohibited. MediaTek hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////


///////////////////////////////////////////////////////////////////////////////////////////////////
///
/// @file   pqmap_utility_graphic.h
/// @brief  Algorithem Driver Interface
/// @author Mediatek Inc.
///
///////////////////////////////////////////////////////////////////////////////////////////////////

#ifndef _PQMAP_UTILITY_GRAPHIC_H_
#define _PQMAP_UTILITY_GRAPHIC_H_
#ifdef __cplusplus
extern "C"{
#endif

//----------------------------------------------------------------------------
//  Driver Capability
//----------------------------------------------------------------------------

//----------------------------------------------------------------------------
//  Macro and Define
//----------------------------------------------------------------------------

//----------------------------------------------------------------------------
//  Type and Structure
//----------------------------------------------------------------------------
typedef enum presetdb_range {
	RANGE_AUTO = 0,
	RANGE_LIMIT = 1,
	RANGE_FULL = 2,
	RANGE_MAX = 0xff
}presetdb_range;

typedef enum presetdb_colorspace {
	COLORSPACE_AUTO = 0,
	COLORSPACE_BT601 = 1,
	COLORSPACE_BT709 = 2,
	COLORSPACE_BT2020 = 3,
	COLORSPACE_MAX = 0xff
}presetdb_colorspace;


typedef enum presetdb_format {
	FORMAT_AUTO = 0,
	FORMAT_RGB = 1,
	FORMAT_YUV = 2,
	FORMAT_MAX = 0xff
}presetdb_format;

typedef struct presetdb_io {
	presetdb_range range;
	presetdb_colorspace colorspace;
	presetdb_format format;
}presetdb_io;

typedef struct presetdb_hdr_mode {
	char xvycc_manual_mode;
	char eotf_enable;
	char oetf_enable;
	char eotf_ext_mode;
	char oetf_ext_mode;
	char gamut_manual_mode;
	char gamut_enable;
	uint64_t user_gain;
}presetdb_hdr_mode;

typedef struct presetdb_rgb_offset {
	char manual_mode;
	char enable;
}presetdb_rgb_offset;

typedef struct presetdb_rgb_clipping {
	char manual_mode;
	char enable;
}presetdb_rgb_clipping;

typedef struct graphic_presetdb_info {
	presetdb_io input;
	presetdb_io output;
	uint64_t hue;
	uint64_t saturation;
	uint64_t contrast;
	presetdb_hdr_mode sdr;
	presetdb_hdr_mode hdr10;
	presetdb_hdr_mode hlg;
	presetdb_rgb_offset rgb_offset;
	presetdb_rgb_clipping rgb_clipping;
} graphic_presetdb_info;

//----------------------------------------------------------------------------
//  Function and Variable
//----------------------------------------------------------------------------
char pqmap_graphic_presetdb_parse(void *json_node, graphic_presetdb_info* info);

#ifdef __cplusplus
}
#endif
#endif // _PQMAP_UTILITY_GRAPHIC_H_