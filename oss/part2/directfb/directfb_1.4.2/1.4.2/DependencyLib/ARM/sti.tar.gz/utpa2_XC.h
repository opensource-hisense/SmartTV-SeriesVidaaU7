/*
 * Copyright (c) [2020], MediaTek Inc. All rights reserved.
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws.
 * The information contained herein is confidential and proprietary to
 * MediaTek Inc. and/or its licensors.
 * Except as otherwise provided in the applicable licensing terms with
 * MediaTek Inc. and/or its licensors, any reproduction, modification, use or
 * disclosure of MediaTek Software, and information contained herein, in whole
 * or in part, shall be strictly prohibited.
*/

//-------------------------------------------------
/*! \defgroup XC TEE modules
  */
//-------------------------------------------------

#ifndef __XC_TEE_H__
#define __XC_TEE_H__

#ifndef __MSOS_TYPES_H__ //remove after srrcap remove msos_types.h
#include "utpa2_Types.h"
#endif

#ifdef __cplusplus
extern "C"
{
#endif

//-------------------------------------------------------------------------------------------------
//  Macro and Define
//-------------------------------------------------------------------------------------------------
#define XC_STI_OPTEE_HANDLER_VERSION                   (2)

//-------------------------------------------------------------------------------------------------
//  Type and Structure
//-------------------------------------------------------------------------------------------------
typedef enum
{
    E_XC_OPTEE_GET_PIPE_ID = 0,
    E_XC_OPTEE_ENABLE,
    E_XC_OPTEE_DISABLE,
    E_XC_OPTEE_SET_HANDLER,
    E_XC_OPTEE_SYNC_HANDLER,
    E_XC_OPTEE_GET_HANDLER,
    E_XC_OPTEE_UPDATE_HANDLER,
    E_XC_OPTEE_SET_MUX,
    E_XC_OPTEE_SYNC_MUX,
    E_XC_OPTEE_GET_MUX,
    E_XC_OPTEE_SET_PIPEID,
    E_XC_OPTEE_GET_VERSION,
    E_XC_OPTEE_GET_SECURE_INPUT,
    E_XC_OPTEE_SET_SECURE_INPUT,
    E_XC_OPTEE_CONFIG_INPUT_PIPE,
    E_XC_OPTEE_SET_VIDEO_PIPELINE,
    E_XC_OPTEE_UNSET_VIDEO_PIPELINE,
    E_XC_OPTEE_SET_POLICY,
    E_XC_OPTEE_UNSET_POLICY,

    //Mapping to STI enum mtk_pq_tee_action & enum srccap_ca_tee_action
    E_XC_OPTEE_CREATE_VIDEO_PIPELINE = 100,
    E_XC_OPTEE_DESTROY_VIDEO_PIPELINE,
    E_XC_OPTEE_CREATE_DISP_PIPELINE,
    E_XC_OPTEE_DESTROY_DISP_PIPELINE,
    E_XC_OPTEE_CREATE_COMP_PIPELINE,
    E_XC_OPTEE_DESTROY_COMP_PIPELINE,
    E_XC_OPTEE_WRITE_PROTECTED_REG,
    E_XC_OPTEE_TEST_DRIVERS,
    E_XC_OPTEE_SET_IPCAP_WIN,
    E_XC_OPTEE_CREATE_DV_PIPELINE,
    E_XC_OPTEE_DESTROY_DV_PIPELINE,

    E_XC_OPTEE_MAX,
} EN_XC_OPTEE_ACTION;

typedef enum
{
    E_XC_STI_AID_NS = 0,
    E_XC_STI_AID_SDC,
    E_XC_STI_AID_S,
    E_XC_STI_AID_CSP,
    E_XC_STI_AID_MAX,
} EN_XC_STI_AID;

typedef enum
{
    E_STI_IP_SOURCE_ADCA = 0,
    E_STI_IP_SOURCE_ADCB,
    E_STI_IP_SOURCE_VD,
    E_STI_IP_SOURCE_HDMI,
    E_STI_IP_SOURCE_HDMI2,
    E_STI_IP_SOURCE_HDMI3,
    E_STI_IP_SOURCE_HDMI4,

    E_STI_IP_SOURCE_MAX,
} EN_STI_IP_SOURCE;

typedef enum
{
    E_XC_COMP_GE = 0,
    E_XC_COMP_GPU,

    E_XC_COMP_MAX,
} EN_XC_COMP_HWIP;

typedef struct __attribute__((__packed__))
{
    MS_U16 u16Version;
    MS_U16 u16Length;
    EN_XC_STI_AID enAID;
    MS_U32 u32VdoPipelineID;
    MS_U32 u32DispPipelineID;
    MS_U32 u32DVPipelineID;
	MS_U32 u32CompPipelineID;
	EN_XC_COMP_HWIP enCompHWIP;
} XC_STI_OPTEE_HANDLER;

typedef struct __attribute__((__packed__))
{
    MS_U16    u16X;
    MS_U16    u16Y;
    MS_U16    u16W;
    MS_U16    u16H;
} XC_CAPTURE_WIN;

#ifdef __cplusplus
}
#endif

#endif // #ifndef __XC_TEE_H__