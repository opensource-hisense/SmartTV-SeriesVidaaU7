#ifndef PQU_PORT_OS_H
#define PQU_PORT_OS_H

#define MODULE_AUTHOR(x)
#define MODULE_DESCRIPTION(x)
#define MODULE_LICENSE(x)
#define EXPORT_SYMBOL(x)

#endif

