/*------------------------------------------------------------------------------
 * MediaTek Inc. (C) 2018. All rights reserved.
 *
 * Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 *----------------------------------------------------------------------------*/

#ifndef _MI_RENDER_H_
#define _MI_RENDER_H_

#ifdef __cplusplus
extern "C" {
#endif

/*
 * NOTICE:
 * This Header is used in <USER> space
 */

//-------------------------------------------------------------------------------------------------
//  Include Files
//-------------------------------------------------------------------------------------------------
#include <string.h>
///LIBDRM
#include "xf86drm.h"
#include "xf86drmMode.h"

//-------------------------------------------------------------------------------------------------
//  Defines
//-------------------------------------------------------------------------------------------------
#define E_MI_RENDER_MULTI_WINDOW_NUM 16
//-------------------------------------------------------------------------------------------------

//  Enum
//-------------------------------------------------------------------------------------------------
typedef enum
{
    E_MI_RENDER_WIN_TYPE_GRAPHIC     = 0,    // Graphic window type
    E_MI_RENDER_WIN_TYPE_VIDEO       = 1,    // Video window type
    E_MI_RENDER_WIN_TYPE_MAX,
} MI_RENDER_WinType_e;

typedef enum
{
    E_MI_RENDER_CALLBACK_EVENT_FLIP_FRMAE_DONE             = MI_BIT(0),// Event for flip frame done(enter driver)
    E_MI_RENDER_CALLBACK_EVENT_INPUT_FORMAT_CHANGE         = MI_BIT(1),// Event for render input format(pq output format) change
    E_MI_RENDER_CALLBACK_EVENT_OUTPUT_PATH_LATENCY_CHANGE  = MI_BIT(2),// Event for render output path latency change
    E_MI_RENDER_CALLBACK_EVENT_WINDOW_PRIORITY_CHANGE      = MI_BIT(3),// Event for window priority change (for all window)
    E_MI_RENDER_CALLBACK_EVENT_WINDOW_DISP_MODE_CHANGE     = MI_BIT(4),// Event for disp mode change (for single window)
    // Event for on flip frame
    E_MI_RENDER_CALLBACK_EVENT_ON_FLIP_FRAME               = MI_BIT(5),
    // Event for panel information change
    E_MI_RENDER_CALLBACK_EVENT_PANEL_INFO_CHANGE           = MI_BIT(6),
    E_MI_RENDER_CALLBACK_EVENT_SECUTIRY_MODE_CHANGE        = MI_BIT(7),
    E_MI_RENDER_CALLBACK_EVENT_MULTI_VIDEOS                = MI_BIT(8),
    E_MI_RENDER_CALLBACK_EVENT_TYPE_NUM
} MI_RENDER_CallbackEvent_e;

typedef enum
{
    E_MI_RENDER_DISP_MODE_BUFFER_SW_MODE,        // Timesharing mode
    E_MI_RENDER_DISP_MODE_BUFFER_HW_MODE,        // Hardwire mode
    E_MI_RENDER_DISP_MODE_TYPE
} MI_RENDER_DispMode_e;

typedef enum
{
    E_MI_RENDER_DEVICE_PROPERTY_CONTROLLER_X,
    E_MI_RENDER_DEVICE_PROPERTY_CONTROLLER_Y,
    E_MI_RENDER_DEVICE_PROPERTY_CONTROLLER_W,
    E_MI_RENDER_DEVICE_PROPERTY_CONTROLLER_H,
    E_MI_RENDER_DEVICE_PROPERTY_SOURCE_X,
    E_MI_RENDER_DEVICE_PROPERTY_SOURCE_Y,
    E_MI_RENDER_DEVICE_PROPERTY_SOURCE_W,
    E_MI_RENDER_DEVICE_PROPERTY_SOURCE_H,
    E_MI_RENDER_DEVICE_PROPERTY_FBID,
    E_MI_RENDER_DEVICE_PROPERTY_H_MIRROR,
    E_MI_RENDER_DEVICE_PROPERTY_V_MIRROR,
    E_MI_RENDER_DEVICE_PROPERTY_H_STRETCH,
    E_MI_RENDER_DEVICE_PROPERTY_V_STRETCH,
    E_MI_RENDER_DEVICE_PROPERTY_ZORDER,
    E_MI_RENDER_DEVICE_PROPERTY_GRAPHIC_PNL_CURLUM,    //HDR panel luminous for GOP
    E_MI_RENDER_DEVICE_PROPERTY_GRAPHIC_BYPASS_MODE,
    E_MI_RENDER_DEVICE_PROPERTY_GFX_PQ_DATA_BLOB_ID,
    E_MI_RENDER_DEVICE_PROPERTY_GFX_ALPHA_MODE,
    E_MI_RENDER_DEVICE_PROPERTY_GFX_AID_TYPE,
    E_MI_RENDER_DEVICE_PROPERTY_NUM
} MI_RENDER_DevicePropertyType_e;

typedef enum
{
    E_MI_RENDER_BUFFER_FORMAT_NONE,
    E_MI_RENDER_BUFFER_FORMAT_ARGB8,    // General format (Non-MEMC event)
    E_MI_RENDER_BUFFER_FORMAT_ABGR8,
    E_MI_RENDER_BUFFER_FORMAT_RGBA8,
    E_MI_RENDER_BUFFER_FORMAT_BGRA8,
    E_MI_RENDER_BUFFER_FORMAT_RGB565,
    E_MI_RENDER_BUFFER_FORMAT_ARGB10,
    E_MI_RENDER_BUFFER_FORMAT_ABGR10,
    E_MI_RENDER_BUFFER_FORMAT_RGBA10,
    E_MI_RENDER_BUFFER_FORMAT_BGRA10,
    E_MI_RENDER_BUFFER_FORMAT_YUV444_10B,
    E_MI_RENDER_BUFFER_FORMAT_YUV444_8B,
    E_MI_RENDER_BUFFER_FORMAT_YUV444_8B_COMPRESS,
    E_MI_RENDER_BUFFER_FORMAT_YUV422_10B,
    E_MI_RENDER_BUFFER_FORMAT_YUV422_8B_1PLN,
    E_MI_RENDER_BUFFER_FORMAT_YUV422_8B_2PLN,
    E_MI_RENDER_BUFFER_FORMAT_YUV422_8B_COMPRESS,
    E_MI_RENDER_BUFFER_FORMAT_YUV422_6B_COMPRESS,
    E_MI_RENDER_BUFFER_FORMAT_YUV420_10B,
    E_MI_RENDER_BUFFER_FORMAT_YUV420_8B,
    E_MI_RENDER_BUFFER_FORMAT_YUV420_8B_COMPRESS,
    E_MI_RENDER_BUFFER_FORMAT_YUV420_6B_COMPRESS,
    E_MI_RENDER_BUFFER_FORMAT_MOTION_RGB444_8B_COMPRESS,    // MEMC Format (MEMC on event)(PC mode)
    E_MI_RENDER_BUFFER_FORMAT_MOTION_RGB444_6B_COMPRESS,    // MEMC Format (MEMC on event)(PC mode)
    E_MI_RENDER_BUFFER_FORMAT_MOTION_YUV444_8B_COMPRESS,    // MEMC Format (MEMC on event)
    E_MI_RENDER_BUFFER_FORMAT_MOTION_YUV444_6B_COMPRESS,    // MEMC Format (MEMC on event)
    E_MI_RENDER_BUFFER_FORMAT_MOTION_YUV422_6B_COMPRESS,    // MEMC Format (MEMC on event)
    E_MI_RENDER_BUFFER_FORMAT_MOTION_YUV420_6B_COMPRESS,    // MEMC Format (MEMC on event)
    E_MI_RENDER_BUFFER_FORMAT_MOTION_YUV422_8B_COMPRESS,
    E_MI_RENDER_BUFFER_FORMAT_MOTION_YUV420_8B_COMPRESS,
    E_MI_RENDER_BUFFER_FORMAT_NUM
} MI_RENDER_BufferFormatType_e;

typedef enum
{
    E_MI_RENDER_COLOR_MODE_SDR = MI_BIT(0),
    E_MI_RENDER_COLOR_MODE_HDR10 = MI_BIT(1),
    E_MI_RENDER_COLOR_MODE_HDR_HLG = MI_BIT(2),
    E_MI_RENDER_COLOR_MODE_NUM = MI_BIT(31)
}MI_RENDER_ColorModeType_e;

typedef enum
{
    E_MI_RENDER_COLOR_RANGE_YCBCR_LIMITED = 0,
    E_MI_RENDER_COLOR_RANGE_YCBCR_FULL,
    E_MI_RENDER_COLOR_RANGE_RGB_LIMITED,
    E_MI_RENDER_COLOR_RANGE_RGB_FULL,
    E_MI_RENDER_COLOR_RANGE_NUM
}MI_RENDER_ColorRangeType_e;

typedef enum
{
    E_MI_RENDER_COLOR_ENCODING_YCBCR_BT601  = 0,
    E_MI_RENDER_COLOR_ENCODING_YCBCR_BT709,
    E_MI_RENDER_COLOR_ENCODING_YCBCR_BT2020,
    E_MI_RENDER_COLOR_ENCODING_RGB_BT601,
    E_MI_RENDER_COLOR_ENCODING_RGB_BT709,
    E_MI_RENDER_COLOR_ENCODING_RGB_BT2020,
    E_MI_RENDER_COLOR_ENCODING_RGB_SRGB,
    E_MI_RENDER_COLOR_ENCODING_RGB_DCIP3_D65,
    E_MI_RENDER_COLOR_ENCODING_NUM
}MI_RENDER_ColorEncodingType_e;

typedef enum
{
    E_MI_RENDER_VRR_SIGNAL_TYPE_NVRR  = 0,
    E_MI_RENDER_VRR_SIGNAL_TYPE_VRR,
    E_MI_RENDER_VRR_SIGNAL_TYPE_CVRR,
    E_MI_RENDER_VRR_SIGNAL_TYPE_NUM,
}MI_RENDER_VrrSignalType_e;

typedef enum
{
    E_MI_RENDER_CAPTURE_POINT_ALL_VIDEO,
    E_MI_RENDER_CAPTURE_POINT_ALL_VIDEO_WITH_OSD,
    E_MI_RENDER_CAPTURE_POINT_DISP_END,
    E_MI_RENDER_CAPTURE_POINT_NUM
} MI_RENDER_CapturePoint_e;

typedef enum
{
    E_MI_RENDER_PANEL_OUTPUT_FORMAT_RGB,
    E_MI_RENDER_PANEL_OUTPUT_FORMAT_YUV444,
    E_MI_RENDER_PANEL_OUTPUT_FORMAT_YUV422,
    E_MI_RENDER_PANEL_OUTPUT_FORMAT_YUV420,
    E_MI_RENDER_PANEL_OUTPUT_FORMAT_ARGB8101010,
    E_MI_RENDER_PANEL_OUTPUT_FORMAT_ARGB8888_W_DITHER,
    E_MI_RENDER_PANEL_OUTPUT_FORMAT_ARGB8888_W_ROUND,
    E_MI_RENDER_PANEL_OUTPUT_FORMAT_ARGB8888_MODE0,
    E_MI_RENDER_PANEL_OUTPUT_FORMAT_ARGB8888_MODE1,
    E_MI_RENDER_PANEL_OUTPUT_FORMAT_NUM
} MI_RENDER_PanelOutputFormat_e;

typedef enum
{
    E_MI_RENDER_DBG_INFO_NONE               = 0,
    //Bit 0~8 are reserved for MI_DBG_LEVEL, Bit 9~15 are reserved.
    E_MI_RENDER_DBG_INFO_SETUP              = MI_BIT(17),
    E_MI_RENDER_DBG_INFO_SETTING            = MI_BIT(18),
    E_MI_RENDER_DBG_INFO_WINDOW             = MI_BIT(19),
    E_MI_RENDER_DBG_INFO_MUTE               = MI_BIT(20),
    E_MI_RENDER_DBG_INFO_FRAME              = MI_BIT(21),
    E_MI_RENDER_DBG_INFO_BUFFER_QUEUE       = MI_BIT(22),
    E_MI_RENDER_DBG_INFO_MUTEX              = MI_BIT(23),
    E_MI_RENDER_DBG_INFO_AVSYNC             = MI_BIT(24),
    E_MI_RENDER_DBG_INFO_DUMP_BUFFER_QUEUE  = MI_BIT(25),
    E_MI_RENDER_DBG_INFO_GPU                = MI_BIT(26),
    E_MI_RENDER_DBG_INFO_FRANME_DOMAIN_PQ   = MI_BIT(27),
    E_MI_RENDER_DBG_INFO_COMPOSER           = MI_BIT(28),
    E_MI_RENDER_DBG_INFO_INTERNAL           = MI_BIT(30),
    E_MI_RENDER_DBG_INFO_DUMPSTACK          = MI_BIT(31),
} MI_RENDER_DbgInfoType_e;

typedef enum
{
    E_MI_RENDER_EVENT_DISPMODE_DEINIT   = MI_BIT(0),
    E_MI_RENDER_EVENT_DISPMODE_CHANGE   = MI_BIT(1),
    E_MI_RENDER_EVENT_MAX,
} MI_RENDER_Event_e;

typedef enum
{
    E_MI_RENDER_POWER_MODE_OFF          = 0,
    E_MI_RENDER_POWER_MODE_DOZE         = 1,
    E_MI_RENDER_POWER_MODE_ON           = 2,
    E_MI_RENDER_POWER_MODE_DOZE_SUSPEND = 3,
    E_MI_RENDER_POWER_MODE_MAX,
} MI_RENDER_PowerMode_e;

typedef enum
{
    E_MI_RENDER_REFRESH_MODE_FIXED = 0,
    E_MI_RENDER_REFRESH_MODE_ADAPTIVE,
    E_MI_RENDER_REFRESH_MODE_NUM
} MI_RENDER_RefreshMode_e;

// IA-Display Mute-less
typedef enum
{
    E_MI_RENDER_MUTE_FACTOR_VRR_NONVRR_OUTPUTFRAMERATE_CHANGE = 0,
    E_MI_RENDER_MUTE_FACTOR_NONVRR_OUTPUTFRAMERATE_CHANGE,
    E_MI_RENDER_MUTE_FACTOR_TIMESHARINGLEGACYMODE_CHANGE,
    E_MI_RENDER_MUTE_FACTOR_FRCPATH_CHANGE,
    E_MI_RENDER_MUTE_FACTOR_PLANEPOSITION_CHANGE,
    E_MI_RENDER_MUTE_FACTOR_PLANESIZE_CHANGE,
    E_MI_RENDER_MUTE_FACTOR_PLANEORDER_SWITCH,
    E_MI_RENDER_MUTE_FACTOR_GPUFALLBACK,
    E_MI_RENDER_MUTE_FACTOR_NONVRR_ASPECTRATIO_CHANGE,
    E_MI_RENDER_MUTE_FACTOR_VRR_ASPECTRATIO_CHANGE,
    E_MI_RENDER_MUTE_FACTOR_APP_TRIGGER_MUTE,
    E_MI_RENDER_MUTE_FACTOR_APP_TRIGGER_FREEZE,
    E_MI_RENDER_MUTE_FACTOR_NUM,
} MI_RENDER_MuteFactor_e;

typedef enum
{
    E_MI_RENDER_MUTE_ACTION_NO_ACTION = 0,
    E_MI_RENDER_MUTE_ACTION_WINDOW_FREEZE,
    E_MI_RENDER_MUTE_ACTION_WINDOW_MUTE,
    E_MI_RENDER_MUTE_ACTION_PANEL_MUTE,
    E_MI_RENDER_MUTE_ACTION_BACKLIGHT_MUTE,
    E_MI_RENDER_MUTE_ACTION_TX_MUTE,
    E_MI_RENDER_MUTE_ACTION_MAX,
} MI_RENDER_MuteAction_e;

typedef enum
{
    E_MI_RENDER_MIRROR_MODE_NORMAL  = 0,
    E_MI_RENDER_MIRROR_MODE_HORIZONTAL,
    E_MI_RENDER_MIRROR_MODE_VERTICAL,
    E_MI_RENDER_MIRROR_MODE_HVBOTH,
    E_MI_RENDER_MIRROR_MODE_MAX,
}MI_RENDER_MirrorMode_e;

typedef struct  MI_Render_RTInfo_s
{
    MI_U32 u32Rank;    //smaller rank, higher priority.
} MI_Render_RTInfo_t;

typedef enum
{
    E_MI_RENDER_MOD_PATTERN          = 0,
    E_MI_RENDER_PATTERN_MAX,
} MI_Render_TestPattern_e;

typedef enum
{
    // Backlight Mute
    E_MI_RENDER_PANELMUTE_BACKLIGHT_MUTE   = MI_BIT(0),
    E_MI_RENDER_PANELMUTE_MAX,
} MI_Render_PanelMute_Type_e;

typedef enum // For MI_DISP_FrameInfo_t
{
    E_MI_RENDER_FRAME_COLOR_FORMAT_YUV420 = 0, /// YUV420.
    E_MI_RENDER_FRAME_COLOR_FORMAT_YUV422,     /// YUV422. (YUYV)
    E_MI_RENDER_FRAME_COLOR_FORMAT_ARGB8888,     /// ARGB8888
    E_MI_RENDER_FRAME_COLOR_FORMAT_MAX,
}MI_Render_FrameColorFmt_e;

typedef enum
{
    E_MI_RENDER_PQ_BACKLIGHT_VALUE,
    E_MI_RENDER_PQ_MAX,
} MI_Render_PQ_Type_e;

/* m_pq.h */
#ifndef E_COMPONENT5_TAG_START
#define E_COMPONENT5_TAG_START 0x00050000
enum EN_COMPONENT5_TAG { // range 0x00050000 ~ 0x0005FFFF
	PQ_DISP_SVP_META_TAG = E_COMPONENT5_TAG_START,
	META_PQ_OUTPUT_FRAME_INFO_TAG,
	MTK_PQ_SH_FRM_INFO_TAG,
	META_PQ_DISPLAY_FLOW_INFO_TAG,
	META_PQ_DISPLAY_IDR_CTRL_META_TAG,
	META_PQ_STREAM_INTERNAL_INFO_TAG,
	PQ_DISP_STREAM_META_TAG,
	META_PQ_INPUT_QUEUE_EXT_INFO_TAG,
	META_PQ_OUTPUT_QUEUE_EXT_INFO_TAG,
	META_PQ_FRAMESYNC_INFO_TAG,
	META_PQ_OUTPUT_RENDER_INFO_TAG,
	META_PQ_DISPLAY_WM_INFO_TAG,
	META_PQ_BBD_INFO_TAG,
	META_PQ_PQPARAM_TAG,
	E_COMPONENT5_TAG_MAX,
};
#endif

//-------------------------------------------------------------------------------------------------
//  Structures
//-------------------------------------------------------------------------------------------------
typedef struct MI_RENDER_InitParams_s
{
    MI_BOOL bTestMode;
    MI_U8 u8Reserverd;
} MI_RENDER_InitParams_t;

typedef struct MI_RENDER_OpenParams_s
{
    /// Window type
    MI_RENDER_WinType_e eWinType;
    /// Handler name
    MI_U8* pszName;
    /// Id for compose Pq mode to do window pq.
    MI_U32 u32PqId;
    MI_U8  u8LayerId;
    MI_BOOL bAdvaceGameModeEnable;
} MI_RENDER_OpenParams_t;

typedef struct MI_RENDER_OpenControllerParams_s
{
    MI_U8 u8Reserved;
} MI_RENDER_OpenControllerParams_t;

typedef struct MI_RENDER_WindowRatio_s
{
    MI_U32 u32Up;    // Up ratio of window (0~1000)
    MI_U32 u32Down;    // Down ratio of window (0~1000)
    MI_U32 u32Left;    // Left ratio of window (0~1000)
    MI_U32 u32Right;    // Right ratio of window (0~1000)
} MI_RENDER_WindowRatio_t;

typedef struct MI_RENDER_WindowRect_s
{
    MI_U32 u32X;    // Rectangle region for x
    MI_U32 u32Y;    // Rectangle region for y
    MI_U32 u32Width;    // Rectangle region for width
    MI_U32 u32Height;    // Rectangle region for height
    MI_U32 u32WidthBase;    // Rectangle Width Base
    MI_U32 u32HeightBase;     //Rectangle Height Base
} MI_RENDER_WindowRect_t;

typedef struct MI_RENDER_WindowParams_s
{
    MI_RENDER_WindowRect_t stDispWinRect;
    MI_RENDER_WindowRect_t stCropWinRect;
} MI_RENDER_WindowParams_t;

typedef struct MI_RENDER_Zorder_s
{
    MI_U32 u32Zorder;    // Input zorder value of window, u32Zorder is reprentative hierarchy, the Larger the number, the higher the level
} MI_RENDER_Zorder_t;

typedef struct MI_RENDER_PanelInfo_s
{
    MI_U32 u32PanelWidth;   // Panel width
    MI_U32 u32PanelHeight;  // Panel height
    MI_U32 u32FrameRate;    // Panel output timing
    MI_BOOL bPanelHMirror;  // Panel H Mirror
    MI_BOOL bPanelVMirror;  // Panel V Mirror
} MI_RENDER_PanelInfo_t;

typedef struct MI_RENDER_RgbColor_s
{
    MI_U64 u64Red;      // Color range 0~255 for red.
    MI_U64 u64Green;    // Color range 0~255 for green.
    MI_U64 u64Blue;     // Color range 0~255 for blue.
} MI_RENDER_RgbColor_t;

typedef struct MI_RENDER_OutputLatencyParams_s
{
    MI_U64 u64DevicesLatancyTime;  // Drm + Memc(if on) total latency time
} MI_RENDER_OutputLatencyParams_t;

typedef struct MI_RENDER_OutputLatencyInfo_s
{
    MI_U64 u64DevicesLatancyTime;  // Drm + Memc(if on) total latency time
    MI_U32 u32VSyncFreq;
} MI_RENDER_OutputLatencyInfo_t;

typedef struct MI_RENDER_PresetOutputLatencyInput_s
{
    MI_U32 u32InputFrameRate;  //fps x 1000
} MI_RENDER_PresetOutputLatencyInput_t;

typedef struct MI_RENDER_PanelGammaParams_s
{
    MI_U8 u8Reserved;
} MI_RENDER_PanelGammaParams_t;

typedef MI_RESULT (* MI_RENDER_EventCallback)(MI_HANDLE hWindowId, MI_U32 u32Event, void *pEventParams, void *pUserParams);

typedef struct MI_RENDER_CallbackInputParams_s
{
    MI_U64 u64CallbackId;    // For multi-callback, use 0 for first register or single callback.
    MI_RENDER_EventCallback pfEventCallback;    // Callback function pointer.
    MI_U32 u32EventFlags;    // Event flags defined by MI_RENDER_CallbackEvent_e
    void *pUserParams;    // User parameter
} MI_RENDER_CallbackInputParams_t;

typedef struct MI_RENDER_CallbackOutputParams_s
{
    MI_U64 u64CallbackId;    // The returned ID for update or unregister callback.
} MI_RENDER_CallbackOutputParams_t;

typedef struct MI_RENDER_Caps_s
{
    MI_U32 u32ModeCount;
} MI_RENDER_Caps_t;

typedef struct MI_RENDER_FrameBufferInfo_s
{
    MI_S32 s32ShareFd;    //  Share fd of frame
    MI_U32 u32FrameBufferWidth;    //after pq scaling
    MI_U32 u32FrameBufferHeight;
    MI_RENDER_BufferFormatType_e eBufferFormat;    //pq user scalling and buffer size
    MI_S32 s32ShareFdSize;
    MI_RENDER_WindowRect_t stSourceCropedContentRect;    //source crop rect
    MI_RENDER_WindowRect_t stUserCropedContentRect;    //pq user crop rect
}MI_RENDER_FrameBufferInfo_t;

typedef struct MI_RENDER_FlipInfo_s
{
    MI_S32 s32ShareFd;
    MI_S32 s32MetadataFd;    // Metadata fd of frame
    MI_U32 u32FrameIndex;    // Frame id for identify frame.
    MI_U64 u64RenderTime;  // User gives calling libdrm time(v sync point)
    void *pMetadataAddr;    // User gives pointer which is mapping from metadata fd to address.
    MI_RENDER_FrameBufferInfo_t stFrameBufferInfo;    // Frame buffer info
    MI_U32 u32FrameRate;    // Input frame rate
    MI_U64 u64UserTimestamp;    // User timestamp for profiling each round from flip to flip done cb
    MI_U32 u32PqInFrameIndex; //pqin frame index
    MI_BOOL bReportFrameStamp;
} MI_RENDER_FlipInfo_t;

typedef struct MI_RENDER_ReleaseFrameCallbackParams_s
{
    MI_BOOL bDropFrame;    // Is this frame dropped or not
    MI_U32 u32FrameIndex;    // The index of frame
    MI_U64 u64Pts;    // The pts of frame
    MI_U64 u64ShowScreenTime;    // The show time of frame on the sceen
} MI_RENDER_ReleaseFrameCallbackParams_t;

typedef struct MI_RENDER_FlipFrameCallbackParams_s
{
    MI_U32 u32FrameIndex;       // The index of frame
    MI_U64 u64Pts;              // The pts of frame
    MI_U64 u64ShowSystemTime;   // The show system time of frame on the screen
    MI_U64 u64UserTimestamp;    // User defined timestamp
    MI_BOOL bSwFrcEvent;        // The frame repeat is swfrc or not
    MI_U32 u32AccRepeatCount;   // The frame's accumulated repeat count
    //The actual latency time
    MI_U64 u64LatencyTotalTime;
    //The difference between the actual latency time and the estimated latency time
    MI_S64 s64LatencyDeltaTime; //unit is ns
    MI_U32 u32PqInFrameIndex; ////pqin frame index
    MI_BOOL bReportFrameStamp;
} MI_RENDER_FlipFrameCallbackParams_t;

typedef struct MI_RENDER_MultiVideoFrame_s
{
    MI_U32 u32UnicId;
    MI_U32 u32X;
    MI_U32 u32Y;
    MI_U32 u32SourceWidth;
    MI_U32 u32SourceHeight;
    MI_U32 u32DestinyWidth;
    MI_U32 u32DestinyHeight;
    MI_U32 u32Format;
} MI_RENDER_MultiVideoFrame_t;

typedef struct MI_RENDER_MultiVideoFrameInfo_s
{
    MI_U32 u32MultiVideoNum;
    MI_RENDER_MultiVideoFrame_t stMultiVideoFrame[E_MI_RENDER_MULTI_WINDOW_NUM];
}MI_RENDER_MultiVideoFrameInfo_t;

typedef struct MI_RENDER_VsyncInfo_s
{
    MI_U64 u64VsyncTime;     // Last vsync system time
    MI_U64 u64VsyncDuration;    // Vsync duration
} MI_RENDER_VsyncInfo_t;

typedef struct MI_RENDER_InputFormat_s
{
    MI_U8 u8Reserved;
} MI_RENDER_InputFormat_t;

typedef struct MI_RENDER_WindowProrityList_s
{
    void *pWindowPriorityInfo;    // Window priortiy list
    MI_U32 u32ListSize;    // List size
} MI_RENDER_WindowPriorityList_t;


typedef struct MI_RENDER_OutputFormatChangeInfo_s
{
    MI_RENDER_BufferFormatType_e eBufferFormatType;    // Buffer format type
    MI_BOOL                      bGPU64Alignment;      // buffer size 64 byte alignment
} MI_RENDER_OutputFormatChangeInfo_t;

typedef struct MI_RENDER_WindowDispModeInfo_s
{
    MI_RENDER_DispMode_e eDispModeType;
    MI_BOOL bLowLatency;                   //TRUE: Low latency enable.
    MI_BOOL bVrr;                          //TRUE: VRR enable.
} MI_RENDER_WindowDispModeInfo_t;

typedef struct MI_RENDER_PanelTimingInfo_s
{
    MI_HANDLE  hLockHandleId;    // Frame Lock Window ID
} MI_RENDER_PanelTimingInfo_t;

typedef struct MI_RENDER_RwDiffInfo_s
{
    MI_U32 u32MemcRwDiff;
    MI_U16 u16MdgwRwDiff;
} MI_RENDER_RwDiffInfo_t;

typedef struct MI_RENDER_GetCaptureInfoParams_s
{
    MI_RENDER_CapturePoint_e eCapturePoint;
} MI_RENDER_GetCaptureInfoParams_t;

typedef struct MI_RENDER_CaptureInfo_s
{
    MI_U16 u16Width;
    MI_U16 u16Height;
    MI_RENDER_PanelOutputFormat_e ePanelFormat;
    MI_U32 u32Fps;
    MI_U8 u8HwEngine;
    MI_BOOL bIsSecurityMode;
} MI_RENDER_CaptureInfo_t;

typedef struct MI_RENDER_BEPowerModeParams_s
{
    MI_U32 u32Mode;
} MI_RENDER_BEPowerModeParams_t;

typedef struct MI_RENDER_SecurityInfo_s
{
    MI_BOOL bIsSecurityMode;
} MI_RENDER_SecurityInfo_t;

typedef struct MI_RENDER_GammaSetting_s
{
    MI_U16 *pu16GammaR;
    MI_U16 *pu16GammaG;
    MI_U16 *pu16GammaB;
    MI_U16 u16GammaRMax;
    MI_U16 u16GammaGMax;
    MI_U16 u16GammaBMax;
    MI_U16 u16CurveSize;
} MI_RENDER_GammaSetting_t;

typedef struct MI_RENDER_GammaGainOffset_s
{
    MI_BOOL bPreGainOffset;
    MI_U32 u32RGain;
    MI_U32 u32GGain;
    MI_U32 u32BGain;
    MI_U32 u32ROffset;
    MI_U32 u32GOffset;
    MI_U32 u32BOffset;
} MI_RENDER_GammaGainOffset_t;

typedef struct MI_RENDER_BlueLightSetting_s
{
    MI_S32 s32RGain;
    MI_S32 s32GGain;
    MI_S32 s32BGain;
} MI_RENDER_BlueLightSetting_t;

// IA-Display Mute-less
typedef struct MI_RENDER_MuteTable_s
{
    MI_RENDER_MuteAction_e eMuteAction[E_MI_RENDER_MUTE_FACTOR_NUM];
} MI_RENDER_MuteTable_t;

typedef struct  MI_Render_TestPattern_s
{
    MI_Render_TestPattern_e eRenderTestPattern;
    MI_BOOL bEnable;
    MI_U32 u32MODRed;
    MI_U32 u32MODGreen;
    MI_U32 u32MODBlue;
} MI_Render_TestPattern_t;

typedef struct MI_RENDER_VideoStatistic_s
{
    // Total Statistics
    MI_U32 u32BufEmptyCnt;
    // Per frame information
    MI_U32 u32FrameIndex;
    MI_U64 u64Flip2AtomicTime;
    MI_U64 u64Flip2AtomicTimeMin;
    MI_U64 u64Flip2AtomicTimeMax;
    // Update per sec
    MI_U32 u32CalFlipInCnt;
    // unit:ns
    MI_U64 u64CalFlipInInterval;
    // unit:ns
    MI_U64 u64LastFlipInTime;
    MI_U32 u32FlipInCnt;
} MI_RENDER_VideoStatistic_t;

typedef struct MI_Render_SetPanelMute_s
{
    //MI_BIT(0): Backlight Mute
    MI_U32 u32PanelMuteFlag;
    MI_BOOL bEnable;
} MI_Render_SetPanelMute_t;

typedef struct MI_Render_SetPQ_Backlight_Value_s
{
    MI_BOOL bEnable;
    MI_U32 u32MaxValue;
    MI_U32 u32MinValue;
    MI_U32 u32Value;
} MI_Render_SetPQ_Backlight_Value_t;

typedef struct MI_RENDER_MetaPqWindow_s
{
    MI_U16 x;
    MI_U16 y;
    MI_U16 width;
    MI_U16 height;
    MI_U16 w_align;
    MI_U16 h_align;
} MI_RENDER_MetaPqWindow_t;

#define MI_RENDER_STRUCT_META_PQ_OUTPUT_FRAME_INFO_VERSION (1)
typedef struct MI_RENDER_MetaPqOutputFrameInfo_s
{
    MI_U32 width;
    MI_U32 height;
    MI_RENDER_MetaPqWindow_t capture;
    MI_RENDER_MetaPqWindow_t crop;
    MI_RENDER_MetaPqWindow_t display;
    MI_BOOL nonlinear;
    MI_U64 fd_offset[3];
    MI_S32 pq_frame_id;
} MI_RENDER_MetaPqOutputFrameInfo_t;

#define MI_RENDER_STRUCT_META_PQ_OUTPUT_RENDER_INFO_VERSION (1)
typedef struct MI_RENDER_MetaPqOutputRenderInfo_s
{
    MI_RENDER_MetaPqWindow_t capture;
    MI_RENDER_MetaPqWindow_t crop;
    MI_RENDER_MetaPqWindow_t displayRange;
    MI_RENDER_MetaPqWindow_t displayArea;
    MI_RENDER_MetaPqWindow_t displayWin;
    MI_U8 u8DotByDotType;
    MI_U8 u8SignalStable;
    MI_U32 u32RefreshRate;
    MI_U8 u8Aid;
    MI_U32 u32Pipelineid;
    MI_U8 u8MuteAction;
    MI_U8 u8PqMuteAction;
    MI_U64 u64Pts;
    MI_U32 u32OriginalInputFps;
} MI_RENDER_MetaPqOutputRenderInfo_t;

typedef struct MI_RENDER_BufferCountInfo_s
{
    MI_U32 u32RenderBufferCnt;
} MI_RENDER_BufferCountInfo_t;

/******/


//-------------------------------------------------------------------------------------------------
//  Global Functions
//-------------------------------------------------------------------------------------------------

//------------------------------------------------------------------------------
/// @brief Open and get Drm device resources and initial global data.
/// @param[in] pstInitParams: Render initialize paramaters.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_HAS_INITED: Render module has been initialized.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_RENDER_Init(const MI_RENDER_InitParams_t *pstInitParams);

//------------------------------------------------------------------------------
/// @brief Close and release Drm device resources and reset global data.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_RENDER_DeInit(void);

//------------------------------------------------------------------------------
/// @brief Open a handler and pair with a plane for a specified stream.
/// @param[in] pstOpenParams : Open parameters.
/// @param[out] phWindowId : Output a resource handler id.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_RENDER_Open(const MI_RENDER_OpenParams_t *pstOpenParams, MI_HANDLE *phWindowId);

//------------------------------------------------------------------------------
/// @brief Close a handler and free pair with a plane for a specified stream.
/// @param[in] hWindowId : hWindowId.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_RENDER_Close(MI_HANDLE hWindowId);

//------------------------------------------------------------------------------
/// @brief Open controller for global setting.
/// @param[in] pstParams : Open controller parameters.
/// @param[out] phDispController : A controller id of MI_Render for global API.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_RENDER_OpenController(const MI_RENDER_OpenControllerParams_t *pstOpenParams, MI_HANDLE *phDispController);

//------------------------------------------------------------------------------
/// @brief Close controller for global setting.
/// @param[in] hDispController  : A controller id of MI_Render for global setting API.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_RENDER_CloseController(MI_HANDLE hDispController);

//------------------------------------------------------------------------------
/// @brief Open controller for global setting.
/// @param[in] pstParams : Open controller parameters.
/// @param[out] phDispController : A controller id of MI_Render for global API.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_RENDER_OpenContorller(const MI_RENDER_OpenControllerParams_t *pstOpenParams, MI_HANDLE *phDispController);

//------------------------------------------------------------------------------
/// @brief Close controller for global setting.
/// @param[in] hDispController  : A controller id of MI_Render for global setting API.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_RENDER_CloseContorller(MI_HANDLE hDispController);

//------------------------------------------------------------------------------
/// @brief Render frame for a specified stream.
/// @param[in] hWindowId : A resource handler id.
/// @param[in] stFlipInfo : Flip frame info.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_RENDER_Flip (MI_HANDLE hWindowId, MI_RENDER_FlipInfo_t stFlipInfo);

//------------------------------------------------------------------------------
/// @brief Set mute for a specified stream.
/// @param[in] hWindowId : A resource handler id.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_RENDER_MuteWindow(MI_HANDLE hWindowId);

//------------------------------------------------------------------------------
/// @brief Set un-mute for a specified stream.
/// @param[in] hWindowId : A resource handler id.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_RENDER_UnMuteWindow(MI_HANDLE hWindowId);

//------------------------------------------------------------------------------
/// @brief Register callback.
/// @param[in] hHandler : A resource handler id.
/// @param[in] pstInputParams : Input parameters of register callback.
/// @param[out] pstOutputParams : Output parameters of register callback.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_RENDER_RegisterCallback(MI_HANDLE hHandler, const MI_RENDER_CallbackInputParams_t *pstInputParams, MI_RENDER_CallbackOutputParams_t *pstOutputParams);

//------------------------------------------------------------------------------
/// @brief Unregister callback.
/// @param[in] hHandler : A resource handler id.
/// @param[in] pstInputParams : Input parameters of unregister callback.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_RENDER_UnRegisterCallback(MI_HANDLE hHandler, const MI_RENDER_CallbackInputParams_t *pstInputParams);

//------------------------------------------------------------------------------
/// @brief Register Controller callback.
/// @param[in] hHandler : A resource hController for all stream(global).
/// @param[in] pstInputParams : Input parameters of register callback.
/// @param[out] pstOutputParams : Output parameters of register callback.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_RENDER_RegisterControllerCallback(MI_HANDLE hHandler, const MI_RENDER_CallbackInputParams_t *pstInputParams, MI_RENDER_CallbackOutputParams_t *pstOutputParams);

//------------------------------------------------------------------------------
/// @brief Unregister Controller callback.
/// @param[in] hHandler : A resource hController for all stream(global).
/// @param[in] pstInputParams : Input parameters of unregister callback.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_RENDER_UnRegisterControllerCallback(MI_HANDLE hHandler, const MI_RENDER_CallbackInputParams_t *pstInputParams);

//------------------------------------------------------------------------------
/// @brief Set freeze for a specified stream.
/// @param[in] hHandler :  A resource handler id.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_RENDER_FreezeWindow(MI_HANDLE hWindowId);

//------------------------------------------------------------------------------
/// @brief Set unfreeze for a specified stream.
/// @param[in] hHandler :  A resource handler id.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_RENDER_UnFreezeWindow(MI_HANDLE hWindowId);

//------------------------------------------------------------------------------
/// @brief Get capability of drm devices.
/// @param[out] pstCaps :  Devices capability.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_RENDER_GetCaps(MI_RENDER_Caps_t *pstCaps);

//------------------------------------------------------------------------------
/// @brief Set window crop by ratio info.
/// @param[in] hHandler :  A resource handler id.
/// @param[in] pstCropRatio  : Crop ratio info.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_RENDER_SetCropWindowByRatio(MI_HANDLE hWindowId, MI_RENDER_WindowRatio_t *pstWindowRatio);

//------------------------------------------------------------------------------
/// @brief Set window crop rectangle by window rectangle info.
/// @param[in] hHandler :  A resource handler id.
/// @param[in] pstWindowRect  : Crop rectangel info.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_RENDER_SetCropWindowRect(MI_HANDLE hWindowId, MI_RENDER_WindowRect_t *pstWindowRect);

//------------------------------------------------------------------------------
/// @brief Set window disp rectangle by window rectangle info.
/// @param[in] hHandler :  A resource handler id.
/// @param[in] pstWindowRect  : Disp rectangel info.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_RENDER_SetDispWindowRect(MI_HANDLE hWindowId, MI_RENDER_WindowRect_t *pstWindowRect);

//------------------------------------------------------------------------------
/// @brief Set zorder of window.
/// @param[in] hHandler :  A resource handler id.
/// @param[in] pstWindowRect  : Disp rectangel info.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_RENDER_SetWindowZorder(MI_HANDLE hWindowId, MI_S64 s64Zorder);

//------------------------------------------------------------------------------
/// @brief Set mute window color.
/// @param[in] hController: The controller of MI_Render.
/// @param[in] pstRgbColor  : Set mute window color.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_RENDER_SetWindowMuteColor(MI_HANDLE hController, MI_RENDER_RgbColor_t *pstRgbColor);

//------------------------------------------------------------------------------
/// @brief Get output path latency (for av sync).
/// @param[in] hHandler :  A resource handler id.
/// @param[out] pstOutputLatencyParams  : Render output path latency.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_RENDER_GetOutputPathLatency(MI_HANDLE hWindowId, MI_RENDER_OutputLatencyParams_t *pstOutputLatencyParams);

//------------------------------------------------------------------------------
/// @brief Get Preset output path latency (for av sync).
/// @param[in] hController: A resource handler id.
/// @param[in] pstPresetOutputLatencyInput: A pointer for the sturcuture of Render input parameters.
/// @param[out] pstOutputLatencyInfo: A Pointer for the sturcture of Render output frame latency.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: No value matching for the input parameter in pstPresetOutputLatencyInput.
//------------------------------------------------------------------------------
MI_RESULT MI_RENDER_GetPresetOutputLatency(MI_HANDLE hController, \
    MI_RENDER_PresetOutputLatencyInput_t *pstPresetOutputLatencyInput, \
    MI_RENDER_OutputLatencyInfo_t *pstOutputLatencyInfo);

//------------------------------------------------------------------------------
/// @brief Get panel info.
/// @param[in] hHandler :  A resource handler id.
/// @param[out] pstPanelInfo  : panel info.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_RENDER_GetPanelInfo(MI_HANDLE hController, MI_RENDER_PanelInfo_t *pstPanelInfo);

//------------------------------------------------------------------------------
/// @brief Set panel info.
/// @param[in] hHandler :  A resource handler id.
/// @param[in] pstPanelGamma  : panel gamma.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_RENDER_SetPanelGamma(MI_HANDLE hController, MI_RENDER_PanelGammaParams_t *pstPanelGamma);

//------------------------------------------------------------------------------
/// @brief Switch display mode for legacy mode (HW mode) or time sharing mode.
/// @param[in] hHandler :  A resource handler id.
/// @param[in] eDispMode  : Display mode type
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_RENDER_SetDispMode(MI_HANDLE hWindowId, MI_RENDER_DispMode_e eDispMode);

//------------------------------------------------------------------------------
/// @brief Set debug level.
/// @param[in] u32DebugLevel  : Debug level.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_RENDER_SetDebugLevel(MI_U32 u32DebugLevel);

//------------------------------------------------------------------------------
/// @brief Get vsync info(last vsync time stamp and vsync duration)
/// @param[in] hController: A controller id of MI_Render for global API.
/// @param[out] pstVsyncInfo: A pointer of vsync info.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_INVALID_HANDLE: Controller is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_RENDER_GetVsyncInfo(MI_HANDLE hController, MI_RENDER_VsyncInfo_t *pstVsyncInfo);

//------------------------------------------------------------------------------
/// @brief flush window
/// @param[in] hWindowId: A resource handler id.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_INVALID_HANDLE: Render window handle is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_RENDER_FlushWindow(MI_HANDLE hWindowId);

//------------------------------------------------------------------------------
/// @brief Add property of DRM device.
/// @param[in] hWindowId: A resource handler id.
/// @param[in] ePropertyType: The DRM device property.
/// @param[in] u64Value: The property value.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_INVALID_HANDLE: Render window handle is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_RENDER_AddDeviceProperty(MI_HANDLE hWindowId, MI_RENDER_DevicePropertyType_e ePropertyType, MI_U64 u64Value);

//------------------------------------------------------------------------------
/// @brief Get the DRM device FBID.
/// @param[in] hController: The controller of MI_Render.
/// @param[out] ps32FdId: The DRM device FBID.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_INVALID_HANDLE: Render window handle is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_RENDER_GetDeviceId(MI_HANDLE hController, MI_S32 *ps32FdId);

//------------------------------------------------------------------------------
/// @brief Ready to apply all property to DRM device.
/// @param[in] hController: The controller of MI_Render.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_INVALID_HANDLE: Render window handle is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_RENDER_ApplyDeviceProperty(MI_HANDLE hController);

//------------------------------------------------------------------------------
/// @brief Get input format which render perfers.
/// @param[in] hWindowId: A resource handler id.
/// @param[out] peBufferFormat: Buffer format.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_INVALID_HANDLE: Render window handle is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_RENDER_GetPreferableFormatType(MI_HANDLE hWindowId, MI_RENDER_BufferFormatType_e *peBufferFormatType);

//------------------------------------------------------------------------------
/// @brief Get input format which render perfers.
/// @param[in] hWindowId: A resource handler id.
/// @param[out] pstBufferFormatInfo: Buffer format info.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_INVALID_HANDLE: Render window handle is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_RENDER_GetPreferableFormatInfo(MI_HANDLE hWindowId,
                                          MI_RENDER_OutputFormatChangeInfo_t *pstBufferFormatInfo);

//------------------------------------------------------------------------------
/// @brief Set Low latency enable/disable for a window.
/// @param[in] hHandler: A resource handler id.
/// @param[in] bLowLatency: Low latency enable/disable.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_INVALID_HANDLE: Render window handle is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_RENDER_SetLowLatency(MI_HANDLE hWindowId, MI_BOOL bLowLatency);

//------------------------------------------------------------------------------
/// @brief Set VRR signal type for a window.
/// @param[in] hHandler: A resource handler id.
/// @param[in] eVrrSignalType: VRR signal type for a window.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_INVALID_HANDLE: Render window handle is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_RENDER_SetVrrSignal(MI_HANDLE hWindowId, MI_RENDER_VrrSignalType_e eVrrSignalType);

//------------------------------------------------------------------------------
/// @brief Set Force VRR enable/disable for a window.
/// @param[in] hHandler: A resource handler id.
/// @param[in] bForceVrr: Force VRR enable/disable.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_INVALID_HANDLE: Render window handle is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_RENDER_SetForceVrr(MI_HANDLE hWindowId, MI_BOOL bForceVrr);

//------------------------------------------------------------------------------
/// @brief Get Disp mode info by window.
/// @param[in] hWindowId: A resource handler id.
/// @param[out] pstDispModeInfo: Disp mode info.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_INVALID_HANDLE: Render window handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: invalid parameter
//------------------------------------------------------------------------------
MI_RESULT MI_RENDER_GetDispModeInfo(MI_HANDLE hWindowId, MI_RENDER_WindowDispModeInfo_t *pstDispModeInfo);

//------------------------------------------------------------------------------
/// @brief Set Window PQ for a window.
/// @param[in] hWindowId: A window handler.
/// @param[in] pszWindowPqSetting: Window pq setting.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_INVALID_HANDLE: Render window handle is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_RENDER_SetWindowPq(MI_HANDLE hWindowId, MI_U8* pszWindowPqSetting);

//------------------------------------------------------------------------------
/// @brief Set Global PQ setting.
/// @param[in] hController: A Controller handler.
/// @param[in] pszGlobalPqSetting: Global pq setting.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_INVALID_HANDLE: Render window handle is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_RENDER_SetGlobalPq(MI_HANDLE hController, MI_U8* pszGlobalPqSetting);

//------------------------------------------------------------------------------
/// @brief Set crop window & display window
/// @param[in] hWindowId: A resource handler id.
/// @param[in] pstWindowRect: crop& display window parameters.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_INVALID_HANDLE: Render window handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: invalid parameter
//------------------------------------------------------------------------------
MI_RESULT MI_RENDER_SetWindow(MI_HANDLE hWindowId, MI_RENDER_WindowParams_t *pstWindowRect);

/// @brief User did panel timing.
/// @param[in] hController: The controller of MI_Render.
/// @param[in] pstPanelTimingInfo: Panel timing info
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_INVALID_HANDLE: Render window handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Invalid parameter.
//------------------------------------------------------------------------------
MI_RESULT MI_RENDER_SetPanelTiming(MI_HANDLE hController,
    MI_RENDER_PanelTimingInfo_t *pstPanelTimingInfo);

//------------------------------------------------------------------------------
/// @brief Prefer vrr mode.
/// @param[in] hController: The controller of MI_Render.
/// @param[in] bEnable: Prefer vrr mode enabled/disabled.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_INVALID_HANDLE: Controller is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_RENDER_PreferVrrMode(MI_HANDLE hController, MI_BOOL bEnable);

//------------------------------------------------------------------------------
/// @brief Set force time sharing mode.
/// @param[in] hController: The controller of MI_Render.
/// @param[in] bEnable: Force Time Sharing Mode enabled/disabled.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_INVALID_HANDLE: Controller is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_RENDER_ForceTimeSharingMode(MI_HANDLE hController, MI_BOOL bEnable);

//------------------------------------------------------------------------------
/// @brief Get Render Read/write Diff Info
/// @param[in] hWindowId: A resource handler id.
/// @param[out] pstRwDiffInfo: Render Read/write Diff Info.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_INVALID_HANDLE: Render window handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameter is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_RENDER_GetRwDiffInfo(MI_HANDLE hWindowId, MI_RENDER_RwDiffInfo_t *pstRwDiffInfo);

//------------------------------------------------------------------------------
/// @brief Check if the window is muted
/// @param[in] hWindowId: A resource handler id.
/// @param[out] pu32MuteEnabled: Mute is enabled or not.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_INVALID_HANDLE: Render window handle is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_RENDER_GetWindowMuteStatus(MI_HANDLE hWindowId, MI_U32 *pu32MuteEnabled);

//------------------------------------------------------------------------------
/// @brief Set debug info.
/// @param[in] eDebugInfo  : Debug info.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_RENDER_SetDebugInfo(MI_RENDER_DbgInfoType_e eDebugInfo);

//------------------------------------------------------------------------------
/// @brief Enable or disable ATrace.
/// @param[in] bEnable  : Enable ATrace or not.
/// @return MI_OK: Process success.
//------------------------------------------------------------------------------
MI_RESULT MI_RENDER_SetDebugATrace(MI_BOOL bEnable);

//------------------------------------------------------------------------------
/// @brief Set event.
/// @param[in] eEvent  : Event ID.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_RENDER_SetEvent(MI_RENDER_Event_e eEvent);

//------------------------------------------------------------------------------
/// @brief Get capture info.
/// @param[in] hController: The controller of MI_Render.
/// @param[in] pstGetParams: Capture option.
/// @param[out] pstCaptureInfo: Capture information.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_RENDER_GetCaptureInfo(
    MI_HANDLE hController,
    MI_RENDER_GetCaptureInfoParams_t *pstGetParams,
    MI_RENDER_CaptureInfo_t *pstCaptureInfo);

//------------------------------------------------------------------------------
/// @brief Get supported output frame rate.
/// @param[in] hController: The controller of MI_Render.
/// @param[out] pu32TimingTable: Refer to a list contains supported output frame rate
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_HAS_INITED: Render module has been initialized.
/// @return MI_ERR_INVALID_HANDLE: Controller is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_RENDER_GetSupportRefreshRate(MI_HANDLE hController, MI_U32 *pu32TimingTable);

//------------------------------------------------------------------------------
/// @brief Set power mode on/off
/// @param[in] hController: The controller of MI_Render.
/// @param[in] eMode: Power mode on or off .
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_RENDER_SetPowerMode(MI_HANDLE hController, MI_RENDER_PowerMode_e eMode);

//------------------------------------------------------------------------------
/// @brief Set BE power mode on/off
/// @param[in] hController: The controller of MI_Render.
/// @param[in] pstPowerModeParams: Parameter of setting BE power mode.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_RENDER_SetBEPowerMode(
    MI_HANDLE hController,
    MI_RENDER_BEPowerModeParams_t *pstPowerModeParams);

/// @brief Set panel output refresh mode and framerate.
/// @param[in] hController: The controller of MI_Render.
/// @param[in] eMode: Indicate which mode to be used.
/// @param[in] u32FrameRate: Indicate which framerate to be used.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_HAS_INITED: Render module has been initialized.
/// @return MI_ERR_INVALID_HANDLE: Controller is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_RENDER_SetRefreshMode(
    MI_HANDLE hController, MI_RENDER_RefreshMode_e eMode, MI_U32 u32FrameRate);

//------------------------------------------------------------------------------
/// @brief Set Prefer Minimal Post Processing on/off
/// @param[in] hController: The controller of MI_Render.
/// @param[in] bEnable: Parameter of setting Prefer Minimal Post Processing.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_RENDER_SetPreferMinimalPostProcessing(
    MI_HANDLE hController, MI_BOOL bEnable);

//------------------------------------------------------------------------------
/// @brief enable pq gamma
/// @param[in] hController: The controller of MI_Render.
/// @param[in] bEnable: Parameter of enable pq gamma.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_RENDER_EnablePqGamma(MI_HANDLE hController, MI_BOOL bEnable);

//------------------------------------------------------------------------------
/// @brief Set pq gamma curve
/// @param[in] hController: The controller of MI_Render.
/// @param[in] pstGammaSetting: Parameter of setting pq gamma curve.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_RENDER_SetPqGamma(MI_HANDLE hController, MI_RENDER_GammaSetting_t *pstGammaSetting);

//------------------------------------------------------------------------------
/// @brief Set pq gamma gain offset
/// @param[in] hController: The controller of MI_Render.
/// @param[in] pstGammaGainOffset: Parameter of set pq gamma gain offset.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_RENDER_SetPqGammaGainOffset(MI_HANDLE hController,
                                                   MI_RENDER_GammaGainOffset_t *pstGammaGainOffset);

//------------------------------------------------------------------------------
/// @brief Set debug cmd
/// @param[in] pu8Cmd: Command string
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_RENDER_SetDebugCli(const MI_U8 *pu8Cmd);

//------------------------------------------------------------------------------
/// @brief Get suppoer of pixel shift.
/// @param[in] hController: The controller of MI_Render.
/// @param[out] pbIsSupported  : Pixel Shift is supported or not.
/// @return MI_OK: Process success.
//------------------------------------------------------------------------------
MI_RESULT MI_RENDER_GetPixelShiftSupport(MI_HANDLE hController, MI_BOOL *pbIsSupported);

/// @brief Get pq gamma gain offset
/// @param[in] hController: The controller of MI_Render.
/// @param[in] bPreGainOffset: The parameter to confirm pre of post gain offset
/// @param[out] pstGammaGainOffset: Parameter of get pq gamma gain offset.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_RENDER_GetPqGammaGainOffset(MI_HANDLE hController,
                           MI_BOOL bPreGainOffset, MI_RENDER_GammaGainOffset_t *pstGammaGainOffset);

//------------------------------------------------------------------------------
/// @brief Set low blue light setting.
/// @param[in] hController: The controller of MI_Render.
/// @param[in] pstBlueLightSetting: Parameter of blue light setting.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_RENDER_SetLowBlueLight(
    MI_HANDLE hController, MI_RENDER_BlueLightSetting_t *pstBlueLightSetting);

//------------------------------------------------------------------------------
/// @brief Enable or disable Pixel Shift.
/// @param[in] hController: The controller of MI_Render.
/// @param[in] bEnable  : Enable Pixel Shift or not.
/// @return MI_OK: Process success.
//------------------------------------------------------------------------------
MI_RESULT MI_RENDER_SetPixelShift(MI_HANDLE hController, MI_BOOL bEnable);

/// @brief Set mirror mode type
/// @param[in] hWindowId: The window handle of MI_Render.
/// @param[in] eMirrorModeType: mirror mode type.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_RENDER_SetMirrorMode(MI_HANDLE hController, MI_RENDER_MirrorMode_e eMirrorModeType);

/// @brief Set Allm signal
/// @param[in] hWindowId: The window handle of MI_Render.
/// @param[in] bAllmSignal:  Allm signal type for a window.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_RENDER_SetAllmSignal(MI_HANDLE hWindowId, MI_BOOL bAllmSignal);

//------------------------------------------------------------------------------
/// @brief Set test pattern
/// @param[in] hController: The controller of MI_Render.
/// @param[in] stTestPattern: test pattern type .
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_RENDER_GenerateStageTestPattern(MI_HANDLE hController,
                                                 MI_Render_TestPattern_t stTestPattern);

//------------------------------------------------------------------------------
/// @brief Set Real Time Window Mode with Real Time Info
/// @param[in] hController: The window handle of MI_Render.
/// @param[in] pstRTInfo: real time info.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_RENDER_SetRTMode(MI_HANDLE hWindowId, MI_Render_RTInfo_t *pstRTInfo);

//------------------------------------------------------------------------------
/// @brief Get Video Statistics.
/// @param[in] u32WinIndex: Window array index.
/// @param[in] pstVdoStats  :Video Statistics.
/// @return MI_OK: Process success.
//------------------------------------------------------------------------------
MI_RESULT MI_RENDER_GetVideoStatistic(MI_U32 u32WinIndex,
    MI_RENDER_VideoStatistic_t *pstVideoStatistic);

//------------------------------------------------------------------------------
/// @brief Reset Video Statistics.
/// @param[in] none.
/// @return MI_OK: Process success.
//------------------------------------------------------------------------------
MI_RESULT MI_RENDER_ResetVideoStatistic(void);

//------------------------------------------------------------------------------
/// @brief Set Panel Mute
/// @param[in] hController: The controller of MI_Render.
/// @param[in] stSetPanelMute: Set Panel Mute type .
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_RENDER_SetPanelMute(MI_HANDLE hController,
                            MI_Render_SetPanelMute_t *pstSetPanelMute);

//------------------------------------------------------------------------------
/// @brief Set PQ
/// @param[in] hController: The controller of MI_Render.
/// @param[in] ePQType: Set PQ type .
/// @param[in] pstPQInfo: Set pstPQInfo .
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_Render_SetGlobalPQValue(MI_HANDLE hController,
                            MI_Render_PQ_Type_e ePQType, void *pstPQInfo);

//------------------------------------------------------------------------------
/// @brief Query Buffer Count
/// @param[in] hWindowId: The window handle of MI_Render.
/// @param[in] eDispModeType: Disp Mode Type (HW/SW) .
/// @param[out] pstBufferCountInfo: Structure Of Buffer Count Info.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_Render_QueryBufferCount(MI_HANDLE hWindowId,
               MI_RENDER_DispMode_e eDispModeType, MI_RENDER_BufferCountInfo_t *pstBufferCountInfo);


#ifdef __cplusplus
}
#endif

#endif///_MI_DMX_H_

