////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2020-2024 MediaTek Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MediaTek Inc. and be kept in strict confidence
// ("MediaTek Confidential Information") by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MediaTek Confidential
// Information is unlawful and strictly prohibited. MediaTek hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////


///////////////////////////////////////////////////////////////////////////////////////////////////
///
/// @file   pqmap_utility.h
/// @brief  Algorithem Driver Interface
/// @author Mediatek Inc.
///
///////////////////////////////////////////////////////////////////////////////////////////////////

#ifndef _PQMAP_UTILITY_H_
#define _PQMAP_UTILITY_H_
#ifdef __cplusplus
extern "C"{
#endif

//----------------------------------------------------------------------------
//  Driver Capability
//----------------------------------------------------------------------------

//----------------------------------------------------------------------------
//  Macro and Define
//----------------------------------------------------------------------------

//----------------------------------------------------------------------------
//  Type and Structure
//----------------------------------------------------------------------------
struct pqmap_mem_info {
    uint64_t phy_addr;
    uint8_t *virt_addr;
    size_t buf_max;
    size_t ctrie_offset;
    size_t ctrie_used;
    size_t pim_offset;
    size_t pim_used;
    size_t rm_offset;
    size_t rm_used;
};

typedef enum extmem_tag
{
    EXTMEM_TAG_INVALID=-1,
    EXTMEM_TAG_UNSPECIFIED=0,
    EXTMEM_TAG_GENERAL,
    EXTMEM_TAG_CUSTOM_BEGIN=16, /* enum to separate customized tag. */
#include "node_tag_cus.inc"
    EXTMEM_TAG_DATA_TYPE_BEGIN,
    EXTMEM_TAG_DATA,
#include "data_tag_cus.inc"
    EXTMEM_TAG_UNUSED_BEGIN
} extmem_tag;

/*
 *Structure to store (function idx, value) pair
 */
typedef struct func_pair
{
    uint32_t    fn_idx;
    uint32_t    fn_para;
} func_pair;


/*
 *Struct to store register function calls
 */
typedef struct reg_func
{
    union{
        uint32_t    fn_num;
        func_pair   padding;
    } padded_data;

    func_pair fn_tbl[];
} __attribute__((aligned(8))) reg_func;

/*
 *Version
 */
typedef struct __attribute__((__packed__)) pqmap_version
{
    uint16_t	u16MajorNumber;
    uint16_t	u16MinorNumber;
    uint32_t	u32Revision;
} pqmap_version;

typedef char (*pqmap_callback)(int tag, const char *data, const size_t datalen, void* pCtx);
typedef char (*pqmap_alg_callback)(int tag, const char *data, const size_t datalen, const char *label, const size_t labellen);

//----------------------------------------------------------------------------
//  Function and Variable
//----------------------------------------------------------------------------
/* cJSON */
void pqmap_json_get_size(size_t *size);
void *pqmap_json_parse(const char *value);
void pqmap_json_delete(void *item);
/* cJSON */

/* pim field */
char pqmap_pim_init(void **pim_ptr, char* buf, const size_t buf_len);
size_t pqmap_pim_export(void *pim_ptr, char* buf);
size_t pqmap_pim_get_export_size(void *pim_ptr);
char pqmap_pim_insert_regmap(void *pim_ptr, const char* regname, const size_t func_pos);
char pqmap_pim_insert_regmap_json(void *pim_ptr, void *json_node);
char pqmap_pim_insert_vregmap(void *pim_ptr, const char* vregname, const int descriptor);
char pqmap_pim_insert_vregmap_json(void *pim_ptr, void *json_node);
char pqmap_pim_insert_file(void *pim_ptr, const char* filename, const char* data, const size_t datalen);
char pqmap_pim_insert_handler(void *pim_ptr, const char* fn_label, pqmap_callback fn);
char pqmap_pim_insert_alg_handler(void *pim_ptr, pqmap_alg_callback fn);
char pqmap_pim_insert(void *pim_ptr, void *json_node);
void pqmap_pim_load_setting_by_name(void *pim_ptr, const char* label, pqmap_callback fn, void* pCtx);
void pqmap_pim_load_setting(void *pim_ptr, uint16_t nid, char bCheckCommon, pqmap_callback fn, void* pCtx);
void pqmap_pim_load_common_reg_setting(void *pim_ptr, pqmap_callback fn, void* pCtx);
char pqmap_pim_destroy(void **pim_ptr);
char pqmap_pim_finish(void *pim_ptr);
char pqmap_pim_get_hwreg_version(void *pim_ptr, pqmap_version* ver_in);
char pqmap_pim_get_swreg_version(void *pim_ptr, pqmap_version* ver_in);
/* pim field */

/* rule map field */
char pqmap_rm_init(void **rm_ptr, char* buf, const size_t buf_len);
size_t pqmap_rm_get_export_size(void *rm_ptr);
size_t pqmap_rm_export(void *rm_ptr, char* buf);
char pqmap_rm_insert_source_json(void *rm_ptr, void *json_node);
char pqmap_rm_insert(void *rm_ptr, void *json_node, void *pim_ptr);
char pqmap_rm_set(void *rm_ptr, const char* source_filter, const uint64_t source_value);
char pqmap_rm_trigger(void *rm_ptr, const char* rule_name);
char pqmap_rm_clear(void *rm_ptr);
size_t pqmap_rm_get_result(void *rm_ptr, uint16_t **result_list);
char pqmap_rm_destroy(void **rm_ptr);
char pqmap_rm_finish(void *rm_ptr);
/* rule map field */

#ifdef __cplusplus
}
#endif
#endif // _PQMAP_UTILITY_H_
