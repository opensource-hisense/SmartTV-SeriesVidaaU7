#ifndef PQU_PORT_H
#define PQU_PORT_H

#include "pqu_port_os.h"
#include "msos_types.h"

#endif //PQU_PORT_H
