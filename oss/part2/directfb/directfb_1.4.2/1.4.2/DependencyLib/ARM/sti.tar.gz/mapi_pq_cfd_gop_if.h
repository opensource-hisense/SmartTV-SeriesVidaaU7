////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2020-2024 MediaTek Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MediaTek Inc. and be kept in strict confidence
// ("MediaTek Confidential Information") by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MediaTek Confidential
// Information is unlawful and strictly prohibited. MediaTek hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////


////////////////////////////////////////////////////////////////////////////////
///
/// @file   mhal_pqreg_gop.h
/// @brief  platform or kdrv_xc related function macros used by CFD
/// @author Mediatek Inc.
///
////////////////////////////////////////////////////////////////////////////////
#ifndef __MAPI_PQ_GOP_IF_H__
#define __MAPI_PQ_GOP_IF_H__


#ifdef __cplusplus
extern "C"{
#endif

#include "pqu_port.h"

#define CFD_DEFAULT_UI_PARAM_HUE           (50)
#define CFD_DEFAULT_UI_PARAM_SATURATION    (128)
#define CFD_DEFAULT_UI_PARAM_CONTRAST      (1024)
#define CFD_DEFAULT_UI_PARAM_BRIGHTNESS    (1024)
#define CFD_DEFAULT_UI_PARAM_RGBGAIN       (1024)

typedef enum _EN_PQ_CFD_TMO_MODE
{
    E_CFD_TMO_MODE_ATUO = 0x0,
    E_CFD_TMO_MODE_12P_MODE = 0x1,
    E_CFD_TMO_MODE_256P_MODE = 0x2
}EN_PQ_CFD_TMO_MODE;

typedef enum _EN_PQ_CFD_MANUAL_MODE
{
    E_CFD_MANUAL_OFF = 0x0,
    E_CFD_MANUAL_ON = 0x1
}EN_PQ_CFD_MANUAL_MODE;

typedef enum _EN_PQ_CFD_XVYCC_DEGAMMA_MODE
{
    EN_PQ_CFD_XVYCC_DEGAMMA_MODE_EXTEND_RANGE = 0x0,
    EN_PQ_CFD_XVYCC_DEGAMMA_MODE_STANDAR_RANGE = 0x1
}EN_PQ_CFD_XVYCC_DEGAMMA_MODE;

typedef enum _EN_PQ_CFD_HDR_MODE
{
    E_CFD_SDR_MODE = 0x0,
    E_CFD_HLG_MODE = 0x1,
    E_CFD_HDR10_MODE = 0x2,
    E_CFD_HDR10PLUS_MODE = 0x3
}EN_PQ_CFD_HDR_MODE;

typedef enum _EN_PQ_CFD_DATAFORMAT
{
    E_CFD_YUV = 0x0,
    E_CFD_RGB = 0x1
}EN_PQ_CFD_DATAFORMAT;

typedef enum _EN_PQ_CFD_RANGE
{
    E_CFD_LIMIT = 0x0,
    E_CFD_FULL = 0x1
}EN_PQ_CFD_RANGE;

typedef enum _EN_PQ_CFD_SET_COLORSPACE
{
    E_CFD_COLORSPACE_BT601 = 0x0,
    E_CFD_COLORSPACE_BT709 = 0x1,
    E_CFD_COLORSPACE_BT2020 = 0x2,
    E_CFD_COLORSPACE_DCI_P3 = 0x3,
    E_CFD_COLORSPACE_ADOBE_RGB = 0x4
}EN_PQ_CFD_SET_COLORSPACE;

typedef enum _EN_PQ_CFD_SET_TC
{
    E_CFD_TC_SMPTE_170M = 0x0,
    E_CFD_TC_SRGB = 0x1,
    E_CFD_TC_GAMMA2_2 = 0x2,
    E_CFD_TC_GAMMA2_6 = 0x3,
    E_CFD_TC_ST2084 = 0x4,
    E_CFD_TC_LINEAR = 0x5
}EN_PQ_CFD_SET_TC;

typedef enum EN_PQ_CFD_GOP_RETURN_FMT
{
    E_CFD_GOP_RETURN_GOP = 0x0,
    E_CFD_GOP_RETURN_GPU = 0x1
}EN_PQ_CFD_GOP_RETURN_FMT;

typedef enum EN_PQ_CFD_COLOR_INVERSE
{
    E_CFD_COLOR_INVERSE_DISABLE = 0x0,
    E_CFD_COLOR_INVERSE_ENABLE = 0x1
}EN_PQ_CFD_COLOR_INVERSE;

typedef enum EN_PQ_CFD_COLOR_CORRECTION
{
    E_CFD_COLOR_CORRECTION_DISABLE = 0x0,
    E_CFD_COLOR_CORRECTION_ENABLE = 0x1
}EN_PQ_CFD_COLOR_CORRECTION;

typedef enum EN_PQ_CFD_SET_CORRECTION_MODE
{
    E_CFD_CORRECTION_MODE_0 = 0x0,
    E_CFD_CORRECTION_MODE_1 = 0x1,
    E_CFD_CORRECTION_MODE_2 = 0x2
}EN_PQ_CFD_SET_CORRECTION_MODE;

enum EN_PQ_CFD_SET_GAMUT_MODE
{
    E_CFD_AUTO_TARGET = 0x0,
    E_CFD_AUTO_SOURCE_TARGET= 0x1,
    E_CFD_GAMUT_MANUAL_MODE = 0x2,
};

typedef struct ST_PQ_CFD_GOP_UI_PARAMS
{
    u32 u32Version;
    u16 u16Length;
    u16 u16Hue;
    u16 u16Saturation;
    u16 u16Contrast;
    u16 u16Brightness[3];
    bool bIsColorInversionEnable;
    bool bIsColorCorrectionEnable;
    u8 u8CorrectionMode;
    u16 u16RGBGain[3];
}ST_PQ_CFD_GOP_UI_PARAMS;

typedef struct _ST_PQ_CFD_TMO_PARAMS
{
    u32 u32Version;
    u16 u16Length;
    u8 u8HDRMode;
    u8 u8TMOMode;
    u16 u16PanelMax;
    u16 u16Samplesize;
    u32 *pu32SrcNits_Address;
    u32 *pu32TgtNits_Address;
}ST_PQ_CFD_TMO_PARAMS;

typedef struct _ST_PQ_CFD_SET_EOTF_PARAMS
{
    u32 u32Version;
    u16 u16Length;
    u16 u16LUT_Size;
    u32 *pu32EotfLut_Address;
} ST_PQ_CFD_SET_EOTF_PARAMS;

typedef struct _ST_PQ_CFD_SET_OETF_PARAMS
{
    u32 u32Version;
    u16 u16Length;
    u16 u16LUT_Size;
    u32 *pu32OetfLut_Address;
} ST_PQ_CFD_SET_OETF_PARAMS;

typedef struct ST_PQ_CFD_GOP_FMT_PARAMS
{
    u32 u32Version;
    u16 u16Length;
    u8 u8HDRMode;
    u8 u8InputDataFormat;
    u8 u8InputRange;
    u8 u8InputColorSpace;
    u8 u8TrasferTC;
    u8 u8OutputDataFormat;
    u8 u8OutputRange;
    u8 u8OutputColorSpace;
}ST_PQ_CFD_GOP_FMT_PARAMS;

typedef struct ST_PQ_CFD_COLORMETRY_PARAMS
{
    u32 u32Version;
    u16 u16Length;
    u16 u16DisplayPrimaries_x[3];
    u16 u16DisplayPrimaries_y[3];
    u16 u16White_point_x;
    u16 u16White_point_y;
} ST_PQ_CFD_COLORMETRY_PARAMS;

typedef struct ST_PQ_CFD_GOP_BRIGHTNESS_GAIN
{
    u32 u32Version;
    u16 u16Length;
    u16 u16User_gain_sdr;
    u16 u16User_gain_pq;
    u16 u16User_gain_hlg;
}ST_PQ_CFD_GOP_BRIGHTNESS_GAIN;

typedef struct ST_PQ_CFD_SET_XVYCC_PARAMS
{
    u32 u32Version;
    u16 u16Length;
    u8 u83x3Mode;
    bool b3x3Enable;
    ST_PQ_CFD_COLORMETRY_PARAMS *pst_source_colormetry;
    ST_PQ_CFD_COLORMETRY_PARAMS *pst_target_colormetry;
    u16 *pu163x3_addr;
    bool bXvycc_curve_Manual_Mode;
    ST_PQ_CFD_SET_EOTF_PARAMS *pst_eotf_params;
    bool bEotf_ExtendMode;
    ST_PQ_CFD_SET_OETF_PARAMS *pst_oetf_params;
    bool bOetf_ExtendMode;
}ST_PQ_CFD_SET_XVYCC_PARAMS;

typedef struct ST_PQ_CFD_GOP_CLIPPING_PARMS
{
    u32 u32Version;
    u16 u16Length;
    bool bRGBClippingManualMode;
    bool bRGBClippingEnable;
    u16 *pu16RGB_min_limit_addr;
    u16 *pu16RGB_max_limit_addr;
}ST_PQ_CFD_GOP_CLIPPING_PARMS;

typedef struct ST_PQ_CFD_GOP_OFFSET_PARAMS
{
    u32 u32Version;
    u16 u16Length;
    bool bRGBOffsetManualMode;
    bool bRGBOffsetEnable;
    u16 *pu16RGBOffset_addr;
}ST_PQ_CFD_GOP_OFFSET_PARAMS;

struct ST_PQ_CFD_GOP_PARAMS
{
    u32 u32Version;
    u16 u16Length;
    u8 u8Path;
    bool bIsGPUFmt;
    ST_PQ_CFD_GOP_UI_PARAMS *pst_ui_params;
    ST_PQ_CFD_TMO_PARAMS *pst_tmo_params;
    ST_PQ_CFD_GOP_BRIGHTNESS_GAIN *pst_brightness_gain_params;
    ST_PQ_CFD_GOP_FMT_PARAMS *pst_color_fmt_params;
    ST_PQ_CFD_SET_XVYCC_PARAMS *pst_xvycc_info_params;
    ST_PQ_CFD_GOP_OFFSET_PARAMS *pst_rgb_offset_params;
    ST_PQ_CFD_GOP_CLIPPING_PARMS *pst_rgb_clipping_params;
};

typedef struct
{
    u32 u32Version;
    u16 u16Length;
    //STU_Register_Table stRegTable;
    //STU_Autodownload_Table stAdlTable;
    //ST_CFD_STATUS stStatus;
}ST_CFD_CSC_HW_OUTPUT;

typedef struct
{
    u32 u32Version;
    u16 u16Length;
    //STU_Register_Table stRegTable;
    //STU_Autodownload_Table stAdlTable;
    //ST_CFD_STATUS stStatus;
}ST_CFD_DEGAMMA_HW_OUTPUT;

typedef struct
{
    u32 u32Version;
    u16 u16Length;
    //STU_Register_Table stRegTable;
    //STU_Autodownload_Table stAdlTable;
    //ST_CFD_STATUS stStatus;
}ST_CFD_GAMUT_MAPPING_HW_OUTPUT;

typedef struct
{
    u32 u32Version;
    u16 u16Length;
    //STU_Register_Table stRegTable;
    //STU_Autodownload_Table stAdlTable;
    //ST_CFD_STATUS stStatus;
}ST_CFD_GAMMA_HW_OUTPUT;

typedef struct ST_PQ_CFD_GOP_SETTNG_TABLE
{
    u32 u32Version;
    u16 u16Length;
    u64 *pu64Ml_addr;
    u32 u32Ml_used_size;
    u64 *pu64Adl_addr;
    u32 u32Adl_used_sized;
}ST_PQ_CFD_GOP_SETTNG_TABLE;

struct ST_PQ_CFD_GOP_INFO
{
    u32 u32Version;
    u16 u16Length;
    ST_PQ_CFD_GOP_SETTNG_TABLE *pst_gop_setting_table;
};

typedef struct ST_PQ_CFD_GOP_ALG_CONTROL_POINT
{
    u32 u32Version;
    u16 u16Length;
    u8 u8DataFormat;
    u8 u8IsFullRange;
    u8 u8HDRMode;
    u8 u8ColorPriamries;
    u8 u8MatrixCoefficients;
} ST_PQ_CFD_GOP_ALG_CONTROL_POINT;


enum EN_PQAPI_RESULT_CODES  MApi_PQ_CFD_GOP_Process(
    void *pCtx,
    const struct ST_PQ_CFD_GOP_PARAMS *gop_input,
    struct ST_PQ_CFD_GOP_INFO *gop_output);

#ifdef __cplusplus
}
#endif

#endif /* __MAPI_PQ_GOP_IF_H__ */
