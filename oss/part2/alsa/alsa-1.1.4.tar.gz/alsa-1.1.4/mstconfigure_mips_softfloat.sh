#!/bin/bash

TOOL_CHAIN_PREFIX="mips-linux-gnu-"
CFLAGS_SETTINGS="-fPIC -msoft-float -O2"
LDFLAGS_SETTINGS="-fPIC -msoft-float"

BUILD="i386-linux"
HOST="mips-linux-gnu"

function build()
{
test -z ${MST_PREFIX} && echo "  The MST_PREFIX must be set to proceed!!" && exit 0
echo "MST_PREFIX=$MST_PREFIX"

export CC="${TOOL_CHAIN_PREFIX}gcc -EL"
echo "CC=${CC}"

./configure --prefix=${MST_PREFIX} \
            --build=${BUILD} \
            --host=${HOST} \
            CFLAGS="${CFLAGS_SETTINGS}" \
            LDFLAGS="${LDFLAGS_SETTINGS}" \
            --enable-shared \
            --enable-static
}

LIBRARY_NAME="alsa-lib"
LIBRARY_VERSION="1.0.23"
PACKAGE_NAME="${LIBRARY_NAME}"
PACKAGE_PATH=../../

function package()
{
    if [ "$1" != "" ]; then
        PACKAGE_PATH=$1
    fi
    echo "PACKAGE_PATH=${PACKAGE_PATH}"

    RETURN_PATH=`pwd`

    cd ${PACKAGE_PATH}
    mkdir -p ${PACKAGE_NAME}/bin
    mkdir -p ${PACKAGE_NAME}/include
    mkdir -p ${PACKAGE_NAME}/include/alsa
    mkdir -p ${PACKAGE_NAME}/include/sys
    mkdir -p ${PACKAGE_NAME}/lib
    mkdir -p ${PACKAGE_NAME}/lib/alsa-lib
    mkdir -p ${PACKAGE_NAME}/lib/alsa-lib/smixer
    mkdir -p ${PACKAGE_NAME}/lib/pkgconfig
    mkdir -p ${PACKAGE_NAME}/share/aclocal
    mkdir -p ${PACKAGE_NAME}/share/alsa
    cp -vrfP ${RETURN_PATH}/aserver/.libs/aserver ${PACKAGE_NAME}/bin/
    cp -vrfP ${RETURN_PATH}/include/*.h ${PACKAGE_NAME}/include/alsa/
    cp -vrfP ${RETURN_PATH}/include/sound ${PACKAGE_NAME}/include/alsa/
    cp -vrfP ${RETURN_PATH}/asoundlib.h ${PACKAGE_NAME}/include/sys/
    cp -vrfP ${RETURN_PATH}/src/libasound.la ${PACKAGE_NAME}/lib/
    cp -vrfP ${RETURN_PATH}/src/.libs/libasound.a ${PACKAGE_NAME}/lib/
    cp -vrfP ${RETURN_PATH}/src/.libs/libasound.so.2.0.0 ${PACKAGE_NAME}/lib/
    cp -vrfP ${RETURN_PATH}/modules/mixer/simple/*.la ${PACKAGE_NAME}/lib/alsa-lib/smixer/
    cp -vrfP ${RETURN_PATH}/modules/mixer/simple/.libs/*.a ${PACKAGE_NAME}/lib/alsa-lib/smixer/
    cp -vrfP ${RETURN_PATH}/modules/mixer/simple/.libs/*.so ${PACKAGE_NAME}/lib/alsa-lib/smixer/
    cp -vrfP ${RETURN_PATH}/utils/alsa.pc ${PACKAGE_NAME}/lib/pkgconfig/
    cp -vrfP ${RETURN_PATH}/utils/alsa.m4 ${PACKAGE_NAME}/share/aclocal/
    cp -vrfP ${RETURN_PATH}/src/conf/alsa.conf ${PACKAGE_NAME}/share/alsa/
    cp -vrfP ${RETURN_PATH}/src/conf/smixer.conf ${PACKAGE_NAME}/share/alsa/
    cp -vrfP ${RETURN_PATH}/src/conf/sndo-mixer.alisp ${PACKAGE_NAME}/share/alsa/
    cp -vrfP ${RETURN_PATH}/src/conf/cards ${PACKAGE_NAME}/share/alsa/
    cp -vrfP ${RETURN_PATH}/src/conf/pcm ${PACKAGE_NAME}/share/alsa/
    find ./ -name Makefile* | xargs rm -f
    cd ${PACKAGE_PATH}/${PACKAGE_NAME}/include/alsa/sound
    rm -f asequencer.h asound.h asoundef.h
    cd ${PACKAGE_PATH}/${PACKAGE_NAME}/include/alsa
    rm -f alsa-symbols.h aserver.h asoundlib-head.h asoundlib-tail.h config.h list.h local.h search.h sys.h
    cd ${PACKAGE_PATH}/${PACKAGE_NAME}/lib
    ln -sf libasound.so.2.0.0 libasound.so
    ln -sf libasound.so.2.0.0 libasound.so.2

    cd ${PACKAGE_PATH}
    tar -zvcf ${PACKAGE_NAME}-${LIBRARY_VERSION}.tar.gz ${PACKAGE_NAME}
    rm -rf ${PACKAGE_NAME}

    cd ${RETURN_PATH}
}

case $1 in
"package")
    echo "################  pacakage ${LIBRARY_NAME}"
    package $2
    ;;
*)
    echo "################  building ${LIBRARY_NAME}"
    build
    ;;
esac
