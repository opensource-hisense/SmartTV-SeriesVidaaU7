#!/bin/bash

TOOL_CHAIN_PREFIX="arm-linux-gnueabihf-"
CFLAGS_SETTINGS="-DMSOS_PROCESS_SAFT_MUTEX -gdwarf-2 -fPIC -mlittle-endian -march=armv7-a -mfpu=vfpv3 -mfloat-abi=softfp -Wall -Wpointer-arith -Wstrict-prototypes -Winline -Wundef -fno-strict-aliasing -fno-optimize-sibling-calls -fno-exceptions -ffunction-sections -fdata-sections -c -O2"
LDFLAGS_SETTINGS="-fPIC -shared"

BUILD="i386-linux"
HOST="arm-linux-gnueabihf"
#HOST="${MCHEF_ENV_TOOLCHAIN}"

function build()
{
test -z ${MST_PREFIX} && echo "  The MST_PREFIX must be set to proceed!!" && exit 0
echo "MST_PREFIX=$MST_PREFIX"

CC="${TOOL_CHAIN_PREFIX}gcc"
echo "CC=${CC}"
echo "HOST=${HOST}"

./configure --prefix=${MST_PREFIX} \
            --build=${BUILD} \
            --host=${HOST} \
            --disable-python \
#            CFLAGS="${CFLAGS_SETTINGS}" \
            LDFLAGS="${LDFLAGS_SETTINGS}"
}

LIBRARY_NAME="alsa-lib"
LIBRARY_VERSION="1.1.4"
PACKAGE_NAME="${LIBRARY_NAME}"
PACKAGE_PATH=../../

function package()
{
    if [ "$1" != "" ]; then
        PACKAGE_PATH=$1
    fi
    echo "PACKAGE_PATH=${PACKAGE_PATH}"

    RETURN_PATH=`pwd`

    echo "RETURN_PATH=${RETURN_PATH}"
    
    cd ${PACKAGE_PATH}
    mkdir -p ${PACKAGE_NAME}/include
    mkdir -p ${PACKAGE_NAME}/include/alsa
    mkdir -p ${PACKAGE_NAME}/lib
    cp -vrfP ${RETURN_PATH}/include/*.h ${PACKAGE_NAME}/include/alsa/
    cp -vrfP ${RETURN_PATH}/include/sound ${PACKAGE_NAME}/include/alsa/
    cp -vrfP ${RETURN_PATH}/src/.libs/libasound.so.2.0.0 ${PACKAGE_NAME}/lib/
    find ./ -name Makefile* | xargs rm -f
    cd ${PACKAGE_PATH}/${PACKAGE_NAME}/include/alsa/sound
    rm -f asequencer.h asound.h asoundef.h
    cd ${PACKAGE_PATH}/${PACKAGE_NAME}/include/alsa
    rm -f alsa-symbols.h aserver.h asoundlib-head.h asoundlib-tail.h config.h list.h local.h search.h sys.h
    cd ${PACKAGE_PATH}/${PACKAGE_NAME}/lib
    ln -sf libasound.so.2.0.0 libasound.so
    ln -sf libasound.so.2.0.0 libasound.so.2

    cd ${RETURN_PATH}
}

case $1 in
"package")
    echo "################  pacakage ${LIBRARY_NAME}"
    package $2
    ;;
*)
    echo "################  building ${LIBRARY_NAME}"
    build
    ;;
esac