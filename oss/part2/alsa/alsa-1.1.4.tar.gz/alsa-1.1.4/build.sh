#!/bin/bash

function help()
{
	echo "Incorrect parameter for build.sh!!!"
	echo "Please try \"./build.sh [CPU] [LIBRARY_TYPE]\""
	echo "----------------------------------------------"
	echo "[CPU]          : \"arm\" or \"mips\""
	echo "[LIBRARY_TYPE] : \"softfloat\" or \"hardfloat\""
	echo "----------------------------------------------"
}

if [ "$#" != "2" ]; then
	help
	exit 0
elif [ "$1" != "arm" ] && [ "$1" != "mips" ]; then
	help
	exit 0
elif [ "$2" != "softfloat" ] && [ "$2" != "hardfloat" ]; then
	help
	exit 0
fi

export MST_PREFIX=/usr

MSTCONFIGURE_FILE=mstconfigure_$1_$2.sh
OUTPUT_DIR=output_$1_$2

./${MSTCONFIGURE_FILE}
if [ "$?" != "0" ]; then
	echo "Stage1: fails to generate ALSA Makefile!!!"
	exit 0
fi

make clean
make
if [ "$?" != "0" ]; then
        echo "Stage2: fails to compile ALSA source code!!!"
        exit 0
fi

mkdir -p ${PWD}/${OUTPUT_DIR}
./${MSTCONFIGURE_FILE} package ${PWD}/${OUTPUT_DIR}
if [ "$?" != "0" ]; then
        echo "Stage3: fails to generate ALSA output files!!!"
        exit 0
fi

