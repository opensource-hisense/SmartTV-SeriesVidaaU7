#! /bin/sh

echo "enter libnl-3.3.0 build"

export PATH="/proj/mtk13910/git_views_3/apollo/tools/mtk_toolchain/gcc-arm-linux-gnu-5.5.0-ubuntu/x86_64/bin:$PATH"
export CROSS_COMPILE=/proj/mtk13910/git_views_3/apollo/tools/mtk_toolchain/gcc-arm-linux-gnu-5.5.0-ubuntu/x86_64/bin/arm-linux-gnueabi-
make clean
make distclean

./configure CC=${CROSS_COMPILE}gcc CFLAGS="-fstack-protector -D_FORTIFY_SOURCE=2 -Wl,-z,noexecstack -Wl,-z,noexecheap -Wl,-z,relro -Wl,-z,now -s" \
--host=arm-linux-gnueabi \
--target=arm-linux-gnueabi \
--disable-cli \
--enable-shared \
--disable-static \
--prefix=$(pwd)/../usr

make 
make install
